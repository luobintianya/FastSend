import{n as e}from"./Dd_uD5pT.js";import{b as t,en as n,et as r,mt as i,rn as a,v as o,wt as s,xt as c,y as l}from"./CkeaFxZg.js";import{r as u,t as d}from"./DwuRs3jv.js";import{t as f}from"./CRHlWn3X.js";var p=u.extend({name:`avatar`,style:`
    .p-avatar {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: dt('avatar.width');
        height: dt('avatar.height');
        font-size: dt('avatar.font.size');
        background: dt('avatar.background');
        color: dt('avatar.color');
        border-radius: dt('avatar.border.radius');
    }

    .p-avatar-image {
        background: transparent;
    }

    .p-avatar-circle {
        border-radius: 50%;
    }

    .p-avatar-circle img {
        border-radius: 50%;
    }

    .p-avatar-icon {
        font-size: dt('avatar.icon.size');
        width: dt('avatar.icon.size');
        height: dt('avatar.icon.size');
    }

    .p-avatar img {
        width: 100%;
        height: 100%;
    }

    .p-avatar-lg {
        width: dt('avatar.lg.width');
        height: dt('avatar.lg.width');
        font-size: dt('avatar.lg.font.size');
    }

    .p-avatar-lg .p-avatar-icon {
        font-size: dt('avatar.lg.icon.size');
        width: dt('avatar.lg.icon.size');
        height: dt('avatar.lg.icon.size');
    }

    .p-avatar-xl {
        width: dt('avatar.xl.width');
        height: dt('avatar.xl.width');
        font-size: dt('avatar.xl.font.size');
    }

    .p-avatar-xl .p-avatar-icon {
        font-size: dt('avatar.xl.icon.size');
        width: dt('avatar.xl.icon.size');
        height: dt('avatar.xl.icon.size');
    }

    .p-avatar-group {
        display: flex;
        align-items: center;
    }

    .p-avatar-group .p-avatar + .p-avatar {
        margin-inline-start: dt('avatar.group.offset');
    }

    .p-avatar-group .p-avatar {
        border: 2px solid dt('avatar.group.border.color');
    }

    .p-avatar-group .p-avatar-lg + .p-avatar-lg {
        margin-inline-start: dt('avatar.lg.group.offset');
    }

    .p-avatar-group .p-avatar-xl + .p-avatar-xl {
        margin-inline-start: dt('avatar.xl.group.offset');
    }
`,classes:{root:function(e){var t=e.props;return[`p-avatar p-component`,{"p-avatar-image":t.image!=null,"p-avatar-circle":t.shape===`circle`,"p-avatar-lg":t.size===`large`,"p-avatar-xl":t.size===`xlarge`}]},label:`p-avatar-label`,icon:`p-avatar-icon`}}),m=e({default:()=>b}),h={name:`BaseAvatar`,extends:d,props:{label:{type:String,default:null},icon:{type:String,default:null},image:{type:String,default:null},size:{type:String,default:`normal`},shape:{type:String,default:`square`},ariaLabelledby:{type:String,default:null},ariaLabel:{type:String,default:null}},style:p,provide:function(){return{$pcAvatar:this,$parentInstance:this}}};function g(e){"@babel/helpers - typeof";return g=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},g(e)}function _(e,t,n){return(t=v(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function v(e){var t=y(e,`string`);return g(t)==`symbol`?t:t+``}function y(e,t){if(g(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t);if(g(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}var b={name:`Avatar`,extends:h,inheritAttrs:!1,emits:[`error`],methods:{onError:function(e){this.$emit(`error`,e)}},computed:{dataP:function(){return f(_(_({},this.shape,this.shape),this.size,this.size))}}},x=[`aria-labelledby`,`aria-label`,`data-p`],S=[`data-p`],C=[`data-p`],w=[`src`,`alt`,`data-p`];function T(e,u,d,f,p,m){return i(),t(`div`,r({class:e.cx(`root`),"aria-labelledby":e.ariaLabelledby,"aria-label":e.ariaLabel},e.ptmi(`root`),{"data-p":m.dataP}),[c(e.$slots,`default`,{},function(){return[e.label?(i(),t(`span`,r({key:0,class:e.cx(`label`)},e.ptm(`label`),{"data-p":m.dataP}),a(e.label),17,S)):e.$slots.icon?(i(),o(s(e.$slots.icon),{key:1,class:n(e.cx(`icon`))},null,8,[`class`])):e.icon?(i(),t(`span`,r({key:2,class:[e.cx(`icon`),e.icon]},e.ptm(`icon`),{"data-p":m.dataP}),null,16,C)):e.image?(i(),t(`img`,r({key:3,src:e.image,alt:e.ariaLabel,onError:u[0]||=function(){return m.onError&&m.onError.apply(m,arguments)}},e.ptm(`image`),{"data-p":m.dataP}),null,16,w)):l(``,!0)]})],16,x)}b.render=T;export{b as n,m as t};