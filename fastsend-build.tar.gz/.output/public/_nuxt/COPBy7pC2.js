import{n as e}from"./Dd_uD5pT.js";import{St as t,en as n,et as r,mt as i,qt as a,v as o,wt as s,xt as c,y as l}from"./CkeaFxZg.js";import{t as u}from"./B4I3GQrr.js";import{r as d,s as f,t as p}from"./DwuRs3jv.js";import{t as m}from"./cO8iUN-n.js";import{n as h}from"./SMPtMMWf2.js";import{t as g}from"./BRqHv64u2.js";var _=d.extend({name:`scrolltop`,style:`
    .p-scrolltop.p-button {
        position: fixed !important;
        inset-block-end: 20px;
        inset-inline-end: 20px;
    }

    .p-scrolltop-sticky.p-button {
        position: sticky !important;
        display: flex;
        margin-inline-start: auto;
    }

    .p-scrolltop-enter-from {
        opacity: 0;
    }

    .p-scrolltop-enter-active {
        transition: opacity 300ms;
    }

    .p-scrolltop-leave-to {
        opacity: 0;
    }

    .p-scrolltop-leave-active {
        transition: opacity 300ms;
    }
`,classes:{root:function(e){return[`p-scrolltop`,{"p-scrolltop-sticky":e.props.target!==`window`}]},icon:`p-scrolltop-icon`}}),v=e({default:()=>y}),y={name:`ScrollTop`,extends:{name:`BaseScrollTop`,extends:p,props:{target:{type:String,default:`window`},threshold:{type:Number,default:400},icon:{type:String,default:void 0},behavior:{type:String,default:`smooth`},buttonProps:{type:Object,default:function(){return{rounded:!0}}}},style:_,provide:function(){return{$pcScrollTop:this,$parentInstance:this}}},inheritAttrs:!1,scrollListener:null,container:null,data:function(){return{visible:!1}},mounted:function(){this.target===`window`?this.bindDocumentScrollListener():this.target===`parent`&&this.bindParentScrollListener()},beforeUnmount:function(){this.target===`window`?this.unbindDocumentScrollListener():this.target===`parent`&&this.unbindParentScrollListener(),this.container&&(m.clear(this.container),this.overlay=null)},methods:{onClick:function(){(this.target===`window`?window:this.$el.parentElement).scroll({top:0,behavior:this.behavior})},checkVisibility:function(e){this.visible=e>this.threshold},bindParentScrollListener:function(){var e=this;this.scrollListener=function(){e.checkVisibility(e.$el.parentElement.scrollTop)},this.$el.parentElement.addEventListener(`scroll`,this.scrollListener)},bindDocumentScrollListener:function(){var e=this;this.scrollListener=function(){e.checkVisibility(f())},window.addEventListener(`scroll`,this.scrollListener)},unbindParentScrollListener:function(){this.scrollListener&&=(this.$el.parentElement.removeEventListener(`scroll`,this.scrollListener),null)},unbindDocumentScrollListener:function(){this.scrollListener&&=(window.removeEventListener(`scroll`,this.scrollListener),null)},onEnter:function(e){m.set(`overlay`,e,this.$primevue.config.zIndex.overlay)},onAfterLeave:function(e){m.clear(e)},containerRef:function(e){this.container=e?e.$el:void 0}},computed:{scrollTopAriaLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.scrollTop:void 0}},components:{ChevronUpIcon:g,Button:h}};function b(e,d,f,p,m,h){var g=t(`Button`);return i(),o(u,r({name:`p-scrolltop`,appear:``,onEnter:h.onEnter,onAfterLeave:h.onAfterLeave},e.ptm(`transition`)),{default:a(function(){return[m.visible?(i(),o(g,r({key:0,ref:h.containerRef,class:e.cx(`root`),onClick:h.onClick,"aria-label":h.scrollTopAriaLabel,unstyled:e.unstyled},e.buttonProps,{pt:e.ptm(`root`)}),{icon:a(function(t){return[c(e.$slots,`icon`,{class:n(e.cx(`icon`))},function(){return[(i(),o(s(e.icon?`span`:`ChevronUpIcon`),r({class:[e.cx(`icon`),e.icon,t.class]},e.ptm(`root`).icon,{"data-pc-section":`icon`}),null,16,[`class`]))]})]}),_:3},16,[`class`,`onClick`,`aria-label`,`unstyled`,`pt`])):l(``,!0)]}),_:3},16,[`onEnter`,`onAfterLeave`])}y.render=b;export{v as n,y as t};