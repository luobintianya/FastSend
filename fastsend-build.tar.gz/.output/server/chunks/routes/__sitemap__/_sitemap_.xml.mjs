import { a as defineEventHandler, C as sitemapChildXmlEventHandler } from '../../nitro/nitro.mjs';
import 'fs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'consola';
import 'vue-router';
import '@primeuix/styled';
import 'node:url';
import '@iconify/utils';
import 'nuxtseo-shared/utils';
import 'fast-xml-parser';

const _sitemap__xml = defineEventHandler(sitemapChildXmlEventHandler);

export { _sitemap__xml as default };
//# sourceMappingURL=_sitemap_.xml.mjs.map
