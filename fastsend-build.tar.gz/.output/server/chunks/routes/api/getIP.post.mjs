import { a as defineEventHandler, g as getRequestIP } from '../../nitro/nitro.mjs';
import 'fs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'consola';
import 'vue-router';
import '@primeuix/styled';
import 'node:url';
import '@iconify/utils';
import 'nuxtseo-shared/utils';
import 'fast-xml-parser';

const getIP_post = defineEventHandler((event) => {
  return getRequestIP(event, { xForwardedFor: true });
});

export { getIP_post as default };
//# sourceMappingURL=getIP.post.mjs.map
