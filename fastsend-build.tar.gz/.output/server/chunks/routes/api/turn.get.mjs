import { a as defineEventHandler, c as getRequestHost, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import { createHmac } from 'node:crypto';
import 'fs';
import 'node:http';
import 'node:https';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'consola';
import 'vue-router';
import '@primeuix/styled';
import 'node:url';
import '@iconify/utils';
import 'nuxtseo-shared/utils';
import 'fast-xml-parser';

const turn_get = defineEventHandler((event) => {
  const host = getRequestHost(event).replace(/:\d+$/, "");
  const stunUrls = [`stun:${host}:443`, `stun:${host}:3478`];
  const secret = String(useRuntimeConfig(event).turnSecret || "");
  if (!secret) {
    return { urls: stunUrls, tcpUrls: [] };
  }
  const expiry = Math.floor(Date.now() / 1e3) + 12 * 3600;
  const username = `${expiry}:fs`;
  const credential = createHmac("sha1", secret).update(username).digest("base64");
  return {
    username,
    credential,
    urls: [...stunUrls, `turn:${host}:443?transport=udp`, `turn:${host}:3478?transport=udp`],
    tcpUrls: [`turn:${host}:3478?transport=tcp`]
  };
});

export { turn_get as default };
//# sourceMappingURL=turn.get.mjs.map
