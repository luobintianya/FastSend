import { d as defineWebSocketHandler, i as increaseTransCount } from '../../nitro/nitro.mjs';
import { TTLCache } from '@isaacs/ttlcache';
import 'fs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'consola';
import 'vue-router';
import '@primeuix/styled';
import 'node:url';
import '@iconify/utils';
import 'nuxtseo-shared/utils';
import 'fast-xml-parser';

const ROOM_CODE_RE = /^[A-Z0-9]{4,8}$/;
const ROOM_STALE_MS = 6e4;
const initPool = new TTLCache({
  max: 8192,
  ttl: 6e5,
  dispose: (peer) => {
    if (!peer.isInited) {
      peer.close();
    }
  }
});
const waitConnectPool = new TTLCache({
  max: 2e4,
  ttl: 6e5,
  dispose: (peer) => {
    if (!peer.pairPeer) {
      peer.close();
    }
  }
});
const initedPool = new TTLCache({
  max: 2e4,
  ttl: 30 * 6e4,
  dispose: (peer) => {
    peer.close();
  }
});
const rooms = /* @__PURE__ */ new Map();
function isOpen(peer) {
  const state = peer == null ? void 0 : peer.readyState;
  return state === 1 || state === "OPEN" || state === "open";
}
function sendJson(peer, payload) {
  try {
    peer.send(JSON.stringify(payload));
  } catch {
  }
}
function leaveRoom(peer) {
  const code = peer.roomCode;
  if (!code) {
    return;
  }
  const room = rooms.get(code);
  peer.roomCode = "";
  if (!room) {
    return;
  }
  room.members.delete(peer.id);
  const leavePayload = {
    type: "peerLeave",
    id: peer.id,
    user: peer.user || { nickname: "unknown", avatarURL: "" }
  };
  for (const other of room.members.values()) {
    sendJson(other, leavePayload);
  }
  if (room.members.size === 0) {
    rooms.delete(code);
  }
}
function disposePeer(peer) {
  leaveRoom(peer);
  initPool.delete(peer.id);
  initedPool.delete(peer.id);
  try {
    peer.close();
  } catch {
  }
  if (peer.pairPeer && isOpen(peer.pairPeer)) {
    const other = peer.pairPeer;
    peer.pairPeer = null;
    other.pairPeer = null;
    disposePeer(other);
  }
}
function heartbeat(peer) {
  if (peer.roomCode && peer.lastSeen && Date.now() - peer.lastSeen > ROOM_STALE_MS) {
    disposePeer(peer);
    return;
  }
  sendJson(peer, { type: "ping" });
  if (isOpen(peer)) {
    setTimeout(() => {
      heartbeat(peer);
    }, 5e3);
  }
}
function initSend(peer) {
  if (peer.isInited) {
    return;
  }
  let code = genDigitCode(4);
  let retryCount = 2048;
  while (waitConnectPool.has(code)) {
    if (retryCount-- <= 0) {
      sendJson(peer, { type: "err", data: -1, msg: "Init code fail" });
      throw new Error("Init code fail");
    }
    code = genDigitCode(4);
  }
  waitConnectPool.set(code, peer);
  peer.isInited = true;
  initPool.delete(peer.id);
  sendJson(peer, { type: "code", code });
  heartbeat(peer);
}
function initReceive(peer, code) {
  if (peer.pairPeer) {
    return;
  }
  const targetPeer = waitConnectPool.get(code);
  if (!targetPeer || targetPeer.pairPeer) {
    sendJson(peer, { type: "status", code: 404 });
    disposePeer(peer);
    return;
  }
  targetPeer.pairPeer = peer;
  peer.pairPeer = targetPeer;
  waitConnectPool.delete(code);
  peer.isInited = true;
  initedPool.set(peer.id, peer);
  initPool.delete(peer.id);
  initedPool.set(targetPeer.id, targetPeer);
  sendJson(peer, { type: "status", code: 0 });
  heartbeat(peer);
  increaseTransCount();
}
function joinRoom(peer, rawCode, user, clientId) {
  const code = String(rawCode || "").trim().toUpperCase();
  if (!ROOM_CODE_RE.test(code)) {
    sendJson(peer, { type: "err", data: -3, msg: "Invalid room" });
    disposePeer(peer);
    return;
  }
  if (peer.roomCode) {
    leaveRoom(peer);
  }
  let room = rooms.get(code);
  if (!room) {
    room = { code, members: /* @__PURE__ */ new Map(), counted: false };
    rooms.set(code, room);
  }
  peer.user = user || { nickname: "unknown", avatarURL: "" };
  peer.clientId = String(clientId || "").slice(0, 64) || peer.id;
  peer.roomCode = code;
  peer.isInited = true;
  peer.lastSeen = Date.now();
  for (const other of [...room.members.values()]) {
    if (other.id !== peer.id && other.clientId && other.clientId === peer.clientId) {
      disposePeer(other);
    }
  }
  const hasOtherPeople = [...room.members.values()].some(
    (member) => member.id !== peer.id && member.clientId !== peer.clientId
  );
  room.members.set(peer.id, peer);
  initPool.delete(peer.id);
  sendJson(peer, {
    type: "joined",
    room: code,
    selfId: peer.id,
    members: snapshotMembers(room, peer.id)
  });
  for (const other of room.members.values()) {
    if (other.id === peer.id) {
      continue;
    }
    sendJson(other, {
      type: "peerJoin",
      id: peer.id,
      user: peer.user
    });
  }
  heartbeat(peer);
  if (hasOtherPeople && !room.counted) {
    room.counted = true;
    increaseTransCount();
  }
}
function handleRoomMessage(peer, data) {
  var _a, _b;
  const room = rooms.get(peer.roomCode);
  if (!room) {
    return;
  }
  if (data.type === "updateUser") {
    peer.user = data.user || peer.user;
    for (const other of room.members.values()) {
      if (other.id !== peer.id) {
        sendJson(other, { type: "peerUser", id: peer.id, user: peer.user });
      }
    }
    return;
  }
  if (data.type === "chat") {
    const text = String(((_a = data.data) == null ? void 0 : _a.text) || "").trim().slice(0, 2e3);
    const image = typeof ((_b = data.data) == null ? void 0 : _b.image) === "string" ? data.data.image.slice(0, 3e6) : "";
    if (!text && !image) {
      return;
    }
    const to = String(data.to || "");
    const payload = {
      type: "chat",
      from: peer.id,
      to: to || void 0,
      private: !!to,
      user: peer.user || { nickname: "unknown", avatarURL: "" },
      data: { text, ...image ? { image } : {} }
    };
    if (to) {
      const target = room.members.get(to);
      if (target && target.id !== peer.id) {
        sendJson(target, payload);
      }
      return;
    }
    for (const other of room.members.values()) {
      if (other.id !== peer.id) {
        sendJson(other, payload);
      }
    }
    return;
  }
  if (data.to && (data.type === "offerFile" || data.type === "acceptFile" || data.type === "rejectFile" || data.type === "err")) {
    const target = room.members.get(data.to);
    if (target) {
      sendJson(target, {
        type: data.type,
        from: peer.id,
        data: data.data
      });
    }
    return;
  }
  if (data.type === "sdp" || data.type === "candidate") {
    const target = room.members.get(data.to);
    if (target) {
      sendJson(target, {
        type: data.type,
        from: peer.id,
        data: data.data
      });
    }
  }
}
const connect = defineWebSocketHandler({
  open(peer) {
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} open: #${peer.id}`);
    peer.lastSeen = Date.now();
    initPool.set(peer.id, peer);
  },
  close(peer) {
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} close: #${peer.id}`);
    disposePeer(peer);
  },
  message(peer, msg) {
    try {
      peer.lastSeen = Date.now();
      const data = JSON.parse(msg.text());
      if (data.type === "pong") {
        return;
      }
      if (data.type === "leave") {
        disposePeer(peer);
        return;
      }
      if (data.type === "join") {
        joinRoom(peer, data.room, data.user, data.clientId);
      } else if (data.type === "send") {
        initSend(peer);
      } else if (data.type === "receive") {
        if (/^\d{4}$/.test(data.code)) {
          initReceive(peer, data.code);
        } else {
          disposePeer(peer);
        }
      } else if (peer.roomCode) {
        handleRoomMessage(peer, data);
      } else if (peer.pairPeer) {
        peer.pairPeer.send(msg.text());
      }
    } catch (e) {
      console.warn("ws message error", e);
      disposePeer(peer);
    }
  },
  error(peer, error) {
    console.warn(error);
    disposePeer(peer);
  }
});
function snapshotMembers(room, excludeId) {
  return [...room.members.entries()].filter(([id]) => id !== excludeId).map(([id, member]) => ({
    id,
    user: member.user || { nickname: "unknown", avatarURL: "" }
  }));
}
function genDigitCode(length) {
  let code = "";
  for (let i = 0; i < length; i++) {
    const digit = Math.floor(Math.random() * 10);
    code += digit;
  }
  return code;
}

export { connect as default };
//# sourceMappingURL=connect.mjs.map
