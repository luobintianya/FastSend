import { d as defineWebSocketHandler, i as increaseTransCount } from '../../nitro/nitro.mjs';
import { TTLCache } from '@isaacs/ttlcache';
import 'fs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'vue';
import 'consola';
import 'vue-router';
import '@primeuix/styled';
import 'node:url';
import '@iconify/utils';
import 'nuxtseo-shared/utils';
import 'fast-xml-parser';

const initPool = new TTLCache({
  max: 8192,
  ttl: 6e5,
  dispose: (peer) => {
    if (!peer.isInited) {
      peer.close();
    }
  }
});
const waitConnectPool = new TTLCache({
  max: 2e4,
  ttl: 6e5,
  dispose: (peer) => {
    if (!peer.pairPeer) {
      peer.close();
    }
  }
});
const initedPool = new TTLCache({
  max: 2e4,
  ttl: 30 * 6e4,
  dispose: (peer) => {
    peer.close();
  }
});
function disposePeer(peer) {
  initPool.delete(peer.id);
  initedPool.delete(peer.id);
  peer.close();
  if (peer.pairPeer && peer.pairPeer.readyState === 1) {
    disposePeer(peer.pairPeer);
  }
}
function heartbeat(peer) {
  peer.send(JSON.stringify({ type: "ping" }));
  if (peer.readyState === 1) {
    setTimeout(() => {
      heartbeat(peer);
    }, 5e3);
  }
}
function initSend(peer) {
  if (peer.isInited) {
    return;
  }
  let code = genDigitCode(4);
  let retryCount = 2048;
  while (waitConnectPool.has(code)) {
    if (retryCount-- <= 0) {
      peer.send(JSON.stringify({ type: "err", data: -1, msg: "Init code fail" }));
      throw new Error("Init code fail");
    }
    code = genDigitCode(4);
  }
  waitConnectPool.set(code, peer);
  peer.isInited = true;
  initPool.delete(peer.id);
  peer.send(JSON.stringify({ type: "code", code }));
  heartbeat(peer);
}
function initReceive(peer, code) {
  if (peer.pairPeer) {
    return;
  }
  const targetPeer = waitConnectPool.get(code);
  if (!targetPeer || targetPeer.pairPeer) {
    peer.send(JSON.stringify({ type: "status", code: 404 }));
    disposePeer(peer);
    return;
  }
  targetPeer.pairPeer = peer;
  peer.pairPeer = targetPeer;
  waitConnectPool.delete(code);
  peer.isInited = true;
  initedPool.set(peer.id, peer);
  initPool.delete(peer.id);
  initedPool.set(targetPeer.id, targetPeer);
  peer.send(JSON.stringify({ type: "status", code: 0 }));
  heartbeat(peer);
  increaseTransCount();
}
const connect = defineWebSocketHandler({
  open(peer) {
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} open: #${peer.id}`);
    initPool.set(peer.id, peer);
  },
  close(peer) {
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} close: #${peer.id}`);
    disposePeer(peer);
  },
  message(peer, msg) {
    try {
      const data = JSON.parse(msg.text());
      if (data.type === "send") {
        initSend(peer);
      } else if (data.type === "receive") {
        if (/^\d{4}$/.test(data.code)) {
          initReceive(peer, data.code);
        } else {
          disposePeer(peer);
        }
      } else if (peer.pairPeer) {
        peer.pairPeer.send(msg.text());
      } else {
        disposePeer(peer);
      }
    } catch (e) {
      disposePeer(peer);
    }
  },
  error(peer, error) {
    console.warn(error);
    disposePeer(peer);
  }
});
function genDigitCode(length) {
  let code = "";
  for (let i = 0; i < length; i++) {
    const digit = Math.floor(Math.random() * 10);
    code += digit;
  }
  return code;
}

export { connect as default };
//# sourceMappingURL=connect.mjs.map
