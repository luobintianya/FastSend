const interopDefault = r => r.default || r || [];
const styles = {
  "../node_modules/nuxt/dist/app/entry.js": () => import('../build/entry-styles.CvkF6QaL.mjs').then(interopDefault),
  "components/FullScreenLoader.vue": () => import('../build/FullScreenLoader-styles.DuJdG5tK.mjs').then(interopDefault),
  "components/NavBar.vue": () => import('../build/NavBar-styles.B2BR3iRI.mjs').then(interopDefault),
  "components/DocPanel.vue": () => import('../build/DocPanel-styles.BYXp5EFf.mjs').then(interopDefault),
  "pages/sender.vue": () => import('../build/sender-styles.tBHd7xLe.mjs').then(interopDefault),
  "pages/recipient.vue": () => import('../build/recipient-styles.HReKA3pg.mjs').then(interopDefault),
  "pages/index.vue": () => import('../build/index-styles.DndHIR4Y.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.CbLQIMfl.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.CB5z51D_.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
