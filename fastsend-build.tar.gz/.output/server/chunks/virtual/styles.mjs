const interopDefault = r => r.default || r || [];
const styles = {
  "../node_modules/nuxt/dist/app/entry.js": () => import('../build/entry-styles.D6qVSA0o.mjs').then(interopDefault),
  "components/RoomHome.vue": () => import('../build/RoomHome-styles.D32uGT2P.mjs').then(interopDefault),
  "pages/recipient.vue": () => import('../build/recipient-styles.CLQLBpF7.mjs').then(interopDefault),
  "pages/room/index.vue": () => import('../build/index-styles.BJTdUAKX.mjs').then(interopDefault),
  "pages/sender.vue": () => import('../build/sender-styles.C3fxZDnH.mjs').then(interopDefault),
  "pages/index.vue": () => import('../build/index-styles-2.KO4vkL_g.mjs').then(interopDefault),
  "components/FullScreenLoader.vue": () => import('../build/FullScreenLoader-styles.2xpn_Pu0.mjs').then(interopDefault),
  "components/NavBar.vue": () => import('../build/NavBar-styles.DNn-LSFY.mjs').then(interopDefault),
  "components/DocPanel.vue": () => import('../build/DocPanel-styles.Cct5FoMZ.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.B9ed6RTH.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.BOKpVvHh.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
