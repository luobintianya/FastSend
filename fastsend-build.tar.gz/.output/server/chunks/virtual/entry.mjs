import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { defineProdDiagnostics } from 'nostics';
import { ansiFormatter } from 'nostics/formatters/ansi';
import * as Vue from 'vue';
import { hasInjectionContext, inject, isRef, toValue, getCurrentScope, ref, watchEffect, getCurrentInstance, onBeforeUnmount, onDeactivated, onActivated, shallowReactive, reactive, effectScope, toRef, defineComponent, shallowRef, h, resolveComponent, computed, unref, createElementBlock, onServerPrefetch, provide, cloneVNode, nextTick, queuePostFlushCb, createVNode, Text, Fragment, customRef, mergeProps, useId, readonly, watch, openBlock, createElementVNode, renderSlot, createTextVNode, toDisplayString, resolveDirective, withDirectives, createBlock, resolveDynamicComponent, withCtx, createCommentVNode, normalizeClass, Teleport, createApp, onErrorCaptured, defineAsyncComponent, isVNode, isReadonly, toRaw, useSSRContext, Suspense, isShallow, isReactive, Transition, withKeys, normalizeProps, TransitionGroup, renderList, markRaw } from 'vue';
import * as import_unhead_plugins from 'unhead/plugins';
import { FlatMetaPlugin, TemplateParamsPlugin } from 'unhead/plugins';
import { walkResolver, hasOwn as hasOwn$1 } from 'unhead/utils';
import { r as createError, D as sanitizeStatusCode, E as klona, F as defuFn, $ as $fetch$1, G as baseURL, H as getRequestURL, I as defu, J as getRequestHeader, K as getCookie, L as joinURL$1, M as hasProtocol$1, N as isEqual, O as createDefu, P as withQuery$1, Q as parsePath$1, R as parseQuery$1, S as setCookie, T as deleteCookie, U as withoutTrailingSlash$1, V as isEqual$1, W as style$c, X as m, Y as a, Z as C, _ as s$2, a0 as g$1, a1 as F, a2 as c, a3 as z, a4 as c$1, a5 as Y, a6 as A, a7 as _t, a8 as T, a9 as ne, aa as i, ab as l, ac as Q, ad as P, ae as Tt, af as Rt, ag as v, ah as C$1, ai as K, aj as W, ak as U, al as At, am as Lt, an as bt, ao as vt, ap as It, aq as tt, ar as $, as as h$1, at as S, au as parseURL$1, av as withHttps, aw as Yt, ax as D, p as publicAssetsURL, ay as titleCase, az as stringifyQuery$1, aA as camelCase, aB as withLeadingSlash, aC as withBase, aD as withTrailingSlash$1, aE as k, aF as X, aG as p } from '../nitro/nitro.mjs';
import { START_LOCATION, RouterView, createMemoryHistory, createRouter } from 'vue-router';
import { Icon, getIcon, loadIcon, _api, addAPIProvider, setCustomIconsLoader } from '@iconify/vue';
import { getIconCSS } from '@iconify/utils/lib/css/icon';
import { isPlainObject } from '@vue/shared';
import { fnv1a64Base36 } from 'fnv1a-64';
import { identify } from 'object-identity';
import CryptoJS from 'crypto-js';
import * as import_pinia from 'pinia';
import { setActivePinia, createPinia, shouldHydrate } from 'pinia';
import { ThemeService, Theme, css, dt, $dt } from '@primeuix/styled';
import * as utils from '@primeuix/utils';
import { isNotEmpty, cn, mergeKeys } from '@primeuix/utils';
import { InferSeoMetaPlugin } from '@unhead/addons';
import { defineWebSite, defineWebPage, SchemaOrgUnheadPlugin } from '@unhead/schema-org/vue';
import { ssrRenderSuspense, ssrRenderComponent, ssrRenderVNode, ssrRenderAttrs, ssrInterpolate, ssrRenderAttr } from '@vue/server-renderer';

const headSymbol$1 = "usehead";
// @__NO_SIDE_EFFECTS__
function injectHead$2() {
  if (hasInjectionContext()) {
    const instance = inject(headSymbol$1);
    if (instance)
      return instance;
  }
  throw new Error("useHead() was called without provide context, ensure you call it through the setup() function.");
}

const VueResolver$1 = /* @__PURE__ */ Object.assign(
  (_, value) => isRef(value) ? toValue(value) : value,
  // identity for plain non-reactive values, so the SSR default init entry
  // keeps its precomputed fast path (see unhead/server createHead)
  { _static: true }
);

function useHead$2(input, options = {}) {
  const head = options.head || injectHead$2();
  return head.ssr ? head.push(input || {}, options) : clientUseHead$1(head, input, options);
}
function clientUseHead$1(head, input, options = {}) {
  const scope = getCurrentScope();
  if (scope && !scope.active) {
    return { patch() {
    }, dispose() {
    }, _i: -1 };
  }
  const deactivated = ref(false);
  if (options.onRendered && scope) {
    const _onRendered = options.onRendered;
    options = { ...options, onRendered: (ctx) => scope.run(() => _onRendered(ctx)) };
  }
  let entry;
  watchEffect(() => {
    const i = deactivated.value ? {} : walkResolver(input, VueResolver$1);
    if (entry) {
      entry.patch(i);
    } else {
      entry = head.push(i, options);
    }
  });
  const vm = getCurrentInstance();
  if (vm) {
    onBeforeUnmount(() => {
      entry.dispose();
    });
    onDeactivated(() => {
      deactivated.value = true;
    });
    onActivated(() => {
      deactivated.value = false;
    });
  }
  return entry;
}
function normalizeSeoMetaInput$1(input) {
  if (input._flatMeta)
    return input;
  const meta = {};
  for (const key in input) {
    if (!hasOwn$1(input, key) || key === "title" || key === "titleTemplate")
      continue;
    meta[key] = input[key];
  }
  return {
    title: input.title,
    titleTemplate: input.titleTemplate,
    _flatMeta: meta
  };
}
function useSeoMeta$2(input = {}, options = {}) {
  const head = options.head || injectHead$2();
  head.use(FlatMetaPlugin);
  const entry = useHead$2(normalizeSeoMetaInput$1(input), options);
  const corePatch = entry.patch;
  if (!entry.__patched) {
    entry.patch = (input2) => corePatch(normalizeSeoMetaInput$1(input2));
    entry.__patched = true;
  }
  return entry;
}

//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	__defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget);

function flatHooks(configHooks, hooks = {}, parentName) {
	for (const key in configHooks) {
		const subHook = configHooks[key];
		const name = parentName ? `${parentName}:${key}` : key;
		if (typeof subHook === "object" && subHook !== null) flatHooks(subHook, hooks, name);
		else if (typeof subHook === "function") hooks[name] = subHook;
	}
	return hooks;
}
const createTask = /* @__PURE__ */ (() => {
	if (console.createTask) return console.createTask;
	const defaultTask = { run: (fn) => fn() };
	return () => defaultTask;
})();
function callHooks(hooks, args, startIndex, task) {
	for (let i = startIndex; i < hooks.length; i += 1) try {
		const result = task ? task.run(() => hooks[i](...args)) : hooks[i](...args);
		if (result && typeof result.then === "function") return Promise.resolve(result).then(() => callHooks(hooks, args, i + 1, task));
	} catch (error) {
		return Promise.reject(error);
	}
}
function serialTaskCaller(hooks, args, name) {
	if (hooks.length > 0) return callHooks(hooks, args, 0, createTask(name));
}
function parallelTaskCaller(hooks, args, name) {
	if (hooks.length > 0) {
		const task = createTask(name);
		return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
	}
}
function callEachWith(callbacks, arg0) {
	for (const callback of [...callbacks]) callback(arg0);
}
var Hookable = class {
	_hooks;
	_before;
	_after;
	_deprecatedHooks;
	_deprecatedMessages;
	constructor() {
		this._hooks = {};
		this._before = void 0;
		this._after = void 0;
		this._deprecatedMessages = void 0;
		this._deprecatedHooks = {};
		this.hook = this.hook.bind(this);
		this.callHook = this.callHook.bind(this);
		this.callHookWith = this.callHookWith.bind(this);
	}
	hook(name, function_, options = {}) {
		if (!name || typeof function_ !== "function") return () => {};
		const originalName = name;
		let dep;
		while (this._deprecatedHooks[name]) {
			dep = this._deprecatedHooks[name];
			name = dep.to;
		}
		if (dep && !options.allowDeprecated) {
			let message = dep.message;
			if (!message) message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
			if (!this._deprecatedMessages) this._deprecatedMessages = /* @__PURE__ */ new Set();
			if (!this._deprecatedMessages.has(message)) {
				console.warn(message);
				this._deprecatedMessages.add(message);
			}
		}
		if (!function_.name) try {
			Object.defineProperty(function_, "name", {
				get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
				configurable: true
			});
		} catch {}
		this._hooks[name] = this._hooks[name] || [];
		this._hooks[name].push(function_);
		return () => {
			if (function_) {
				this.removeHook(name, function_);
				function_ = void 0;
			}
		};
	}
	hookOnce(name, function_) {
		let _unreg;
		let _function = (...arguments_) => {
			if (typeof _unreg === "function") _unreg();
			_unreg = void 0;
			_function = void 0;
			return function_(...arguments_);
		};
		_unreg = this.hook(name, _function);
		return _unreg;
	}
	removeHook(name, function_) {
		const hooks = this._hooks[name];
		if (hooks) {
			const index = hooks.indexOf(function_);
			if (index !== -1) hooks.splice(index, 1);
			if (hooks.length === 0) this._hooks[name] = void 0;
		}
	}
	clearHook(name) {
		this._hooks[name] = void 0;
	}
	deprecateHook(name, deprecated) {
		this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
		const _hooks = this._hooks[name] || [];
		this._hooks[name] = void 0;
		for (const hook of _hooks) this.hook(name, hook);
	}
	deprecateHooks(deprecatedHooks) {
		for (const name in deprecatedHooks) this.deprecateHook(name, deprecatedHooks[name]);
	}
	addHooks(configHooks) {
		const hooks = flatHooks(configHooks);
		const removeFns = Object.keys(hooks).map((key) => this.hook(key, hooks[key]));
		return () => {
			for (const unreg of removeFns) unreg();
			removeFns.length = 0;
		};
	}
	removeHooks(configHooks) {
		const hooks = flatHooks(configHooks);
		for (const key in hooks) this.removeHook(key, hooks[key]);
	}
	removeAllHooks() {
		this._hooks = {};
	}
	callHook(name, ...args) {
		return this.callHookWith(serialTaskCaller, name, args);
	}
	callHookParallel(name, ...args) {
		return this.callHookWith(parallelTaskCaller, name, args);
	}
	callHookWith(caller, name, args) {
		const event = this._before || this._after ? {
			name,
			args,
			context: {}
		} : void 0;
		if (this._before) callEachWith(this._before, event);
		const result = caller(this._hooks[name] ? [...this._hooks[name]] : [], args, name);
		if (result instanceof Promise) return result.finally(() => {
			if (this._after && event) callEachWith(this._after, event);
		});
		if (this._after && event) callEachWith(this._after, event);
		return result;
	}
	beforeEach(function_) {
		this._before = this._before || [];
		this._before.push(function_);
		return () => {
			if (this._before !== void 0) {
				const index = this._before.indexOf(function_);
				if (index !== -1) this._before.splice(index, 1);
			}
		};
	}
	afterEach(function_) {
		this._after = this._after || [];
		this._after.push(function_);
		return () => {
			if (this._after !== void 0) {
				const index = this._after.indexOf(function_);
				if (index !== -1) this._after.splice(index, 1);
			}
		};
	}
};
function createHooks() {
	return new Hookable();
}

function _getAsyncLocalStorage() {
	return globalThis.AsyncLocalStorage || globalThis.process?.getBuiltinModule?.("node:async_hooks")?.AsyncLocalStorage;
}
function createContext(opts = {}) {
	let currentInstance;
	let isSingleton = false;
	const checkConflict = (instance) => {
		if (currentInstance && currentInstance !== instance) throw new Error("Context conflict");
	};
	let als;
	if (opts.asyncContext) {
		const _AsyncLocalStorage = opts.AsyncLocalStorage || _getAsyncLocalStorage();
		if (_AsyncLocalStorage) als = new _AsyncLocalStorage();
		else console.warn("[unctx] `AsyncLocalStorage` is not provided.");
	}
	const _wrapInstance = (instance) => als && instance !== null && typeof instance === "object" ? { __unctx_weak: new WeakRef(instance) } : instance;
	const _unwrapInstance = (store) => store && store.__unctx_weak ? store.__unctx_weak.deref() : store;
	const _getCurrentInstance = () => {
		if (als) {
			const store = als.getStore();
			if (store !== void 0) return _unwrapInstance(store);
		}
		return currentInstance;
	};
	return {
		use: () => {
			const _instance = _getCurrentInstance();
			if (_instance === void 0) throw new Error("Context is not available");
			return _instance;
		},
		tryUse: () => {
			return _getCurrentInstance();
		},
		set: (instance, replace) => {
			if (!replace) checkConflict(instance);
			currentInstance = instance;
			isSingleton = true;
		},
		unset: () => {
			currentInstance = void 0;
			isSingleton = false;
		},
		call: (instance, callback) => {
			checkConflict(instance);
			currentInstance = instance;
			try {
				return als ? als.run(_wrapInstance(instance), callback) : callback();
			} finally {
				if (!isSingleton) currentInstance = void 0;
			}
		},
		async callAsync(instance, callback) {
			currentInstance = instance;
			const onRestore = () => {
				currentInstance = instance;
			};
			const onLeave = () => currentInstance === instance ? onRestore : void 0;
			asyncHandlers.add(onLeave);
			try {
				const r = als ? als.run(_wrapInstance(instance), callback) : callback();
				if (!isSingleton) currentInstance = void 0;
				return await r;
			} finally {
				asyncHandlers.delete(onLeave);
			}
		}
	};
}
function createNamespace(defaultOpts = {}) {
	const contexts = {};
	return { get(key, opts = {}) {
		if (!contexts[key]) contexts[key] = createContext({
			...defaultOpts,
			...opts
		});
		return contexts[key];
	} };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
	const restores = [];
	for (const leaveHandler of asyncHandlers) {
		const restore = leaveHandler();
		if (restore) restores.push(restore);
	}
	const restore = () => {
		for (const restore of restores) restore();
	};
	let awaitable = function_();
	if (awaitable && typeof awaitable === "object" && "catch" in awaitable) awaitable = awaitable.catch((error) => {
		restore();
		throw error;
	});
	return [awaitable, restore];
}

//#region node_modules/nuxt/dist/app/diagnostics/_shared.js
/**
* Shared configuration for the runtime (E<N>xxx) diagnostics catalogs.
*
* Catalogs are split by domain and imported directly where used (no barrel),
* so the browser bundle only pulls in the codes a module references. Pair the
* pure-call annotations on each `defineDiagnostics()` with dev-guarded,
* statement-level report calls so report-only diagnostics strip from production.
*
* Codes are stable, fully-qualified `NUXT_E<NNNN>` identifiers. Codes with a
* dedicated docs page resolve a `see:` URL via {@link docsBase}; the rest opt
* out with `docs: false`.
*/
function docsBase(code) {
	return `https://nuxt.com/docs/4.x/errors/${code.replace("NUXT_", "").toLowerCase()}`;
}
var ansi = (open, close) => (s) => `\x1B[${open}m${s}\x1B[${close}m`;
var colors = {
	red: ansi(31, 39),
	yellow: ansi(33, 39),
	cyan: ansi(36, 39),
	gray: ansi(90, 39),
	bold: ansi(1, 22),
	dim: ansi(2, 22)
};
ansiFormatter(colors);
var prodReporter = (diagnostic) => {
	console.error(`[${diagnostic.name}]`);
};
var prodReporters = [prodReporter];
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/core.js
/**
* E1xxx
* Core / Nuxt-instance / lifecycle runtime diagnostics.
*/
var appDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fnuxt.config.mjs
var nuxtLinkDefaults = {
	"componentName": "NuxtLink"};
var asyncDataDefaults = { "deep": false };
var fetchDefaults = {};
//#endregion
//#region node_modules/nuxt/dist/app/nuxt.js
function getNuxtAppCtx(id = "nuxt-app") {
	return getContext(id, { asyncContext: false });
}
var NuxtPluginIndicator = "__nuxt_plugin";
/** @since 3.0.0 */
function createNuxtApp(options) {
	let hydratingCount = 0;
	const nuxtApp = {
		_id: options.id || "nuxt-app",
		_scope: effectScope(),
		provide: void 0,
		versions: {
			get nuxt() {
				return "4.5.2";
			},
			get vue() {
				return nuxtApp.vueApp.version;
			}
		},
		payload: shallowReactive({
			...options.ssrContext?.payload || {},
			data: shallowReactive({}),
			state: reactive({}),
			once: /* @__PURE__ */ new Set(),
			_errors: shallowReactive({})
		}),
		static: { data: {} },
		runWithContext(fn) {
			if (nuxtApp._scope.active && !getCurrentScope()) return nuxtApp._scope.run(() => callWithNuxt(nuxtApp, fn));
			return callWithNuxt(nuxtApp, fn);
		},
		isHydrating: false,
		deferHydration() {
			if (!nuxtApp.isHydrating) return () => {};
			hydratingCount++;
			let called = false;
			return () => {
				if (called) return;
				called = true;
				hydratingCount--;
				if (hydratingCount === 0) {
					nuxtApp.isHydrating = false;
					return nuxtApp.callHook("app:suspense:resolve");
				}
			};
		},
		_asyncDataPromises: {},
		_asyncData: shallowReactive({}),
		_state: shallowReactive({}),
		_payloadRevivers: {},
		...options
	};
	nuxtApp.payload.serverRendered = true;
	if (nuxtApp.ssrContext) {
		nuxtApp.payload.path = nuxtApp.ssrContext.url;
		nuxtApp.ssrContext.nuxt = nuxtApp;
		nuxtApp.ssrContext.payload = nuxtApp.payload;
		nuxtApp.ssrContext.config = {
			public: nuxtApp.ssrContext.runtimeConfig.public,
			app: nuxtApp.ssrContext.runtimeConfig.app
		};
	}
	nuxtApp.hooks = createHooks();
	nuxtApp.hook = nuxtApp.hooks.hook;
	{
		const contextCaller = async function(hooks, args) {
			for (const hook of hooks) await nuxtApp.runWithContext(() => hook(...args));
		};
		nuxtApp.hooks.callHook = (name, ...args) => nuxtApp.hooks.callHookWith(contextCaller, name, args);
	}
	nuxtApp.callHook = nuxtApp.hooks.callHook;
	nuxtApp.provide = (name, value) => {
		const $name = "$" + name;
		defineGetter(nuxtApp, $name, value);
		defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
	};
	defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
	defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
	const runtimeConfig = options.ssrContext.runtimeConfig;
	nuxtApp.provide("config", runtimeConfig);
	return nuxtApp;
}
/** @since 3.12.0 */
function registerPluginHooks(nuxtApp, plugin) {
	if (plugin.hooks) nuxtApp.hooks.addHooks(plugin.hooks);
}
/** @since 3.0.0 */
async function applyPlugin(nuxtApp, plugin) {
	if (typeof plugin === "function") {
		const run = () => nuxtApp.runWithContext(() => plugin(nuxtApp));
		const { provide } = await run() || {};
		if (provide && typeof provide === "object") for (const key in provide) nuxtApp.provide(key, provide[key]);
	}
}
/** @since 3.0.0 */
async function applyPlugins(nuxtApp, plugins) {
	return applyPluginsWithDependencies(nuxtApp, plugins);
}
async function applyPluginsWithDependencies(nuxtApp, plugins) {
	const resolvedPlugins = /* @__PURE__ */ new Set();
	const unresolvedPlugins = [];
	const parallels = [];
	let error;
	let promiseDepth = 0;
	async function executePlugin(plugin) {
		const unresolvedPluginsForThisPlugin = plugin.dependsOn?.filter((name) => plugins.some((p) => p._name === name) && !resolvedPlugins.has(name)) ?? [];
		if (unresolvedPluginsForThisPlugin.length > 0) unresolvedPlugins.push([new Set(unresolvedPluginsForThisPlugin), plugin]);
		else {
			const promise = applyPlugin(nuxtApp, plugin).then(async () => {
				if (plugin._name) {
					resolvedPlugins.add(plugin._name);
					await Promise.all(unresolvedPlugins.map(async ([dependsOn, unexecutedPlugin]) => {
						if (dependsOn.has(plugin._name)) {
							dependsOn.delete(plugin._name);
							if (dependsOn.size === 0) {
								promiseDepth++;
								await executePlugin(unexecutedPlugin);
							}
						}
					}));
				}
			}).catch((e) => {
				if (!plugin.parallel && !nuxtApp.payload.error) throw e;
				error ||= e;
			});
			if (plugin.parallel) parallels.push(promise);
			else await promise;
		}
	}
	for (const plugin of plugins) registerPluginHooks(nuxtApp, plugin);
	for (const plugin of plugins) await executePlugin(plugin);
	await Promise.all(parallels);
	if (promiseDepth) for (let i = 0; i < promiseDepth; i++) await Promise.all(parallels);
	if (error) throw nuxtApp.payload.error || error;
}
/** @since 3.0.0 */
/* @__NO_SIDE_EFFECTS__ */
function defineNuxtPlugin(plugin) {
	if (typeof plugin === "function") return plugin;
	const _name = plugin._name || plugin.name;
	delete plugin.name;
	return Object.assign(plugin.setup || (() => {}), plugin, {
		[NuxtPluginIndicator]: true,
		_name
	});
}
var definePayloadPlugin = defineNuxtPlugin;
/**
* Ensures that the setup function passed in has access to the Nuxt instance via `useNuxtApp`.
* @param nuxt A Nuxt instance
* @param setup The function to call
* @since 3.0.0
*/
function callWithNuxt(nuxt, setup, args) {
	const fn = () => setup();
	const nuxtAppCtx = getNuxtAppCtx(nuxt._id);
	return nuxt.vueApp.runWithContext(() => nuxtAppCtx.callAsync(nuxt, fn));
}
function tryUseNuxtApp(id) {
	let nuxtAppInstance;
	if (hasInjectionContext()) nuxtAppInstance = getCurrentInstance()?.appContext.app.$nuxt;
	nuxtAppInstance ||= getNuxtAppCtx(id).tryUse();
	return nuxtAppInstance || null;
}
function useNuxtApp(id) {
	const nuxtAppInstance = tryUseNuxtApp(id);
	if (!nuxtAppInstance) throw appDiagnostics.NUXT_E1001();
	return nuxtAppInstance;
}
/** @since 3.0.0 */
/* @__NO_SIDE_EFFECTS__ */
function useRuntimeConfig(_event) {
	return useNuxtApp().$config;
}
function defineGetter(obj, key, val) {
	Object.defineProperty(obj, key, { get: () => val });
}
/** @since 3.0.0 */
function defineAppConfig(config) {
	return config;
}
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/head.js
/**
* E6xxx
* Head / unhead runtime diagnostics.
*/
var unheadDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region node_modules/nuxt/dist/head/runtime/composables.js
/**
* Injects the head client from the Nuxt context or Vue inject.
*/
function injectHead$1(nuxtApp) {
	const nuxt = nuxtApp || useNuxtApp();
	return nuxt.ssrContext?.head || nuxt.runWithContext(() => {
		if (hasInjectionContext()) {
			const head = inject(headSymbol$1);
			if (!head) throw unheadDiagnostics.NUXT_E6001();
			return head;
		}
	});
}
function useHead$1(input, options = {}) {
	const head = options.head || injectHead$1(options.nuxt);
	return useHead$2(input, {
		head,
		...options
	});
}
function useSeoMeta$1(input, options = {}) {
	const head = options.head || injectHead$1(options.nuxt);
	return useSeoMeta$2(input, {
		head,
		...options
	});
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

globalThis._importMeta_.url.replace(/\/app\/.*$/, "/");
//#endregion
//#region node_modules/nuxt/dist/app/components/injections.js
var LayoutMetaSymbol = Symbol("layout-meta");
var PageRouteSymbol = Symbol("route");
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/navigation.js
/**
* E2xxx
* Navigation / routing / middleware runtime diagnostics.
*/
var navigationDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region node_modules/nuxt/dist/app/composables/router.js
/** @since 3.0.0 */
var useRouter = () => {
	return useNuxtApp()?.$router;
};
/**
* Whether the current effect scope is (a descendant of) the component instance's scope.
* A detached scope (e.g. `createSharedComposable`) outlives the component, so the
* per-page route injected there would freeze after navigation (#18903).
*/
function isScopeWithinInstance(instance) {
	const instanceScope = instance.scope;
	let scope = getCurrentScope();
	while (scope) {
		if (scope === instanceScope) return true;
		scope = scope.parent;
	}
	return false;
}
/** @since 3.0.0 */
var useRoute$1 = (() => {
	if (hasInjectionContext()) {
		const instance = getCurrentInstance();
		if (!instance || isScopeWithinInstance(instance)) return inject(PageRouteSymbol, useNuxtApp()._route);
	}
	return useNuxtApp()._route;
});
/** @since 3.0.0 */
/* @__NO_SIDE_EFFECTS__ */
function defineNuxtRouteMiddleware(middleware) {
	return middleware;
}
/** @since 3.0.0 */
var isProcessingMiddleware = () => {
	try {
		if (useNuxtApp()._processingMiddleware) return true;
	} catch {
		return false;
	}
	return false;
};
var HTML_ATTR_UNSAFE_RE = /[&"'<>]/g;
var HTML_ATTR_ENCODE_MAP = {
	"&": "&amp;",
	"\"": "&quot;",
	"'": "&#x27;",
	"<": "&lt;",
	">": "&gt;"
};
function encodeForHtmlAttr(value) {
	return value.replace(HTML_ATTR_UNSAFE_RE, (c) => HTML_ATTR_ENCODE_MAP[c]);
}
/**
* A helper that aids in programmatic navigation within your Nuxt application.
*
* Can be called on the server and on the client, within pages, route middleware, plugins, and more.
* @param {RouteLocationRaw | undefined | null} [to] - The route to navigate to. Accepts a route object, string path, `undefined`, or `null`. Defaults to '/'.
* @param {NavigateToOptions} [options] - Optional customization for controlling the behavior of the navigation.
* @returns {Promise<void | NavigationFailure | false> | false | void | RouteLocationRaw} The navigation result, which varies depending on context and options.
* @see https://nuxt.com/docs/4.x/api/utils/navigate-to
* @since 3.0.0
*/
var navigateTo = (to, options) => {
	to ||= "/";
	const toPath = typeof to === "string" ? to : "path" in to ? resolveRouteObject(to) : useRouter().resolve(to).href;
	const isExternalHost = hasProtocol(toPath, { acceptRelative: true });
	const isExternal = options?.external || isExternalHost;
	if (isExternal) {
		if (!options?.external) throw navigationDiagnostics.NUXT_E2001({ toPath });
		const { protocol } = new URL(toPath, "http://localhost");
		if (protocol && isScriptProtocol(protocol)) throw navigationDiagnostics.NUXT_E2002({
			toPath,
			protocol
		});
	}
	const inMiddleware = isProcessingMiddleware();
	const router = useRouter();
	const nuxtApp = useNuxtApp();
	if (nuxtApp.ssrContext) {
		const fullPath = typeof to === "string" || isExternal ? toPath : router.resolve(to).fullPath || "/";
		const location = isExternal ? toPath : joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, fullPath);
		const redirect = async function(response) {
			await nuxtApp.callHook("app:redirected");
			const encodedHeader = encodeURL(location, isExternalHost);
			const encodedLoc = encodeForHtmlAttr(encodedHeader);
			nuxtApp.ssrContext["~renderResponse"] = {
				statusCode: sanitizeStatusCode(options?.redirectCode || 302, 302),
				body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`,
				headers: { location: encodedHeader }
			};
			return response;
		};
		if (!isExternal && inMiddleware) {
			router.afterEach((final) => final.fullPath === fullPath ? redirect(false) : void 0);
			return to;
		}
		return redirect(!inMiddleware ? void 0 : false);
	}
	if (isExternal) {
		nuxtApp._scope.stop();
		if (options?.replace) (void 0).replace(toPath);
		else (void 0).href = toPath;
		if (inMiddleware) {
			if (!nuxtApp.isHydrating) return false;
			return new Promise(() => {});
		}
		return Promise.resolve();
	}
	const encodedTo = typeof to === "string" ? encodeRoutePath(to) : to;
	return options?.replace ? router.replace(encodedTo) : router.push(encodedTo);
};
/**
* @internal
*/
function resolveRouteObject(to) {
	return withQuery(to.path || "", to.query || {}) + (to.hash || "");
}
/**
* @internal
*/
function encodeURL(location, isExternalHost = false) {
	const url = new URL(location, "http://localhost");
	if (!isExternalHost) return url.pathname.replace(/^\/{2,}/, "/") + url.search + url.hash;
	if (location.startsWith("//")) return url.toString().replace(url.protocol, "");
	return url.toString();
}
/**
* Encode the pathname of a route location string. Ensures decoded paths like
* `/café` are percent-encoded to match vue-router's encoded route records.
* Already-encoded paths are not double-encoded.
* @internal
*/
function encodeRoutePath(url) {
	const parsed = parseURL(url);
	return encodePath(decodePath(parsed.pathname)) + parsed.search + parsed.hash;
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/error.js
var NUXT_ERROR_SIGNATURE = "__nuxt_error";
/** @since 3.0.0 */
var useError = /* @__NO_SIDE_EFFECTS__ */ () => toRef(useNuxtApp().payload, "error");
/** @since 3.0.0 */
var showError = (error) => {
	const nuxtError = createError$1(error);
	try {
		const error = /* @__PURE__ */ useError();
		error.value ||= nuxtError;
	} catch {
		throw nuxtError;
	}
	return nuxtError;
};
/**
* Show the error page unless the current client is a crawler, in which case the
* bot receives the already server-rendered HTML instead (#32137, #35338).
*
* @internal
*/
var _showErrorUnlessCrawler = async (nuxtApp, error) => {
	await nuxtApp.runWithContext(() => showError(error));
};
/** @since 3.0.0 */
var isNuxtError = (error) => !!error && typeof error === "object" && "__nuxt_error" in error;
/** @since 3.0.0 */
var createError$1 = (error) => {
	if (typeof error !== "string" && error.statusText) error.message ??= error.statusText;
	const nuxtError = createError(error);
	Object.defineProperty(nuxtError, NUXT_ERROR_SIGNATURE, {
		value: true,
		configurable: false,
		writable: false
	});
	Object.defineProperty(nuxtError, "status", {
		get: () => nuxtError.statusCode,
		configurable: true
	});
	Object.defineProperty(nuxtError, "statusText", {
		get: () => nuxtError.statusMessage,
		configurable: true
	});
	return nuxtError;
};
//#endregion
//#region node_modules/nuxt/dist/app/components/utils.js
var ROUTE_KEY_PARENTHESES_RE$1 = /(:\w+)\([^)]+\)/g;
var ROUTE_KEY_SYMBOLS_RE$1 = /(:\w+)[?+*]/g;
var ROUTE_KEY_NORMAL_RE$1 = /:\w+/g;
function generateRouteKey$1(route) {
	const source = route?.meta.key ?? route.path.replace(ROUTE_KEY_PARENTHESES_RE$1, "$1").replace(ROUTE_KEY_SYMBOLS_RE$1, "$1").replace(ROUTE_KEY_NORMAL_RE$1, (r) => route.params[r.slice(1)]?.toString() || "");
	return typeof source === "function" ? source(route) : source;
}
/**
* Utility used within router guards
* return true if the route has been changed with a page change during navigation
*/
function isChangingPage(to, from) {
	if (to === from || from === START_LOCATION) return false;
	if (generateRouteKey$1(to) !== generateRouteKey$1(from)) return true;
	if (to.matched.every((comp, index) => comp.components && comp.components.default === from.matched[index]?.components?.default)) return false;
	return true;
}
var VALID_TAG_RE = /^[a-z][a-z0-9-]*$/i;
/** Return `tag` if it is a safe HTML tag name, otherwise `fallback`. */
function sanitizeTag(tag, fallback) {
	return tag && VALID_TAG_RE.test(tag) ? tag : fallback;
}

//#region node_modules/nuxt/dist/pages/runtime/router.options.js
var router_options_default = { scrollBehavior(to, from, savedPosition) {
	const nuxtApp = useNuxtApp();
	const router = useRouter();
	const hashScrollBehaviour = router.options?.scrollBehaviorType ?? "auto";
	if (to.path.replace(/\/$/, "") === from.path.replace(/\/$/, "")) {
		if (from.hash && !to.hash) return savedPosition ?? {
			left: 0,
			top: 0
		};
		if (to.hash) return {
			el: to.hash,
			top: _getHashElementScrollMarginTop(to.hash),
			behavior: hashScrollBehaviour
		};
		return false;
	}
	if ((typeof to.meta.scrollToTop === "function" ? to.meta.scrollToTop(to, from) : to.meta.scrollToTop) === false) return false;
	if (from === START_LOCATION) return _calculatePosition(to, from, savedPosition, hashScrollBehaviour);
	return new Promise((resolve) => {
		const doScroll = () => {
			requestAnimationFrame(() => {
				if (router.currentRoute.value.fullPath !== to.fullPath) {
					resolve(false);
					return;
				}
				resolve(_calculatePosition(to, from, savedPosition, hashScrollBehaviour));
			});
		};
		nuxtApp.hooks.hookOnce("page:loading:end", () => {
			const transitionPromise = nuxtApp["~transitionPromise"];
			if (transitionPromise) transitionPromise.then(doScroll);
			else doScroll();
		});
	});
} };
function _getHashElementScrollMarginTop(selector) {
	try {
		const elem = (void 0).querySelector(selector);
		if (elem) return (Number.parseFloat(getComputedStyle(elem).scrollMarginTop) || 0) + (Number.parseFloat(getComputedStyle((void 0).documentElement).scrollPaddingTop) || 0);
	} catch {}
	return 0;
}
function _calculatePosition(to, from, savedPosition, defaultHashScrollBehaviour) {
	if (savedPosition) return savedPosition;
	if (to.hash) return {
		el: to.hash,
		top: _getHashElementScrollMarginTop(to.hash),
		behavior: isChangingPage(to, from) ? defaultHashScrollBehaviour : "instant"
	};
	return {
		left: 0,
		top: 0
	};
}
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default = {
	hashMode: false,
	scrollBehaviorType: "auto",
	...router_options_default
};
//#endregion
//#region node_modules/nuxt/dist/app/components/nuxt-link.js
var firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
/**
* Reject URL strings that would resolve to a script-capable protocol when used as the
* `href` of an anchor element. Returns the value unchanged when safe, or `null`.
*
* The denylist is delegated to `ufo`'s `isScriptProtocol` so it stays in sync with the
* check used by `navigateTo` (currently `javascript:`, `data:`, `vbscript:`, `blob:`).
* ASCII whitespace and control characters are stripped first because browser URL
* parsers tolerate them before the scheme, and `view-source:` is peeled recursively
* because Chromium resolves it transparently to the inner URL.
*/
function sanitizeExternalHref(value) {
	let candidate = value.replace(/[\u0000-\u001F\s]+/g, "");
	while (candidate.toLowerCase().startsWith("view-source:")) candidate = candidate.slice(12);
	const colon = candidate.indexOf(":");
	if (colon > 0 && isScriptProtocol(candidate.slice(0, colon + 1))) return null;
	return value;
}
/* @__NO_SIDE_EFFECTS__ */
function defineNuxtLink(options) {
	const componentName = options.componentName || "NuxtLink";
	function isHashLinkWithoutHashMode(link) {
		return typeof link === "string" && link.startsWith("#");
	}
	function resolveTrailingSlashBehavior(to, resolve, trailingSlash) {
		const effectiveTrailingSlash = trailingSlash ?? options.trailingSlash;
		if (!to || effectiveTrailingSlash !== "append" && effectiveTrailingSlash !== "remove") return to;
		if (typeof to === "string") return applyTrailingSlashBehavior(to, effectiveTrailingSlash);
		const path = "path" in to && to.path !== void 0 ? to.path : resolve(to).path;
		return {
			...to,
			name: void 0,
			path: applyTrailingSlashBehavior(path, effectiveTrailingSlash)
		};
	}
	function useNuxtLink(props) {
		const router = useRouter();
		const config = /* @__PURE__ */ useRuntimeConfig();
		const hasTarget = computed(() => !!unref(props.target) && unref(props.target) !== "_self");
		const isAbsoluteUrl = computed(() => {
			const path = unref(props.to) || unref(props.href) || "";
			return typeof path === "string" && hasProtocol(path, { acceptRelative: true });
		});
		const builtinRouterLink = resolveComponent("RouterLink");
		const useBuiltinLink = builtinRouterLink && typeof builtinRouterLink !== "string" ? builtinRouterLink.useLink : void 0;
		const isExternal = computed(() => {
			if (unref(props.external)) return true;
			const path = unref(props.to) || unref(props.href) || "";
			if (typeof path === "object") return false;
			return path === "" || isAbsoluteUrl.value;
		});
		const to = computed(() => {
			const path = unref(props.to) || unref(props.href) || "";
			if (isExternal.value) return path;
			return resolveTrailingSlashBehavior(path, router.resolve, unref(props.trailingSlash));
		});
		const link = isExternal.value ? void 0 : useBuiltinLink?.({
			...props,
			to,
			viewTransition: unref(props.viewTransition)
		});
		const href = computed(() => {
			const effectiveTrailingSlash = unref(props.trailingSlash) ?? options.trailingSlash;
			if (!to.value || isAbsoluteUrl.value || isHashLinkWithoutHashMode(to.value)) {
				const raw = to.value;
				return typeof raw === "string" ? sanitizeExternalHref(raw) : raw;
			}
			if (isExternal.value) {
				const path = typeof to.value === "object" && "path" in to.value ? resolveRouteObject(to.value) : to.value;
				const href = typeof path === "object" ? router.resolve(path).href : path;
				const safe = typeof href === "string" ? sanitizeExternalHref(href) : href;
				return safe === null ? null : applyTrailingSlashBehavior(safe, effectiveTrailingSlash);
			}
			if (typeof to.value === "object") return router.resolve(to.value)?.href ?? null;
			return applyTrailingSlashBehavior(joinURL(config.app.baseURL, to.value), effectiveTrailingSlash);
		});
		return {
			to,
			hasTarget,
			isAbsoluteUrl,
			isExternal,
			href,
			isActive: link?.isActive ?? computed(() => to.value === router.currentRoute.value.path),
			isExactActive: link?.isExactActive ?? computed(() => to.value === router.currentRoute.value.path),
			route: link?.route ?? computed(() => router.resolve(to.value)),
			async navigate(_e) {
				if (href.value === null) return;
				await navigateTo(href.value, {
					replace: unref(props.replace),
					external: isExternal.value || hasTarget.value
				});
			}
		};
	}
	return defineComponent({
		name: componentName,
		props: {
			to: {
				type: [String, Object],
				default: void 0,
				required: false
			},
			href: {
				type: [String, Object],
				default: void 0,
				required: false
			},
			target: {
				type: String,
				default: void 0,
				required: false
			},
			rel: {
				type: String,
				default: void 0,
				required: false
			},
			noRel: {
				type: Boolean,
				default: void 0,
				required: false
			},
			prefetch: {
				type: Boolean,
				default: void 0,
				required: false
			},
			prefetchOn: {
				type: [String, Object],
				default: void 0,
				required: false
			},
			noPrefetch: {
				type: Boolean,
				default: void 0,
				required: false
			},
			activeClass: {
				type: String,
				default: void 0,
				required: false
			},
			exactActiveClass: {
				type: String,
				default: void 0,
				required: false
			},
			prefetchedClass: {
				type: String,
				default: void 0,
				required: false
			},
			replace: {
				type: Boolean,
				default: void 0,
				required: false
			},
			ariaCurrentValue: {
				type: String,
				default: void 0,
				required: false
			},
			external: {
				type: Boolean,
				default: void 0,
				required: false
			},
			custom: {
				type: Boolean,
				default: void 0,
				required: false
			},
			trailingSlash: {
				type: String,
				default: void 0,
				required: false
			}
		},
		useLink: useNuxtLink,
		setup(props, { slots }) {
			const router = useRouter();
			const { to, href, navigate, isExternal, hasTarget, isAbsoluteUrl } = useNuxtLink(props);
			const prefetched = shallowRef(false);
			const el = void 0;
			const elRef = void 0;
			function shouldPrefetch(mode) {
				return false;
			}
			async function prefetch(nuxtApp = useNuxtApp()) {}
			return () => {
				const target = props.target || null;
				const rel = firstNonUndefined(props.noRel ? "" : props.rel, options.externalRelAttribute, isAbsoluteUrl.value || hasTarget.value ? "noopener noreferrer" : "") || null;
				const getCustomSlotProps = (routerLinkSlotProps) => ({
					href: href.value,
					navigate,
					get route() {
						if (!href.value) return;
						const url = new URL(href.value, "http://localhost");
						return {
							path: url.pathname,
							fullPath: url.pathname,
							get query() {
								return parseQuery(url.search);
							},
							hash: url.hash,
							params: {},
							name: void 0,
							matched: [],
							redirectedFrom: void 0,
							meta: {},
							href: href.value
						};
					},
					rel,
					target,
					isExternal: isExternal.value || hasTarget.value,
					isActive: false,
					isExactActive: false,
					...routerLinkSlotProps,
					prefetch,
					prefetched: prefetched.value,
					shouldPrefetch
				});
				if (!isExternal.value && !hasTarget.value && !isHashLinkWithoutHashMode(to.value)) {
					const routerLinkProps = {
						ref: elRef,
						to: to.value,
						activeClass: props.activeClass || options.activeClass,
						exactActiveClass: props.exactActiveClass || options.exactActiveClass,
						replace: props.replace,
						ariaCurrentValue: props.ariaCurrentValue,
						custom: props.custom
					};
					if (!props.custom) routerLinkProps.rel = props.rel || void 0;
					return h(resolveComponent("RouterLink"), routerLinkProps, props.custom && slots.default ? { default: (slotProps) => slots.default(getCustomSlotProps(slotProps)) } : slots.default);
				}
				if (props.custom) {
					if (!slots.default) return null;
					return slots.default(getCustomSlotProps());
				}
				return h("a", {
					ref: el,
					href: href.value || null,
					rel,
					target,
					onClick: async (event) => {
						if (isExternal.value || hasTarget.value) return;
						event.preventDefault();
						try {
							const encodedHref = encodeRoutePath(href.value ?? "");
							return await (props.replace ? router.replace(encodedHref) : router.push(encodedHref));
						} finally {}
					}
				}, slots.default?.());
			};
		}
	});
}
var NuxtLink = /* @__PURE__ */ defineNuxtLink(nuxtLinkDefaults);
function applyTrailingSlashBehavior(to, trailingSlash) {
	if (trailingSlash !== "append" && trailingSlash !== "remove") return to;
	const normalizeFn = trailingSlash === "append" ? withTrailingSlash : withoutTrailingSlash;
	if (hasProtocol(to) && !to.startsWith("http")) return to;
	return normalizeFn(to, true);
}

//#region app/app.config.ts
var app_config_default = defineAppConfig({});
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fapp_config_default = /*@__PURE__*/ defuFn(app_config_default, {
	"nuxt": {},
	"icon": {
		"provider": "server",
		"class": "",
		"aliases": {},
		"iconifyApiEndpoint": "https://api.iconify.design",
		"localApiEndpoint": "/api/_nuxt_icon",
		"fallbackToApi": true,
		"cssSelectorPrefix": "i-",
		"cssWherePseudo": true,
		"mode": "css",
		"attrs": { "aria-hidden": true },
		"collections": [
			"academicons",
			"akar-icons",
			"ant-design",
			"arcticons",
			"basil",
			"bi",
			"bitcoin-icons",
			"bpmn",
			"brandico",
			"bx",
			"bxl",
			"bxs",
			"bytesize",
			"carbon",
			"catppuccin",
			"cbi",
			"charm",
			"ci",
			"cib",
			"cif",
			"cil",
			"circle-flags",
			"circum",
			"clarity",
			"codex",
			"codicon",
			"covid",
			"cryptocurrency",
			"cryptocurrency-color",
			"cuida",
			"dashicons",
			"devicon",
			"devicon-plain",
			"dinkie-icons",
			"duo-icons",
			"ei",
			"el",
			"emojione",
			"emojione-monotone",
			"emojione-v1",
			"entypo",
			"entypo-social",
			"eos-icons",
			"ep",
			"et",
			"eva",
			"f7",
			"fa",
			"fa-brands",
			"fa-regular",
			"fa-solid",
			"fa6-brands",
			"fa6-regular",
			"fa6-solid",
			"fa7-brands",
			"fa7-regular",
			"fa7-solid",
			"fad",
			"famicons",
			"fe",
			"feather",
			"file-icons",
			"flag",
			"flagpack",
			"flat-color-icons",
			"flat-ui",
			"flowbite",
			"fluent",
			"fluent-color",
			"fluent-emoji",
			"fluent-emoji-flat",
			"fluent-emoji-high-contrast",
			"fluent-mdl2",
			"fontelico",
			"fontisto",
			"formkit",
			"foundation",
			"fxemoji",
			"gala",
			"game-icons",
			"garden",
			"geo",
			"gg",
			"gis",
			"gravity-ui",
			"gridicons",
			"grommet-icons",
			"guidance",
			"healthicons",
			"heroicons",
			"heroicons-outline",
			"heroicons-solid",
			"hugeicons",
			"humbleicons",
			"ic",
			"icomoon-free",
			"icon-park",
			"icon-park-outline",
			"icon-park-solid",
			"icon-park-twotone",
			"iconamoon",
			"iconoir",
			"icons8",
			"il",
			"ion",
			"iwwa",
			"ix",
			"jam",
			"la",
			"lets-icons",
			"line-md",
			"lineicons",
			"logos",
			"ls",
			"lsicon",
			"lucide",
			"lucide-lab",
			"mage",
			"majesticons",
			"maki",
			"map",
			"marketeq",
			"material-icon-theme",
			"material-symbols",
			"material-symbols-light",
			"mdi",
			"mdi-light",
			"medical-icon",
			"memory",
			"meteocons",
			"meteor-icons",
			"mi",
			"mingcute",
			"mono-icons",
			"mynaui",
			"nimbus",
			"nonicons",
			"noto",
			"noto-v1",
			"nrk",
			"octicon",
			"oi",
			"ooui",
			"openmoji",
			"oui",
			"pajamas",
			"pepicons",
			"pepicons-pencil",
			"pepicons-pop",
			"pepicons-print",
			"ph",
			"picon",
			"pixel",
			"pixelarticons",
			"prime",
			"proicons",
			"ps",
			"qlementine-icons",
			"quill",
			"radix-icons",
			"raphael",
			"ri",
			"rivet-icons",
			"roentgen",
			"si",
			"si-glyph",
			"sidekickicons",
			"simple-icons",
			"simple-line-icons",
			"skill-icons",
			"solar",
			"stash",
			"streamline",
			"streamline-block",
			"streamline-color",
			"streamline-cyber",
			"streamline-cyber-color",
			"streamline-emojis",
			"streamline-flex",
			"streamline-flex-color",
			"streamline-freehand",
			"streamline-freehand-color",
			"streamline-kameleon-color",
			"streamline-logos",
			"streamline-pixel",
			"streamline-plump",
			"streamline-plump-color",
			"streamline-sharp",
			"streamline-sharp-color",
			"streamline-stickies-color",
			"streamline-ultimate",
			"streamline-ultimate-color",
			"subway",
			"svg-spinners",
			"system-uicons",
			"tabler",
			"tdesign",
			"teenyicons",
			"temaki",
			"token",
			"token-branded",
			"topcoat",
			"twemoji",
			"typcn",
			"uil",
			"uim",
			"uis",
			"uit",
			"uiw",
			"unjs",
			"vaadin",
			"vs",
			"vscode-icons",
			"websymbol",
			"weui",
			"whh",
			"wi",
			"wpf",
			"zmdi",
			"zondicons"
		],
		"fetchTimeout": 1500
	}
});
//#endregion
//#region node_modules/nuxt/dist/app/config.js
function useAppConfig() {
	const nuxtApp = useNuxtApp();
	nuxtApp._appConfig ||= klona(virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fapp_config_default);
	return nuxtApp._appConfig;
}
//#endregion
//#region node_modules/nuxt/dist/app/utils/debounce-tick.js
/**
* Debounce an async function so that repeated calls within the same tick are
* collapsed into a single call (plus a trailing call if arguments arrived
* while the debounced call was still pending).
*
* Adapted from https://github.com/unjs/perfect-debounce with the timeout
* replaced by Vue's post-flush callback queue.
*/
function debounceTick(fn, options = {}) {
	let leadingValue;
	let active = false;
	let resolveList = [];
	let currentPromise;
	let trailingArgs;
	const applyFn = (_this, args) => {
		const promise = _applyPromised(fn, _this, args);
		currentPromise = promise;
		promise.finally(() => {
			currentPromise = void 0;
			if (trailingArgs && !active) {
				const args = trailingArgs;
				trailingArgs = void 0;
				applyFn(_this, args);
			}
		});
		return promise;
	};
	return function(...args) {
		trailingArgs = args;
		if (currentPromise) return currentPromise;
		return new Promise((resolve) => {
			const shouldCallNow = options.leading && !active;
			if (!active) {
				active = true;
				queuePostFlushCb(() => {
					active = false;
					const flushArgs = trailingArgs ?? args;
					trailingArgs = void 0;
					const promise = options.leading ? leadingValue : applyFn(this, flushArgs);
					for (const _resolve of resolveList) _resolve(promise);
					resolveList = [];
				});
			}
			if (shouldCallNow) {
				leadingValue = applyFn(this, args);
				resolve(leadingValue);
			} else resolveList.push(resolve);
		});
	};
}
async function _applyPromised(fn, _this, args) {
	return await fn.apply(_this, args);
}
//#endregion
//#region node_modules/nuxt/dist/app/components/server-placeholder.js
var ServerPlaceholder = defineComponent({
	name: "ServerPlaceholder",
	render() {
		return createElementBlock("div");
	}
});
//#endregion
//#region node_modules/nuxt/dist/app/components/client-only.js
var clientOnlySymbol = Symbol.for("nuxt:client-only");
defineComponent({
	name: "ClientOnly",
	inheritAttrs: false,
	props: [
		"fallback",
		"placeholder",
		"placeholderTag",
		"fallbackTag"
	],
	setup(props, { slots, attrs }) {
		const mounted = shallowRef(false);
		const vm = getCurrentInstance();
		if (vm) vm._nuxtClientOnly = true;
		provide(clientOnlySymbol, true);
		return () => {
			if (mounted.value) {
				const vnodes = slots.default?.();
				if (vnodes && vnodes.length === 1) return [cloneVNode(vnodes[0], attrs)];
				return vnodes;
			}
			const slot = slots.fallback || slots.placeholder;
			if (slot) return h(slot);
			const fallbackStr = props.fallback || props.placeholder || "";
			const fallbackTag = sanitizeTag(props.fallbackTag || props.placeholderTag, "span");
			return createElementBlock(fallbackTag, attrs, fallbackStr);
		};
	}
});
//#endregion
//#region node_modules/nuxt/dist/compiler/runtime/index.js
/**
* Define a factory for a function that should be registered for automatic key injection.
* @since 4.2.0
* @param factory
*/
function defineKeyedFunctionFactory(factory) {
	const placeholder = function() {
		throw appDiagnostics.NUXT_E1007({ name: factory.name });
	};
	return Object.defineProperty(placeholder, "__nuxt_factory", {
		enumerable: false,
		get: () => factory.factory
	});
}
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/data.js
/**
* E3xxx
* Data fetching (useFetch / useAsyncData) runtime diagnostics.
*/
var dataDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region node_modules/nuxt/dist/app/composables/asyncData.js
var createUseAsyncData = defineKeyedFunctionFactory({
	name: "createUseAsyncData",
	factory(options = {}) {
		function useAsyncData(...args) {
			const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
			if (_isAutoKeyNeeded(args[0], args[1])) args.unshift(autoKey);
			let [_key, _handler, opts = {}] = args;
			const key = isRef(_key) || typeof _key === "function" ? computed(() => toValue(_key)) : { value: _key };
			if (!key.value || typeof key.value !== "string") throw dataDiagnostics.NUXT_E3008();
			if (typeof _handler !== "function") throw dataDiagnostics.NUXT_E3009();
			const shouldFactoryOptionsOverride = typeof options === "function";
			const nuxtApp = useNuxtApp();
			const factoryOptions = shouldFactoryOptionsOverride ? options(opts) : options;
			if (!shouldFactoryOptionsOverride) for (const key in factoryOptions) {
				if (factoryOptions[key] === void 0) continue;
				if (opts[key] !== void 0) continue;
				opts[key] = factoryOptions[key];
			}
			opts.server ??= true;
			opts.default ??= getDefault;
			opts.getCachedData ??= getDefaultCachedData;
			opts.lazy ??= false;
			opts.immediate ??= true;
			opts.deep ??= asyncDataDefaults.deep;
			opts.dedupe ??= "cancel";
			opts.enabled ??= true;
			if (shouldFactoryOptionsOverride) for (const key in factoryOptions) {
				if (factoryOptions[key] === void 0) continue;
				opts[key] = factoryOptions[key];
			}
			nuxtApp._asyncData[key.value];
			function createInitialFetch() {
				const initialFetchOptions = {
					cause: "initial",
					dedupe: opts.dedupe
				};
				const existing = nuxtApp._asyncData[key.value];
				if (!existing?._init) {
					initialFetchOptions.cachedData = opts.getCachedData(key.value, nuxtApp, { cause: "initial" });
					nuxtApp._asyncData[key.value] = buildAsyncData(nuxtApp, key.value, _handler, opts, initialFetchOptions.cachedData);
					nuxtApp._asyncData[key.value]._initialCachedData = initialFetchOptions.cachedData;
				} else if (nuxtApp._asyncDataPromises[key.value]) initialFetchOptions.cachedData = existing._initialCachedData;
				return () => nuxtApp._asyncData[key.value].execute(initialFetchOptions);
			}
			const initialFetch = createInitialFetch();
			const asyncData = nuxtApp._asyncData[key.value];
			asyncData._deps++;
			if (opts.server !== false && nuxtApp.payload.serverRendered && opts.immediate) {
				const promise = initialFetch();
				if (getCurrentInstance()) onServerPrefetch(() => promise);
				else nuxtApp.hook("app:created", async () => {
					await promise;
				});
			}
			const asyncReturn = {
				data: writableComputedRef(() => nuxtApp._asyncData[key.value]?.data),
				pending: writableComputedRef(() => nuxtApp._asyncData[key.value]?.pending),
				status: writableComputedRef(() => nuxtApp._asyncData[key.value]?.status),
				error: writableComputedRef(() => nuxtApp._asyncData[key.value]?.error),
				refresh: (...args) => {
					if (!nuxtApp._asyncData[key.value]?._init) return createInitialFetch()();
					return nuxtApp._asyncData[key.value].execute(...args);
				},
				execute: (...args) => asyncReturn.refresh(...args),
				clear: () => {
					const entry = nuxtApp._asyncData[key.value];
					if (entry?._abortController) try {
						entry._abortController.abort(new DOMException("AsyncData aborted by user.", "AbortError"));
					} finally {
						entry._abortController = void 0;
					}
					clearNuxtDataByKey(nuxtApp, key.value);
				}
			};
			const asyncDataPromise = Promise.resolve(nuxtApp._asyncDataPromises[key.value]).then(() => asyncReturn);
			Object.assign(asyncDataPromise, asyncReturn);
			Object.defineProperties(asyncDataPromise, {
				then: {
					enumerable: true,
					value: asyncDataPromise.then.bind(asyncDataPromise)
				},
				catch: {
					enumerable: true,
					value: asyncDataPromise.catch.bind(asyncDataPromise)
				},
				finally: {
					enumerable: true,
					value: asyncDataPromise.finally.bind(asyncDataPromise)
				}
			});
			return asyncDataPromise;
		}
		return useAsyncData;
	}
});
var useAsyncData = createUseAsyncData.__nuxt_factory();
createUseAsyncData.__nuxt_factory({
	lazy: true,
	_functionName: "useLazyAsyncData"
});
function writableComputedRef(getter) {
	return computed({
		get() {
			return getter()?.value;
		},
		set(value) {
			const ref = getter();
			if (ref) ref.value = value;
		}
	});
}
function _isAutoKeyNeeded(keyOrFetcher, fetcher) {
	if (typeof keyOrFetcher === "string") return false;
	if (typeof keyOrFetcher === "object" && keyOrFetcher !== null) return false;
	if (typeof keyOrFetcher === "function" && typeof fetcher === "function") return false;
	return true;
}
function clearNuxtDataByKey(nuxtApp, key) {
	delete nuxtApp.payload.data[key];
	delete nuxtApp.payload._errors[key];
	if (nuxtApp._asyncData[key]) {
		nuxtApp._asyncData[key].data.value = unref(nuxtApp._asyncData[key]._default());
		nuxtApp._asyncData[key].error.value = void 0;
		nuxtApp._asyncData[key].status.value = "idle";
		nuxtApp._asyncData[key]._initialCachedData = void 0;
	}
	delete nuxtApp._asyncDataPromises[key];
}
function pick(obj, keys) {
	const newObj = {};
	for (const key of keys) newObj[key] = obj[key];
	return newObj;
}
function buildAsyncData(nuxtApp, key, _handler, options, initialCachedData) {
	nuxtApp.payload._errors[key] ??= void 0;
	const hasCustomGetCachedData = options.getCachedData !== getDefaultCachedData;
	const handler = _handler ;
	const _ref = options.deep ? ref : shallowRef;
	const hasCachedData = initialCachedData !== void 0;
	const unsubRefreshAsyncData = nuxtApp.hook("app:data:refresh", async (keys) => {
		if (!keys || keys.includes(key)) await asyncData.execute({ cause: "refresh:hook" });
	});
	const asyncData = {
		data: _ref(hasCachedData ? initialCachedData : options.default()),
		pending: computed(() => asyncData.status.value === "pending"),
		error: toRef(nuxtApp.payload._errors, key),
		status: shallowRef("idle"),
		execute: (...args) => {
			const [_opts, newValue = void 0] = args;
			const opts = _opts && newValue === void 0 && typeof _opts === "object" ? _opts : {};
			if (nuxtApp._asyncDataPromises[key]) {
				if ((opts.dedupe ?? options.dedupe) === "defer") return nuxtApp._asyncDataPromises[key];
			}
			{
				const cachedData = "cachedData" in opts ? opts.cachedData : options.getCachedData(key, nuxtApp, { cause: opts.cause ?? "refresh:manual" });
				if (cachedData !== void 0) {
					nuxtApp.payload.data[key] = asyncData.data.value = cachedData;
					asyncData.error.value = void 0;
					asyncData.status.value = "success";
					return Promise.resolve(cachedData);
				}
			}
			if (toValue(options.enabled) === false) return Promise.resolve(asyncData.data.value);
			if (asyncData._abortController) asyncData._abortController.abort(new DOMException("AsyncData request cancelled by deduplication", "AbortError"));
			asyncData._abortController = new AbortController();
			asyncData.status.value = "pending";
			const cleanupController = new AbortController();
			const promise = new Promise((resolve, reject) => {
				try {
					const timeout = opts.timeout ?? options.timeout;
					const mergedSignal = mergeAbortSignals([asyncData._abortController?.signal, opts?.signal], cleanupController.signal, timeout);
					if (mergedSignal.aborted) {
						const reason = mergedSignal.reason;
						reject(reason instanceof Error ? reason : new DOMException(String(reason ?? "Aborted"), "AbortError"));
						return;
					}
					mergedSignal.addEventListener("abort", () => {
						const reason = mergedSignal.reason;
						reject(reason instanceof Error ? reason : new DOMException(String(reason ?? "Aborted"), "AbortError"));
					}, {
						once: true,
						signal: cleanupController.signal
					});
					return Promise.resolve(handler(nuxtApp, { signal: mergedSignal })).then(resolve, reject);
				} catch (err) {
					reject(err);
				}
			}).then(async (_result) => {
				if (nuxtApp._asyncDataPromises[key] !== promise) return;
				let result = _result;
				if (options.transform) result = await options.transform(_result);
				if (options.pick) result = pick(result, options.pick);
				nuxtApp.payload.data[key] = result;
				asyncData.data.value = result;
				asyncData.error.value = void 0;
				asyncData.status.value = "success";
			}).catch((error) => {
				if (nuxtApp._asyncDataPromises[key] !== promise) return nuxtApp._asyncDataPromises[key];
				if (asyncData._abortController?.signal.aborted) return nuxtApp._asyncDataPromises[key];
				if (typeof DOMException !== "undefined" && error instanceof DOMException && error.name === "AbortError") {
					asyncData.status.value = "idle";
					return nuxtApp._asyncDataPromises[key];
				}
				asyncData.error.value = createError$1(error);
				asyncData.data.value = unref(options.default());
				asyncData.status.value = "error";
			}).finally(() => {
				cleanupController.abort();
				if (nuxtApp._asyncDataPromises[key] === promise) delete nuxtApp._asyncDataPromises[key];
			});
			nuxtApp._asyncDataPromises[key] = promise;
			return nuxtApp._asyncDataPromises[key];
		},
		_execute: debounceTick((...args) => asyncData.execute(...args)),
		_default: options.default,
		_deps: 0,
		_init: true,
		_hash: void 0,
		_off: () => {
			unsubRefreshAsyncData();
			if (nuxtApp._asyncData[key]?._init) nuxtApp._asyncData[key]._init = false;
			if (nuxtApp._asyncDataPromises[key]) {
				asyncData._abortController?.abort(new DOMException("AsyncData request cancelled by unmount", "AbortError"));
				delete nuxtApp._asyncDataPromises[key];
				if (asyncData.status.value === "pending") asyncData.status.value = "idle";
			}
			if (!hasCustomGetCachedData) nextTick(() => {
				if (!nuxtApp._asyncData[key]?._init) {
					clearNuxtDataByKey(nuxtApp, key);
					asyncData.execute = () => Promise.resolve();
				}
			});
		}
	};
	return asyncData;
}
var getDefault = () => void 0;
var getDefaultCachedData = (key, nuxtApp, ctx) => {
	if (nuxtApp.isHydrating) return nuxtApp.payload.data[key];
	if (ctx.cause !== "refresh:manual" && ctx.cause !== "refresh:hook") return nuxtApp.static.data[key];
};
function mergeAbortSignals(signals, cleanupSignal, timeout) {
	const list = signals.filter((s) => !!s);
	if (typeof timeout === "number" && timeout >= 0) {
		const timeoutSignal = AbortSignal.timeout?.(timeout);
		if (timeoutSignal) list.push(timeoutSignal);
	}
	if (AbortSignal.any) return AbortSignal.any(list);
	const controller = new AbortController();
	for (const sig of list) if (sig.aborted) {
		const reason = sig.reason ?? new DOMException("Aborted", "AbortError");
		try {
			controller.abort(reason);
		} catch {
			controller.abort();
		}
		return controller.signal;
	}
	const onAbort = () => {
		const reason = list.find((s) => s.aborted)?.reason ?? new DOMException("Aborted", "AbortError");
		try {
			controller.abort(reason);
		} catch {
			controller.abort();
		}
	};
	for (const sig of list) sig.addEventListener?.("abort", onAbort, {
		once: true,
		signal: cleanupSignal
	});
	return controller.signal;
}
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/components/shared.js
async function loadIcon$1(name, timeout) {
	if (!name) return null;
	const _icon = getIcon(name);
	if (_icon) return _icon;
	let timeoutWarn;
	const load = loadIcon(name).catch(() => {
		console.warn(`[Icon] failed to load icon \`${name}\``);
		return null;
	});
	if (timeout > 0) await Promise.race([load, new Promise((resolve) => {
		timeoutWarn = setTimeout(() => {
			console.warn(`[Icon] loading icon \`${name}\` timed out after ${timeout}ms`);
			resolve();
		}, timeout);
	})]).finally(() => clearTimeout(timeoutWarn));
	else await load;
	return getIcon(name);
}
function useResolvedName(getName) {
	const options = useAppConfig().icon;
	const collections = (options.collections || []).sort((a, b) => b.length - a.length);
	return computed(() => {
		const name = getName();
		const bare = name.startsWith(options.cssSelectorPrefix) ? name.slice(options.cssSelectorPrefix.length) : name;
		const resolved = options.aliases?.[bare] || bare;
		if (!resolved.includes(":")) {
			const collection = collections.find((c) => resolved.startsWith(c + "-"));
			return collection ? collection + ":" + resolved.slice(collection.length + 1) : resolved;
		}
		return resolved;
	});
}
function resolveCustomizeFn(customize, globalCustomize) {
	if (customize === false) return void 0;
	if (customize === true || customize === null) return globalCustomize;
	return customize;
}
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/components/css.js
var SYMBOL_SERVER_CSS = "NUXT_ICONS_SERVER_CSS";
function escapeCssSelector(selector) {
	return selector.replace(/([^\w-])/g, "\\$1");
}
var NuxtIconCss = /* @__PURE__ */ defineComponent({
	name: "NuxtIconCss",
	props: {
		name: {
			type: String,
			required: true
		},
		customize: {
			type: [
				Function,
				Boolean,
				null
			],
			default: null,
			required: false
		}
	},
	setup(props) {
		const nuxt = useNuxtApp();
		const options = useAppConfig().icon;
		const cssClass = computed(() => props.name ? options.cssSelectorPrefix + props.name : "");
		const selector = computed(() => "." + escapeCssSelector(cssClass.value));
		function getCSS(icon, withLayer = true) {
			let iconSelector = selector.value;
			if (options.cssWherePseudo) iconSelector = `:where(${iconSelector})`;
			const css = getIconCSS(icon, {
				iconSelector,
				format: "compressed",
				customise: resolveCustomizeFn(props.customize, options.customize)
			});
			if (options.cssLayer && withLayer) return `@layer ${options.cssLayer} { ${css} }`;
			return css;
		}
		onServerPrefetch(async () => {
			if (!(useRuntimeConfig().icon || {})?.serverKnownCssClasses?.includes(cssClass.value)) {
				const icon = await loadIcon$1(props.name, options.fetchTimeout).catch(() => null);
				if (!icon) return null;
				let ssrCSS = nuxt.vueApp._context.provides[SYMBOL_SERVER_CSS];
				if (!ssrCSS) {
					ssrCSS = nuxt.vueApp._context.provides[SYMBOL_SERVER_CSS] = /* @__PURE__ */ new Map();
					nuxt.runWithContext(() => {
						useHead$1({ style: [() => {
							const sep = "";
							let css = Array.from(ssrCSS.values()).sort().join(sep);
							if (options.cssLayer) css = `@layer ${options.cssLayer} {${sep}${css}${sep}}`;
							return { innerHTML: css };
						}] }, { tagPriority: "low" });
					});
				}
				if (props.name && !ssrCSS.has(props.name)) {
					const css = getCSS(icon, false);
					ssrCSS.set(props.name, css);
				}
				return null;
			}
		});
		return () => h("span", { class: ["iconify", cssClass.value] });
	}
});
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/components/svg.js
var NuxtIconSvg = /* @__PURE__ */ defineComponent({
	name: "NuxtIconSvg",
	props: {
		name: {
			type: String,
			required: true
		},
		customize: {
			type: [
				Function,
				Boolean,
				null
			],
			default: null,
			required: false
		}
	},
	setup(props, { slots }) {
		useNuxtApp();
		const options = useAppConfig().icon;
		const name = useResolvedName(() => props.name);
		const storeKey = "i-" + name.value;
		if (name.value) onServerPrefetch(async () => {
			await useAsyncData(storeKey, async () => await loadIcon$1(name.value, options.fetchTimeout), { deep: false });
		});
		return () => h(Icon, {
			icon: name.value,
			ssr: true,
			customise: resolveCustomizeFn(props.customize, options.customize)
		}, slots);
	}
});
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/components/index.js
var components_exports = /* @__PURE__ */ __exportAll({ default: () => components_default$1 });
var components_default$1 = defineComponent({
	name: "NuxtIcon",
	props: {
		name: {
			type: String,
			required: true
		},
		mode: {
			type: String,
			required: false,
			default: null
		},
		size: {
			type: [Number, String],
			required: false,
			default: null
		},
		customize: {
			type: [
				Function,
				Boolean,
				null
			],
			default: null,
			required: false
		}
	},
	setup(props, { slots }) {
		const nuxtApp = useNuxtApp();
		const runtimeOptions = useAppConfig().icon;
		const name = useResolvedName(() => props.name);
		const component = computed(() => nuxtApp.vueApp?.component(name.value) || ((props.mode || runtimeOptions.mode) === "svg" ? NuxtIconSvg : NuxtIconCss));
		const style = computed(() => {
			const size = props.size || runtimeOptions.size;
			return size ? { fontSize: Number.isNaN(+size) ? size : size + "px" } : null;
		});
		return () => h(component.value, {
			...runtimeOptions.attrs,
			name: name.value,
			class: runtimeOptions.class,
			style: style.value,
			customize: props.customize
		}, slots);
	}
});

const componentsDAaOEnvX = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  a: defineKeyedFunctionFactory,
  i: dataDiagnostics,
  n: components_exports,
  o: ServerPlaceholder,
  r: useAsyncData,
  s: useAppConfig,
  t: components_default$1
}, Symbol.toStringTag, { value: 'Module' }));

function endIndex(str, min, len) {
	const index = str.indexOf(";", min);
	return index === -1 ? len : index;
}
function eqIndex(str, min, max) {
	const index = str.indexOf("=", min);
	return index < max ? index : -1;
}
function valueSlice(str, min, max) {
	if (min === max) return "";
	let start = min;
	let end = max;
	do {
		const code = str.charCodeAt(start);
		if (code !== 32 && code !== 9) break;
	} while (++start < end);
	while (end > start) {
		const code = str.charCodeAt(end - 1);
		if (code !== 32 && code !== 9) break;
		end--;
	}
	return str.slice(start, end);
}
const NullObject = /* @__PURE__ */ (() => {
	const C = function() {};
	C.prototype = Object.create(null);
	return C;
})();
function parse(str, options) {
	const obj = new NullObject();
	const len = str.length;
	if (len < 2) return obj;
	const dec = options?.decode || decode;
	const allowMultiple = options?.allowMultiple || false;
	let index = 0;
	do {
		const eqIdx = eqIndex(str, index, len);
		if (eqIdx === -1) break;
		const endIdx = endIndex(str, index, len);
		if (eqIdx > endIdx) {
			index = str.lastIndexOf(";", eqIdx - 1) + 1;
			continue;
		}
		const key = valueSlice(str, index, eqIdx);
		if (options?.filter && !options.filter(key)) {
			index = endIdx + 1;
			continue;
		}
		const val = dec(valueSlice(str, eqIdx + 1, endIdx));
		if (allowMultiple) {
			const existing = obj[key];
			if (existing === void 0) obj[key] = val;
			else if (Array.isArray(existing)) existing.push(val);
			else obj[key] = [existing, val];
		} else if (obj[key] === void 0) obj[key] = val;
		index = endIdx + 1;
	} while (index < len);
	return obj;
}
function decode(str) {
	if (!str.includes("%")) return str;
	try {
		return decodeURIComponent(str);
	} catch {
		return str;
	}
}

//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Ffetch.mjs
if (!globalThis.$fetch) globalThis.$fetch = $fetch$1.create({ baseURL: baseURL() });
var $fetch$2 = globalThis.$fetch;
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/state.js
/**
* E7xxx
* Payload / state / cookie runtime diagnostics.
*/
var stateDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region node_modules/nuxt/dist/app/diagnostics/manifest.js
/**
* E5xxx
* App manifest / route-rules runtime diagnostics.
*/
var manifestDiagnostics = /* #__PURE__ */ defineProdDiagnostics({
	docsBase,
	reporters: prodReporters
});
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Froute-rules.mjs
var sensitiveMatcher = /* @__PURE__ */ (() => {
	const $0 = {}, $1 = { redirect: "/sitemap_index.xml" };
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1);
		if (p === "/__sitemap__/style.xsl") r.push({ data: $0 });
		else if (p === "/sitemap.xml") r.push({ data: $1 });
		else if (p === "/sitemap_index.xml") r.push({ data: $0 });
		else if (p === "/__sitemap__/en-US.xml") r.push({ data: $0 });
		else if (p === "/__sitemap__/zh-CN.xml") r.push({ data: $0 });
		else if (p === "/_nuxt") r.push({ data: $0 });
		else if (p.charCodeAt(p.length - 1) === 47) {
			if (p === "/__sitemap__/style.xsl/") r.push({ data: $0 });
			else if (p === "/sitemap.xml/") r.push({ data: $1 });
			else if (p === "/sitemap_index.xml/") r.push({ data: $0 });
			else if (p === "/__sitemap__/en-US.xml/") r.push({ data: $0 });
			else if (p === "/__sitemap__/zh-CN.xml/") r.push({ data: $0 });
			else if (p === "/_nuxt/") r.push({ data: $0 });
		}
		return r.reverse();
	};
})();
var foldedMatcher = /* @__PURE__ */ (() => {
	const $0 = {}, $1 = { redirect: "/sitemap_index.xml" };
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1);
		if (p === "/__sitemap__/style.xsl") r.push({ data: $0 });
		else if (p === "/sitemap.xml") r.push({ data: $1 });
		else if (p === "/sitemap_index.xml") r.push({ data: $0 });
		else if (p === "/__sitemap__/en-us.xml") r.push({ data: $0 });
		else if (p === "/__sitemap__/zh-cn.xml") r.push({ data: $0 });
		else if (p === "/_nuxt") r.push({ data: $0 });
		else if (p.charCodeAt(p.length - 1) === 47) {
			if (p === "/__sitemap__/style.xsl/") r.push({ data: $0 });
			else if (p === "/sitemap.xml/") r.push({ data: $1 });
			else if (p === "/sitemap_index.xml/") r.push({ data: $0 });
			else if (p === "/__sitemap__/en-us.xml/") r.push({ data: $0 });
			else if (p === "/__sitemap__/zh-cn.xml/") r.push({ data: $0 });
			else if (p === "/_nuxt/") r.push({ data: $0 });
		}
		return r.reverse();
	};
})();
var decodeRoutePath = function decodeRoutePath(path) {
	if (!path.includes("%")) return path;
	const queryIndex = path.indexOf("?");
	const pathname = queryIndex === -1 ? path : path.slice(0, queryIndex);
	try {
		return queryIndex === -1 ? decodeURI(pathname) : decodeURI(pathname) + path.slice(queryIndex);
	} catch {
		return path;
	}
};
var normalizePath = (path, fold) => {
	if (typeof path !== "string") return path;
	const decoded = decodeRoutePath(path);
	return fold ? decoded.toLowerCase() : decoded;
};
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froute_rules_default = (path) => virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.sensitive ? defu({}, ...sensitiveMatcher("", normalizePath(path, false)).map((r) => r.data).reverse()) : defu({}, ...foldedMatcher("", normalizePath(path, true)).map((r) => r.data).reverse());
//#endregion
//#region node_modules/nuxt/dist/app/composables/manifest.js
var routeRulesMatcher = virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froute_rules_default;
function getRouteRules(arg) {
	const path = typeof arg === "string" ? arg : arg.path;
	try {
		return routeRulesMatcher(path);
	} catch (e) {
		manifestDiagnostics.NUXT_E5003({
			path,
			cause: e
		});
		return {};
	}
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/payload.js
/**
* This is an experimental function for configuring passing rich data from server -> client.
* @since 3.4.0
*/
function definePayloadReducer(name, reduce) {
	useNuxtApp().ssrContext["~payloadReducers"][name] = reduce;
}
//#endregion
//#region node_modules/nuxt/dist/app/utils/hash.js
/**
* Hash an arbitrary value into a short, stable string key.
*
* Values are serialized to a canonical, locale-independent representation
* (equal structures hash equally regardless of key order or runtime locale),
* then digested with a fast non-cryptographic hash. This is what `useFetch` and
* `useAsyncData` use internally to derive their cache keys, so it is safe to use
* for the same purpose in your own code.
*
* The digest is non-cryptographic and must not be used for integrity checks.
*
* @since 4.5.0
*/
function hashKey(value) {
	return fnv1a64Base36(identify(value));
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/state.js
var useStateKeyPrefix = "$s";
function useState(...args) {
	const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
	if (typeof args[0] !== "string") args.unshift(autoKey);
	const [_key, init] = args;
	if (!_key || typeof _key !== "string") throw stateDiagnostics.NUXT_E7009({ key: _key });
	if (init !== void 0 && typeof init !== "function") throw stateDiagnostics.NUXT_E7007({ type: typeof init });
	const key = useStateKeyPrefix + _key;
	const nuxtApp = useNuxtApp();
	const state = toRef(nuxtApp.payload.state, key);
	if (init) nuxtApp._state[key] ??= { _default: init };
	if (state.value === void 0 && init) {
		const initialValue = init();
		if (isRef(initialValue)) {
			nuxtApp.payload.state[key] = initialValue;
			return initialValue;
		}
		state.value = initialValue;
	}
	return state;
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/ssr.js
var $fetch$1$2 = $fetch$2;
/** @since 3.0.0 */
function useRequestEvent(nuxtApp) {
	nuxtApp ||= useNuxtApp();
	return nuxtApp.ssrContext?.event;
}
/** @since 3.2.0 */
function useRequestFetch() {
	return useRequestEvent()?.$fetch || $fetch$1$2;
}
/** @since 3.8.0 */
function prerenderRoutes(path) {
	return;
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/fetch.js
var $fetch$1$1 = $fetch$2;
var MAYBE_REF_OR_GETTER_OPTION_KEYS = [
	"method",
	"baseURL",
	"query",
	"params",
	"body",
	"headers"
];
function generateOptionSegments(opts) {
	const segments = [toValue(opts.method)?.toUpperCase() || "GET", toValue(opts.baseURL)];
	for (const _obj of [opts.query || opts.params]) {
		const obj = toValue(_obj);
		if (!obj) continue;
		const unwrapped = {};
		for (const [key, value] of Object.entries(obj)) unwrapped[toValue(key)] = toValue(value);
		segments.push(unwrapped);
	}
	if (opts.body) {
		const value = toValue(opts.body);
		if (!value) segments.push(hashKey(value));
		else if (value instanceof ArrayBuffer) segments.push(hashKey(Object.fromEntries([...new Uint8Array(value).entries()].map(([k, v]) => [k, v.toString()]))));
		else if (value instanceof FormData) {
			const entries = [];
			for (const entry of value.entries()) {
				const [key, val] = entry;
				entries.push([key, val instanceof File ? `${val.name}:${val.size}:${val.lastModified}` : val]);
			}
			segments.push(hashKey(entries));
		} else if (isPlainObject(value)) segments.push(hashKey(reactive(value)));
		else try {
			segments.push(hashKey(value));
		} catch {
			dataDiagnostics.NUXT_E3002({ cause: value });
		}
	}
	return segments;
}
/**
* A factory function to create a custom `useFetch` composable with pre-defined default options.
* @since 4.2.0
*/
var createUseFetch = defineKeyedFunctionFactory({
	name: "createUseFetch",
	factory(options = {}) {
		function useFetch(request, arg1, arg2) {
			const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
			const factoryOptions = typeof options === "function" ? options(opts) : options;
			const { server, lazy, default: defaultFn, transform, pick, watch: watchSources, immediate, getCachedData, deep, dedupe, timeout, enabled, ...fetchOptions } = {
				...typeof options === "function" ? {} : factoryOptions,
				...opts,
				...typeof options === "function" ? factoryOptions : {}
			};
			const _request = computed(() => toValue(request));
			const key = computed(() => toValue(fetchOptions.key) || "$f" + hashKey([
				autoKey,
				typeof _request.value === "string" ? _request.value : "",
				...generateOptionSegments(fetchOptions)
			]));
			if (!fetchOptions.baseURL && typeof _request.value === "string" && _request.value[0] === "/" && _request.value[1] === "/") throw dataDiagnostics.NUXT_E3001({ url: _request.value });
			const _fetchOptions = reactive({
				...fetchDefaults,
				...fetchOptions,
				cache: typeof fetchOptions.cache === "boolean" ? void 0 : fetchOptions.cache
			});
			const _asyncDataOptions = {
				server,
				lazy,
				default: defaultFn,
				transform,
				pick,
				immediate,
				getCachedData,
				deep,
				dedupe,
				timeout,
				enabled,
				watch: watchSources === false ? [] : [...watchSources || [], _fetchOptions]
			};
			if (watchSources === false) _asyncDataOptions._keyTriggersExecute = false;
			return useAsyncData(key, (_, { signal }) => {
				let _$fetch = fetchOptions.$fetch || $fetch$1$1;
				if (!fetchOptions.$fetch) {
					if (typeof _request.value === "string" && _request.value[0] === "/" && (!toValue(fetchOptions.baseURL) || toValue(fetchOptions.baseURL)[0] === "/")) _$fetch = useRequestFetch();
				}
				const resolvedOptions = {
					signal,
					..._fetchOptions
				};
				for (const key of MAYBE_REF_OR_GETTER_OPTION_KEYS) if (typeof resolvedOptions[key] === "function") resolvedOptions[key] = toValue(resolvedOptions[key]);
				return _$fetch(_request.value, resolvedOptions);
			}, _asyncDataOptions);
		}
		return useFetch;
	}
});
var useFetch = createUseFetch.__nuxt_factory();
createUseFetch.__nuxt_factory({
	lazy: true,
	_functionName: "useLazyFetch"
});
//#endregion
//#region node_modules/nuxt/dist/app/composables/cookie.js
function parseCookieValue(value) {
	if (value === "undefined") return;
	try {
		const parsed = JSON.parse(value);
		if (typeof parsed === "number" && String(parsed) !== value) return value;
		return parsed;
	} catch {
		return value;
	}
}
var CookieDefaults = {
	path: "/",
	watch: true,
	decode: (val) => val ? parseCookieValue(decodeURIComponent(val)) : val,
	encode: (val) => {
		if (typeof val !== "string" || val === "undefined") return encodeURIComponent(JSON.stringify(val));
		try {
			if (typeof JSON.parse(val) !== "string") return encodeURIComponent(JSON.stringify(val));
		} catch {}
		return encodeURIComponent(val);
	},
	refresh: false
};
function useCookie(name, _opts) {
	const opts = {
		...CookieDefaults,
		..._opts
	};
	opts.filter ??= (key) => key === name;
	const cookies = readRawCookies(opts) || {};
	let delay;
	if (opts.maxAge !== void 0) delay = opts.maxAge * 1e3;
	else if (opts.expires) delay = opts.expires.getTime() - Date.now();
	const cookie = cookieServerRef(name, klona(delay !== void 0 && delay <= 0 ? void 0 : cookies[name] ?? opts.default?.()));
	{
		const nuxtApp = useNuxtApp();
		const writeFinalCookieValue = () => {
			const valueIsSame = isEqual(cookie.value, cookies[name]);
			if (opts.readonly || valueIsSame && !opts.refresh) return;
			nuxtApp._cookiesChanged ||= {};
			if (valueIsSame && opts.refresh && !nuxtApp._cookiesChanged[name]) return;
			nuxtApp._cookies ||= {};
			if (name in nuxtApp._cookies) {
				if (isEqual(cookie.value, nuxtApp._cookies[name])) return;
			}
			nuxtApp._cookies[name] = cookie.value;
			const encoded = cookie.value === null || cookie.value === void 0 ? void 0 : opts.encode(cookie.value);
			writeServerCookie(useRequestEvent(nuxtApp), name, encoded, opts);
		};
		const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
		nuxtApp.hooks.hookOnce("app:error", () => {
			unhook();
			return writeFinalCookieValue();
		});
	}
	return cookie;
}
function readRawCookies(opts = {}) {
	return parse(getRequestHeader(useRequestEvent(), "cookie") || "", opts);
}
var identityEncode = (val) => val;
function toSerializeOptions(opts) {
	const { encode: _encode, decode: _decode, ...rest } = opts;
	return {
		...rest,
		encode: identityEncode
	};
}
function writeServerCookie(event, name, value, opts = {}) {
	if (event) {
		const serializeOpts = toSerializeOptions(opts);
		if (value !== void 0) return setCookie(event, name, value, serializeOpts);
		if (getCookie(event, name) !== void 0) return deleteCookie(event, name, serializeOpts);
	}
}
/**
* Custom ref that tracks explicit cookie writes on the server.
*
* This is required for the `refresh` option to ensure the cookie is
* re-written on SSR even when the value remains unchanged.
*/
function cookieServerRef(name, value) {
	const internalRef = ref(value);
	const nuxtApp = useNuxtApp();
	return customRef((track, trigger) => {
		return {
			get() {
				track();
				return internalRef.value;
			},
			set(newValue) {
				nuxtApp._cookiesChanged ||= {};
				nuxtApp._cookiesChanged[name] = true;
				internalRef.value = newValue;
				trigger();
			}
		};
	});
}
//#endregion
//#region node_modules/nuxt/dist/app/composables/url.js
/** @since 3.5.0 */
function useRequestURL(opts) {
	return getRequestURL(useRequestEvent(), opts);
}
//#endregion
//#region node_modules/@intlify/shared/dist/shared.mjs
/*!
* shared v11.3.2
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
function warn(msg, err) {
	if (typeof console !== "undefined") {
		console.warn(`[intlify] ` + msg);
		/* istanbul ignore if */
		if (err) console.warn(err.stack);
	}
}
var makeSymbol = (name, shareable = false) => !shareable ? Symbol(name) : Symbol.for(name);
var generateFormatCacheKey = (locale, key, source) => friendlyJSONstringify({
	l: locale,
	k: key,
	s: source
});
var friendlyJSONstringify = (json) => JSON.stringify(json).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027");
var isNumber = (val) => typeof val === "number" && isFinite(val);
var isDate = (val) => toTypeString(val) === "[object Date]";
var isRegExp = (val) => toTypeString(val) === "[object RegExp]";
var isEmptyObject = (val) => isPlainObject$1(val) && Object.keys(val).length === 0;
var assign = Object.assign;
var _create = Object.create;
var create = (obj = null) => _create(obj);
function escapeHtml(rawText) {
	return rawText.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/\//g, "&#x2F;").replace(/=/g, "&#x3D;");
}
function escapeAttributeValue(value) {
	return value.replace(/&(?![a-zA-Z0-9#]{2,6};)/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function sanitizeTranslatedHtml(html) {
	html = html.replace(/(\w+)\s*=\s*"([^"]*)"/g, (_, attrName, attrValue) => `${attrName}="${escapeAttributeValue(attrValue)}"`);
	html = html.replace(/(\w+)\s*=\s*'([^']*)'/g, (_, attrName, attrValue) => `${attrName}='${escapeAttributeValue(attrValue)}'`);
	if (/\s*on\w+\s*=\s*["']?[^"'>]+["']?/gi.test(html)) html = html.replace(/(\s+)(on)(\w+\s*=)/gi, "$1&#111;n$3");
	[/(\s+(?:href|src|action|formaction)\s*=\s*["']?)\s*javascript:/gi, /(style\s*=\s*["'][^"']*url\s*\(\s*)javascript:/gi].forEach((pattern) => {
		html = html.replace(pattern, "$1javascript&#58;");
	});
	return html;
}
var hasOwnProperty = Object.prototype.hasOwnProperty;
function hasOwn(obj, key) {
	return hasOwnProperty.call(obj, key);
}
/**
* Useful Utilities By Evan you
* Modified by kazuya kawaguchi
* MIT License
* https://github.com/vuejs/vue-next/blob/master/packages/shared/src/index.ts
* https://github.com/vuejs/vue-next/blob/master/packages/shared/src/codeframe.ts
*/
var isArray = Array.isArray;
var isFunction = (val) => typeof val === "function";
var isString = (val) => typeof val === "string";
var isBoolean = (val) => typeof val === "boolean";
var isObject = (val) => val !== null && typeof val === "object";
var isPromise = (val) => {
	return isObject(val) && isFunction(val.then) && isFunction(val.catch);
};
var objectToString = Object.prototype.toString;
var toTypeString = (value) => objectToString.call(value);
var isPlainObject$1 = (val) => toTypeString(val) === "[object Object]";
var toDisplayString$1 = (val) => {
	return val == null ? "" : isArray(val) || isPlainObject$1(val) && val.toString === objectToString ? JSON.stringify(val, null, 2) : String(val);
};
function join(items, separator = "") {
	return items.reduce((str, item, index) => index === 0 ? str + item : str + separator + item, "");
}
var isNotObjectOrIsArray = (val) => !isObject(val) || isArray(val);
function deepCopy(src, des) {
	if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) throw new Error("Invalid value");
	const stack = [{
		src,
		des
	}];
	while (stack.length) {
		const { src, des } = stack.pop();
		Object.keys(src).forEach((key) => {
			if (key === "__proto__") return;
			if (isObject(src[key]) && !isObject(des[key])) des[key] = Array.isArray(src[key]) ? [] : create();
			if (isNotObjectOrIsArray(des[key]) || isNotObjectOrIsArray(src[key])) des[key] = src[key];
			else stack.push({
				src: src[key],
				des: des[key]
			});
		});
	}
}
//#endregion
//#region node_modules/@intlify/message-compiler/dist/message-compiler.mjs
/*!
* message-compiler v11.3.2
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
function createPosition(line, column, offset) {
	return {
		line,
		column,
		offset
	};
}
function createLocation(start, end, source) {
	const loc = {
		start,
		end
	};
	return loc;
}
var CompileErrorCodes = {
	EXPECTED_TOKEN: 1,
	INVALID_TOKEN_IN_PLACEHOLDER: 2,
	UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
	UNKNOWN_ESCAPE_SEQUENCE: 4,
	INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
	UNBALANCED_CLOSING_BRACE: 6,
	UNTERMINATED_CLOSING_BRACE: 7,
	EMPTY_PLACEHOLDER: 8,
	NOT_ALLOW_NEST_PLACEHOLDER: 9,
	INVALID_LINKED_FORMAT: 10,
	MUST_HAVE_MESSAGES_IN_PLURAL: 11,
	UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
	UNEXPECTED_EMPTY_LINKED_KEY: 13,
	UNEXPECTED_LEXICAL_ANALYSIS: 14};
function createCompileError(code, loc, options = {}) {
	const { domain, messages, args } = options;
	const error = new SyntaxError(String(code));
	error.code = code;
	if (loc) error.location = loc;
	error.domain = domain;
	return error;
}
/** @internal */
function defaultOnError(error) {
	throw error;
}
var CHAR_SP = " ";
var CHAR_CR = "\r";
var CHAR_LF = "\n";
var CHAR_LS = String.fromCharCode(8232);
var CHAR_PS = String.fromCharCode(8233);
function createScanner(str) {
	const _buf = str;
	let _index = 0;
	let _line = 1;
	let _column = 1;
	let _peekOffset = 0;
	const isCRLF = (index) => _buf[index] === CHAR_CR && _buf[index + 1] === CHAR_LF;
	const isLF = (index) => _buf[index] === CHAR_LF;
	const isPS = (index) => _buf[index] === CHAR_PS;
	const isLS = (index) => _buf[index] === CHAR_LS;
	const isLineEnd = (index) => isCRLF(index) || isLF(index) || isPS(index) || isLS(index);
	const index = () => _index;
	const line = () => _line;
	const column = () => _column;
	const peekOffset = () => _peekOffset;
	const charAt = (offset) => isCRLF(offset) || isPS(offset) || isLS(offset) ? CHAR_LF : _buf[offset];
	const currentChar = () => charAt(_index);
	const currentPeek = () => charAt(_index + _peekOffset);
	function next() {
		_peekOffset = 0;
		if (isLineEnd(_index)) {
			_line++;
			_column = 0;
		}
		if (isCRLF(_index)) _index++;
		_index++;
		_column++;
		return _buf[_index];
	}
	function peek() {
		if (isCRLF(_index + _peekOffset)) _peekOffset++;
		_peekOffset++;
		return _buf[_index + _peekOffset];
	}
	function reset() {
		_index = 0;
		_line = 1;
		_column = 1;
		_peekOffset = 0;
	}
	function resetPeek(offset = 0) {
		_peekOffset = offset;
	}
	function skipToPeek() {
		const target = _index + _peekOffset;
		while (target !== _index) next();
		_peekOffset = 0;
	}
	return {
		index,
		line,
		column,
		peekOffset,
		charAt,
		currentChar,
		currentPeek,
		next,
		peek,
		reset,
		resetPeek,
		skipToPeek
	};
}
var EOF = void 0;
var DOT = ".";
var LITERAL_DELIMITER = "'";
var ERROR_DOMAIN$3 = "tokenizer";
function createTokenizer(source, options = {}) {
	const location = options.location !== false;
	const _scnr = createScanner(source);
	const currentOffset = () => _scnr.index();
	const currentPosition = () => createPosition(_scnr.line(), _scnr.column(), _scnr.index());
	const _initLoc = currentPosition();
	const _initOffset = currentOffset();
	const _context = {
		currentType: 13,
		offset: _initOffset,
		startLoc: _initLoc,
		endLoc: _initLoc,
		lastType: 13,
		lastOffset: _initOffset,
		lastStartLoc: _initLoc,
		lastEndLoc: _initLoc,
		braceNest: 0,
		inLinked: false,
		text: ""
	};
	const context = () => _context;
	const { onError } = options;
	function emitError(code, pos, offset, ...args) {
		const ctx = context();
		pos.column += offset;
		pos.offset += offset;
		if (onError) {
			const err = createCompileError(code, location ? createLocation(ctx.startLoc, pos) : null, {
				domain: ERROR_DOMAIN$3,
				args
			});
			onError(err);
		}
	}
	function getToken(context, type, value) {
		context.endLoc = currentPosition();
		context.currentType = type;
		const token = { type };
		if (location) token.loc = createLocation(context.startLoc, context.endLoc);
		if (value != null) token.value = value;
		return token;
	}
	const getEndToken = (context) => getToken(context, 13);
	function eat(scnr, ch) {
		if (scnr.currentChar() === ch) {
			scnr.next();
			return ch;
		} else {
			emitError(CompileErrorCodes.EXPECTED_TOKEN, currentPosition(), 0, ch);
			return "";
		}
	}
	function peekSpaces(scnr) {
		let buf = "";
		while (scnr.currentPeek() === CHAR_SP || scnr.currentPeek() === CHAR_LF) {
			buf += scnr.currentPeek();
			scnr.peek();
		}
		return buf;
	}
	function skipSpaces(scnr) {
		const buf = peekSpaces(scnr);
		scnr.skipToPeek();
		return buf;
	}
	function isIdentifierStart(ch) {
		if (ch === EOF) return false;
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc === 95;
	}
	function isNumberStart(ch) {
		if (ch === EOF) return false;
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57;
	}
	function isNamedIdentifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) return false;
		peekSpaces(scnr);
		const ret = isIdentifierStart(scnr.currentPeek());
		scnr.resetPeek();
		return ret;
	}
	function isListIdentifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) return false;
		peekSpaces(scnr);
		const ret = isNumberStart(scnr.currentPeek() === "-" ? scnr.peek() : scnr.currentPeek());
		scnr.resetPeek();
		return ret;
	}
	function isLiteralStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) return false;
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === LITERAL_DELIMITER;
		scnr.resetPeek();
		return ret;
	}
	function isLinkedDotStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 7) return false;
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === ".";
		scnr.resetPeek();
		return ret;
	}
	function isLinkedModifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 8) return false;
		peekSpaces(scnr);
		const ret = isIdentifierStart(scnr.currentPeek());
		scnr.resetPeek();
		return ret;
	}
	function isLinkedDelimiterStart(scnr, context) {
		const { currentType } = context;
		if (!(currentType === 7 || currentType === 11)) return false;
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === ":";
		scnr.resetPeek();
		return ret;
	}
	function isLinkedReferStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 9) return false;
		const fn = () => {
			const ch = scnr.currentPeek();
			if (ch === "{") return isIdentifierStart(scnr.peek());
			else if (ch === "@" || ch === "|" || ch === ":" || ch === "." || ch === CHAR_SP || !ch) return false;
			else if (ch === CHAR_LF) {
				scnr.peek();
				return fn();
			} else return isTextStart(scnr, false);
		};
		const ret = fn();
		scnr.resetPeek();
		return ret;
	}
	function isPluralStart(scnr) {
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === "|";
		scnr.resetPeek();
		return ret;
	}
	function isTextStart(scnr, reset = true) {
		const fn = (hasSpace = false, prev = "") => {
			const ch = scnr.currentPeek();
			if (ch === "{") return hasSpace;
			else if (ch === "@" || !ch) return hasSpace;
			else if (ch === "|") return !(prev === CHAR_SP || prev === CHAR_LF);
			else if (ch === CHAR_SP) {
				scnr.peek();
				return fn(true, CHAR_SP);
			} else if (ch === CHAR_LF) {
				scnr.peek();
				return fn(true, CHAR_LF);
			} else return true;
		};
		const ret = fn();
		reset && scnr.resetPeek();
		return ret;
	}
	function takeChar(scnr, fn) {
		const ch = scnr.currentChar();
		if (ch === EOF) return;
		if (fn(ch)) {
			scnr.next();
			return ch;
		}
		return null;
	}
	function isIdentifier(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc >= 48 && cc <= 57 || cc === 95 || cc === 36;
	}
	function takeIdentifierChar(scnr) {
		return takeChar(scnr, isIdentifier);
	}
	function isNamedIdentifier(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc >= 48 && cc <= 57 || cc === 95 || cc === 36 || cc === 45;
	}
	function takeNamedIdentifierChar(scnr) {
		return takeChar(scnr, isNamedIdentifier);
	}
	function isDigit(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57;
	}
	function takeDigit(scnr) {
		return takeChar(scnr, isDigit);
	}
	function isHexDigit(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57 || cc >= 65 && cc <= 70 || cc >= 97 && cc <= 102;
	}
	function takeHexDigit(scnr) {
		return takeChar(scnr, isHexDigit);
	}
	function getDigits(scnr) {
		let ch = "";
		let num = "";
		while (ch = takeDigit(scnr)) num += ch;
		return num;
	}
	function readText(scnr) {
		let buf = "";
		while (true) {
			const ch = scnr.currentChar();
			if (ch === "\\") {
				const nextCh = scnr.peek();
				if (nextCh === "{" || nextCh === "}" || nextCh === "@" || nextCh === "|" || nextCh === "\\") {
					buf += ch + nextCh;
					scnr.next();
					scnr.next();
				} else {
					scnr.resetPeek();
					buf += ch;
					scnr.next();
				}
			} else if (ch === "{" || ch === "}" || ch === "@" || ch === "|" || !ch) break;
			else if (ch === CHAR_SP || ch === CHAR_LF) {
				if (isTextStart(scnr)) {
					buf += ch;
					scnr.next();
				} else if (isPluralStart(scnr)) break;
				else {
					buf += ch;
					scnr.next();
				}
			} else {
				buf += ch;
				scnr.next();
			}
		}
		return buf;
	}
	function readNamedIdentifier(scnr) {
		skipSpaces(scnr);
		let ch = "";
		let name = "";
		while (ch = takeNamedIdentifierChar(scnr)) name += ch;
		const currentChar = scnr.currentChar();
		if (currentChar && currentChar !== "}" && currentChar !== EOF && currentChar !== CHAR_SP && currentChar !== CHAR_LF && currentChar !== "　") {
			const invalidPart = readInvalidIdentifier(scnr);
			emitError(CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER, currentPosition(), 0, name + invalidPart);
			return name + invalidPart;
		}
		if (scnr.currentChar() === EOF) emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
		return name;
	}
	function readListIdentifier(scnr) {
		skipSpaces(scnr);
		let value = "";
		if (scnr.currentChar() === "-") {
			scnr.next();
			value += `-${getDigits(scnr)}`;
		} else value += getDigits(scnr);
		if (scnr.currentChar() === EOF) emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
		return value;
	}
	function isLiteral(ch) {
		return ch !== LITERAL_DELIMITER && ch !== CHAR_LF;
	}
	function readLiteral(scnr) {
		skipSpaces(scnr);
		eat(scnr, `\'`);
		let ch = "";
		let literal = "";
		while (ch = takeChar(scnr, isLiteral)) if (ch === "\\") literal += readEscapeSequence(scnr);
		else literal += ch;
		const current = scnr.currentChar();
		if (current === CHAR_LF || current === EOF) {
			emitError(CompileErrorCodes.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, currentPosition(), 0);
			if (current === CHAR_LF) {
				scnr.next();
				eat(scnr, `\'`);
			}
			return literal;
		}
		eat(scnr, `\'`);
		return literal;
	}
	function readEscapeSequence(scnr) {
		const ch = scnr.currentChar();
		switch (ch) {
			case "\\":
			case `\'`:
				scnr.next();
				return `\\${ch}`;
			case "u": return readUnicodeEscapeSequence(scnr, ch, 4);
			case "U": return readUnicodeEscapeSequence(scnr, ch, 6);
			default:
				emitError(CompileErrorCodes.UNKNOWN_ESCAPE_SEQUENCE, currentPosition(), 0, ch);
				return "";
		}
	}
	function readUnicodeEscapeSequence(scnr, unicode, digits) {
		eat(scnr, unicode);
		let sequence = "";
		for (let i = 0; i < digits; i++) {
			const ch = takeHexDigit(scnr);
			if (!ch) {
				emitError(CompileErrorCodes.INVALID_UNICODE_ESCAPE_SEQUENCE, currentPosition(), 0, `\\${unicode}${sequence}${scnr.currentChar()}`);
				break;
			}
			sequence += ch;
		}
		return `\\${unicode}${sequence}`;
	}
	function isInvalidIdentifier(ch) {
		return ch !== "{" && ch !== "}" && ch !== CHAR_SP && ch !== CHAR_LF;
	}
	function readInvalidIdentifier(scnr) {
		skipSpaces(scnr);
		let ch = "";
		let identifiers = "";
		while (ch = takeChar(scnr, isInvalidIdentifier)) identifiers += ch;
		return identifiers;
	}
	function readLinkedModifier(scnr) {
		let ch = "";
		let name = "";
		while (ch = takeIdentifierChar(scnr)) name += ch;
		return name;
	}
	function readLinkedRefer(scnr) {
		const fn = (buf) => {
			const ch = scnr.currentChar();
			if (ch === "{" || ch === "@" || ch === "|" || ch === "(" || ch === ")" || !ch) return buf;
			else if (ch === CHAR_SP) return buf;
			else if (ch === CHAR_LF || ch === DOT) {
				buf += ch;
				scnr.next();
				return fn(buf);
			} else {
				buf += ch;
				scnr.next();
				return fn(buf);
			}
		};
		return fn("");
	}
	function readPlural(scnr) {
		skipSpaces(scnr);
		const plural = eat(scnr, "|");
		skipSpaces(scnr);
		return plural;
	}
	function readTokenInPlaceholder(scnr, context) {
		let token = null;
		switch (scnr.currentChar()) {
			case "{":
				if (context.braceNest >= 1) emitError(CompileErrorCodes.NOT_ALLOW_NEST_PLACEHOLDER, currentPosition(), 0);
				scnr.next();
				token = getToken(context, 2, "{");
				skipSpaces(scnr);
				context.braceNest++;
				return token;
			case "}":
				if (context.braceNest > 0 && context.currentType === 2) emitError(CompileErrorCodes.EMPTY_PLACEHOLDER, currentPosition(), 0);
				scnr.next();
				token = getToken(context, 3, "}");
				context.braceNest--;
				context.braceNest > 0 && skipSpaces(scnr);
				if (context.inLinked && context.braceNest === 0) context.inLinked = false;
				return token;
			case "@":
				if (context.braceNest > 0) emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
				token = readTokenInLinked(scnr, context) || getEndToken(context);
				context.braceNest = 0;
				return token;
			default: {
				let validNamedIdentifier = true;
				let validListIdentifier = true;
				let validLiteral = true;
				if (isPluralStart(scnr)) {
					if (context.braceNest > 0) emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
					token = getToken(context, 1, readPlural(scnr));
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (context.braceNest > 0 && (context.currentType === 4 || context.currentType === 5 || context.currentType === 6)) {
					emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
					context.braceNest = 0;
					return readToken(scnr, context);
				}
				if (validNamedIdentifier = isNamedIdentifierStart(scnr, context)) {
					token = getToken(context, 4, readNamedIdentifier(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (validListIdentifier = isListIdentifierStart(scnr, context)) {
					token = getToken(context, 5, readListIdentifier(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (validLiteral = isLiteralStart(scnr, context)) {
					token = getToken(context, 6, readLiteral(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (!validNamedIdentifier && !validListIdentifier && !validLiteral) {
					token = getToken(context, 12, readInvalidIdentifier(scnr));
					emitError(CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER, currentPosition(), 0, token.value);
					skipSpaces(scnr);
					return token;
				}
				break;
			}
		}
		return token;
	}
	function readTokenInLinked(scnr, context) {
		const { currentType } = context;
		let token = null;
		const ch = scnr.currentChar();
		if ((currentType === 7 || currentType === 8 || currentType === 11 || currentType === 9) && (ch === CHAR_LF || ch === CHAR_SP)) emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
		switch (ch) {
			case "@":
				scnr.next();
				token = getToken(context, 7, "@");
				context.inLinked = true;
				return token;
			case ".":
				skipSpaces(scnr);
				scnr.next();
				return getToken(context, 8, ".");
			case ":":
				skipSpaces(scnr);
				scnr.next();
				return getToken(context, 9, ":");
			default:
				if (isPluralStart(scnr)) {
					token = getToken(context, 1, readPlural(scnr));
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (isLinkedDotStart(scnr, context) || isLinkedDelimiterStart(scnr, context)) {
					skipSpaces(scnr);
					return readTokenInLinked(scnr, context);
				}
				if (isLinkedModifierStart(scnr, context)) {
					skipSpaces(scnr);
					return getToken(context, 11, readLinkedModifier(scnr));
				}
				if (isLinkedReferStart(scnr, context)) {
					skipSpaces(scnr);
					if (ch === "{") return readTokenInPlaceholder(scnr, context) || token;
					else return getToken(context, 10, readLinkedRefer(scnr));
				}
				if (currentType === 7) emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
				context.braceNest = 0;
				context.inLinked = false;
				return readToken(scnr, context);
		}
	}
	function readToken(scnr, context) {
		let token = { type: 13 };
		if (context.braceNest > 0) return readTokenInPlaceholder(scnr, context) || getEndToken(context);
		if (context.inLinked) return readTokenInLinked(scnr, context) || getEndToken(context);
		switch (scnr.currentChar()) {
			case "{": return readTokenInPlaceholder(scnr, context) || getEndToken(context);
			case "}":
				emitError(CompileErrorCodes.UNBALANCED_CLOSING_BRACE, currentPosition(), 0);
				scnr.next();
				return getToken(context, 3, "}");
			case "@": return readTokenInLinked(scnr, context) || getEndToken(context);
			default:
				if (isPluralStart(scnr)) {
					token = getToken(context, 1, readPlural(scnr));
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (isTextStart(scnr)) return getToken(context, 0, readText(scnr));
		}
		return token;
	}
	function nextToken() {
		const { currentType, offset, startLoc, endLoc } = _context;
		_context.lastType = currentType;
		_context.lastOffset = offset;
		_context.lastStartLoc = startLoc;
		_context.lastEndLoc = endLoc;
		_context.offset = currentOffset();
		_context.startLoc = currentPosition();
		if (_scnr.currentChar() === EOF) return getToken(_context, 13);
		return readToken(_scnr, _context);
	}
	return {
		nextToken,
		currentOffset,
		currentPosition,
		context
	};
}
var ERROR_DOMAIN$2 = "parser";
var KNOWN_ESCAPES = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;
var TEXT_ESCAPES = /\\([\\@{}|])/g;
function fromTextEscapeSequence(_match, char) {
	return char;
}
function fromEscapeSequence(match, codePoint4, codePoint6) {
	switch (match) {
		case `\\\\`: return `\\`;
		case `\\\'`: return `\'`;
		default: {
			const codePoint = parseInt(codePoint4 || codePoint6, 16);
			if (codePoint <= 55295 || codePoint >= 57344) return String.fromCodePoint(codePoint);
			return "�";
		}
	}
}
function createParser(options = {}) {
	const location = options.location !== false;
	const { onError } = options;
	function emitError(tokenzer, code, start, offset, ...args) {
		const end = tokenzer.currentPosition();
		end.offset += offset;
		end.column += offset;
		if (onError) {
			const err = createCompileError(code, location ? createLocation(start, end) : null, {
				domain: ERROR_DOMAIN$2,
				args
			});
			onError(err);
		}
	}
	function startNode(type, offset, loc) {
		const node = { type };
		if (location) {
			node.start = offset;
			node.end = offset;
			node.loc = {
				start: loc,
				end: loc
			};
		}
		return node;
	}
	function endNode(node, offset, pos, type) {
		if (location) {
			node.end = offset;
			if (node.loc) node.loc.end = pos;
		}
	}
	function parseText(tokenizer, value) {
		const context = tokenizer.context();
		const node = startNode(3, context.offset, context.startLoc);
		node.value = value.replace(TEXT_ESCAPES, fromTextEscapeSequence);
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseList(tokenizer, index) {
		const { lastOffset: offset, lastStartLoc: loc } = tokenizer.context();
		const node = startNode(5, offset, loc);
		node.index = parseInt(index, 10);
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseNamed(tokenizer, key) {
		const { lastOffset: offset, lastStartLoc: loc } = tokenizer.context();
		const node = startNode(4, offset, loc);
		node.key = key;
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLiteral(tokenizer, value) {
		const { lastOffset: offset, lastStartLoc: loc } = tokenizer.context();
		const node = startNode(9, offset, loc);
		node.value = value.replace(KNOWN_ESCAPES, fromEscapeSequence);
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLinkedModifier(tokenizer) {
		const token = tokenizer.nextToken();
		const context = tokenizer.context();
		const { lastOffset: offset, lastStartLoc: loc } = context;
		const node = startNode(8, offset, loc);
		if (token.type !== 11) {
			emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_MODIFIER, context.lastStartLoc, 0);
			node.value = "";
			endNode(node, offset, loc);
			return {
				nextConsumeToken: token,
				node
			};
		}
		if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
		node.value = token.value || "";
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return { node };
	}
	function parseLinkedKey(tokenizer, value) {
		const context = tokenizer.context();
		const node = startNode(7, context.offset, context.startLoc);
		node.value = value;
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLinked(tokenizer) {
		const context = tokenizer.context();
		const linkedNode = startNode(6, context.offset, context.startLoc);
		let token = tokenizer.nextToken();
		if (token.type === 8) {
			const parsed = parseLinkedModifier(tokenizer);
			linkedNode.modifier = parsed.node;
			token = parsed.nextConsumeToken || tokenizer.nextToken();
		}
		if (token.type !== 9) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
		token = tokenizer.nextToken();
		if (token.type === 2) token = tokenizer.nextToken();
		switch (token.type) {
			case 10:
				if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				linkedNode.key = parseLinkedKey(tokenizer, token.value || "");
				break;
			case 4:
				if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				linkedNode.key = parseNamed(tokenizer, token.value || "");
				break;
			case 5:
				if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				linkedNode.key = parseList(tokenizer, token.value || "");
				break;
			case 6:
				if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				linkedNode.key = parseLiteral(tokenizer, token.value || "");
				break;
			default: {
				emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_KEY, context.lastStartLoc, 0);
				const nextContext = tokenizer.context();
				const emptyLinkedKeyNode = startNode(7, nextContext.offset, nextContext.startLoc);
				emptyLinkedKeyNode.value = "";
				endNode(emptyLinkedKeyNode, nextContext.offset, nextContext.startLoc);
				linkedNode.key = emptyLinkedKeyNode;
				endNode(linkedNode, nextContext.offset, nextContext.startLoc);
				return {
					nextConsumeToken: token,
					node: linkedNode
				};
			}
		}
		endNode(linkedNode, tokenizer.currentOffset(), tokenizer.currentPosition());
		return { node: linkedNode };
	}
	function parseMessage(tokenizer) {
		const context = tokenizer.context();
		const node = startNode(2, context.currentType === 1 ? tokenizer.currentOffset() : context.offset, context.currentType === 1 ? context.endLoc : context.startLoc);
		node.items = [];
		let nextToken = null;
		do {
			const token = nextToken || tokenizer.nextToken();
			nextToken = null;
			switch (token.type) {
				case 0:
					if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					node.items.push(parseText(tokenizer, token.value || ""));
					break;
				case 5:
					if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					node.items.push(parseList(tokenizer, token.value || ""));
					break;
				case 4:
					if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					node.items.push(parseNamed(tokenizer, token.value || ""));
					break;
				case 6:
					if (token.value == null) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					node.items.push(parseLiteral(tokenizer, token.value || ""));
					break;
				case 7: {
					const parsed = parseLinked(tokenizer);
					node.items.push(parsed.node);
					nextToken = parsed.nextConsumeToken || null;
					break;
				}
			}
		} while (context.currentType !== 13 && context.currentType !== 1);
		endNode(node, context.currentType === 1 ? context.lastOffset : tokenizer.currentOffset(), context.currentType === 1 ? context.lastEndLoc : tokenizer.currentPosition());
		return node;
	}
	function parsePlural(tokenizer, offset, loc, msgNode) {
		const context = tokenizer.context();
		let hasEmptyMessage = msgNode.items.length === 0;
		const node = startNode(1, offset, loc);
		node.cases = [];
		node.cases.push(msgNode);
		do {
			const msg = parseMessage(tokenizer);
			if (!hasEmptyMessage) hasEmptyMessage = msg.items.length === 0;
			node.cases.push(msg);
		} while (context.currentType !== 13);
		if (hasEmptyMessage) emitError(tokenizer, CompileErrorCodes.MUST_HAVE_MESSAGES_IN_PLURAL, loc, 0);
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseResource(tokenizer) {
		const context = tokenizer.context();
		const { offset, startLoc } = context;
		const msgNode = parseMessage(tokenizer);
		if (context.currentType === 13) return msgNode;
		else return parsePlural(tokenizer, offset, startLoc, msgNode);
	}
	function parse(source) {
		const tokenizer = createTokenizer(source, assign({}, options));
		const context = tokenizer.context();
		const node = startNode(0, context.offset, context.startLoc);
		if (location && node.loc) node.loc.source = source;
		node.body = parseResource(tokenizer);
		if (options.onCacheKey) node.cacheKey = options.onCacheKey(source);
		if (context.currentType !== 13) emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, source[context.offset] || "");
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	return { parse };
}
function getTokenCaption(token) {
	if (token.type === 13) return "EOF";
	const name = (token.value || "").replace(/\r?\n/gu, "\\n");
	return name.length > 10 ? name.slice(0, 9) + "…" : name;
}
function createTransformer(ast, options = {}) {
	const _context = {
		ast,
		helpers: /* @__PURE__ */ new Set()
	};
	const context = () => _context;
	const helper = (name) => {
		_context.helpers.add(name);
		return name;
	};
	return {
		context,
		helper
	};
}
function traverseNodes(nodes, transformer) {
	for (let i = 0; i < nodes.length; i++) traverseNode(nodes[i], transformer);
}
function traverseNode(node, transformer) {
	switch (node.type) {
		case 1:
			traverseNodes(node.cases, transformer);
			transformer.helper("plural");
			break;
		case 2:
			traverseNodes(node.items, transformer);
			break;
		case 6:
			traverseNode(node.key, transformer);
			transformer.helper("linked");
			transformer.helper("type");
			break;
		case 5:
			transformer.helper("interpolate");
			transformer.helper("list");
			break;
		case 4:
			transformer.helper("interpolate");
			transformer.helper("named");
	}
}
function transform(ast, options = {}) {
	const transformer = createTransformer(ast);
	transformer.helper("normalize");
	ast.body && traverseNode(ast.body, transformer);
	const context = transformer.context();
	ast.helpers = Array.from(context.helpers);
}
function optimize(ast) {
	const body = ast.body;
	if (body.type === 2) optimizeMessageNode(body);
	else body.cases.forEach((c) => optimizeMessageNode(c));
	return ast;
}
function optimizeMessageNode(message) {
	if (message.items.length === 1) {
		const item = message.items[0];
		if (item.type === 3 || item.type === 9) {
			message.static = item.value;
			delete item.value;
		}
	} else {
		const values = [];
		for (let i = 0; i < message.items.length; i++) {
			const item = message.items[i];
			if (!(item.type === 3 || item.type === 9)) break;
			if (item.value == null) break;
			values.push(item.value);
		}
		if (values.length === message.items.length) {
			message.static = join(values);
			for (let i = 0; i < message.items.length; i++) {
				const item = message.items[i];
				if (item.type === 3 || item.type === 9) delete item.value;
			}
		}
	}
}
function minify(node) {
	node.t = node.type;
	switch (node.type) {
		case 0: {
			const resource = node;
			minify(resource.body);
			resource.b = resource.body;
			delete resource.body;
			break;
		}
		case 1: {
			const plural = node;
			const cases = plural.cases;
			for (let i = 0; i < cases.length; i++) minify(cases[i]);
			plural.c = cases;
			delete plural.cases;
			break;
		}
		case 2: {
			const message = node;
			const items = message.items;
			for (let i = 0; i < items.length; i++) minify(items[i]);
			message.i = items;
			delete message.items;
			if (message.static) {
				message.s = message.static;
				delete message.static;
			}
			break;
		}
		case 3:
		case 9:
		case 8:
		case 7: {
			const valueNode = node;
			if (valueNode.value) {
				valueNode.v = valueNode.value;
				delete valueNode.value;
			}
			break;
		}
		case 6: {
			const linked = node;
			minify(linked.key);
			linked.k = linked.key;
			delete linked.key;
			if (linked.modifier) {
				minify(linked.modifier);
				linked.m = linked.modifier;
				delete linked.modifier;
			}
			break;
		}
		case 5: {
			const list = node;
			list.i = list.index;
			delete list.index;
			break;
		}
		case 4: {
			const named = node;
			named.k = named.key;
			delete named.key;
			break;
		}
	}
	delete node.type;
}
function createCodeGenerator(ast, options) {
	const { filename, breakLineCode, needIndent: _needIndent } = options;
	const location = options.location !== false;
	const _context = {
		filename,
		code: "",
		column: 1,
		line: 1,
		offset: 0,
		map: void 0,
		breakLineCode,
		needIndent: _needIndent,
		indentLevel: 0
	};
	if (location && ast.loc) _context.source = ast.loc.source;
	const context = () => _context;
	function push(code, node) {
		_context.code += code;
	}
	function _newline(n, withBreakLine = true) {
		const _breakLineCode = withBreakLine ? breakLineCode : "";
		push(_needIndent ? _breakLineCode + `  `.repeat(n) : _breakLineCode);
	}
	function indent(withNewLine = true) {
		const level = ++_context.indentLevel;
		withNewLine && _newline(level);
	}
	function deindent(withNewLine = true) {
		const level = --_context.indentLevel;
		withNewLine && _newline(level);
	}
	function newline() {
		_newline(_context.indentLevel);
	}
	const helper = (key) => `_${key}`;
	const needIndent = () => _context.needIndent;
	return {
		context,
		push,
		indent,
		deindent,
		newline,
		helper,
		needIndent
	};
}
function generateLinkedNode(generator, node) {
	const { helper } = generator;
	generator.push(`${helper("linked")}(`);
	generateNode(generator, node.key);
	if (node.modifier) {
		generator.push(`, `);
		generateNode(generator, node.modifier);
		generator.push(`, _type`);
	} else generator.push(`, undefined, _type`);
	generator.push(`)`);
}
function generateMessageNode(generator, node) {
	const { helper, needIndent } = generator;
	generator.push(`${helper("normalize")}([`);
	generator.indent(needIndent());
	const length = node.items.length;
	for (let i = 0; i < length; i++) {
		generateNode(generator, node.items[i]);
		if (i === length - 1) break;
		generator.push(", ");
	}
	generator.deindent(needIndent());
	generator.push("])");
}
function generatePluralNode(generator, node) {
	const { helper, needIndent } = generator;
	if (node.cases.length > 1) {
		generator.push(`${helper("plural")}([`);
		generator.indent(needIndent());
		const length = node.cases.length;
		for (let i = 0; i < length; i++) {
			generateNode(generator, node.cases[i]);
			if (i === length - 1) break;
			generator.push(", ");
		}
		generator.deindent(needIndent());
		generator.push(`])`);
	}
}
function generateResource(generator, node) {
	if (node.body) generateNode(generator, node.body);
	else generator.push("null");
}
function generateNode(generator, node) {
	const { helper } = generator;
	switch (node.type) {
		case 0:
			generateResource(generator, node);
			break;
		case 1:
			generatePluralNode(generator, node);
			break;
		case 2:
			generateMessageNode(generator, node);
			break;
		case 6:
			generateLinkedNode(generator, node);
			break;
		case 8:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 7:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 5:
			generator.push(`${helper("interpolate")}(${helper("list")}(${node.index}))`, node);
			break;
		case 4:
			generator.push(`${helper("interpolate")}(${helper("named")}(${JSON.stringify(node.key)}))`, node);
			break;
		case 9:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 3: generator.push(JSON.stringify(node.value), node);
	}
}
var generate = (ast, options = {}) => {
	const mode = isString(options.mode) ? options.mode : "normal";
	const filename = isString(options.filename) ? options.filename : "message.intl";
	!!options.sourceMap;
	const breakLineCode = options.breakLineCode != null ? options.breakLineCode : mode === "arrow" ? ";" : "\n";
	const needIndent = options.needIndent ? options.needIndent : mode !== "arrow";
	const helpers = ast.helpers || [];
	const generator = createCodeGenerator(ast, {
		filename,
		breakLineCode,
		needIndent
	});
	generator.push(mode === "normal" ? `function __msg__ (ctx) {` : `(ctx) => {`);
	generator.indent(needIndent);
	if (helpers.length > 0) {
		generator.push(`const { ${join(helpers.map((s) => `${s}: _${s}`), ", ")} } = ctx`);
		generator.newline();
	}
	generator.push(`return `);
	generateNode(generator, ast);
	generator.deindent(needIndent);
	generator.push(`}`);
	delete ast.helpers;
	const { code, map } = generator.context();
	return {
		ast,
		code,
		map: map ? map.toJSON() : void 0
	};
};
function baseCompile$1(source, options = {}) {
	const assignedOptions = assign({}, options);
	const jit = !!assignedOptions.jit;
	const enalbeMinify = !!assignedOptions.minify;
	const enambeOptimize = assignedOptions.optimize == null ? true : assignedOptions.optimize;
	const ast = createParser(assignedOptions).parse(source);
	if (!jit) {
		transform(ast, assignedOptions);
		return generate(ast, assignedOptions);
	} else {
		enambeOptimize && optimize(ast);
		enalbeMinify && minify(ast);
		return {
			ast,
			code: ""
		};
	}
}
//#endregion
//#region node_modules/@intlify/core-base/dist/core-base.mjs
/*!
* core-base v11.3.2
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
function isMessageAST(val) {
	return isObject(val) && resolveType(val) === 0 && (hasOwn(val, "b") || hasOwn(val, "body"));
}
var PROPS_BODY = ["b", "body"];
function resolveBody(node) {
	return resolveProps(node, PROPS_BODY);
}
var PROPS_CASES = ["c", "cases"];
function resolveCases(node) {
	return resolveProps(node, PROPS_CASES, []);
}
var PROPS_STATIC = ["s", "static"];
function resolveStatic(node) {
	return resolveProps(node, PROPS_STATIC);
}
var PROPS_ITEMS = ["i", "items"];
function resolveItems(node) {
	return resolveProps(node, PROPS_ITEMS, []);
}
var PROPS_TYPE = ["t", "type"];
function resolveType(node) {
	return resolveProps(node, PROPS_TYPE);
}
var PROPS_VALUE = ["v", "value"];
function resolveValue$1(node, type) {
	const resolved = resolveProps(node, PROPS_VALUE);
	if (resolved != null) return resolved;
	else throw createUnhandleNodeError(type);
}
var PROPS_MODIFIER = ["m", "modifier"];
function resolveLinkedModifier(node) {
	return resolveProps(node, PROPS_MODIFIER);
}
var PROPS_KEY = ["k", "key"];
function resolveLinkedKey(node) {
	const resolved = resolveProps(node, PROPS_KEY);
	if (resolved) return resolved;
	else throw createUnhandleNodeError(6);
}
function resolveProps(node, props, defaultValue) {
	for (let i = 0; i < props.length; i++) {
		const prop = props[i];
		if (hasOwn(node, prop) && node[prop] != null) return node[prop];
	}
	return defaultValue;
}
var AST_NODE_PROPS_KEYS = [
	...PROPS_BODY,
	...PROPS_CASES,
	...PROPS_STATIC,
	...PROPS_ITEMS,
	...PROPS_KEY,
	...PROPS_MODIFIER,
	...PROPS_VALUE,
	...PROPS_TYPE
];
function createUnhandleNodeError(type) {
	return /* @__PURE__ */ new Error(`unhandled node type: ${type}`);
}
function format(ast) {
	const msg = (ctx) => formatParts(ctx, ast);
	return msg;
}
function formatParts(ctx, ast) {
	const body = resolveBody(ast);
	if (body == null) throw createUnhandleNodeError(0);
	if (resolveType(body) === 1) {
		const cases = resolveCases(body);
		return ctx.plural(cases.reduce((messages, c) => [...messages, formatMessageParts(ctx, c)], []));
	} else return formatMessageParts(ctx, body);
}
function formatMessageParts(ctx, node) {
	const static_ = resolveStatic(node);
	if (static_ != null) return ctx.type === "text" ? static_ : ctx.normalize([static_]);
	else {
		const messages = resolveItems(node).reduce((acm, c) => [...acm, formatMessagePart(ctx, c)], []);
		return ctx.normalize(messages);
	}
}
function formatMessagePart(ctx, node) {
	const type = resolveType(node);
	switch (type) {
		case 3: return resolveValue$1(node, type);
		case 9: return resolveValue$1(node, type);
		case 4: {
			const named = node;
			if (hasOwn(named, "k") && named.k) return ctx.interpolate(ctx.named(named.k));
			if (hasOwn(named, "key") && named.key) return ctx.interpolate(ctx.named(named.key));
			throw createUnhandleNodeError(type);
		}
		case 5: {
			const list = node;
			if (hasOwn(list, "i") && isNumber(list.i)) return ctx.interpolate(ctx.list(list.i));
			if (hasOwn(list, "index") && isNumber(list.index)) return ctx.interpolate(ctx.list(list.index));
			throw createUnhandleNodeError(type);
		}
		case 6: {
			const linked = node;
			const modifier = resolveLinkedModifier(linked);
			const key = resolveLinkedKey(linked);
			return ctx.linked(formatMessagePart(ctx, key), modifier ? formatMessagePart(ctx, modifier) : void 0, ctx.type);
		}
		case 7: return resolveValue$1(node, type);
		case 8: return resolveValue$1(node, type);
		default: throw new Error(`unhandled node on format message part: ${type}`);
	}
}
var defaultOnCacheKey = (message) => message;
var compileCache = create();
function baseCompile(message, options = {}) {
	let detectError = false;
	const onError = options.onError || defaultOnError;
	options.onError = (err) => {
		detectError = true;
		onError(err);
	};
	return {
		...baseCompile$1(message, options),
		detectError
	};
}
/* #__NO_SIDE_EFFECTS__ */
function compile(message, context) {
	if (isString(message)) {
		isBoolean(context.warnHtmlMessage) && context.warnHtmlMessage;
		const cacheKey = (context.onCacheKey || defaultOnCacheKey)(message);
		const cached = compileCache[cacheKey];
		if (cached) return cached;
		const { ast, detectError } = baseCompile(message, {
			...context,
			location: false,
			jit: true
		});
		const msg = format(ast);
		return !detectError ? compileCache[cacheKey] = msg : msg;
	} else {
		const cacheKey = message.cacheKey;
		if (cacheKey) {
			const cached = compileCache[cacheKey];
			if (cached) return cached;
			return compileCache[cacheKey] = format(message);
		} else return format(message);
	}
}
var CoreErrorCodes = {
	INVALID_ARGUMENT: 17,
	INVALID_DATE_ARGUMENT: 18,
	INVALID_ISO_DATE_ARGUMENT: 19,
	NOT_SUPPORT_LOCALE_PROMISE_VALUE: 21,
	NOT_SUPPORT_LOCALE_ASYNC_FUNCTION: 22,
	NOT_SUPPORT_LOCALE_TYPE: 23
};
function createCoreError(code) {
	return createCompileError(code, null, void 0);
}
/** @internal */
function getLocale(context, options) {
	return options.locale != null ? resolveLocale(options.locale) : resolveLocale(context.locale);
}
var _resolveLocale;
/** @internal */
function resolveLocale(locale) {
	if (isString(locale)) return locale;
	else if (isFunction(locale)) {
		if (locale.resolvedOnce && _resolveLocale != null) return _resolveLocale;
		else if (locale.constructor.name === "Function") {
			const resolve = locale();
			if (isPromise(resolve)) throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_PROMISE_VALUE);
			return _resolveLocale = resolve;
		} else throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION);
	} else throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_TYPE);
}
/**
* Fallback with simple implemenation
*
* @remarks
* A fallback locale function implemented with a simple fallback algorithm.
*
* Basically, it returns the value as specified in the `fallbackLocale` props, and is processed with the fallback inside intlify.
*
* @param ctx - A {@link CoreContext | context}
* @param fallback - A {@link FallbackLocale | fallback locale}
* @param start - A starting {@link Locale | locale}
*
* @returns Fallback locales
*
* @VueI18nGeneral
*/
function fallbackWithSimple(ctx, fallback, start) {
	return [.../* @__PURE__ */ new Set([start, ...isArray(fallback) ? fallback : isObject(fallback) ? Object.keys(fallback) : isString(fallback) ? [fallback] : [start]])];
}
/**
* Fallback with locale chain
*
* @remarks
* A fallback locale function implemented with a fallback chain algorithm. It's used in VueI18n as default.
*
* @param ctx - A {@link CoreContext | context}
* @param fallback - A {@link FallbackLocale | fallback locale}
* @param start - A starting {@link Locale | locale}
*
* @returns Fallback locales
*
* @VueI18nSee [Fallbacking](../guide/essentials/fallback)
*
* @VueI18nGeneral
*/
function fallbackWithLocaleChain(ctx, fallback, start) {
	const startLocale = isString(start) ? start : DEFAULT_LOCALE;
	const context = ctx;
	if (!context.__localeChainCache) context.__localeChainCache = /* @__PURE__ */ new Map();
	let chain = context.__localeChainCache.get(startLocale);
	if (!chain) {
		chain = [];
		let block = [start];
		while (isArray(block)) block = appendBlockToChain(chain, block, fallback);
		const defaults = isArray(fallback) || !isPlainObject$1(fallback) ? fallback : fallback["default"] ? fallback["default"] : null;
		block = isString(defaults) ? [defaults] : defaults;
		if (isArray(block)) appendBlockToChain(chain, block, false);
		context.__localeChainCache.set(startLocale, chain);
	}
	return chain;
}
function appendBlockToChain(chain, block, blocks) {
	let follow = true;
	for (let i = 0; i < block.length && isBoolean(follow); i++) {
		const locale = block[i];
		if (isString(locale)) follow = appendLocaleToChain(chain, block[i], blocks);
	}
	return follow;
}
function appendLocaleToChain(chain, locale, blocks) {
	let follow;
	const tokens = locale.split("-");
	do {
		follow = appendItemToChain(chain, tokens.join("-"), blocks);
		tokens.splice(-1, 1);
	} while (tokens.length && follow === true);
	return follow;
}
function appendItemToChain(chain, target, blocks) {
	let follow = false;
	if (!chain.includes(target)) {
		follow = true;
		if (target) {
			follow = target[target.length - 1] !== "!";
			const locale = target.replace(/!/g, "");
			chain.push(locale);
			if ((isArray(blocks) || isPlainObject$1(blocks)) && blocks[locale]) follow = blocks[locale];
		}
	}
	return follow;
}
var pathStateMachine = [];
pathStateMachine[0] = {
	["w"]: [0],
	["i"]: [3, 0],
	["["]: [4],
	["o"]: [7]
};
pathStateMachine[1] = {
	["w"]: [1],
	["."]: [2],
	["["]: [4],
	["o"]: [7]
};
pathStateMachine[2] = {
	["w"]: [2],
	["i"]: [3, 0],
	["0"]: [3, 0]
};
pathStateMachine[3] = {
	["i"]: [3, 0],
	["0"]: [3, 0],
	["w"]: [1, 1],
	["."]: [2, 1],
	["["]: [4, 1],
	["o"]: [7, 1]
};
pathStateMachine[4] = {
	["'"]: [5, 0],
	["\""]: [6, 0],
	["["]: [4, 2],
	["]"]: [1, 3],
	["o"]: 8,
	["l"]: [4, 0]
};
pathStateMachine[5] = {
	["'"]: [4, 0],
	["o"]: 8,
	["l"]: [5, 0]
};
pathStateMachine[6] = {
	["\""]: [4, 0],
	["o"]: 8,
	["l"]: [6, 0]
};
/**
* Check if an expression is a literal value.
*/
var literalValueRE = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral(exp) {
	return literalValueRE.test(exp);
}
/**
* Strip quotes from a string
*/
function stripQuotes(str) {
	const a = str.charCodeAt(0);
	return a === str.charCodeAt(str.length - 1) && (a === 34 || a === 39) ? str.slice(1, -1) : str;
}
/**
* Determine the type of a character in a keypath.
*/
function getPathCharType(ch) {
	if (ch === void 0 || ch === null) return "o";
	switch (ch.charCodeAt(0)) {
		case 91:
		case 93:
		case 46:
		case 34:
		case 39: return ch;
		case 95:
		case 36:
		case 45: return "i";
		case 9:
		case 10:
		case 13:
		case 160:
		case 65279:
		case 8232:
		case 8233: return "w";
	}
	return "i";
}
/**
* Format a subPath, return its plain form if it is
* a literal string or number. Otherwise prepend the
* dynamic indicator (*).
*/
function formatSubPath(path) {
	const trimmed = path.trim();
	if (path.charAt(0) === "0" && isNaN(parseInt(path))) return false;
	return isLiteral(trimmed) ? stripQuotes(trimmed) : "*" + trimmed;
}
/**
* Parse a string path into an array of segments
*/
function parse$1(path) {
	const keys = [];
	let index = -1;
	let mode = 0;
	let subPathDepth = 0;
	let c;
	let key;
	let newChar;
	let type;
	let transition;
	let action;
	let typeMap;
	const actions = [];
	actions[0] = () => {
		if (key === void 0) key = newChar;
		else key += newChar;
	};
	actions[1] = () => {
		if (key !== void 0) {
			keys.push(key);
			key = void 0;
		}
	};
	actions[2] = () => {
		actions[0]();
		subPathDepth++;
	};
	actions[3] = () => {
		if (subPathDepth > 0) {
			subPathDepth--;
			mode = 4;
			actions[0]();
		} else {
			subPathDepth = 0;
			if (key === void 0) return false;
			key = formatSubPath(key);
			if (key === false) return false;
			else actions[1]();
		}
	};
	function maybeUnescapeQuote() {
		const nextChar = path[index + 1];
		if (mode === 5 && nextChar === "'" || mode === 6 && nextChar === "\"") {
			index++;
			newChar = "\\" + nextChar;
			actions[0]();
			return true;
		}
	}
	while (mode !== null) {
		index++;
		c = path[index];
		if (c === "\\" && maybeUnescapeQuote()) continue;
		type = getPathCharType(c);
		typeMap = pathStateMachine[mode];
		transition = typeMap[type] || typeMap["l"] || 8;
		if (transition === 8) return;
		mode = transition[0];
		if (transition[1] !== void 0) {
			action = actions[transition[1]];
			if (action) {
				newChar = c;
				if (action() === false) return;
			}
		}
		if (mode === 7) return keys;
	}
}
var cache = /* @__PURE__ */ new Map();
/**
* key-value message resolver
*
* @remarks
* Resolves messages with the key-value structure. Note that messages with a hierarchical structure such as objects cannot be resolved
*
* @param obj - A target object to be resolved with path
* @param path - A {@link Path | path} to resolve the value of message
*
* @returns A resolved {@link PathValue | path value}
*
* @VueI18nGeneral
*/
function resolveWithKeyValue(obj, path) {
	return isObject(obj) ? obj[path] : null;
}
/**
* message resolver
*
* @remarks
* Resolves messages. messages with a hierarchical structure such as objects can be resolved. This resolver is used in VueI18n as default.
*
* @param obj - A target object to be resolved with path
* @param path - A {@link Path | path} to resolve the value of message
*
* @returns A resolved {@link PathValue | path value}
*
* @VueI18nGeneral
*/
function resolveValue(obj, path) {
	if (!isObject(obj)) return null;
	let hit = cache.get(path);
	if (!hit) {
		hit = parse$1(path);
		if (hit) cache.set(path, hit);
	}
	if (!hit) return null;
	const len = hit.length;
	let last = obj;
	let i = 0;
	while (i < len) {
		const key = hit[i];
		/**
		* NOTE:
		* if `key` is intlify message format AST node key and `last` is intlify message format AST, skip it.
		* because the AST node is not a key-value structure.
		*/
		if (AST_NODE_PROPS_KEYS.includes(key) && isMessageAST(last)) return null;
		if (!isObject(last)) return null;
		if (!hasOwn(last, key)) return null;
		const val = last[key];
		if (val === void 0) return null;
		if (isFunction(last)) return null;
		last = val;
		i++;
	}
	return last;
}
/**
* Intlify core-base version
* @internal
*/
var VERSION$1 = "11.3.2";
var DEFAULT_LOCALE = "en-US";
var capitalize = (str) => `${str.charAt(0).toLocaleUpperCase()}${str.substr(1)}`;
function getDefaultLinkedModifiers() {
	return {
		upper: (val, type) => {
			return type === "text" && isString(val) ? val.toUpperCase() : type === "vnode" && isObject(val) && "__v_isVNode" in val ? val.children.toUpperCase() : val;
		},
		lower: (val, type) => {
			return type === "text" && isString(val) ? val.toLowerCase() : type === "vnode" && isObject(val) && "__v_isVNode" in val ? val.children.toLowerCase() : val;
		},
		capitalize: (val, type) => {
			return type === "text" && isString(val) ? capitalize(val) : type === "vnode" && isObject(val) && "__v_isVNode" in val ? capitalize(val.children) : val;
		}
	};
}
var _compiler;
function registerMessageCompiler(compiler) {
	_compiler = compiler;
}
var _resolver;
/**
* Register the message resolver
*
* @param resolver - A {@link MessageResolver} function
*
* @VueI18nGeneral
*/
function registerMessageResolver(resolver) {
	_resolver = resolver;
}
var _fallbacker;
/**
* Register the locale fallbacker
*
* @param fallbacker - A {@link LocaleFallbacker} function
*
* @VueI18nGeneral
*/
function registerLocaleFallbacker(fallbacker) {
	_fallbacker = fallbacker;
}
var _fallbackContext = null;
var setFallbackContext = (context) => {
	_fallbackContext = context;
};
var getFallbackContext = () => _fallbackContext;
var _cid = 0;
function createCoreContext(options = {}) {
	const onWarn = isFunction(options.onWarn) ? options.onWarn : warn;
	const version = isString(options.version) ? options.version : VERSION$1;
	const locale = isString(options.locale) || isFunction(options.locale) ? options.locale : DEFAULT_LOCALE;
	const _locale = isFunction(locale) ? DEFAULT_LOCALE : locale;
	const fallbackLocale = isArray(options.fallbackLocale) || isPlainObject$1(options.fallbackLocale) || isString(options.fallbackLocale) || options.fallbackLocale === false ? options.fallbackLocale : _locale;
	const messages = isPlainObject$1(options.messages) ? options.messages : createResources(_locale);
	const datetimeFormats = isPlainObject$1(options.datetimeFormats) ? options.datetimeFormats : createResources(_locale);
	const numberFormats = isPlainObject$1(options.numberFormats) ? options.numberFormats : createResources(_locale);
	const modifiers = assign(create(), options.modifiers, getDefaultLinkedModifiers());
	const pluralRules = options.pluralRules || create();
	const missing = isFunction(options.missing) ? options.missing : null;
	const missingWarn = isBoolean(options.missingWarn) || isRegExp(options.missingWarn) ? options.missingWarn : true;
	const fallbackWarn = isBoolean(options.fallbackWarn) || isRegExp(options.fallbackWarn) ? options.fallbackWarn : true;
	const fallbackFormat = !!options.fallbackFormat;
	const unresolving = !!options.unresolving;
	const postTranslation = isFunction(options.postTranslation) ? options.postTranslation : null;
	const processor = isPlainObject$1(options.processor) ? options.processor : null;
	const warnHtmlMessage = isBoolean(options.warnHtmlMessage) ? options.warnHtmlMessage : true;
	const escapeParameter = !!options.escapeParameter;
	const messageCompiler = isFunction(options.messageCompiler) ? options.messageCompiler : _compiler;
	const messageResolver = isFunction(options.messageResolver) ? options.messageResolver : _resolver || resolveWithKeyValue;
	const localeFallbacker = isFunction(options.localeFallbacker) ? options.localeFallbacker : _fallbacker || fallbackWithSimple;
	const fallbackContext = isObject(options.fallbackContext) ? options.fallbackContext : void 0;
	const internalOptions = options;
	const __datetimeFormatters = isObject(internalOptions.__datetimeFormatters) ? internalOptions.__datetimeFormatters : /* @__PURE__ */ new Map();
	const __numberFormatters = isObject(internalOptions.__numberFormatters) ? internalOptions.__numberFormatters : /* @__PURE__ */ new Map();
	const __meta = isObject(internalOptions.__meta) ? internalOptions.__meta : {};
	_cid++;
	const context = {
		version,
		cid: _cid,
		locale,
		fallbackLocale,
		messages,
		modifiers,
		pluralRules,
		missing,
		missingWarn,
		fallbackWarn,
		fallbackFormat,
		unresolving,
		postTranslation,
		processor,
		warnHtmlMessage,
		escapeParameter,
		messageCompiler,
		messageResolver,
		localeFallbacker,
		fallbackContext,
		onWarn,
		__meta
	};
	context.datetimeFormats = datetimeFormats;
	context.numberFormats = numberFormats;
	context.__datetimeFormatters = __datetimeFormatters;
	context.__numberFormatters = __numberFormatters;
	return context;
}
var createResources = (locale) => ({ [locale]: create() });
/** @internal */
function handleMissing(context, key, locale, missingWarn, type) {
	const { missing, onWarn } = context;
	if (missing !== null) {
		const ret = missing(context, locale, key, type);
		return isString(ret) ? ret : key;
	} else return key;
}
/** @internal */
function updateFallbackLocale(ctx, locale, fallback) {
	const context = ctx;
	context.__localeChainCache = /* @__PURE__ */ new Map();
	ctx.localeFallbacker(ctx, fallback, locale);
}
/** @internal */
function isAlmostSameLocale(locale, compareLocale) {
	if (locale === compareLocale) return false;
	return locale.split("-")[0] === compareLocale.split("-")[0];
}
/** @internal */
function isImplicitFallback(targetLocale, locales) {
	const index = locales.indexOf(targetLocale);
	if (index === -1) return false;
	for (let i = index + 1; i < locales.length; i++) if (isAlmostSameLocale(targetLocale, locales[i])) return true;
	return false;
}
function datetime(context, ...args) {
	const { datetimeFormats, unresolving, fallbackLocale, onWarn, localeFallbacker } = context;
	const { __datetimeFormatters } = context;
	if (!isString(args[0]) && !isDate(args[0]) && !isNumber(args[0])) return "";
	const [key, value, options, overrides] = parseDateTimeArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const part = !!options.part;
	const locale = getLocale(context, options);
	const locales = localeFallbacker(context, fallbackLocale, locale);
	if (!isString(key) || key === "") return new Intl.DateTimeFormat(locale.replace(/!/g, ""), overrides).format(value);
	let datetimeFormat = {};
	let targetLocale;
	let format = null;
	const type = "datetime format";
	for (let i = 0; i < locales.length; i++) {
		targetLocale = locales[i];
		datetimeFormat = datetimeFormats[targetLocale] || {};
		format = datetimeFormat[key];
		if (isPlainObject$1(format)) break;
		handleMissing(context, key, targetLocale, missingWarn, type);
	}
	if (!isPlainObject$1(format) || !isString(targetLocale)) return unresolving ? -1 : key;
	let id = `${targetLocale}__${key}`;
	if (!isEmptyObject(overrides)) id = `${id}__${JSON.stringify(overrides)}`;
	let formatter = __datetimeFormatters.get(id);
	if (!formatter) {
		formatter = new Intl.DateTimeFormat(targetLocale, assign({}, format, overrides));
		__datetimeFormatters.set(id, formatter);
	}
	return !part ? formatter.format(value) : formatter.formatToParts(value);
}
/** @internal */
var DATETIME_FORMAT_OPTIONS_KEYS = [
	"localeMatcher",
	"weekday",
	"era",
	"year",
	"month",
	"day",
	"hour",
	"minute",
	"second",
	"timeZoneName",
	"formatMatcher",
	"hour12",
	"timeZone",
	"dateStyle",
	"timeStyle",
	"calendar",
	"dayPeriod",
	"numberingSystem",
	"hourCycle",
	"fractionalSecondDigits"
];
/** @internal */
function parseDateTimeArgs(...args) {
	const [arg1, arg2, arg3, arg4] = args;
	const options = create();
	let overrides = create();
	let value;
	if (isString(arg1)) {
		const matches = arg1.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
		if (!matches) throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
		const dateTime = matches[3] ? matches[3].trim().startsWith("T") ? `${matches[1].trim()}${matches[3].trim()}` : `${matches[1].trim()}T${matches[3].trim()}` : matches[1].trim();
		value = new Date(dateTime);
		try {
			value.toISOString();
		} catch {
			throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
		}
	} else if (isDate(arg1)) {
		if (isNaN(arg1.getTime())) throw createCoreError(CoreErrorCodes.INVALID_DATE_ARGUMENT);
		value = arg1;
	} else if (isNumber(arg1)) value = arg1;
	else throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	if (isString(arg2)) options.key = arg2;
	else if (isPlainObject$1(arg2)) Object.keys(arg2).forEach((key) => {
		if (DATETIME_FORMAT_OPTIONS_KEYS.includes(key)) overrides[key] = arg2[key];
		else options[key] = arg2[key];
	});
	if (isString(arg3)) options.locale = arg3;
	else if (isPlainObject$1(arg3)) overrides = arg3;
	if (isPlainObject$1(arg4)) overrides = arg4;
	return [
		options.key || "",
		value,
		options,
		overrides
	];
}
/** @internal */
function clearDateTimeFormat(ctx, locale, format) {
	const context = ctx;
	for (const key in format) {
		const id = `${locale}__${key}`;
		if (!context.__datetimeFormatters.has(id)) continue;
		context.__datetimeFormatters.delete(id);
	}
}
function number(context, ...args) {
	const { numberFormats, unresolving, fallbackLocale, onWarn, localeFallbacker } = context;
	const { __numberFormatters } = context;
	if (!isNumber(args[0])) return "";
	const [key, value, options, overrides] = parseNumberArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const part = !!options.part;
	const locale = getLocale(context, options);
	const locales = localeFallbacker(context, fallbackLocale, locale);
	if (!isString(key) || key === "") return new Intl.NumberFormat(locale.replace(/!/g, ""), overrides).format(value);
	let numberFormat = {};
	let targetLocale;
	let format = null;
	const type = "number format";
	for (let i = 0; i < locales.length; i++) {
		targetLocale = locales[i];
		numberFormat = numberFormats[targetLocale] || {};
		format = numberFormat[key];
		if (isPlainObject$1(format)) break;
		handleMissing(context, key, targetLocale, missingWarn, type);
	}
	if (!isPlainObject$1(format) || !isString(targetLocale)) return unresolving ? -1 : key;
	let id = `${targetLocale}__${key}`;
	if (!isEmptyObject(overrides)) id = `${id}__${JSON.stringify(overrides)}`;
	let formatter = __numberFormatters.get(id);
	if (!formatter) {
		formatter = new Intl.NumberFormat(targetLocale, assign({}, format, overrides));
		__numberFormatters.set(id, formatter);
	}
	return !part ? formatter.format(value) : formatter.formatToParts(value);
}
/** @internal */
var NUMBER_FORMAT_OPTIONS_KEYS = [
	"localeMatcher",
	"style",
	"currency",
	"currencyDisplay",
	"currencySign",
	"useGrouping",
	"minimumIntegerDigits",
	"minimumFractionDigits",
	"maximumFractionDigits",
	"minimumSignificantDigits",
	"maximumSignificantDigits",
	"compactDisplay",
	"notation",
	"signDisplay",
	"unit",
	"unitDisplay",
	"roundingMode",
	"roundingPriority",
	"roundingIncrement",
	"trailingZeroDisplay"
];
/** @internal */
function parseNumberArgs(...args) {
	const [arg1, arg2, arg3, arg4] = args;
	const options = create();
	let overrides = create();
	if (!isNumber(arg1)) throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	const value = arg1;
	if (isString(arg2)) options.key = arg2;
	else if (isPlainObject$1(arg2)) Object.keys(arg2).forEach((key) => {
		if (NUMBER_FORMAT_OPTIONS_KEYS.includes(key)) overrides[key] = arg2[key];
		else options[key] = arg2[key];
	});
	if (isString(arg3)) options.locale = arg3;
	else if (isPlainObject$1(arg3)) overrides = arg3;
	if (isPlainObject$1(arg4)) overrides = arg4;
	return [
		options.key || "",
		value,
		options,
		overrides
	];
}
/** @internal */
function clearNumberFormat(ctx, locale, format) {
	const context = ctx;
	for (const key in format) {
		const id = `${locale}__${key}`;
		if (!context.__numberFormatters.has(id)) continue;
		context.__numberFormatters.delete(id);
	}
}
var DEFAULT_MODIFIER = (str) => str;
var DEFAULT_MESSAGE = (ctx) => "";
var DEFAULT_MESSAGE_DATA_TYPE = "text";
var DEFAULT_NORMALIZE = (values) => values.length === 0 ? "" : join(values);
var DEFAULT_INTERPOLATE = toDisplayString$1;
function pluralDefault(choice, choicesLength) {
	choice = Math.abs(choice);
	if (choicesLength === 2) return choice === 1 ? 0 : 1;
	return Math.min(choice, 2);
}
function getPluralIndex(options) {
	const index = isNumber(options.pluralIndex) ? options.pluralIndex : -1;
	return isNumber(options.named?.count) ? options.named.count : isNumber(options.named?.n) ? options.named.n : index;
}
function createMessageContext(options = {}) {
	const locale = options.locale;
	const pluralIndex = getPluralIndex(options);
	const pluralRule = isString(locale) && isFunction(options.pluralRules?.[locale]) ? options.pluralRules[locale] : pluralDefault;
	const orgPluralRule = pluralRule === pluralDefault ? void 0 : pluralDefault;
	const plural = (messages) => messages[pluralRule(pluralIndex, messages.length, orgPluralRule)];
	const _list = options.list || [];
	const list = (index) => _list[index];
	const _named = options.named || create();
	if (isNumber(options.pluralIndex)) {
		_named.count ||= options.pluralIndex;
		_named.n ||= options.pluralIndex;
	}
	const named = (key) => _named[key];
	function message(key, useLinked) {
		const msg = isFunction(options.messages) ? options.messages(key, !!useLinked) : isObject(options.messages) ? options.messages[key] : false;
		return !msg ? options.parent ? options.parent.message(key) : DEFAULT_MESSAGE : msg;
	}
	const _modifier = (name) => options.modifiers ? options.modifiers[name] : DEFAULT_MODIFIER;
	const normalize = isFunction(options.processor?.normalize) ? options.processor.normalize : DEFAULT_NORMALIZE;
	const interpolate = isFunction(options.processor?.interpolate) ? options.processor.interpolate : DEFAULT_INTERPOLATE;
	const type = isString(options.processor?.type) ? options.processor.type : DEFAULT_MESSAGE_DATA_TYPE;
	const linked = (key, ...args) => {
		const [arg1, arg2] = args;
		let type = "text";
		let modifier = "";
		if (args.length === 1) {
			if (isObject(arg1)) {
				modifier = arg1.modifier || modifier;
				type = arg1.type || type;
			} else if (isString(arg1)) modifier = arg1 || modifier;
		} else if (args.length === 2) {
			if (isString(arg1)) modifier = arg1 || modifier;
			if (isString(arg2)) type = arg2 || type;
		}
		const ret = message(key, true)(ctx);
		const resolved = ret === "" || ret === void 0 ? key : ret;
		const msg = type === "vnode" && isArray(resolved) && modifier ? resolved[0] : resolved;
		return modifier ? _modifier(modifier)(msg, type) : msg;
	};
	const ctx = {
		["list"]: list,
		["named"]: named,
		["plural"]: plural,
		["linked"]: linked,
		["message"]: message,
		["type"]: type,
		["interpolate"]: interpolate,
		["normalize"]: normalize,
		["values"]: assign(create(), _list, _named)
	};
	return ctx;
}
var NOOP_MESSAGE_FUNCTION = () => "";
var isMessageFunction = (val) => isFunction(val);
function translate(context, ...args) {
	const { fallbackFormat, postTranslation, unresolving, messageCompiler, fallbackLocale, messages } = context;
	const [key, options] = parseTranslateArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	const fallbackWarn = isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const escapeParameter = isBoolean(options.escapeParameter) ? options.escapeParameter : context.escapeParameter;
	const resolvedMessage = !!options.resolvedMessage;
	const defaultMsgOrKey = isString(options.default) || isBoolean(options.default) ? !isBoolean(options.default) ? options.default : !messageCompiler ? () => key : key : fallbackFormat ? !messageCompiler ? () => key : key : null;
	const enableDefaultMsg = fallbackFormat || defaultMsgOrKey != null && (isString(defaultMsgOrKey) || isFunction(defaultMsgOrKey));
	const locale = getLocale(context, options);
	escapeParameter && escapeParams(options);
	let [formatScope, targetLocale, message] = !resolvedMessage ? resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) : [
		key,
		locale,
		messages[locale] || create()
	];
	let format = formatScope;
	let cacheBaseKey = key;
	if (!resolvedMessage && !(isString(format) || isMessageAST(format) || isMessageFunction(format))) {
		if (enableDefaultMsg) {
			format = defaultMsgOrKey;
			cacheBaseKey = format;
		}
	}
	if (!resolvedMessage && (!(isString(format) || isMessageAST(format) || isMessageFunction(format)) || !isString(targetLocale))) return unresolving ? -1 : key;
	let occurred = false;
	const onError = () => {
		occurred = true;
	};
	const msg = !isMessageFunction(format) ? compileMessageFormat(context, key, targetLocale, format, cacheBaseKey, onError) : format;
	if (occurred) return format;
	const messaged = evaluateMessage(context, msg, createMessageContext(getMessageContextOptions(context, targetLocale, message, options)));
	let ret = postTranslation ? postTranslation(messaged, key) : messaged;
	if (escapeParameter && isString(ret)) ret = sanitizeTranslatedHtml(ret);
	return ret;
}
function escapeParams(options) {
	if (isArray(options.list)) options.list = options.list.map((item) => isString(item) ? escapeHtml(item) : item);
	else if (isObject(options.named)) Object.keys(options.named).forEach((key) => {
		if (isString(options.named[key])) options.named[key] = escapeHtml(options.named[key]);
	});
}
function resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) {
	const { messages, onWarn, messageResolver: resolveValue, localeFallbacker } = context;
	const locales = localeFallbacker(context, fallbackLocale, locale);
	let message = create();
	let targetLocale;
	let format = null;
	const type = "translate";
	for (let i = 0; i < locales.length; i++) {
		targetLocale = locales[i];
		message = messages[targetLocale] || create();
		if ((format = resolveValue(message, key)) === null) format = message[key];
		if (isString(format) || isMessageAST(format) || isMessageFunction(format)) break;
		if (!isImplicitFallback(targetLocale, locales)) {
			const missingRet = handleMissing(context, key, targetLocale, missingWarn, type);
			if (missingRet !== key) format = missingRet;
		}
	}
	return [
		format,
		targetLocale,
		message
	];
}
function compileMessageFormat(context, key, targetLocale, format, cacheBaseKey, onError) {
	const { messageCompiler, warnHtmlMessage } = context;
	if (isMessageFunction(format)) {
		const msg = format;
		msg.locale = msg.locale || targetLocale;
		msg.key = msg.key || key;
		return msg;
	}
	if (messageCompiler == null) {
		const msg = (() => format);
		msg.locale = targetLocale;
		msg.key = key;
		return msg;
	}
	const msg = messageCompiler(format, getCompileContext(context, targetLocale, cacheBaseKey, format, warnHtmlMessage, onError));
	msg.locale = targetLocale;
	msg.key = key;
	msg.source = format;
	return msg;
}
function evaluateMessage(context, msg, msgCtx) {
	return msg(msgCtx);
}
/** @internal */
function parseTranslateArgs(...args) {
	const [arg1, arg2, arg3] = args;
	const options = create();
	if (!isString(arg1) && !isNumber(arg1) && !isMessageFunction(arg1) && !isMessageAST(arg1)) throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	const key = isNumber(arg1) ? String(arg1) : isMessageFunction(arg1) ? arg1 : arg1;
	if (isNumber(arg2)) options.plural = arg2;
	else if (isString(arg2)) options.default = arg2;
	else if (isPlainObject$1(arg2) && !isEmptyObject(arg2)) options.named = arg2;
	else if (isArray(arg2)) options.list = arg2;
	if (isNumber(arg3)) options.plural = arg3;
	else if (isString(arg3)) options.default = arg3;
	else if (isPlainObject$1(arg3)) assign(options, arg3);
	return [key, options];
}
function getCompileContext(context, locale, key, source, warnHtmlMessage, onError) {
	return {
		locale,
		key,
		warnHtmlMessage,
		onError: (err) => {
			onError && onError(err);
			throw err;
		},
		onCacheKey: (source) => generateFormatCacheKey(locale, key, source)
	};
}
function getMessageContextOptions(context, locale, message, options) {
	const { modifiers, pluralRules, messageResolver: resolveValue, fallbackLocale, fallbackWarn, missingWarn, fallbackContext } = context;
	const resolveMessage = (key, useLinked) => {
		let val = resolveValue(message, key);
		if (val == null && (fallbackContext || useLinked)) {
			const [format, , message] = resolveMessageFormat(fallbackContext || context, key, locale, fallbackLocale, fallbackWarn, missingWarn);
			val = format ?? resolveValue(message, key);
		}
		if (isString(val) || isMessageAST(val)) {
			let occurred = false;
			const onError = () => {
				occurred = true;
			};
			const msg = compileMessageFormat(context, key, locale, val, key, onError);
			return !occurred ? msg : NOOP_MESSAGE_FUNCTION;
		} else if (isMessageFunction(val)) return val;
		else return NOOP_MESSAGE_FUNCTION;
	};
	const ctxOptions = {
		locale,
		modifiers,
		pluralRules,
		messages: resolveMessage
	};
	if (context.processor) ctxOptions.processor = context.processor;
	if (options.list) ctxOptions.list = options.list;
	if (options.named) ctxOptions.named = options.named;
	if (isNumber(options.plural)) ctxOptions.pluralIndex = options.plural;
	return ctxOptions;
}
//#endregion
//#region node_modules/vue-i18n/dist/vue-i18n.mjs
/*!
* vue-i18n v11.3.2
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
/**
* Vue I18n Version
*
* @remarks
* Semver format. Same format as the package.json `version` field.
*
* @VueI18nGeneral
*/
var VERSION = "11.3.2";
var I18nErrorCodes = {
	UNEXPECTED_RETURN_TYPE: 24,
	INVALID_ARGUMENT: 25,
	MUST_BE_CALL_SETUP_TOP: 26,
	NOT_INSTALLED: 27,
	REQUIRED_VALUE: 28,
	INVALID_VALUE: 29,
	NOT_INSTALLED_WITH_PROVIDE: 31,
	UNEXPECTED_ERROR: 32};
function createI18nError(code, ...args) {
	return createCompileError(code, null, void 0);
}
var TranslateVNodeSymbol = /* #__PURE__*/ makeSymbol("__translateVNode");
var DatetimePartsSymbol = /* #__PURE__*/ makeSymbol("__datetimeParts");
var NumberPartsSymbol = /* #__PURE__*/ makeSymbol("__numberParts");
var SetPluralRulesSymbol = makeSymbol("__setPluralRules");
var InejctWithOptionSymbol = /* #__PURE__*/ makeSymbol("__injectWithOption");
var DisposeSymbol = /* #__PURE__*/ makeSymbol("__dispose");
/**
* Transform flat json in obj to normal json in obj
*/
function handleFlatJson(obj) {
	if (!isObject(obj)) return obj;
	if (isMessageAST(obj)) return obj;
	for (const key in obj) {
		if (!hasOwn(obj, key)) continue;
		if (!key.includes(".")) {
			if (isObject(obj[key])) handleFlatJson(obj[key]);
		} else {
			const subKeys = key.split(".");
			const lastIndex = subKeys.length - 1;
			let currentObj = obj;
			let hasStringValue = false;
			for (let i = 0; i < lastIndex; i++) {
				if (subKeys[i] === "__proto__") throw new Error(`unsafe key: ${subKeys[i]}`);
				if (!(subKeys[i] in currentObj)) currentObj[subKeys[i]] = create();
				if (!isObject(currentObj[subKeys[i]])) {
					hasStringValue = true;
					break;
				}
				currentObj = currentObj[subKeys[i]];
			}
			if (!hasStringValue) {
				if (!isMessageAST(currentObj)) {
					currentObj[subKeys[lastIndex]] = obj[key];
					delete obj[key];
				} else if (!AST_NODE_PROPS_KEYS.includes(subKeys[lastIndex])) delete obj[key];
			}
			if (!isMessageAST(currentObj)) {
				const target = currentObj[subKeys[lastIndex]];
				if (isObject(target)) handleFlatJson(target);
			}
		}
	}
	return obj;
}
function getLocaleMessages$1(locale, options) {
	const { messages, __i18n, messageResolver, flatJson } = options;
	const ret = isPlainObject$1(messages) ? messages : isArray(__i18n) ? create() : { [locale]: create() };
	if (isArray(__i18n)) __i18n.forEach((custom) => {
		if ("locale" in custom && "resource" in custom) {
			const { locale, resource } = custom;
			if (locale) {
				ret[locale] = ret[locale] || create();
				deepCopy(resource, ret[locale]);
			} else deepCopy(resource, ret);
		} else isString(custom) && deepCopy(JSON.parse(custom), ret);
	});
	if (messageResolver == null && flatJson) {
		for (const key in ret) if (hasOwn(ret, key)) handleFlatJson(ret[key]);
	}
	return ret;
}
function getComponentOptions(instance) {
	return instance.type;
}
function adjustI18nResources(gl, options, componentOptions) {
	let messages = isObject(options.messages) ? options.messages : create();
	if ("__i18nGlobal" in componentOptions) messages = getLocaleMessages$1(gl.locale.value, {
		messages,
		__i18n: componentOptions.__i18nGlobal
	});
	const locales = Object.keys(messages);
	if (locales.length) locales.forEach((locale) => {
		gl.mergeLocaleMessage(locale, messages[locale]);
	});
	if (isObject(options.datetimeFormats)) {
		const locales = Object.keys(options.datetimeFormats);
		if (locales.length) locales.forEach((locale) => {
			gl.mergeDateTimeFormat(locale, options.datetimeFormats[locale]);
		});
	}
	if (isObject(options.numberFormats)) {
		const locales = Object.keys(options.numberFormats);
		if (locales.length) locales.forEach((locale) => {
			gl.mergeNumberFormat(locale, options.numberFormats[locale]);
		});
	}
}
function createTextNode(key) {
	return createVNode(Text, null, key, 0);
}
function getCurrentInstance$1() {
	const key = "currentInstance";
	if (key in Vue) return Vue[key];
	else return Vue.getCurrentInstance();
}
var NOOP_RETURN_ARRAY = () => [];
var NOOP_RETURN_FALSE = () => false;
var composerID = 0;
function defineCoreMissingHandler(missing) {
	return ((ctx, locale, key, type) => {
		return missing(locale, key, getCurrentInstance$1() || void 0, type);
	});
}
/**
* Create composer interface factory
*
* @internal
*/
function createComposer(options = {}) {
	const { __root, __injectWithOption } = options;
	const _isGlobal = __root === void 0;
	const flatJson = options.flatJson;
	const _ref = shallowRef;
	let _inheritLocale = isBoolean(options.inheritLocale) ? options.inheritLocale : true;
	const _locale = _ref(__root && _inheritLocale ? __root.locale.value : isString(options.locale) ? options.locale : DEFAULT_LOCALE);
	const _fallbackLocale = _ref(__root && _inheritLocale ? __root.fallbackLocale.value : isString(options.fallbackLocale) || isArray(options.fallbackLocale) || isPlainObject$1(options.fallbackLocale) || options.fallbackLocale === false ? options.fallbackLocale : _locale.value);
	const _messages = _ref(getLocaleMessages$1(_locale.value, options));
	const _datetimeFormats = _ref(isPlainObject$1(options.datetimeFormats) ? options.datetimeFormats : { [_locale.value]: {} });
	const _numberFormats = _ref(isPlainObject$1(options.numberFormats) ? options.numberFormats : { [_locale.value]: {} });
	let _missingWarn = __root ? __root.missingWarn : isBoolean(options.missingWarn) || isRegExp(options.missingWarn) ? options.missingWarn : true;
	let _fallbackWarn = __root ? __root.fallbackWarn : isBoolean(options.fallbackWarn) || isRegExp(options.fallbackWarn) ? options.fallbackWarn : true;
	let _fallbackRoot = __root ? __root.fallbackRoot : isBoolean(options.fallbackRoot) ? options.fallbackRoot : true;
	let _fallbackFormat = !!options.fallbackFormat;
	let _missing = isFunction(options.missing) ? options.missing : null;
	let _runtimeMissing = isFunction(options.missing) ? defineCoreMissingHandler(options.missing) : null;
	let _postTranslation = isFunction(options.postTranslation) ? options.postTranslation : null;
	let _warnHtmlMessage = __root ? __root.warnHtmlMessage : isBoolean(options.warnHtmlMessage) ? options.warnHtmlMessage : true;
	let _escapeParameter = !!options.escapeParameter;
	const _modifiers = __root ? __root.modifiers : isPlainObject$1(options.modifiers) ? options.modifiers : {};
	let _pluralRules = options.pluralRules || __root && __root.pluralRules;
	let _context;
	const getCoreContext = () => {
		_isGlobal && setFallbackContext(null);
		const ctxOptions = {
			version: VERSION,
			locale: _locale.value,
			fallbackLocale: _fallbackLocale.value,
			messages: _messages.value,
			modifiers: _modifiers,
			pluralRules: _pluralRules,
			missing: _runtimeMissing === null ? void 0 : _runtimeMissing,
			missingWarn: _missingWarn,
			fallbackWarn: _fallbackWarn,
			fallbackFormat: _fallbackFormat,
			unresolving: true,
			postTranslation: _postTranslation === null ? void 0 : _postTranslation,
			warnHtmlMessage: _warnHtmlMessage,
			escapeParameter: _escapeParameter,
			messageResolver: options.messageResolver,
			messageCompiler: options.messageCompiler,
			__meta: { framework: "vue" }
		};
		ctxOptions.datetimeFormats = _datetimeFormats.value;
		ctxOptions.numberFormats = _numberFormats.value;
		ctxOptions.__datetimeFormatters = isPlainObject$1(_context) ? _context.__datetimeFormatters : void 0;
		ctxOptions.__numberFormatters = isPlainObject$1(_context) ? _context.__numberFormatters : void 0;
		const ctx = createCoreContext(ctxOptions);
		_isGlobal && setFallbackContext(ctx);
		return ctx;
	};
	_context = getCoreContext();
	updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
	function trackReactivityValues() {
		return [
			_locale.value,
			_fallbackLocale.value,
			_messages.value,
			_datetimeFormats.value,
			_numberFormats.value
		];
	}
	const locale = computed({
		get: () => _locale.value,
		set: (val) => {
			_context.locale = val;
			_locale.value = val;
		}
	});
	const fallbackLocale = computed({
		get: () => _fallbackLocale.value,
		set: (val) => {
			_context.fallbackLocale = val;
			_fallbackLocale.value = val;
			updateFallbackLocale(_context, _locale.value, val);
		}
	});
	const messages = computed(() => _messages.value);
	const datetimeFormats = /* #__PURE__*/ computed(() => _datetimeFormats.value);
	const numberFormats = /* #__PURE__*/ computed(() => _numberFormats.value);
	function getPostTranslationHandler() {
		return isFunction(_postTranslation) ? _postTranslation : null;
	}
	function setPostTranslationHandler(handler) {
		_postTranslation = handler;
		_context.postTranslation = handler;
	}
	function getMissingHandler() {
		return _missing;
	}
	function setMissingHandler(handler) {
		if (handler !== null) _runtimeMissing = defineCoreMissingHandler(handler);
		_missing = handler;
		_context.missing = _runtimeMissing;
	}
	const wrapWithDeps = (fn, argumentParser, warnType, fallbackSuccess, fallbackFail, successCondition) => {
		trackReactivityValues();
		let ret;
		try {
			if (!_isGlobal) _context.fallbackContext = __root ? getFallbackContext() : void 0;
			ret = fn(_context);
		} finally {
			if (!_isGlobal) _context.fallbackContext = void 0;
		}
		if (warnType !== "translate exists" && isNumber(ret) && ret === -1 || warnType === "translate exists" && !ret) {
			const [key, arg2] = argumentParser();
			return __root && _fallbackRoot ? fallbackSuccess(__root) : fallbackFail(key);
		} else if (successCondition(ret)) return ret;
		else
 /* istanbul ignore next */
		throw createI18nError(I18nErrorCodes.UNEXPECTED_RETURN_TYPE);
	};
	function t(...args) {
		return wrapWithDeps((context) => Reflect.apply(translate, null, [context, ...args]), () => parseTranslateArgs(...args), "translate", (root) => Reflect.apply(root.t, root, [...args]), (key) => key, (val) => isString(val));
	}
	function rt(...args) {
		const [arg1, arg2, arg3] = args;
		if (arg3 && !isObject(arg3)) throw createI18nError(I18nErrorCodes.INVALID_ARGUMENT);
		return t(...[
			arg1,
			arg2,
			assign({ resolvedMessage: true }, arg3 || {})
		]);
	}
	function d(...args) {
		return wrapWithDeps((context) => Reflect.apply(datetime, null, [context, ...args]), () => parseDateTimeArgs(...args), "datetime format", (root) => Reflect.apply(root.d, root, [...args]), () => "", (val) => isString(val) || isArray(val));
	}
	function n(...args) {
		return wrapWithDeps((context) => Reflect.apply(number, null, [context, ...args]), () => parseNumberArgs(...args), "number format", (root) => Reflect.apply(root.n, root, [...args]), () => "", (val) => isString(val) || isArray(val));
	}
	function normalize(values) {
		return values.map((val) => isString(val) || isNumber(val) || isBoolean(val) ? createTextNode(String(val)) : val);
	}
	const interpolate = (val) => val;
	const processor = {
		normalize,
		interpolate,
		type: "vnode"
	};
	function translateVNode(...args) {
		return wrapWithDeps((context) => {
			let ret;
			const _context = context;
			try {
				_context.processor = processor;
				ret = Reflect.apply(translate, null, [_context, ...args]);
			} finally {
				_context.processor = null;
			}
			return ret;
		}, () => parseTranslateArgs(...args), "translate", (root) => root[TranslateVNodeSymbol](...args), (key) => [createTextNode(key)], (val) => isArray(val));
	}
	function numberParts(...args) {
		return wrapWithDeps((context) => Reflect.apply(number, null, [context, ...args]), () => parseNumberArgs(...args), "number format", (root) => root[NumberPartsSymbol](...args), NOOP_RETURN_ARRAY, (val) => isString(val) || isArray(val));
	}
	function datetimeParts(...args) {
		return wrapWithDeps((context) => Reflect.apply(datetime, null, [context, ...args]), () => parseDateTimeArgs(...args), "datetime format", (root) => root[DatetimePartsSymbol](...args), NOOP_RETURN_ARRAY, (val) => isString(val) || isArray(val));
	}
	function setPluralRules(rules) {
		_pluralRules = rules;
		_context.pluralRules = _pluralRules;
	}
	function te(key, locale) {
		return wrapWithDeps(() => {
			if (!key) return false;
			const targetLocale = isString(locale) ? locale : _locale.value;
			const locales = isString(locale) ? [targetLocale] : fallbackWithLocaleChain(_context, _fallbackLocale.value, targetLocale);
			for (let i = 0; i < locales.length; i++) {
				const message = getLocaleMessage(locales[i]);
				let resolved = _context.messageResolver(message, key);
				if (resolved === null) resolved = message[key];
				if (isMessageAST(resolved) || isMessageFunction(resolved) || isString(resolved)) return true;
			}
			return false;
		}, () => [key], "translate exists", (root) => {
			return Reflect.apply(root.te, root, [key, locale]);
		}, NOOP_RETURN_FALSE, (val) => isBoolean(val));
	}
	function resolveMessages(key) {
		let messages = null;
		const locales = fallbackWithLocaleChain(_context, _fallbackLocale.value, _locale.value);
		for (let i = 0; i < locales.length; i++) {
			const targetLocaleMessages = _messages.value[locales[i]] || {};
			const messageValue = _context.messageResolver(targetLocaleMessages, key);
			if (messageValue != null) {
				messages = messageValue;
				break;
			}
		}
		return messages;
	}
	function tm(key) {
		const messages = resolveMessages(key);
		return messages != null ? messages : __root ? __root.tm(key) || {} : {};
	}
	function getLocaleMessage(locale) {
		return _messages.value[locale] || {};
	}
	function setLocaleMessage(locale, message) {
		if (flatJson) {
			const _message = { [locale]: message };
			for (const key in _message) if (hasOwn(_message, key)) handleFlatJson(_message[key]);
			message = _message[locale];
		}
		_messages.value[locale] = message;
		_context.messages = _messages.value;
	}
	function mergeLocaleMessage(locale, message) {
		_messages.value[locale] = _messages.value[locale] || {};
		const _message = { [locale]: message };
		if (flatJson) {
			for (const key in _message) if (hasOwn(_message, key)) handleFlatJson(_message[key]);
		}
		message = _message[locale];
		deepCopy(message, _messages.value[locale]);
		_context.messages = _messages.value;
	}
	function getDateTimeFormat(locale) {
		return _datetimeFormats.value[locale] || {};
	}
	function setDateTimeFormat(locale, format) {
		_datetimeFormats.value[locale] = format;
		_context.datetimeFormats = _datetimeFormats.value;
		clearDateTimeFormat(_context, locale, format);
	}
	function mergeDateTimeFormat(locale, format) {
		_datetimeFormats.value[locale] = assign(_datetimeFormats.value[locale] || {}, format);
		_context.datetimeFormats = _datetimeFormats.value;
		clearDateTimeFormat(_context, locale, format);
	}
	function getNumberFormat(locale) {
		return _numberFormats.value[locale] || {};
	}
	function setNumberFormat(locale, format) {
		_numberFormats.value[locale] = format;
		_context.numberFormats = _numberFormats.value;
		clearNumberFormat(_context, locale, format);
	}
	function mergeNumberFormat(locale, format) {
		_numberFormats.value[locale] = assign(_numberFormats.value[locale] || {}, format);
		_context.numberFormats = _numberFormats.value;
		clearNumberFormat(_context, locale, format);
	}
	composerID++;
	const composer = {
		id: composerID,
		locale,
		fallbackLocale,
		get inheritLocale() {
			return _inheritLocale;
		},
		set inheritLocale(val) {
			_inheritLocale = val;
			if (val && __root) {
				_locale.value = __root.locale.value;
				_fallbackLocale.value = __root.fallbackLocale.value;
				updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
			}
		},
		get availableLocales() {
			return Object.keys(_messages.value).sort();
		},
		messages,
		get modifiers() {
			return _modifiers;
		},
		get pluralRules() {
			return _pluralRules || {};
		},
		get isGlobal() {
			return _isGlobal;
		},
		get missingWarn() {
			return _missingWarn;
		},
		set missingWarn(val) {
			_missingWarn = val;
			_context.missingWarn = _missingWarn;
		},
		get fallbackWarn() {
			return _fallbackWarn;
		},
		set fallbackWarn(val) {
			_fallbackWarn = val;
			_context.fallbackWarn = _fallbackWarn;
		},
		get fallbackRoot() {
			return _fallbackRoot;
		},
		set fallbackRoot(val) {
			_fallbackRoot = val;
		},
		get fallbackFormat() {
			return _fallbackFormat;
		},
		set fallbackFormat(val) {
			_fallbackFormat = val;
			_context.fallbackFormat = _fallbackFormat;
		},
		get warnHtmlMessage() {
			return _warnHtmlMessage;
		},
		set warnHtmlMessage(val) {
			_warnHtmlMessage = val;
			_context.warnHtmlMessage = val;
		},
		get escapeParameter() {
			return _escapeParameter;
		},
		set escapeParameter(val) {
			_escapeParameter = val;
			_context.escapeParameter = val;
		},
		t,
		getLocaleMessage,
		setLocaleMessage,
		mergeLocaleMessage,
		getPostTranslationHandler,
		setPostTranslationHandler,
		getMissingHandler,
		setMissingHandler,
		[SetPluralRulesSymbol]: setPluralRules
	};
	composer.datetimeFormats = datetimeFormats;
	composer.numberFormats = numberFormats;
	composer.rt = rt;
	composer.te = te;
	composer.tm = tm;
	composer.d = d;
	composer.n = n;
	composer.getDateTimeFormat = getDateTimeFormat;
	composer.setDateTimeFormat = setDateTimeFormat;
	composer.mergeDateTimeFormat = mergeDateTimeFormat;
	composer.getNumberFormat = getNumberFormat;
	composer.setNumberFormat = setNumberFormat;
	composer.mergeNumberFormat = mergeNumberFormat;
	composer[InejctWithOptionSymbol] = __injectWithOption;
	composer[TranslateVNodeSymbol] = translateVNode;
	composer[DatetimePartsSymbol] = datetimeParts;
	composer[NumberPartsSymbol] = numberParts;
	return composer;
}
var baseFormatProps = {
	tag: { type: [String, Object] },
	locale: { type: String },
	scope: {
		type: String,
		validator: (val) => val === "parent" || val === "global",
		default: "parent"
	},
	i18n: { type: Object }
};
function getInterpolateArg({ slots }, keys) {
	if (keys.length === 1 && keys[0] === "default") return (slots.default ? slots.default() : []).reduce((slot, current) => {
		return [...slot, ...current.type === Fragment ? current.children : [current]];
	}, []);
	else return keys.reduce((arg, key) => {
		const slot = slots[key];
		if (slot) arg[key] = slot();
		return arg;
	}, create());
}
function getFragmentableTag() {
	return Fragment;
}
/**
* export the public type for h/tsx inference
* also to avoid inline import() in generated d.ts files
*/
/**
* Translation Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [TranslationProps](component#translationprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Component Interpolation](../guide/advanced/component)
*
* @example
* ```html
* <div id="app">
*   <!-- ... -->
*   <i18n keypath="term" tag="label" for="tos">
*     <a :href="url" target="_blank">{{ $t('tos') }}</a>
*   </i18n>
*   <!-- ... -->
* </div>
* ```
* ```js
* import { createApp } from 'vue'
* import { createI18n } from 'vue-i18n'
*
* const messages = {
*   en: {
*     tos: 'Term of Service',
*     term: 'I accept xxx {0}.'
*   },
*   ja: {
*     tos: '利用規約',
*     term: '私は xxx の{0}に同意します。'
*   }
* }
*
* const i18n = createI18n({
*   locale: 'en',
*   messages
* })
*
* const app = createApp({
*   data: {
*     url: '/term'
*   }
* }).use(i18n).mount('#app')
* ```
*
* @VueI18nComponent
*/
var Translation = /* @__PURE__ */ defineComponent({
	name: "i18n-t",
	props: assign({
		keypath: {
			type: String,
			required: true
		},
		plural: {
			type: [Number, String],
			validator: (val) => isNumber(val) || !isNaN(val)
		}
	}, baseFormatProps),
	setup(props, context) {
		const { slots, attrs } = context;
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return () => {
			const keys = Object.keys(slots).filter((key) => key[0] !== "_");
			const options = create();
			if (props.locale) options.locale = props.locale;
			if (props.plural !== void 0) options.plural = isString(props.plural) ? +props.plural : props.plural;
			const arg = getInterpolateArg(context, keys);
			const children = i18n[TranslateVNodeSymbol](props.keypath, arg, options);
			const assignedAttrs = assign(create(), attrs);
			const tag = isString(props.tag) || isObject(props.tag) ? props.tag : getFragmentableTag();
			return h(tag, assignedAttrs, children);
		};
	}
});
function isVNode$1(target) {
	return isArray(target) && !isString(target[0]);
}
function renderFormatter(props, context, slotKeys, partFormatter) {
	const { slots, attrs } = context;
	return () => {
		const options = { part: true };
		let overrides = create();
		if (props.locale) options.locale = props.locale;
		if (isString(props.format)) options.key = props.format;
		else if (isObject(props.format)) {
			if (isString(props.format.key)) options.key = props.format.key;
			overrides = Object.keys(props.format).reduce((options, prop) => {
				return slotKeys.includes(prop) ? assign(create(), options, { [prop]: props.format[prop] }) : options;
			}, create());
		}
		const parts = partFormatter(...[
			props.value,
			options,
			overrides
		]);
		let children = [options.key];
		if (isArray(parts)) children = parts.map((part, index) => {
			const slot = slots[part.type];
			const node = slot ? slot({
				[part.type]: part.value,
				index,
				parts
			}) : [part.value];
			if (isVNode$1(node)) node[0].key = `${part.type}-${index}`;
			return node;
		});
		else if (isString(parts)) children = [parts];
		const assignedAttrs = assign(create(), attrs);
		const tag = isString(props.tag) || isObject(props.tag) ? props.tag : getFragmentableTag();
		return h(tag, assignedAttrs, children);
	};
}
/**
* export the public type for h/tsx inference
* also to avoid inline import() in generated d.ts files
*/
/**
* Number Format Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [FormattableProps](component#formattableprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Custom Formatting](../guide/essentials/number#custom-formatting)
*
* @VueI18nDanger
* Not supported IE, due to no support `Intl.NumberFormat#formatToParts` in [IE](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/formatToParts)
*
* If you want to use it, you need to use [polyfill](https://github.com/formatjs/formatjs/tree/main/packages/intl-numberformat)
*
* @VueI18nComponent
*/
var NumberFormat = /* @__PURE__ */ defineComponent({
	name: "i18n-n",
	props: assign({
		value: {
			type: Number,
			required: true
		},
		format: { type: [String, Object] }
	}, baseFormatProps),
	setup(props, context) {
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return renderFormatter(props, context, NUMBER_FORMAT_OPTIONS_KEYS, (...args) => i18n[NumberPartsSymbol](...args));
	}
});
function getComposer$1(i18n, instance) {
	const i18nInternal = i18n;
	if (i18n.mode === "composition") return i18nInternal.__getInstance(instance) || i18n.global;
	else {
		const vueI18n = i18nInternal.__getInstance(instance);
		return vueI18n != null ? vueI18n.__composer : i18n.global.__composer;
	}
}
/**
* @deprecated will be removed at vue-i18n v12
*/
function vTDirective(i18n) {
	const _process = (binding) => {
		const { instance, value } = binding;
		/* istanbul ignore if */
		if (!instance || !instance.$) throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		const composer = getComposer$1(i18n, instance.$);
		const parsedValue = parseValue(value);
		return [Reflect.apply(composer.t, composer, [...makeParams(parsedValue)]), composer];
	};
	const register = (el, binding) => {
		const [textContent, composer] = _process(binding);
		el.__composer = composer;
		el.textContent = textContent;
	};
	const unregister = (el) => {
		if (el.__composer) {
			el.__composer = void 0;
			delete el.__composer;
		}
	};
	const update = (el, { value }) => {
		if (el.__composer) {
			const composer = el.__composer;
			const parsedValue = parseValue(value);
			el.textContent = Reflect.apply(composer.t, composer, [...makeParams(parsedValue)]);
		}
	};
	const getSSRProps = (binding) => {
		const [textContent] = _process(binding);
		return { textContent };
	};
	return {
		created: register,
		unmounted: unregister,
		beforeUpdate: update,
		getSSRProps
	};
}
function parseValue(value) {
	if (isString(value)) return { path: value };
	else if (isPlainObject$1(value)) {
		if (!("path" in value)) throw createI18nError(I18nErrorCodes.REQUIRED_VALUE, "path");
		return value;
	} else throw createI18nError(I18nErrorCodes.INVALID_VALUE);
}
function makeParams(value) {
	const { path, locale, args, choice, plural } = value;
	const options = {};
	const named = args || {};
	if (isString(locale)) options.locale = locale;
	if (isNumber(choice)) options.plural = choice;
	if (isNumber(plural)) options.plural = plural;
	return [
		path,
		named,
		options
	];
}
function apply(app, i18n, ...options) {
	const pluginOptions = isPlainObject$1(options[0]) ? options[0] : {};
	if (isBoolean(pluginOptions.globalInstall) ? pluginOptions.globalInstall : true) {
		[Translation.name, "I18nT"].forEach((name) => app.component(name, Translation));
		[NumberFormat.name, "I18nN"].forEach((name) => app.component(name, NumberFormat));
		[DatetimeFormat.name, "I18nD"].forEach((name) => app.component(name, DatetimeFormat));
	}
	app.directive("t", vTDirective(i18n));
}
/**
* Injection key for {@link useI18n}
*
* @remarks
* The global injection key for I18n instances with `useI18n`. this injection key is used in Web Components.
* Specify the i18n instance created by {@link createI18n} together with `provide` function.
*
* @VueI18nGeneral
*/
var I18nInjectionKey = /* #__PURE__*/ makeSymbol("global-vue-i18n");
function createI18n(options = {}) {
	const __globalInjection = isBoolean(options.globalInjection) ? options.globalInjection : true;
	const __instances = /* @__PURE__ */ new Map();
	const [globalScope, __global] = createGlobal(options);
	const symbol = /* #__PURE__*/ makeSymbol("");
	function __getInstance(component) {
		return __instances.get(component) || null;
	}
	function __setInstance(component, instance) {
		__instances.set(component, instance);
	}
	function __deleteInstance(component) {
		__instances.delete(component);
	}
	const i18n = {
		get mode() {
			return "composition";
		},
		async install(app, ...options) {
			app.__VUE_I18N_SYMBOL__ = symbol;
			app.provide(app.__VUE_I18N_SYMBOL__, i18n);
			if (isPlainObject$1(options[0])) {
				const opts = options[0];
				i18n.__composerExtend = opts.__composerExtend;
				i18n.__vueI18nExtend = opts.__vueI18nExtend;
			}
			let globalReleaseHandler = null;
			if (__globalInjection) globalReleaseHandler = injectGlobalFields(app, i18n.global);
			apply(app, i18n, ...options);
			const unmountApp = app.unmount;
			app.unmount = () => {
				globalReleaseHandler && globalReleaseHandler();
				i18n.dispose();
				unmountApp();
			};
		},
		get global() {
			return __global;
		},
		dispose() {
			globalScope.stop();
		},
		__instances,
		__getInstance,
		__setInstance,
		__deleteInstance
	};
	return i18n;
}
function useI18n(options = {}) {
	const instance = getCurrentInstance$1();
	if (instance == null) throw createI18nError(I18nErrorCodes.MUST_BE_CALL_SETUP_TOP);
	if (!instance.isCE && instance.appContext.app != null && !instance.appContext.app.__VUE_I18N_SYMBOL__) throw createI18nError(I18nErrorCodes.NOT_INSTALLED);
	const i18n = getI18nInstance(instance);
	const gl = getGlobalComposer(i18n);
	const componentOptions = getComponentOptions(instance);
	const scope = getScope(options, componentOptions);
	if (scope === "global") {
		adjustI18nResources(gl, options, componentOptions);
		return gl;
	}
	if (scope === "parent") {
		let composer = getComposer$2(i18n, instance, options.__useComponent);
		if (composer == null) composer = gl;
		return composer;
	}
	const i18nInternal = i18n;
	let composer = i18nInternal.__getInstance(instance);
	if (composer == null) {
		const composerOptions = assign({}, options);
		if ("__i18n" in componentOptions) composerOptions.__i18n = componentOptions.__i18n;
		if (gl) composerOptions.__root = gl;
		composer = createComposer(composerOptions);
		if (i18nInternal.__composerExtend) composer[DisposeSymbol] = i18nInternal.__composerExtend(composer);
		i18nInternal.__setInstance(instance, composer);
	}
	return composer;
}
function createGlobal(options, legacyMode) {
	const scope = effectScope();
	const obj = scope.run(() => createComposer(options));
	if (obj == null) throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
	return [scope, obj];
}
function getI18nInstance(instance) {
	const i18n = inject(!instance.isCE ? instance.appContext.app.__VUE_I18N_SYMBOL__ : I18nInjectionKey);
	/* istanbul ignore if */
	if (!i18n) throw createI18nError(!instance.isCE ? I18nErrorCodes.UNEXPECTED_ERROR : I18nErrorCodes.NOT_INSTALLED_WITH_PROVIDE);
	return i18n;
}
function getScope(options, componentOptions) {
	return isEmptyObject(options) ? "__i18n" in componentOptions ? "local" : "global" : !options.useScope ? "local" : options.useScope;
}
function getGlobalComposer(i18n) {
	return i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
}
function getComposer$2(i18n, target, useComponent = false) {
	let composer = null;
	const root = target.root;
	let current = getParentComponentInstance(target, useComponent);
	while (current != null) {
		const i18nInternal = i18n;
		if (i18n.mode === "composition") composer = i18nInternal.__getInstance(current);
		if (composer != null) break;
		if (root === current) break;
		current = current.parent;
	}
	return composer;
}
function getParentComponentInstance(target, useComponent = false) {
	if (target == null) return null;
	return !useComponent ? target.parent : target.vnode.ctx || target.parent;
}
var globalExportProps = [
	"locale",
	"fallbackLocale",
	"availableLocales"
];
var globalExportMethods = [
	"t",
	"rt",
	"d",
	"n",
	"tm",
	"te"
];
function injectGlobalFields(app, composer) {
	const i18n = Object.create(null);
	globalExportProps.forEach((prop) => {
		const desc = Object.getOwnPropertyDescriptor(composer, prop);
		if (!desc) throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		const wrap = isRef(desc.value) ? {
			get() {
				return desc.value.value;
			},
			set(val) {
				desc.value.value = val;
			}
		} : { get() {
			return desc.get && desc.get();
		} };
		Object.defineProperty(i18n, prop, wrap);
	});
	app.config.globalProperties.$i18n = i18n;
	globalExportMethods.forEach((method) => {
		const desc = Object.getOwnPropertyDescriptor(composer, method);
		if (!desc || !desc.value) throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		Object.defineProperty(app.config.globalProperties, `$${method}`, desc);
	});
	const dispose = () => {
		delete app.config.globalProperties.$i18n;
		globalExportMethods.forEach((method) => {
			delete app.config.globalProperties[`$${method}`];
		});
	};
	return dispose;
}
/**
* Datetime Format Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [FormattableProps](component#formattableprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Custom Formatting](../guide/essentials/datetime#custom-formatting)
*
* @VueI18nDanger
* Not supported IE, due to no support `Intl.DateTimeFormat#formatToParts` in [IE](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/formatToParts)
*
* If you want to use it, you need to use [polyfill](https://github.com/formatjs/formatjs/tree/main/packages/intl-datetimeformat)
*
* @VueI18nComponent
*/
var DatetimeFormat = /* @__PURE__ */ defineComponent({
	name: "i18n-d",
	props: assign({
		value: {
			type: [Number, Date],
			required: true
		},
		format: { type: [String, Object] }
	}, baseFormatProps),
	setup(props, context) {
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return renderFormatter(props, context, DATETIME_FORMAT_OPTIONS_KEYS, (...args) => i18n[DatetimePartsSymbol](...args));
	}
});
registerMessageCompiler(compile);
registerMessageResolver(resolveValue);
registerLocaleFallbacker(fallbackWithLocaleChain);
//#endregion
//#region node_modules/primevue/usetoast/index.mjs
var PrimeVueToastSymbol = Symbol();
function useToast() {
	var PrimeVueToast = inject(PrimeVueToastSymbol);
	if (!PrimeVueToast) throw new Error("No PrimeVue Toast provided!");
	return PrimeVueToast;
}
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fi18n-options.mjs
var localeCodes = ["en", "zh"];
var localeLoaders = {
	en: [],
	zh: []
};
var vueI18nConfigs = [() => import(
	'../build/i18n.config-U3gDhhWo.mjs'
	/* webpackChunkName: "config_i18n_46config_46ts_cf57bcf6" */
)];
var normalizedLocales = [{
	code: "en",
	language: "en-US"
}, {
	code: "zh",
	language: "zh-CN"
}];
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/messages.js
var cacheMessages = /* @__PURE__ */ new Map();
var merger = createDefu((obj, key, value) => {
	if (key === "messages" || key === "datetimeFormats" || key === "numberFormats") {
		obj[key] ??= create(null);
		deepCopy(value, obj[key]);
		return true;
	}
});
async function loadVueI18nOptions(vueI18nConfigs) {
	const nuxtApp = useNuxtApp();
	let vueI18nOptions = { messages: create(null) };
	for (const configFile of vueI18nConfigs) {
		const resolver = await configFile().then((x) => isModule(x) ? x.default : x);
		const resolved = isFunction(resolver) ? await nuxtApp.runWithContext(() => resolver()) : resolver;
		vueI18nOptions = merger(create(null), resolved, vueI18nOptions);
	}
	vueI18nOptions.fallbackLocale ??= false;
	return vueI18nOptions;
}
var isModule = (val) => toTypeString(val) === "[object Module]";
async function getLocaleMessages(locale, loader) {
	const nuxtApp = useNuxtApp();
	try {
		const getter = await nuxtApp.runWithContext(loader.load).then((x) => isModule(x) ? x.default : x);
		return isFunction(getter) ? await nuxtApp.runWithContext(() => getter(locale)) : getter;
	} catch (e) {
		throw new Error(`Failed loading locale (${locale}): ` + e.message);
	}
}
async function getLocaleMessagesMergedCached(locale, loaders = []) {
	const nuxtApp = useNuxtApp();
	const messages = await Promise.all(loaders.map(async (loader) => {
		const cached = getCachedMessages(loader);
		const messages2 = cached || await nuxtApp.runWithContext(() => getLocaleMessages(locale, loader));
		if (!cached && loader.cache !== false) cacheMessages.set(loader.key, {
			ttl: Date.now() + 864e5,
			value: messages2
		});
		return messages2;
	}));
	const merged = {};
	for (const message of messages) deepCopy(message, merged);
	return merged;
}
function getCachedMessages(loader) {
	if (loader.cache === false) return;
	const cache = cacheMessages.get(loader.key);
	if (cache == null) return;
	return cache.ttl > Date.now() ? cache.value : void 0;
}
//#endregion
//#region node_modules/@intlify/utils/dist/shared/utils.9f8159f5.mjs
function parseAcceptLanguage(value) {
	return value.split(",").map((tag) => tag.split(";")[0]).filter((tag) => !(tag === "*" || tag === ""));
}
function createPathIndexLanguageParser(index = 0) {
	return (path) => {
		const parts = (typeof path === "string" ? path : path.pathname).split("?")[0].split("/");
		if (parts[0] === "") parts.shift();
		return parts.length > index ? parts[index] || "" : "";
	};
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/kit/routing.js
var separator = "___";
var defaultRouteNameSuffix = "___default";
function normalizeRouteName(routeName) {
	if (typeof routeName === "string") return routeName;
	if (routeName != null) return routeName.toString();
	return "";
}
function getRouteBaseName(route) {
	return normalizeRouteName(typeof route === "object" ? route?.name : route).split(separator)[0];
}
function getLocalizedRouteName(routeName, locale, isDefault) {
	return true ? routeName + separator + locale : routeName + separator + locale + defaultRouteNameSuffix;
}
var pathLanguageParser = createPathIndexLanguageParser(0);
var getLocaleFromRoutePath = (path) => pathLanguageParser(path);
var getLocaleFromRouteName = (name) => name.split(separator).at(1) ?? "";
function normalizeInput(input) {
	return typeof input !== "object" ? String(input) : String(input?.name || input?.path || "");
}
function getLocaleFromRoute(route) {
	const input = normalizeInput(route);
	return input[0] === "/" ? getLocaleFromRoutePath(input) : getLocaleFromRouteName(input);
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/routing/utils.js
function createLocaleRouteNameGetter(defaultLocale) {
	return (name, locale) => getLocalizedRouteName(normalizeRouteName(name), locale);
}
function createLocalizedRouteByPathResolver(router) {
	return (route) => router.resolve(route);
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/routing/routing.js
function localePath(ctx, route, locale = ctx.getLocale()) {
	if (isString(route) && hasProtocol$1(route, { acceptRelative: true })) return route;
	try {
		return resolveRoute(ctx, route, locale).fullPath;
	} catch {
		return "";
	}
}
function localeRoute(ctx, route, locale = ctx.getLocale()) {
	try {
		return resolveRoute(ctx, route, locale);
	} catch {
		return;
	}
}
function normalizeRawLocation(route) {
	if (!isString(route)) return assign({}, route);
	if (route[0] === "/") {
		const { pathname: path, search, hash } = parsePath$1(route);
		return {
			path,
			query: parseQuery$1(search),
			hash
		};
	}
	return { name: route };
}
function resolveRoute(ctx, route, locale) {
	const normalized = normalizeRawLocation(route);
	const resolved = ctx.router.resolve(ctx.resolveLocalizedRouteObject(normalized, locale));
	if (resolved.name) return resolved;
	return ctx.router.resolve(route);
}
function switchLocalePath(ctx, locale, route = ctx.router.currentRoute.value) {
	const name = ctx.getRouteBaseName(route);
	if (!name) return "";
	const path = localePath(ctx, {
		name,
		params: assign({}, route.params, ctx.getLocalizedDynamicParams(locale)),
		fullPath: route.fullPath,
		query: route.query,
		hash: route.hash,
		path: route.path,
		meta: route.meta
	}, locale);
	return ctx.afterSwitchLocalePath(path, locale);
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/locales.js
function getDefaultLocaleForDomain(host) {
	return normalizedLocales.find((l) => !!l.defaultForDomains?.includes(host))?.code;
}
var isSupportedLocale = (locale) => localeCodes.includes(locale || "");
var resolveSupportedLocale = (locale) => isSupportedLocale(locale) ? locale : void 0;
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/kit/browser.js
function matchBrowserLocale(locales, browserLocales) {
	const matchedLocales = [];
	for (const [index, browserCode] of browserLocales.entries()) {
		const matchedLocale = locales.find((l) => l.language?.toLowerCase() === browserCode.toLowerCase());
		if (matchedLocale) {
			matchedLocales.push({
				code: matchedLocale.code,
				score: 1 - index / browserLocales.length
			});
			break;
		}
	}
	for (const [index, browserCode] of browserLocales.entries()) {
		const languageCode = browserCode.split("-")[0].toLowerCase();
		const matchedLocale = locales.find((l) => l.language?.split("-")[0].toLowerCase() === languageCode);
		if (matchedLocale) {
			matchedLocales.push({
				code: matchedLocale.code,
				score: .999 - index / browserLocales.length
			});
			break;
		}
	}
	return matchedLocales;
}
function compareBrowserLocale(a, b) {
	if (a.score === b.score) return b.code.length - a.code.length;
	return b.score - a.score;
}
function findBrowserLocale(locales, browserLocales) {
	return matchBrowserLocale(locales.map((l) => ({
		code: l.code,
		language: l.language || l.code
	})), browserLocales).sort(compareBrowserLocale).at(0)?.code ?? "";
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/utils.js
function useRuntimeI18n(nuxtApp, event) {
	if (!nuxtApp) return useRuntimeConfig().public.i18n;
	return nuxtApp.$config.public.i18n;
}
function useI18nDetection(nuxtApp) {
	const detectBrowserLanguage = useRuntimeI18n(nuxtApp).detectBrowserLanguage;
	const detect = detectBrowserLanguage || {};
	return {
		...detect,
		enabled: !!detectBrowserLanguage,
		cookieKey: detect.cookieKey || "i18n_redirected"
	};
}
function resolveRootRedirect(config) {
	if (!config) return;
	return {
		path: "/" + (isString(config) ? config : config.path).replace(/^\//, ""),
		code: !isString(config) && config.statusCode || 302
	};
}
function toArray$1(value) {
	return Array.isArray(value) ? value : [value];
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/domain.js
function matchDomainLocale(locales, host, pathLocale) {
	const normalizeDomain = (domain = "") => domain.replace(/https?:\/\//, "");
	const matches = locales.filter((locale) => normalizeDomain(locale.domain) === host || toArray$1(locale.domains).includes(host));
	if (matches.length <= 1) return matches[0]?.code;
	return matches.find((l) => l.code === pathLocale)?.code || matches.find((l) => l.defaultForDomains?.includes(host) ?? l.domainDefault)?.code;
}
function domainFromLocale(domainLocales, url, locale) {
	const lang = normalizedLocales.find((x) => x.code === locale);
	const domain = domainLocales?.[locale]?.domain || lang?.domain || lang?.domains?.find((v) => v === url.host);
	if (!domain) return;
	if (hasProtocol$1(domain, { strict: true })) return domain;
	return url.protocol + "//" + domain;
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/detection.js
var getCookieLocale = (event, cookieName) => getCookie(event, cookieName) || void 0;
var getRouteLocale = (event, route) => getLocaleFromRoute(route);
var getHeaderLocale = (event) => findBrowserLocale(normalizedLocales, parseAcceptLanguage(getRequestHeader(event, "accept-language") || ""));
var getHostLocale = (event, path, domainLocales) => {
	const host = getRequestURL(event, { xForwardedHost: true }).host;
	return matchDomainLocale(normalizedLocales.map((l) => ({
		...l,
		domain: domainLocales[l.code]?.domain ?? l.domain
	})), host, getLocaleFromRoutePath(path));
};
var useDetectors = (event, config, nuxtApp) => {
	if (!event) throw new Error("H3Event is required for server-side locale detection");
	const runtimeI18n = useRuntimeI18n(nuxtApp);
	return {
		cookie: () => getCookieLocale(event, config.cookieKey),
		header: () => getHeaderLocale(event),
		navigator: () => void 0,
		host: (path) => getHostLocale(event, path, runtimeI18n.domainLocales),
		route: (path) => getRouteLocale(event, path)
	};
};
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/utils.js
var isRouteLocationPathRaw = (val) => !!val.path && !val.name;
function useComposableContext(nuxtApp) {
	const context = nuxtApp?._nuxtI18n?.composableCtx;
	if (!context) throw new Error("i18n context is not initialized. Ensure the i18n plugin is installed and the composable is used within a Vue component or setup function.");
	return context;
}
var formatTrailingSlash = withoutTrailingSlash$1;
function createComposableContext(ctx, nuxtApp = useNuxtApp()) {
	const router = useRouter();
	useDetectors(useRequestEvent(), useI18nDetection(nuxtApp), nuxtApp);
	const defaultLocale = ctx.getDefaultLocale();
	const getLocalizedRouteName = createLocaleRouteNameGetter();
	function resolveLocalizedRouteByName(route, locale) {
		route.name = getRouteBaseName(route.name || router.currentRoute.value);
		const localizedName = getLocalizedRouteName(route.name, locale);
		if (router.hasRoute(localizedName)) route.name = localizedName;
		return route;
	}
	const routeByPathResolver = createLocalizedRouteByPathResolver(router);
	function resolveLocalizedRouteByPath(input, locale) {
		const route = routeByPathResolver(input, locale);
		const baseName = getRouteBaseName(route);
		if (baseName) {
			route.name = getLocalizedRouteName(baseName, locale);
			return route;
		}
		if (prefixable(locale, defaultLocale)) route.path = "/" + locale + route.path;
		route.path = formatTrailingSlash(route.path, true);
		return route;
	}
	const composableCtx = {
		router,
		_head: void 0,
		get head() {
			this._head ??= useHead$1({});
			return this._head;
		},
		metaState: {
			htmlAttrs: {},
			meta: [],
			link: []
		},
		seoSettings: {
			dir: false,
			lang: false,
			seo: false
		},
		localePathPayload: getLocalePathPayload(),
		routingOptions: {
			defaultLocale,
			strictCanonicals: ctx.config.experimental.alternateLinkCanonicalQueries ?? true,
			hreflangLinks: true
		},
		getLocale: ctx.getLocale,
		getLocales: ctx.getLocales,
		getBaseUrl: ctx.getBaseUrl,
		getRouteBaseName,
		getRouteLocalizedParams: () => router.currentRoute.value.meta["nuxtI18nInternal"] ?? {},
		getLocalizedDynamicParams: (locale) => {
			return composableCtx.getRouteLocalizedParams()?.[locale];
		},
		afterSwitchLocalePath: (path, locale) => {
			composableCtx.getRouteLocalizedParams();
			return path;
		},
		resolveLocalizedRouteObject: (route, locale) => {
			return isRouteLocationPathRaw(route) ? resolveLocalizedRouteByPath(route, locale) : resolveLocalizedRouteByName(route, locale);
		}
	};
	return composableCtx;
}
function getLocalePathPayload(nuxtApp = useNuxtApp()) {
	return JSON.parse("{}");
}
async function loadAndSetLocale(nuxtApp, locale) {
	const ctx = useNuxtI18nContext(nuxtApp);
	const oldLocale = ctx.getLocale();
	if (locale === oldLocale && !ctx.initial) return locale;
	const data = {
		oldLocale,
		newLocale: locale,
		initialSetup: ctx.initial,
		context: nuxtApp
	};
	let override = await nuxtApp.callHook("i18n:beforeLocaleSwitch", data);
	override ??= data.newLocale;
	if (isSupportedLocale(override)) locale = override;
	await ctx.loadMessages(locale);
	await ctx.setLocaleSuspend(locale);
	return locale;
}
function skipDetect(detect, path, pathLocale) {
	if (detect.redirectOn === "root" && path !== "/") return true;
	if (detect.redirectOn === "no prefix" && !detect.alwaysRedirect && isSupportedLocale(pathLocale)) return true;
	return false;
}
function detectLocale(nuxtApp, route) {
	const detectConfig = useI18nDetection(nuxtApp);
	const detectors = useDetectors(useRequestEvent(nuxtApp), detectConfig, nuxtApp);
	const ctx = useNuxtI18nContext(nuxtApp);
	const path = isString(route) ? route : route.path;
	function* detect() {
		if (ctx.initial && detectConfig.enabled && !skipDetect(detectConfig, path, detectors.route(path))) {
			yield detectors.cookie();
			yield detectors.header();
			yield detectors.navigator();
			yield detectConfig.fallbackLocale;
		}
		yield detectors.route(route);
	}
	for (const detected of detect()) if (detected && isSupportedLocale(detected)) return detected;
	return ctx.getLocale() || ctx.getDefaultLocale() || "";
}
function navigate(nuxtApp, to, locale) {
	const ctx = useNuxtI18nContext(nuxtApp);
	const _ctx = useComposableContext(nuxtApp);
	if (to.path === "/" && ctx.rootRedirect) return navigateTo(localePath(_ctx, ctx.rootRedirect.path, locale), { redirectCode: ctx.rootRedirect.code });
	if (ctx.vueI18n.__pendingLocale && useNuxtApp()._processingMiddleware) return;
	if (useDetectors(useRequestEvent(), useI18nDetection(nuxtApp), nuxtApp).route(to) === locale) return;
	const destination = switchLocalePath(_ctx, locale, to) || localePath(_ctx, to.fullPath, locale);
	if (isEqual$1(destination, to.fullPath)) return;
	return navigateTo(destination, { redirectCode: ctx.redirectStatusCode });
}
function prefixable(currentLocale, defaultLocale) {
	return currentLocale !== defaultLocale || false;
}
function createBaseUrlGetter(nuxt, baseUrl, defaultLocale, getDomainFromLocale) {
	if (isFunction(baseUrl)) return () => baseUrl(nuxt);
	return () => {
		return baseUrl ?? "";
	};
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/compatibility.js
function getI18nTarget(i18n) {
	return i18n != null && "global" in i18n && "mode" in i18n ? i18n.global : i18n;
}
function getComposer(i18n) {
	const target = getI18nTarget(i18n);
	return "__composer" in target ? target.__composer : target;
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/context.js
var useLocaleConfigs = () => useState("i18n:cached-locale-configs", () => void 0);
var useResolvedLocale = () => useState("i18n:resolved-locale", () => "");
function useI18nCookie({ cookieCrossOrigin, cookieDomain, cookieSecure, cookieKey }) {
	const date = /* @__PURE__ */ new Date();
	return useCookie(cookieKey, {
		path: "/",
		readonly: false,
		expires: new Date(date.setDate(date.getDate() + 365)),
		sameSite: cookieCrossOrigin ? "none" : "lax",
		domain: cookieDomain || void 0,
		secure: cookieCrossOrigin || cookieSecure
	});
}
function createNuxtI18nContext(nuxt, vueI18n, defaultLocale) {
	const i18n = getI18nTarget(vueI18n);
	const runtimeI18n = useRuntimeI18n(nuxt);
	const detectConfig = useI18nDetection(nuxt);
	const serverLocaleConfigs = useLocaleConfigs();
	const localeCookie = useI18nCookie(detectConfig);
	const loadMap = /* @__PURE__ */ new Set();
	const getLocaleConfig = (locale) => serverLocaleConfigs.value[locale];
	const getDomainFromLocale = (locale) => domainFromLocale(runtimeI18n.domainLocales, useRequestURL({ xForwardedHost: true }), locale);
	const baseUrl = createBaseUrlGetter(nuxt, runtimeI18n.baseUrl);
	const resolvedLocale = useResolvedLocale();
	if (nuxt.ssrContext?.event?.context?.nuxtI18n?.detectLocale) resolvedLocale.value = nuxt.ssrContext.event.context.nuxtI18n.detectLocale;
	const loadMessagesFromClient = async (locale) => {
		const locales = getLocaleConfig(locale)?.fallbacks ?? [];
		if (!locales.includes(locale)) locales.push(locale);
		for (const k of locales) {
			const msg = await nuxt.runWithContext(() => getLocaleMessagesMergedCached(k, localeLoaders[k]));
			i18n.mergeLocaleMessage(k, msg);
		}
	};
	const loadMessagesFromServer = async (locale) => {
		if (locale in localeLoaders === false) return;
		const headers = getLocaleConfig(locale)?.cacheable ? {} : { "Cache-Control": "no-cache" };
		const messages = await $fetch(`/_i18n/2a1cgsZ8/${locale}/messages.json`, { headers });
		for (const k of Object.keys(messages)) i18n.mergeLocaleMessage(k, messages[k]);
	};
	const ctx = {
		vueI18n,
		initial: true,
		preloaded: false,
		config: runtimeI18n,
		rootRedirect: resolveRootRedirect(runtimeI18n.rootRedirect),
		redirectStatusCode: runtimeI18n.redirectStatusCode ?? 302,
		dynamicResourcesSSG: false,
		getDefaultLocale: () => defaultLocale,
		getLocale: () => unref(i18n.locale),
		setLocale: async (locale) => {
			const oldLocale = ctx.getLocale();
			if (locale === oldLocale || !isSupportedLocale(locale)) return;
			if (isRef(i18n.locale)) i18n.locale.value = locale;
			else i18n.locale = locale;
			await nuxt.callHook("i18n:localeSwitched", {
				newLocale: locale,
				oldLocale
			});
			resolvedLocale.value = locale;
		},
		setLocaleSuspend: async (locale) => {
			if (!isSupportedLocale(locale)) return;
			ctx.vueI18n.__pendingLocale = locale;
			ctx.vueI18n.__pendingLocalePromise = new Promise((resolve) => {
				ctx.vueI18n.__resolvePendingLocalePromise = async () => {
					ctx.setCookieLocale(locale);
					await ctx.setLocale(locale);
					ctx.vueI18n.__pendingLocale = void 0;
					resolve();
				};
			});
			await ctx.vueI18n.__resolvePendingLocalePromise?.();
		},
		getLocales: () => unref(i18n.locales).map((x) => isString(x) ? { code: x } : x),
		setCookieLocale: (locale) => {
			if (detectConfig.useCookie && isSupportedLocale(locale)) localeCookie.value = locale;
		},
		getBaseUrl: (locale) => {
			if (locale) return joinURL$1(getDomainFromLocale(locale) || baseUrl(), nuxt.$config.app.baseURL);
			return joinURL$1(baseUrl(), nuxt.$config.app.baseURL);
		},
		loadMessages: async (locale) => {
			if (nuxt.isHydrating && loadMap.has(locale)) return;
			try {
				return ctx.dynamicResourcesSSG || false ? await loadMessagesFromClient(locale) : await loadMessagesFromServer(locale);
			} catch (e) {
				console.warn(`Failed to load messages for locale "${locale}"`, e);
			} finally {
				loadMap.add(locale);
			}
		},
		composableCtx: void 0
	};
	ctx.composableCtx = createComposableContext(ctx, nuxt);
	return ctx;
}
function useNuxtI18nContext(nuxt) {
	if (nuxt._nuxtI18n == null) throw new Error("Nuxt I18n context has not been set up yet.");
	return nuxt._nuxtI18n;
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/kit/head.js
function localeHead$1(options, currentLanguage = options.getCurrentLanguage(), currentDirection = options.getCurrentDirection()) {
	const metaObject = {
		htmlAttrs: {},
		link: [],
		meta: []
	};
	if (options.dir) metaObject.htmlAttrs.dir = currentDirection;
	if (options.lang && currentLanguage) metaObject.htmlAttrs.lang = currentLanguage;
	if (options.seo) {
		const alternateLinks = getHreflangLinks(options);
		metaObject.link = metaObject.link.concat(alternateLinks, getCanonicalLink(options));
		metaObject.meta = metaObject.meta.concat(getOgUrl(options), getCurrentOgLocale(options), getAlternateOgLocales(options, options.locales.map((x) => x.language || x.code)));
	}
	return metaObject;
}
function createLocaleMap(locales) {
	const localeMap = /* @__PURE__ */ new Map();
	for (const locale of locales) {
		if (!locale.language) {
			console.warn("Locale `language` ISO code is required to generate alternate link");
			continue;
		}
		const [language, region] = locale.language.split("-");
		if (language && region && (locale.isCatchallLocale || !localeMap.has(language))) localeMap.set(language, locale);
		localeMap.set(locale.language, locale);
	}
	return localeMap;
}
function getHreflangLinks(options) {
	if (!options.hreflangLinks) return [];
	const links = [];
	const localeMap = createLocaleMap(options.locales);
	for (const [language, locale] of localeMap.entries()) {
		const link = getHreflangLink(language, locale, options);
		if (!link) continue;
		links.push(link);
		if (options.defaultLocale && options.defaultLocale === locale.code && links[0].hreflang !== "x-default") links.unshift({
			[options.key]: "i18n-xd",
			rel: "alternate",
			href: link.href,
			hreflang: "x-default"
		});
	}
	return links;
}
function getHreflangLink(language, locale, options, routeWithoutQuery = options.strictCanonicals ? options.getRouteWithoutQuery() : void 0) {
	const localePath = options.getLocalizedRoute(locale.code, routeWithoutQuery);
	if (!localePath) return;
	const href = withQuery$1(hasProtocol$1(localePath) ? localePath : joinURL$1(options.baseUrl, localePath), options.strictCanonicals ? getCanonicalQueryParams(options) : {});
	return {
		[options.key]: `i18n-alt-${language}`,
		rel: "alternate",
		href,
		hreflang: language
	};
}
function getCanonicalUrl(options, route = options.getCurrentRoute()) {
	const currentRoute = options.getLocaleRoute(Object.assign({}, route, {
		path: void 0,
		name: options.getRouteBaseName(route)
	}));
	if (!currentRoute) return "";
	return withQuery$1(joinURL$1(options.baseUrl, currentRoute.path), getCanonicalQueryParams(options));
}
function getCanonicalLink(options, href = getCanonicalUrl(options)) {
	if (!href) return [];
	return [{
		[options.key]: "i18n-can",
		rel: "canonical",
		href
	}];
}
function getCanonicalQueryParams(options, route = options.getCurrentRoute()) {
	const currentRouteQuery = options.getLocaleRoute(Object.assign({}, route, {
		path: void 0,
		name: options.getRouteBaseName(route)
	}))?.query ?? {};
	const params = {};
	for (const param of options.canonicalQueries.filter((x) => x in currentRouteQuery)) {
		params[param] ??= [];
		for (const val of toArray$2(currentRouteQuery[param])) params[param].push(val || "");
	}
	return params;
}
function getOgUrl(options, href = getCanonicalUrl(options)) {
	if (!href) return [];
	return [{
		[options.key]: "i18n-og-url",
		property: "og:url",
		content: href
	}];
}
function getCurrentOgLocale(options, currentLanguage = options.getCurrentLanguage()) {
	if (!currentLanguage) return [];
	return [{
		[options.key]: "i18n-og",
		property: "og:locale",
		content: formatOgLanguage(currentLanguage)
	}];
}
function getAlternateOgLocales(options, languages, currentLanguage = options.getCurrentLanguage()) {
	return languages.filter((locale) => locale && locale !== currentLanguage).map((locale) => ({
		[options.key]: `i18n-og-alt-${locale}`,
		property: "og:locale:alternate",
		content: formatOgLanguage(locale)
	}));
}
function formatOgLanguage(val = "") {
	return val.replace(/-/g, "_");
}
function toArray$2(value) {
	return Array.isArray(value) ? value : [value];
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/routing/head.js
function createHeadContext(ctx, config, locale = ctx.getLocale(), locales = ctx.getLocales(), baseUrl = ctx.getBaseUrl()) {
	const currentLocale = locales.find((l) => l.code === locale) || { };
	const canonicalQueries = typeof config.seo === "object" && config.seo?.canonicalQueries || [];
	if (!baseUrl && true) console.warn("I18n `baseUrl` is required to generate valid SEO tag links.");
	return {
		...config,
		key: "id",
		locales,
		baseUrl,
		canonicalQueries,
		hreflangLinks: ctx.routingOptions.hreflangLinks,
		defaultLocale: ctx.routingOptions.defaultLocale,
		strictCanonicals: ctx.routingOptions.strictCanonicals,
		getRouteBaseName: ctx.getRouteBaseName,
		getCurrentRoute: () => ctx.router.currentRoute.value,
		getCurrentLanguage: () => currentLocale.language,
		getCurrentDirection: () => currentLocale.dir || "ltr",
		getLocaleRoute: (route) => localeRoute(ctx, route),
		getLocalizedRoute: (locale2, route) => switchLocalePath(ctx, locale2, route),
		getRouteWithoutQuery: () => {
			try {
				return assign({}, ctx.router.resolve({ query: {} }), { meta: ctx.router.currentRoute.value.meta });
			} catch {
				return;
			}
		}
	};
}
function localeHead(ctx, { dir = true, lang = true, seo = true }) {
	return localeHead$1(createHeadContext(ctx, {
		dir,
		lang,
		seo
	}));
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/composables/index.js
function useRouteBaseName(nuxtApp = useNuxtApp()) {
	const common = useComposableContext(nuxtApp);
	return (route) => {
		if (route == null) return;
		return common.getRouteBaseName(route) || void 0;
	};
}
function useLocalePath(nuxtApp = useNuxtApp()) {
	const common = useComposableContext(nuxtApp);
	return (route, locale) => localePath(common, route, locale);
}
function useLocaleRoute(nuxtApp = useNuxtApp()) {
	const common = useComposableContext(nuxtApp);
	return (route, locale) => localeRoute(common, route, locale);
}
function useSwitchLocalePath(nuxtApp = useNuxtApp()) {
	const common = useComposableContext(nuxtApp);
	return (locale) => switchLocalePath(common, locale);
}
//#endregion
//#region node_modules/@pinia/nuxt/dist/runtime/composables.js
var composables_exports = /* @__PURE__ */ __exportAll({ usePinia: () => usePinia });
__reExport(composables_exports, import_pinia);
var usePinia = () => useNuxtApp().$pinia;
//#endregion
//#region app/stores/app.ts
/**
* 全局界面状态仓库。
* 这里只保存跨页面共享的 UI 状态，避免组件之间通过 useState 隐式耦合。
*/
var useAppStore = (0, composables_exports.defineStore)("app", () => {
	const isFullScreenLoading = ref(true);
	const deferredPrompt = shallowRef(null);
	function setFullScreenLoading(value) {
		isFullScreenLoading.value = value;
	}
	function setDeferredPrompt(event) {
		deferredPrompt.value = event;
	}
	function clearDeferredPrompt() {
		deferredPrompt.value = null;
	}
	return {
		isFullScreenLoading,
		deferredPrompt,
		setFullScreenLoading,
		setDeferredPrompt,
		clearDeferredPrompt
	};
});
//#endregion
//#region app/utils/index.ts
/**
* 判断浏览器是否支持现代文件操作
*/
function isModernFileAPIAvailable() {
	const fileHandleSupported = "FileSystemHandle" in void 0;
	const openFilePickerSupported = "showOpenFilePicker" in void 0;
	const saveFilePickerSupported = "showSaveFilePicker" in void 0;
	const directoryPickerSupported = "showDirectoryPicker" in void 0;
	return fileHandleSupported && openFilePickerSupported && saveFilePickerSupported && directoryPickerSupported;
}
/**
* 判断浏览器是否支持目录选择
* @returns 是否支持目录选择
*/
function supportsDirectorySelection() {
	var input = (void 0).createElement("input");
	input.type = "file";
	return "webkitdirectory" in input || "directory" in input;
}
/**
* 生成随机字符串
* @param length 长度
* @returns
*/
function genRandomString(length) {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	let randomString = "";
	for (let i = 0; i < length; i++) {
		const randomIndex = Math.floor(Math.random() * 62);
		randomString += charset.charAt(randomIndex);
	}
	return randomString;
}
/**
* 将字节格式化为人类友好的文本
*
* @param bytes 字节数量
* @param decimals 显示的小数位数
*
* @return 格式化后的字符串
*/
function humanFileSize(bytes, decimals = 2) {
	if (!bytes) return "0B";
	var k = 1024;
	var dm = decimals || 2;
	var sizes = [
		"B",
		"KB",
		"MB",
		"GB",
		"TB",
		"PB",
		"EB",
		"ZB",
		"YB"
	];
	var i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + (sizes[i] ?? "");
}
function doDownloadFromHref(href, filename) {
	const a = (void 0).createElement("a");
	a.style.display = "none";
	a.href = href;
	a.download = filename;
	(void 0).body.appendChild(a);
	a.click();
	a.remove();
}
/**
* 从Blob下载
*
* @param {Blob} blob
* @param {string} filename
*/
function doDownloadFromBlob(blob, filename) {
	const objUrl = URL.createObjectURL(blob);
	doDownloadFromHref(objUrl, filename);
	URL.revokeObjectURL(objUrl);
}
async function copyToClipboard(content) {}
async function calcMD5(file) {
	const hasher = CryptoJS.algo.MD5.create();
	const sliceSize = 1048576;
	const count = Math.ceil(file.size / sliceSize);
	for (let i = 0; i < count; i++) {
		const ab = await file.slice(i * sliceSize, (i + 1) * sliceSize).arrayBuffer();
		hasher.update(CryptoJS.lib.WordArray.create(ab));
	}
	return hasher.finalize().toString(CryptoJS.enc.Base64);
}
/**
* 将毫秒数格式化为 HH:mm:ss
* @param {number} milliseconds
* @returns
*/
function formatTime(milliseconds) {
	const hours = Math.floor(milliseconds / 36e5);
	const minutes = Math.floor(milliseconds % 36e5 / 6e4);
	const seconds = Math.floor(milliseconds % 6e4 / 1e3);
	const formattedMinutes = minutes.toString().padStart(2, "0");
	const formattedSeconds = seconds.toString().padStart(2, "0");
	return hours === 0 ? `${formattedMinutes}:${formattedSeconds}` : `${hours}:${formattedMinutes}:${formattedSeconds}`;
}

//#region node_modules/@primevue/core/usestyle/index.mjs
function _typeof$2$1(o) {
	"@babel/helpers - typeof";
	return _typeof$2$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$2$1(o);
}
function ownKeys$2$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$2$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$2$1(Object(t), true).forEach(function(r) {
			_defineProperty$2$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$2$1(e, r, t) {
	return (r = _toPropertyKey$2$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$2$1(t) {
	var i = _toPrimitive$2$1(t, "string");
	return "symbol" == _typeof$2$1(i) ? i : i + "";
}
function _toPrimitive$2$1(t, r) {
	if ("object" != _typeof$2$1(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$2$1(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function tryOnMounted(fn) {
	var sync = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
	if (getCurrentInstance() && getCurrentInstance().components);
	else if (sync) fn();
	else nextTick(fn);
}
var _id = 0;
function useStyle(css) {
	var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
	var isLoaded = ref(false);
	var cssRef = ref(css);
	var styleRef = ref(null);
	var defaultDocument = void 0;
	var _options$document = options.document, document = _options$document === void 0 ? defaultDocument : _options$document, _options$immediate = options.immediate, immediate = _options$immediate === void 0 ? true : _options$immediate, _options$manual = options.manual, manual = _options$manual === void 0 ? false : _options$manual, _options$name = options.name, name = _options$name === void 0 ? "style_".concat(++_id) : _options$name, _options$id = options.id, id = _options$id === void 0 ? void 0 : _options$id, _options$media = options.media, media = _options$media === void 0 ? void 0 : _options$media, _options$nonce = options.nonce, nonce = _options$nonce === void 0 ? void 0 : _options$nonce, _options$first = options.first, first = _options$first === void 0 ? false : _options$first, _options$onMounted = options.onMounted, onStyleMounted = _options$onMounted === void 0 ? void 0 : _options$onMounted, _options$onUpdated = options.onUpdated, onStyleUpdated = _options$onUpdated === void 0 ? void 0 : _options$onUpdated, _options$onLoad = options.onLoad, onStyleLoaded = _options$onLoad === void 0 ? void 0 : _options$onLoad, _options$props = options.props, props = _options$props === void 0 ? {} : _options$props;
	var stop = function stop() {};
	var load = function load(_css) {
		var _props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (!document) return;
		var _styleProps = _objectSpread$2$1(_objectSpread$2$1({}, props), _props);
		var _name = _styleProps.name || name, _id = _styleProps.id || id, _nonce = _styleProps.nonce || nonce;
		styleRef.value = document.querySelector("style[data-primevue-style-id=\"".concat(_name, "\"]")) || document.getElementById(_id) || document.createElement("style");
		if (!styleRef.value.isConnected) {
			cssRef.value = _css || css;
			A(styleRef.value, {
				type: "text/css",
				id: _id,
				media,
				nonce: _nonce
			});
			first ? document.head.prepend(styleRef.value) : document.head.appendChild(styleRef.value);
			_t(styleRef.value, "data-primevue-style-id", _name);
			A(styleRef.value, _styleProps);
			styleRef.value.onload = function(event) {
				return onStyleLoaded === null || onStyleLoaded === void 0 ? void 0 : onStyleLoaded(event, { name: _name });
			};
			onStyleMounted === null || onStyleMounted === void 0 || onStyleMounted(_name);
		}
		if (isLoaded.value) return;
		stop = watch(cssRef, function(value) {
			styleRef.value.textContent = value;
			onStyleUpdated === null || onStyleUpdated === void 0 || onStyleUpdated(_name);
		}, { immediate: true });
		isLoaded.value = true;
	};
	var unload = function unload() {
		if (!document || !isLoaded.value) return;
		stop();
		T(styleRef.value) && document.head.removeChild(styleRef.value);
		isLoaded.value = false;
		styleRef.value = null;
	};
	if (immediate && !manual) tryOnMounted(load);
	return {
		id,
		name,
		el: styleRef,
		css: cssRef,
		unload,
		load,
		isLoaded: readonly(isLoaded)
	};
}
//#endregion
//#region node_modules/@primevue/core/base/style/index.mjs
function _typeof$1$3(o) {
	"@babel/helpers - typeof";
	return _typeof$1$3 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1$3(o);
}
var _templateObject;
var _templateObject2;
var _templateObject3;
var _templateObject4;
function _slicedToArray$1(r, e) {
	return _arrayWithHoles$1(r) || _iterableToArrayLimit$1(r, e) || _unsupportedIterableToArray$1$1(r, e) || _nonIterableRest$1();
}
function _nonIterableRest$1() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$1$1(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$1$1(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$1$1(r, a) : void 0;
	}
}
function _arrayLikeToArray$1$1(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit$1(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l);
			else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$1(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys$1$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1$1(Object(t), true).forEach(function(r) {
			_defineProperty$1$2(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1$2(e, r, t) {
	return (r = _toPropertyKey$1$3(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$1$3(t) {
	var i = _toPrimitive$1$3(t, "string");
	return "symbol" == _typeof$1$3(i) ? i : i + "";
}
function _toPrimitive$1$3(t, r) {
	if ("object" != _typeof$1$3(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$1$3(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _taggedTemplateLiteral(e, t) {
	return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var BaseStyle = {
	name: "base",
	css: function css(_ref) {
		var dt = _ref.dt;
		return "\n.p-hidden-accessible {\n    border: 0;\n    clip: rect(0 0 0 0);\n    height: 1px;\n    margin: -1px;\n    opacity: 0;\n    overflow: hidden;\n    padding: 0;\n    pointer-events: none;\n    position: absolute;\n    white-space: nowrap;\n    width: 1px;\n}\n\n.p-overflow-hidden {\n    overflow: hidden;\n    padding-right: ".concat(dt("scrollbar.width"), ";\n}\n");
	},
	style: style$c,
	classes: {},
	inlineStyles: {},
	load: function load(style) {
		var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var computedStyle = (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : function(cs) {
			return cs;
		})(css(_templateObject || (_templateObject = _taggedTemplateLiteral(["", ""])), style));
		return s$2(computedStyle) ? useStyle(Y(computedStyle), _objectSpread$1$1({ name: this.name }, options)) : {};
	},
	loadCSS: function loadCSS() {
		var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		return this.load(this.css, options);
	},
	loadStyle: function loadStyle() {
		var _this = this;
		var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var style = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
		return this.load(this.style, options, function() {
			var computedStyle = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			return Theme.transformCSS(options.name || _this.name, "".concat(computedStyle).concat(css(_templateObject2 || (_templateObject2 = _taggedTemplateLiteral(["", ""])), style)));
		});
	},
	getCommonTheme: function getCommonTheme(params) {
		return Theme.getCommon(this.name, params);
	},
	getComponentTheme: function getComponentTheme(params) {
		return Theme.getComponent(this.name, params);
	},
	getDirectiveTheme: function getDirectiveTheme(params) {
		return Theme.getDirective(this.name, params);
	},
	getPresetTheme: function getPresetTheme(preset, selector, params) {
		return Theme.getCustomPreset(this.name, preset, selector, params);
	},
	getLayerOrderThemeCSS: function getLayerOrderThemeCSS() {
		return Theme.getLayerOrderCSS(this.name);
	},
	getStyleSheet: function getStyleSheet() {
		var extendedCSS = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (this.css) {
			var _css = m(this.css, { dt }) || "";
			var _style = Y(css(_templateObject3 || (_templateObject3 = _taggedTemplateLiteral([
				"",
				"",
				""
			])), _css, extendedCSS));
			var _props = Object.entries(props).reduce(function(acc, _ref2) {
				var _ref3 = _slicedToArray$1(_ref2, 2), k = _ref3[0], v = _ref3[1];
				return acc.push("".concat(k, "=\"").concat(v, "\"")) && acc;
			}, []).join(" ");
			return s$2(_style) ? "<style type=\"text/css\" data-primevue-style-id=\"".concat(this.name, "\" ").concat(_props, ">").concat(_style, "</style>") : "";
		}
		return "";
	},
	getCommonThemeStyleSheet: function getCommonThemeStyleSheet(params) {
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		return Theme.getCommonStyleSheet(this.name, params, props);
	},
	getThemeStyleSheet: function getThemeStyleSheet(params) {
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var css$1 = [Theme.getStyleSheet(this.name, params, props)];
		if (this.style) {
			var name = this.name === "base" ? "global-style" : "".concat(this.name, "-style");
			var _css = css(_templateObject4 || (_templateObject4 = _taggedTemplateLiteral(["", ""])), m(this.style, { dt }));
			var _style = Y(Theme.transformCSS(name, _css));
			var _props = Object.entries(props).reduce(function(acc, _ref4) {
				var _ref5 = _slicedToArray$1(_ref4, 2), k = _ref5[0], v = _ref5[1];
				return acc.push("".concat(k, "=\"").concat(v, "\"")) && acc;
			}, []).join(" ");
			s$2(_style) && css$1.push("<style type=\"text/css\" data-primevue-style-id=\"".concat(name, "\" ").concat(_props, ">").concat(_style, "</style>"));
		}
		return css$1.join("");
	},
	extend: function extend(inStyle) {
		return _objectSpread$1$1(_objectSpread$1$1({}, this), {}, {
			css: void 0,
			style: void 0
		}, inStyle);
	}
};
//#endregion
//#region node_modules/@primevue/core/base/index.mjs
var Base = {
	_loadedStyleNames: /* @__PURE__ */ new Set(),
	getLoadedStyleNames: function getLoadedStyleNames() {
		return this._loadedStyleNames;
	},
	isStyleNameLoaded: function isStyleNameLoaded(name) {
		return this._loadedStyleNames.has(name);
	},
	setLoadedStyleName: function setLoadedStyleName(name) {
		this._loadedStyleNames.add(name);
	},
	deleteLoadedStyleName: function deleteLoadedStyleName(name) {
		this._loadedStyleNames["delete"](name);
	},
	clearLoadedStyleNames: function clearLoadedStyleNames() {
		this._loadedStyleNames.clear();
	}
};
//#endregion
//#region node_modules/@primevue/core/useattrselector/index.mjs
function useAttrSelector() {
	var prefix = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "pc";
	var idx = useId();
	return "".concat(prefix).concat(idx.replace("v-", "").replaceAll("-", "_"));
}
//#endregion
//#region node_modules/@primevue/core/basecomponent/index.mjs
var BaseComponentStyle = BaseStyle.extend({ name: "common" });
function _typeof$h(o) {
	"@babel/helpers - typeof";
	return _typeof$h = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$h(o);
}
function _toArray(r) {
	return _arrayWithHoles$2(r) || _iterableToArray$c(r) || _unsupportedIterableToArray$e(r) || _nonIterableRest$2();
}
function _iterableToArray$c(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _slicedToArray$2(r, e) {
	return _arrayWithHoles$2(r) || _iterableToArrayLimit$2(r, e) || _unsupportedIterableToArray$e(r, e) || _nonIterableRest$2();
}
function _nonIterableRest$2() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$e(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$e(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$e(r, a) : void 0;
	}
}
function _arrayLikeToArray$e(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit$2(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$2(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys$7(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$7(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$7(Object(t), true).forEach(function(r) {
			_defineProperty$h(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$7(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$h(e, r, t) {
	return (r = _toPropertyKey$h(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$h(t) {
	var i = _toPrimitive$h(t, "string");
	return "symbol" == _typeof$h(i) ? i : i + "";
}
function _toPrimitive$h(t, r) {
	if ("object" != _typeof$h(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$h(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$j = {
	name: "BaseComponent",
	props: {
		pt: {
			type: Object,
			"default": void 0
		},
		ptOptions: {
			type: Object,
			"default": void 0
		},
		unstyled: {
			type: Boolean,
			"default": void 0
		},
		dt: {
			type: Object,
			"default": void 0
		}
	},
	inject: { $parentInstance: { "default": void 0 } },
	watch: {
		isUnstyled: {
			immediate: true,
			handler: function handler(newValue) {
				ThemeService.off("theme:change", this._loadCoreStyles);
				if (!newValue) {
					this._loadCoreStyles();
					this._themeChangeListener(this._loadCoreStyles);
				}
			}
		},
		dt: {
			immediate: true,
			handler: function handler(newValue, oldValue) {
				var _this = this;
				ThemeService.off("theme:change", this._themeScopedListener);
				if (newValue) {
					this._loadScopedThemeStyles(newValue);
					this._themeScopedListener = function() {
						return _this._loadScopedThemeStyles(newValue);
					};
					this._themeChangeListener(this._themeScopedListener);
				} else this._unloadScopedThemeStyles();
			}
		}
	},
	scopedStyleEl: void 0,
	rootEl: void 0,
	uid: void 0,
	$attrSelector: void 0,
	beforeCreate: function beforeCreate() {
		var _this$pt, _this$pt2, _this$pt3, _ref, _ref$onBeforeCreate, _this$$primevueConfig, _this$$primevue, _this$$primevue2, _this$$primevue3, _ref2, _ref2$onBeforeCreate;
		var _usept = (_this$pt = this.pt) === null || _this$pt === void 0 ? void 0 : _this$pt["_usept"];
		var originalValue = _usept ? (_this$pt2 = this.pt) === null || _this$pt2 === void 0 || (_this$pt2 = _this$pt2.originalValue) === null || _this$pt2 === void 0 ? void 0 : _this$pt2[this.$.type.name] : void 0;
		(_ref = (_usept ? (_this$pt3 = this.pt) === null || _this$pt3 === void 0 || (_this$pt3 = _this$pt3.value) === null || _this$pt3 === void 0 ? void 0 : _this$pt3[this.$.type.name] : this.pt) || originalValue) === null || _ref === void 0 || (_ref = _ref.hooks) === null || _ref === void 0 || (_ref$onBeforeCreate = _ref["onBeforeCreate"]) === null || _ref$onBeforeCreate === void 0 || _ref$onBeforeCreate.call(_ref);
		var _useptInConfig = (_this$$primevueConfig = this.$primevueConfig) === null || _this$$primevueConfig === void 0 || (_this$$primevueConfig = _this$$primevueConfig.pt) === null || _this$$primevueConfig === void 0 ? void 0 : _this$$primevueConfig["_usept"];
		var originalValueInConfig = _useptInConfig ? (_this$$primevue = this.$primevue) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.config) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.pt) === null || _this$$primevue === void 0 ? void 0 : _this$$primevue.originalValue : void 0;
		(_ref2 = (_useptInConfig ? (_this$$primevue2 = this.$primevue) === null || _this$$primevue2 === void 0 || (_this$$primevue2 = _this$$primevue2.config) === null || _this$$primevue2 === void 0 || (_this$$primevue2 = _this$$primevue2.pt) === null || _this$$primevue2 === void 0 ? void 0 : _this$$primevue2.value : (_this$$primevue3 = this.$primevue) === null || _this$$primevue3 === void 0 || (_this$$primevue3 = _this$$primevue3.config) === null || _this$$primevue3 === void 0 ? void 0 : _this$$primevue3.pt) || originalValueInConfig) === null || _ref2 === void 0 || (_ref2 = _ref2[this.$.type.name]) === null || _ref2 === void 0 || (_ref2 = _ref2.hooks) === null || _ref2 === void 0 || (_ref2$onBeforeCreate = _ref2["onBeforeCreate"]) === null || _ref2$onBeforeCreate === void 0 || _ref2$onBeforeCreate.call(_ref2);
		this.$attrSelector = useAttrSelector();
		this.uid = this.$attrs.id || this.$attrSelector.replace("pc", "pv_id_");
	},
	created: function created() {
		this._hook("onCreated");
	},
	beforeMount: function beforeMount() {
		var _this$$el;
		this.rootEl = z(c$1(this.$el) ? this.$el : (_this$$el = this.$el) === null || _this$$el === void 0 ? void 0 : _this$$el.parentElement, "[".concat(this.$attrSelector, "]"));
		if (this.rootEl) this.rootEl.$pc = _objectSpread$7({
			name: this.$.type.name,
			attrSelector: this.$attrSelector
		}, this.$params);
		this._loadStyles();
		this._hook("onBeforeMount");
	},
	mounted: function mounted() {
		this._hook("onMounted");
	},
	beforeUpdate: function beforeUpdate() {
		this._hook("onBeforeUpdate");
	},
	updated: function updated() {
		this._hook("onUpdated");
	},
	beforeUnmount: function beforeUnmount() {
		this._hook("onBeforeUnmount");
	},
	unmounted: function unmounted() {
		this._removeThemeListeners();
		this._unloadScopedThemeStyles();
		this._hook("onUnmounted");
	},
	methods: {
		_hook: function _hook(hookName) {
			if (!this.$options.hostName) {
				var selfHook = this._usePT(this._getPT(this.pt, this.$.type.name), this._getOptionValue, "hooks.".concat(hookName));
				var defaultHook = this._useDefaultPT(this._getOptionValue, "hooks.".concat(hookName));
				selfHook === null || selfHook === void 0 || selfHook();
				defaultHook === null || defaultHook === void 0 || defaultHook();
			}
		},
		_mergeProps: function _mergeProps(fn) {
			for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key2 = 1; _key2 < _len; _key2++) args[_key2 - 1] = arguments[_key2];
			return c(fn) ? fn.apply(void 0, args) : mergeProps.apply(void 0, args);
		},
		_load: function _load() {
			if (!Base.isStyleNameLoaded("base")) {
				BaseStyle.loadCSS(this.$styleOptions);
				this._loadGlobalStyles();
				Base.setLoadedStyleName("base");
			}
			this._loadThemeStyles();
		},
		_loadStyles: function _loadStyles() {
			this._load();
			this._themeChangeListener(this._load);
		},
		_loadCoreStyles: function _loadCoreStyles() {
			var _this$$style, _this$$style2;
			if (!Base.isStyleNameLoaded((_this$$style = this.$style) === null || _this$$style === void 0 ? void 0 : _this$$style.name) && (_this$$style2 = this.$style) !== null && _this$$style2 !== void 0 && _this$$style2.name) {
				BaseComponentStyle.loadCSS(this.$styleOptions);
				this.$options.style && this.$style.loadCSS(this.$styleOptions);
				Base.setLoadedStyleName(this.$style.name);
			}
		},
		_loadGlobalStyles: function _loadGlobalStyles() {
			var globalCSS = this._useGlobalPT(this._getOptionValue, "global.css", this.$params);
			s$2(globalCSS) && BaseStyle.load(globalCSS, _objectSpread$7({ name: "global" }, this.$styleOptions));
		},
		_loadThemeStyles: function _loadThemeStyles() {
			var _this$$style4, _this$$style5;
			if (this.isUnstyled || this.$theme === "none") return;
			if (!Theme.isStyleNameLoaded("common")) {
				var _this$$style3, _this$$style3$getComm;
				var _ref3 = ((_this$$style3 = this.$style) === null || _this$$style3 === void 0 || (_this$$style3$getComm = _this$$style3.getCommonTheme) === null || _this$$style3$getComm === void 0 ? void 0 : _this$$style3$getComm.call(_this$$style3)) || {}, primitive = _ref3.primitive, semantic = _ref3.semantic, global = _ref3.global, style = _ref3.style;
				BaseStyle.load(primitive === null || primitive === void 0 ? void 0 : primitive.css, _objectSpread$7({ name: "primitive-variables" }, this.$styleOptions));
				BaseStyle.load(semantic === null || semantic === void 0 ? void 0 : semantic.css, _objectSpread$7({ name: "semantic-variables" }, this.$styleOptions));
				BaseStyle.load(global === null || global === void 0 ? void 0 : global.css, _objectSpread$7({ name: "global-variables" }, this.$styleOptions));
				BaseStyle.loadStyle(_objectSpread$7({ name: "global-style" }, this.$styleOptions), style);
				Theme.setLoadedStyleName("common");
			}
			if (!Theme.isStyleNameLoaded((_this$$style4 = this.$style) === null || _this$$style4 === void 0 ? void 0 : _this$$style4.name) && (_this$$style5 = this.$style) !== null && _this$$style5 !== void 0 && _this$$style5.name) {
				var _this$$style6, _this$$style6$getComp, _this$$style7, _this$$style8;
				var _ref4 = ((_this$$style6 = this.$style) === null || _this$$style6 === void 0 || (_this$$style6$getComp = _this$$style6.getComponentTheme) === null || _this$$style6$getComp === void 0 ? void 0 : _this$$style6$getComp.call(_this$$style6)) || {}, css = _ref4.css, _style = _ref4.style;
				(_this$$style7 = this.$style) === null || _this$$style7 === void 0 || _this$$style7.load(css, _objectSpread$7({ name: "".concat(this.$style.name, "-variables") }, this.$styleOptions));
				(_this$$style8 = this.$style) === null || _this$$style8 === void 0 || _this$$style8.loadStyle(_objectSpread$7({ name: "".concat(this.$style.name, "-style") }, this.$styleOptions), _style);
				Theme.setLoadedStyleName(this.$style.name);
			}
			if (!Theme.isStyleNameLoaded("layer-order")) {
				var _this$$style9, _this$$style9$getLaye;
				var layerOrder = (_this$$style9 = this.$style) === null || _this$$style9 === void 0 || (_this$$style9$getLaye = _this$$style9.getLayerOrderThemeCSS) === null || _this$$style9$getLaye === void 0 ? void 0 : _this$$style9$getLaye.call(_this$$style9);
				BaseStyle.load(layerOrder, _objectSpread$7({
					name: "layer-order",
					first: true
				}, this.$styleOptions));
				Theme.setLoadedStyleName("layer-order");
			}
		},
		_loadScopedThemeStyles: function _loadScopedThemeStyles(preset) {
			var _this$$style0, _this$$style0$getPres, _this$$style1;
			var css = (((_this$$style0 = this.$style) === null || _this$$style0 === void 0 || (_this$$style0$getPres = _this$$style0.getPresetTheme) === null || _this$$style0$getPres === void 0 ? void 0 : _this$$style0$getPres.call(_this$$style0, preset, "[".concat(this.$attrSelector, "]"))) || {}).css;
			var scopedStyle = (_this$$style1 = this.$style) === null || _this$$style1 === void 0 ? void 0 : _this$$style1.load(css, _objectSpread$7({ name: "".concat(this.$attrSelector, "-").concat(this.$style.name) }, this.$styleOptions));
			this.scopedStyleEl = scopedStyle.el;
		},
		_unloadScopedThemeStyles: function _unloadScopedThemeStyles() {
			var _this$scopedStyleEl;
			(_this$scopedStyleEl = this.scopedStyleEl) === null || _this$scopedStyleEl === void 0 || (_this$scopedStyleEl = _this$scopedStyleEl.value) === null || _this$scopedStyleEl === void 0 || _this$scopedStyleEl.remove();
		},
		_themeChangeListener: function _themeChangeListener() {
			var callback = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {};
			Base.clearLoadedStyleNames();
			ThemeService.on("theme:change", callback);
		},
		_removeThemeListeners: function _removeThemeListeners() {
			ThemeService.off("theme:change", this._loadCoreStyles);
			ThemeService.off("theme:change", this._load);
			ThemeService.off("theme:change", this._themeScopedListener);
		},
		_getHostInstance: function _getHostInstance(instance) {
			return instance ? this.$options.hostName ? instance.$.type.name === this.$options.hostName ? instance : this._getHostInstance(instance.$parentInstance) : instance.$parentInstance : void 0;
		},
		_getPropValue: function _getPropValue(name) {
			var _this$_getHostInstanc;
			return this[name] || ((_this$_getHostInstanc = this._getHostInstance(this)) === null || _this$_getHostInstanc === void 0 ? void 0 : _this$_getHostInstanc[name]);
		},
		_getOptionValue: function _getOptionValue(options) {
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return F(options, key, params);
		},
		_getPTValue: function _getPTValue() {
			var _this$$primevueConfig2;
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			var searchInDefaultPT = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : true;
			var searchOut = /./g.test(key) && !!params[key.split(".")[0]];
			var _ref6 = this._getPropValue("ptOptions") || ((_this$$primevueConfig2 = this.$primevueConfig) === null || _this$$primevueConfig2 === void 0 ? void 0 : _this$$primevueConfig2.ptOptions) || {}, _ref6$mergeSections = _ref6.mergeSections, mergeSections = _ref6$mergeSections === void 0 ? true : _ref6$mergeSections, _ref6$mergeProps = _ref6.mergeProps, useMergeProps = _ref6$mergeProps === void 0 ? false : _ref6$mergeProps;
			var global = searchInDefaultPT ? searchOut ? this._useGlobalPT(this._getPTClassValue, key, params) : this._useDefaultPT(this._getPTClassValue, key, params) : void 0;
			var self = searchOut ? void 0 : this._getPTSelf(obj, this._getPTClassValue, key, _objectSpread$7(_objectSpread$7({}, params), {}, { global: global || {} }));
			var datasets = this._getPTDatasets(key);
			return mergeSections || !mergeSections && self ? useMergeProps ? this._mergeProps(useMergeProps, global, self, datasets) : _objectSpread$7(_objectSpread$7(_objectSpread$7({}, global), self), datasets) : _objectSpread$7(_objectSpread$7({}, self), datasets);
		},
		_getPTSelf: function _getPTSelf() {
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key3 = 1; _key3 < _len2; _key3++) args[_key3 - 1] = arguments[_key3];
			return mergeProps(this._usePT.apply(this, [this._getPT(obj, this.$name)].concat(args)), this._usePT.apply(this, [this.$_attrsPT].concat(args)));
		},
		_getPTDatasets: function _getPTDatasets() {
			var _this$pt4, _this$pt5;
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var datasetPrefix = "data-pc-";
			var isExtended = key === "root" && s$2((_this$pt4 = this.pt) === null || _this$pt4 === void 0 ? void 0 : _this$pt4["data-pc-section"]);
			return key !== "transition" && _objectSpread$7(_objectSpread$7({}, key === "root" && _objectSpread$7(_objectSpread$7(_defineProperty$h({}, "".concat(datasetPrefix, "name"), g$1(isExtended ? (_this$pt5 = this.pt) === null || _this$pt5 === void 0 ? void 0 : _this$pt5["data-pc-section"] : this.$.type.name)), isExtended && _defineProperty$h({}, "".concat(datasetPrefix, "extend"), g$1(this.$.type.name))), {}, _defineProperty$h({}, "".concat(this.$attrSelector), ""))), {}, _defineProperty$h({}, "".concat(datasetPrefix, "section"), g$1(key)));
		},
		_getPTClassValue: function _getPTClassValue() {
			var value = this._getOptionValue.apply(this, arguments);
			return a(value) || C(value) ? { "class": value } : value;
		},
		_getPT: function _getPT(pt) {
			var _this2 = this;
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var callback = arguments.length > 2 ? arguments[2] : void 0;
			var getValue = function getValue(value) {
				var _ref8;
				var checkSameKey = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
				var computedValue = callback ? callback(value) : value;
				var _key = g$1(key);
				var _cKey = g$1(_this2.$name);
				return (_ref8 = checkSameKey ? _key !== _cKey ? computedValue === null || computedValue === void 0 ? void 0 : computedValue[_key] : void 0 : computedValue === null || computedValue === void 0 ? void 0 : computedValue[_key]) !== null && _ref8 !== void 0 ? _ref8 : computedValue;
			};
			return pt !== null && pt !== void 0 && pt.hasOwnProperty("_usept") ? {
				_usept: pt["_usept"],
				originalValue: getValue(pt.originalValue),
				value: getValue(pt.value)
			} : getValue(pt, true);
		},
		_usePT: function _usePT(pt, callback, key, params) {
			var fn = function fn(value) {
				return callback(value, key, params);
			};
			if (pt !== null && pt !== void 0 && pt.hasOwnProperty("_usept")) {
				var _this$$primevueConfig3;
				var _ref9 = pt["_usept"] || ((_this$$primevueConfig3 = this.$primevueConfig) === null || _this$$primevueConfig3 === void 0 ? void 0 : _this$$primevueConfig3.ptOptions) || {}, _ref9$mergeSections = _ref9.mergeSections, mergeSections = _ref9$mergeSections === void 0 ? true : _ref9$mergeSections, _ref9$mergeProps = _ref9.mergeProps, useMergeProps = _ref9$mergeProps === void 0 ? false : _ref9$mergeProps;
				var originalValue = fn(pt.originalValue);
				var value = fn(pt.value);
				if (originalValue === void 0 && value === void 0) return void 0;
				else if (a(value)) return value;
				else if (a(originalValue)) return originalValue;
				return mergeSections || !mergeSections && value ? useMergeProps ? this._mergeProps(useMergeProps, originalValue, value) : _objectSpread$7(_objectSpread$7({}, originalValue), value) : value;
			}
			return fn(pt);
		},
		_useGlobalPT: function _useGlobalPT(callback, key, params) {
			return this._usePT(this.globalPT, callback, key, params);
		},
		_useDefaultPT: function _useDefaultPT(callback, key, params) {
			return this._usePT(this.defaultPT, callback, key, params);
		},
		ptm: function ptm() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return this._getPTValue(this.pt, key, _objectSpread$7(_objectSpread$7({}, this.$params), params));
		},
		ptmi: function ptmi() {
			var _attrs$id;
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			var attrs = mergeProps(this.$_attrsWithoutPT, this.ptm(key, params));
			attrs !== null && attrs !== void 0 && attrs.hasOwnProperty("id") && ((_attrs$id = attrs.id) !== null && _attrs$id !== void 0 || (attrs.id = this.$id));
			return attrs;
		},
		ptmo: function ptmo() {
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return this._getPTValue(obj, key, _objectSpread$7({ instance: this }, params), false);
		},
		cx: function cx() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return !this.isUnstyled ? this._getOptionValue(this.$style.classes, key, _objectSpread$7(_objectSpread$7({}, this.$params), params)) : void 0;
		},
		sx: function sx() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var when = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			if (when) {
				var self = this._getOptionValue(this.$style.inlineStyles, key, _objectSpread$7(_objectSpread$7({}, this.$params), params));
				return [this._getOptionValue(BaseComponentStyle.inlineStyles, key, _objectSpread$7(_objectSpread$7({}, this.$params), params)), self];
			}
		}
	},
	computed: {
		globalPT: function globalPT() {
			var _this$$primevueConfig4, _this3 = this;
			return this._getPT((_this$$primevueConfig4 = this.$primevueConfig) === null || _this$$primevueConfig4 === void 0 ? void 0 : _this$$primevueConfig4.pt, void 0, function(value) {
				return m(value, { instance: _this3 });
			});
		},
		defaultPT: function defaultPT() {
			var _this$$primevueConfig5, _this4 = this;
			return this._getPT((_this$$primevueConfig5 = this.$primevueConfig) === null || _this$$primevueConfig5 === void 0 ? void 0 : _this$$primevueConfig5.pt, void 0, function(value) {
				return _this4._getOptionValue(value, _this4.$name, _objectSpread$7({}, _this4.$params)) || m(value, _objectSpread$7({}, _this4.$params));
			});
		},
		isUnstyled: function isUnstyled() {
			var _this$$primevueConfig6;
			return this.unstyled !== void 0 ? this.unstyled : (_this$$primevueConfig6 = this.$primevueConfig) === null || _this$$primevueConfig6 === void 0 ? void 0 : _this$$primevueConfig6.unstyled;
		},
		$id: function $id() {
			return this.$attrs.id || this.uid;
		},
		$inProps: function $inProps() {
			var _this$$$vnode;
			var nodePropKeys = Object.keys(((_this$$$vnode = this.$.vnode) === null || _this$$$vnode === void 0 ? void 0 : _this$$$vnode.props) || {});
			return Object.fromEntries(Object.entries(this.$props).filter(function(_ref0) {
				var k = _slicedToArray$2(_ref0, 1)[0];
				return nodePropKeys === null || nodePropKeys === void 0 ? void 0 : nodePropKeys.includes(k);
			}));
		},
		$theme: function $theme() {
			var _this$$primevueConfig7;
			return (_this$$primevueConfig7 = this.$primevueConfig) === null || _this$$primevueConfig7 === void 0 ? void 0 : _this$$primevueConfig7.theme;
		},
		$style: function $style() {
			return _objectSpread$7(_objectSpread$7({
				classes: void 0,
				inlineStyles: void 0,
				load: function load() {},
				loadCSS: function loadCSS() {},
				loadStyle: function loadStyle() {}
			}, (this._getHostInstance(this) || {}).$style), this.$options.style);
		},
		$styleOptions: function $styleOptions() {
			var _this$$primevueConfig8;
			return { nonce: (_this$$primevueConfig8 = this.$primevueConfig) === null || _this$$primevueConfig8 === void 0 || (_this$$primevueConfig8 = _this$$primevueConfig8.csp) === null || _this$$primevueConfig8 === void 0 ? void 0 : _this$$primevueConfig8.nonce };
		},
		$primevueConfig: function $primevueConfig() {
			var _this$$primevue4;
			return (_this$$primevue4 = this.$primevue) === null || _this$$primevue4 === void 0 ? void 0 : _this$$primevue4.config;
		},
		$name: function $name() {
			return this.$options.hostName || this.$.type.name;
		},
		$params: function $params() {
			var parentInstance = this._getHostInstance(this) || this.$parent;
			return {
				instance: this,
				props: this.$props,
				state: this.$data,
				attrs: this.$attrs,
				parent: {
					instance: parentInstance,
					props: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$props,
					state: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$data,
					attrs: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$attrs
				}
			};
		},
		$_attrsPT: function $_attrsPT() {
			return Object.entries(this.$attrs || {}).filter(function(_ref10) {
				var key = _slicedToArray$2(_ref10, 1)[0];
				return key === null || key === void 0 ? void 0 : key.startsWith("pt:");
			}).reduce(function(result, _ref12) {
				var _ref13 = _slicedToArray$2(_ref12, 2), key = _ref13[0], value = _ref13[1];
				var rest = _arrayLikeToArray$e(_toArray(key.split(":"))).slice(1);
				rest === null || rest === void 0 || rest.reduce(function(currentObj, nestedKey, index, array) {
					!currentObj[nestedKey] && (currentObj[nestedKey] = index === array.length - 1 ? value : {});
					return currentObj[nestedKey];
				}, result);
				return result;
			}, {});
		},
		$_attrsWithoutPT: function $_attrsWithoutPT() {
			return Object.entries(this.$attrs || {}).filter(function(_ref14) {
				var key = _slicedToArray$2(_ref14, 1)[0];
				return !(key !== null && key !== void 0 && key.startsWith("pt:"));
			}).reduce(function(acc, _ref16) {
				var _ref17 = _slicedToArray$2(_ref16, 2), key = _ref17[0];
				acc[key] = _ref17[1];
				return acc;
			}, {});
		}
	}
};

function s$1(){let r=new Map;return {on(e,t){let n=r.get(e);return n?n.push(t):n=[t],r.set(e,n),this},off(e,t){let n=r.get(e);return n&&n.splice(n.indexOf(t)>>>0,1),this},emit(e,t){let n=r.get(e);n&&n.forEach(i=>{i(t);});},clear(){r.clear();}}}

var t={};function s(n="pui_id_"){return Object.hasOwn(t,n)||(t[n]=0),t[n]++,`${n}${t[n]}`}

//#region node_modules/@primevue/core/service/index.mjs
var PrimeVueService = s$1();
//#endregion
//#region node_modules/@primevue/core/basedirective/index.mjs
function _typeof$g(o) {
	"@babel/helpers - typeof";
	return _typeof$g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$g(o);
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray$d(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$d(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$d(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$d(r, a) : void 0;
	}
}
function _arrayLikeToArray$d(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l);
			else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys$6(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$6(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$6(Object(t), true).forEach(function(r) {
			_defineProperty$g(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$6(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$g(e, r, t) {
	return (r = _toPropertyKey$g(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$g(t) {
	var i = _toPrimitive$g(t, "string");
	return "symbol" == _typeof$g(i) ? i : i + "";
}
function _toPrimitive$g(t, r) {
	if ("object" != _typeof$g(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$g(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var BaseDirective = {
	_getMeta: function _getMeta() {
		return [i(arguments.length <= 0 ? void 0 : arguments[0]) ? void 0 : arguments.length <= 0 ? void 0 : arguments[0], m(i(arguments.length <= 0 ? void 0 : arguments[0]) ? arguments.length <= 0 ? void 0 : arguments[0] : arguments.length <= 1 ? void 0 : arguments[1])];
	},
	_getConfig: function _getConfig(binding, vnode) {
		var _ref, _binding$instance, _vnode$ctx;
		return (_ref = (binding === null || binding === void 0 || (_binding$instance = binding.instance) === null || _binding$instance === void 0 ? void 0 : _binding$instance.$primevue) || (vnode === null || vnode === void 0 || (_vnode$ctx = vnode.ctx) === null || _vnode$ctx === void 0 || (_vnode$ctx = _vnode$ctx.appContext) === null || _vnode$ctx === void 0 || (_vnode$ctx = _vnode$ctx.config) === null || _vnode$ctx === void 0 || (_vnode$ctx = _vnode$ctx.globalProperties) === null || _vnode$ctx === void 0 ? void 0 : _vnode$ctx.$primevue)) === null || _ref === void 0 ? void 0 : _ref.config;
	},
	_getOptionValue: F,
	_getPTValue: function _getPTValue() {
		var _instance$binding, _instance$$primevueCo;
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var obj = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var key = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "";
		var params = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
		var searchInDefaultPT = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : true;
		var getValue = function getValue() {
			var value = BaseDirective._getOptionValue.apply(BaseDirective, arguments);
			return a(value) || C(value) ? { "class": value } : value;
		};
		var _ref2 = ((_instance$binding = instance.binding) === null || _instance$binding === void 0 || (_instance$binding = _instance$binding.value) === null || _instance$binding === void 0 ? void 0 : _instance$binding.ptOptions) || ((_instance$$primevueCo = instance.$primevueConfig) === null || _instance$$primevueCo === void 0 ? void 0 : _instance$$primevueCo.ptOptions) || {}, _ref2$mergeSections = _ref2.mergeSections, mergeSections = _ref2$mergeSections === void 0 ? true : _ref2$mergeSections, _ref2$mergeProps = _ref2.mergeProps, useMergeProps = _ref2$mergeProps === void 0 ? false : _ref2$mergeProps;
		var global = searchInDefaultPT ? BaseDirective._useDefaultPT(instance, instance.defaultPT(), getValue, key, params) : void 0;
		var self = BaseDirective._usePT(instance, BaseDirective._getPT(obj, instance.$name), getValue, key, _objectSpread$6(_objectSpread$6({}, params), {}, { global: global || {} }));
		var datasets = BaseDirective._getPTDatasets(instance, key);
		return mergeSections || !mergeSections && self ? useMergeProps ? BaseDirective._mergeProps(instance, useMergeProps, global, self, datasets) : _objectSpread$6(_objectSpread$6(_objectSpread$6({}, global), self), datasets) : _objectSpread$6(_objectSpread$6({}, self), datasets);
	},
	_getPTDatasets: function _getPTDatasets() {
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
		var datasetPrefix = "data-pc-";
		return _objectSpread$6(_objectSpread$6({}, key === "root" && _defineProperty$g({}, "".concat(datasetPrefix, "name"), g$1(instance.$name))), {}, _defineProperty$g({}, "".concat(datasetPrefix, "section"), g$1(key)));
	},
	_getPT: function _getPT(pt) {
		var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
		var callback = arguments.length > 2 ? arguments[2] : void 0;
		var getValue = function getValue(value) {
			var _computedValue$_key;
			var computedValue = callback ? callback(value) : value;
			var _key = g$1(key);
			return (_computedValue$_key = computedValue === null || computedValue === void 0 ? void 0 : computedValue[_key]) !== null && _computedValue$_key !== void 0 ? _computedValue$_key : computedValue;
		};
		return pt && Object.hasOwn(pt, "_usept") ? {
			_usept: pt["_usept"],
			originalValue: getValue(pt.originalValue),
			value: getValue(pt.value)
		} : getValue(pt);
	},
	_usePT: function _usePT() {
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var pt = arguments.length > 1 ? arguments[1] : void 0;
		var callback = arguments.length > 2 ? arguments[2] : void 0;
		var key = arguments.length > 3 ? arguments[3] : void 0;
		var params = arguments.length > 4 ? arguments[4] : void 0;
		var fn = function fn(value) {
			return callback(value, key, params);
		};
		if (pt && Object.hasOwn(pt, "_usept")) {
			var _instance$$primevueCo2;
			var _ref4 = pt["_usept"] || ((_instance$$primevueCo2 = instance.$primevueConfig) === null || _instance$$primevueCo2 === void 0 ? void 0 : _instance$$primevueCo2.ptOptions) || {}, _ref4$mergeSections = _ref4.mergeSections, mergeSections = _ref4$mergeSections === void 0 ? true : _ref4$mergeSections, _ref4$mergeProps = _ref4.mergeProps, useMergeProps = _ref4$mergeProps === void 0 ? false : _ref4$mergeProps;
			var originalValue = fn(pt.originalValue);
			var value = fn(pt.value);
			if (originalValue === void 0 && value === void 0) return void 0;
			else if (a(value)) return value;
			else if (a(originalValue)) return originalValue;
			return mergeSections || !mergeSections && value ? useMergeProps ? BaseDirective._mergeProps(instance, useMergeProps, originalValue, value) : _objectSpread$6(_objectSpread$6({}, originalValue), value) : value;
		}
		return fn(pt);
	},
	_useDefaultPT: function _useDefaultPT() {
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var defaultPT = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var callback = arguments.length > 2 ? arguments[2] : void 0;
		var key = arguments.length > 3 ? arguments[3] : void 0;
		var params = arguments.length > 4 ? arguments[4] : void 0;
		return BaseDirective._usePT(instance, defaultPT, callback, key, params);
	},
	_loadStyles: function _loadStyles() {
		var _config$csp;
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var binding = arguments.length > 1 ? arguments[1] : void 0;
		var vnode = arguments.length > 2 ? arguments[2] : void 0;
		var config = BaseDirective._getConfig(binding, vnode);
		var useStyleOptions = { nonce: config === null || config === void 0 || (_config$csp = config.csp) === null || _config$csp === void 0 ? void 0 : _config$csp.nonce };
		BaseDirective._loadCoreStyles(instance, useStyleOptions);
		BaseDirective._loadThemeStyles(instance, useStyleOptions);
		BaseDirective._loadScopedThemeStyles(instance, useStyleOptions);
		BaseDirective._removeThemeListeners(instance);
		instance.$loadStyles = function() {
			return BaseDirective._loadThemeStyles(instance, useStyleOptions);
		};
		BaseDirective._themeChangeListener(instance.$loadStyles);
	},
	_loadCoreStyles: function _loadCoreStyles() {
		var _instance$$style, _instance$$style2;
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var useStyleOptions = arguments.length > 1 ? arguments[1] : void 0;
		if (!Base.isStyleNameLoaded((_instance$$style = instance.$style) === null || _instance$$style === void 0 ? void 0 : _instance$$style.name) && (_instance$$style2 = instance.$style) !== null && _instance$$style2 !== void 0 && _instance$$style2.name) {
			var _instance$$style3;
			BaseStyle.loadCSS(useStyleOptions);
			(_instance$$style3 = instance.$style) === null || _instance$$style3 === void 0 || _instance$$style3.loadCSS(useStyleOptions);
			Base.setLoadedStyleName(instance.$style.name);
		}
	},
	_loadThemeStyles: function _loadThemeStyles() {
		var _instance$theme, _instance$$style5, _instance$$style6;
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var useStyleOptions = arguments.length > 1 ? arguments[1] : void 0;
		if (instance !== null && instance !== void 0 && instance.isUnstyled() || (instance === null || instance === void 0 || (_instance$theme = instance.theme) === null || _instance$theme === void 0 ? void 0 : _instance$theme.call(instance)) === "none") return;
		if (!Theme.isStyleNameLoaded("common")) {
			var _instance$$style4, _instance$$style4$get;
			var _ref5 = ((_instance$$style4 = instance.$style) === null || _instance$$style4 === void 0 || (_instance$$style4$get = _instance$$style4.getCommonTheme) === null || _instance$$style4$get === void 0 ? void 0 : _instance$$style4$get.call(_instance$$style4)) || {}, primitive = _ref5.primitive, semantic = _ref5.semantic, global = _ref5.global, style = _ref5.style;
			BaseStyle.load(primitive === null || primitive === void 0 ? void 0 : primitive.css, _objectSpread$6({ name: "primitive-variables" }, useStyleOptions));
			BaseStyle.load(semantic === null || semantic === void 0 ? void 0 : semantic.css, _objectSpread$6({ name: "semantic-variables" }, useStyleOptions));
			BaseStyle.load(global === null || global === void 0 ? void 0 : global.css, _objectSpread$6({ name: "global-variables" }, useStyleOptions));
			BaseStyle.loadStyle(_objectSpread$6({ name: "global-style" }, useStyleOptions), style);
			Theme.setLoadedStyleName("common");
		}
		if (!Theme.isStyleNameLoaded((_instance$$style5 = instance.$style) === null || _instance$$style5 === void 0 ? void 0 : _instance$$style5.name) && (_instance$$style6 = instance.$style) !== null && _instance$$style6 !== void 0 && _instance$$style6.name) {
			var _instance$$style7, _instance$$style7$get, _instance$$style8, _instance$$style9;
			var _ref6 = ((_instance$$style7 = instance.$style) === null || _instance$$style7 === void 0 || (_instance$$style7$get = _instance$$style7.getDirectiveTheme) === null || _instance$$style7$get === void 0 ? void 0 : _instance$$style7$get.call(_instance$$style7)) || {}, css = _ref6.css, _style = _ref6.style;
			(_instance$$style8 = instance.$style) === null || _instance$$style8 === void 0 || _instance$$style8.load(css, _objectSpread$6({ name: "".concat(instance.$style.name, "-variables") }, useStyleOptions));
			(_instance$$style9 = instance.$style) === null || _instance$$style9 === void 0 || _instance$$style9.loadStyle(_objectSpread$6({ name: "".concat(instance.$style.name, "-style") }, useStyleOptions), _style);
			Theme.setLoadedStyleName(instance.$style.name);
		}
		if (!Theme.isStyleNameLoaded("layer-order")) {
			var _instance$$style0, _instance$$style0$get;
			var layerOrder = (_instance$$style0 = instance.$style) === null || _instance$$style0 === void 0 || (_instance$$style0$get = _instance$$style0.getLayerOrderThemeCSS) === null || _instance$$style0$get === void 0 ? void 0 : _instance$$style0$get.call(_instance$$style0);
			BaseStyle.load(layerOrder, _objectSpread$6({
				name: "layer-order",
				first: true
			}, useStyleOptions));
			Theme.setLoadedStyleName("layer-order");
		}
	},
	_loadScopedThemeStyles: function _loadScopedThemeStyles() {
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var useStyleOptions = arguments.length > 1 ? arguments[1] : void 0;
		var preset = instance.preset();
		if (preset && instance.$attrSelector) {
			var _instance$$style1, _instance$$style1$get, _instance$$style10;
			var css = (((_instance$$style1 = instance.$style) === null || _instance$$style1 === void 0 || (_instance$$style1$get = _instance$$style1.getPresetTheme) === null || _instance$$style1$get === void 0 ? void 0 : _instance$$style1$get.call(_instance$$style1, preset, "[".concat(instance.$attrSelector, "]"))) || {}).css;
			instance.scopedStyleEl = ((_instance$$style10 = instance.$style) === null || _instance$$style10 === void 0 ? void 0 : _instance$$style10.load(css, _objectSpread$6({ name: "".concat(instance.$attrSelector, "-").concat(instance.$style.name) }, useStyleOptions))).el;
		}
	},
	_themeChangeListener: function _themeChangeListener() {
		var callback = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {};
		Base.clearLoadedStyleNames();
		ThemeService.on("theme:change", callback);
	},
	_removeThemeListeners: function _removeThemeListeners() {
		var instance = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		ThemeService.off("theme:change", instance.$loadStyles);
		instance.$loadStyles = void 0;
	},
	_hook: function _hook(directiveName, hookName, el, binding, vnode, prevVnode) {
		var _binding$value, _config$pt;
		var name = "on".concat(ne(hookName));
		var config = BaseDirective._getConfig(binding, vnode);
		var instance = el === null || el === void 0 ? void 0 : el.$instance;
		var selfHook = BaseDirective._usePT(instance, BaseDirective._getPT(binding === null || binding === void 0 || (_binding$value = binding.value) === null || _binding$value === void 0 ? void 0 : _binding$value.pt, directiveName), BaseDirective._getOptionValue, "hooks.".concat(name));
		var defaultHook = BaseDirective._useDefaultPT(instance, config === null || config === void 0 || (_config$pt = config.pt) === null || _config$pt === void 0 || (_config$pt = _config$pt.directives) === null || _config$pt === void 0 ? void 0 : _config$pt[directiveName], BaseDirective._getOptionValue, "hooks.".concat(name));
		var options = {
			el,
			binding,
			vnode,
			prevVnode
		};
		selfHook === null || selfHook === void 0 || selfHook(instance, options);
		defaultHook === null || defaultHook === void 0 || defaultHook(instance, options);
	},
	_mergeProps: function _mergeProps() {
		var fn = arguments.length > 1 ? arguments[1] : void 0;
		for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key2 = 2; _key2 < _len; _key2++) args[_key2 - 2] = arguments[_key2];
		return c(fn) ? fn.apply(void 0, args) : mergeProps.apply(void 0, args);
	},
	_extend: function _extend(name) {
		var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var handleHook = function handleHook(hook, el, binding, vnode, prevVnode) {
			var _el$$pd, _el$$instance$hook, _el$$instance, _el$$pd2;
			el._$instances = el._$instances || {};
			var config = BaseDirective._getConfig(binding, vnode);
			var $prevInstance = el._$instances[name] || {};
			var $options = l($prevInstance) ? _objectSpread$6(_objectSpread$6({}, options), options === null || options === void 0 ? void 0 : options.methods) : {};
			el._$instances[name] = _objectSpread$6(_objectSpread$6({}, $prevInstance), {}, {
				$name: name,
				$host: el,
				$binding: binding,
				$modifiers: binding === null || binding === void 0 ? void 0 : binding.modifiers,
				$value: binding === null || binding === void 0 ? void 0 : binding.value,
				$el: $prevInstance["$el"] || el || void 0,
				$style: _objectSpread$6({
					classes: void 0,
					inlineStyles: void 0,
					load: function load() {},
					loadCSS: function loadCSS() {},
					loadStyle: function loadStyle() {}
				}, options === null || options === void 0 ? void 0 : options.style),
				$primevueConfig: config,
				$attrSelector: (_el$$pd = el.$pd) === null || _el$$pd === void 0 || (_el$$pd = _el$$pd[name]) === null || _el$$pd === void 0 ? void 0 : _el$$pd.attrSelector,
				defaultPT: function defaultPT() {
					return BaseDirective._getPT(config === null || config === void 0 ? void 0 : config.pt, void 0, function(value) {
						var _value$directives;
						return value === null || value === void 0 || (_value$directives = value.directives) === null || _value$directives === void 0 ? void 0 : _value$directives[name];
					});
				},
				isUnstyled: function isUnstyled() {
					var _el$_$instances$name, _el$_$instances$name2;
					return ((_el$_$instances$name = el._$instances[name]) === null || _el$_$instances$name === void 0 || (_el$_$instances$name = _el$_$instances$name.$binding) === null || _el$_$instances$name === void 0 || (_el$_$instances$name = _el$_$instances$name.value) === null || _el$_$instances$name === void 0 ? void 0 : _el$_$instances$name.unstyled) !== void 0 ? (_el$_$instances$name2 = el._$instances[name]) === null || _el$_$instances$name2 === void 0 || (_el$_$instances$name2 = _el$_$instances$name2.$binding) === null || _el$_$instances$name2 === void 0 || (_el$_$instances$name2 = _el$_$instances$name2.value) === null || _el$_$instances$name2 === void 0 ? void 0 : _el$_$instances$name2.unstyled : config === null || config === void 0 ? void 0 : config.unstyled;
				},
				theme: function theme() {
					var _el$_$instances$name3;
					return (_el$_$instances$name3 = el._$instances[name]) === null || _el$_$instances$name3 === void 0 || (_el$_$instances$name3 = _el$_$instances$name3.$primevueConfig) === null || _el$_$instances$name3 === void 0 ? void 0 : _el$_$instances$name3.theme;
				},
				preset: function preset() {
					var _el$_$instances$name4;
					return (_el$_$instances$name4 = el._$instances[name]) === null || _el$_$instances$name4 === void 0 || (_el$_$instances$name4 = _el$_$instances$name4.$binding) === null || _el$_$instances$name4 === void 0 || (_el$_$instances$name4 = _el$_$instances$name4.value) === null || _el$_$instances$name4 === void 0 ? void 0 : _el$_$instances$name4.dt;
				},
				ptm: function ptm() {
					var _el$_$instances$name5;
					var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
					var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
					return BaseDirective._getPTValue(el._$instances[name], (_el$_$instances$name5 = el._$instances[name]) === null || _el$_$instances$name5 === void 0 || (_el$_$instances$name5 = _el$_$instances$name5.$binding) === null || _el$_$instances$name5 === void 0 || (_el$_$instances$name5 = _el$_$instances$name5.value) === null || _el$_$instances$name5 === void 0 ? void 0 : _el$_$instances$name5.pt, key, _objectSpread$6({}, params));
				},
				ptmo: function ptmo() {
					var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
					var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
					var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
					return BaseDirective._getPTValue(el._$instances[name], obj, key, params, false);
				},
				cx: function cx() {
					var _el$_$instances$name6, _el$_$instances$name7;
					var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
					var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
					return !((_el$_$instances$name6 = el._$instances[name]) !== null && _el$_$instances$name6 !== void 0 && _el$_$instances$name6.isUnstyled()) ? BaseDirective._getOptionValue((_el$_$instances$name7 = el._$instances[name]) === null || _el$_$instances$name7 === void 0 || (_el$_$instances$name7 = _el$_$instances$name7.$style) === null || _el$_$instances$name7 === void 0 ? void 0 : _el$_$instances$name7.classes, key, _objectSpread$6({}, params)) : void 0;
				},
				sx: function sx() {
					var _el$_$instances$name8;
					var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
					var when = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
					var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
					return when ? BaseDirective._getOptionValue((_el$_$instances$name8 = el._$instances[name]) === null || _el$_$instances$name8 === void 0 || (_el$_$instances$name8 = _el$_$instances$name8.$style) === null || _el$_$instances$name8 === void 0 ? void 0 : _el$_$instances$name8.inlineStyles, key, _objectSpread$6({}, params)) : void 0;
				}
			}, $options);
			el.$instance = el._$instances[name];
			(_el$$instance$hook = (_el$$instance = el.$instance)[hook]) === null || _el$$instance$hook === void 0 || _el$$instance$hook.call(_el$$instance, el, binding, vnode, prevVnode);
			el["$".concat(name)] = el.$instance;
			BaseDirective._hook(name, hook, el, binding, vnode, prevVnode);
			el.$pd || (el.$pd = {});
			el.$pd[name] = _objectSpread$6(_objectSpread$6({}, (_el$$pd2 = el.$pd) === null || _el$$pd2 === void 0 ? void 0 : _el$$pd2[name]), {}, {
				name,
				instance: el._$instances[name]
			});
		};
		var handleWatchers = function handleWatchers(el) {
			var _watchers$config2, _watchers$configRipp2, _instance$$primevueCo3;
			var instance = el._$instances[name];
			var watchers = instance === null || instance === void 0 ? void 0 : instance.watch;
			var handleWatchConfig = function handleWatchConfig(_ref8) {
				var _watchers$config;
				var newValue = _ref8.newValue, oldValue = _ref8.oldValue;
				return watchers === null || watchers === void 0 || (_watchers$config = watchers["config"]) === null || _watchers$config === void 0 ? void 0 : _watchers$config.call(instance, newValue, oldValue);
			};
			var handleWatchConfigRipple = function handleWatchConfigRipple(_ref9) {
				var _watchers$configRipp;
				var newValue = _ref9.newValue, oldValue = _ref9.oldValue;
				return watchers === null || watchers === void 0 || (_watchers$configRipp = watchers["config.ripple"]) === null || _watchers$configRipp === void 0 ? void 0 : _watchers$configRipp.call(instance, newValue, oldValue);
			};
			instance.$watchersCallback = {
				config: handleWatchConfig,
				"config.ripple": handleWatchConfigRipple
			};
			watchers === null || watchers === void 0 || (_watchers$config2 = watchers["config"]) === null || _watchers$config2 === void 0 || _watchers$config2.call(instance, instance === null || instance === void 0 ? void 0 : instance.$primevueConfig);
			PrimeVueService.on("config:change", handleWatchConfig);
			watchers === null || watchers === void 0 || (_watchers$configRipp2 = watchers["config.ripple"]) === null || _watchers$configRipp2 === void 0 || _watchers$configRipp2.call(instance, instance === null || instance === void 0 || (_instance$$primevueCo3 = instance.$primevueConfig) === null || _instance$$primevueCo3 === void 0 ? void 0 : _instance$$primevueCo3.ripple);
			PrimeVueService.on("config:ripple:change", handleWatchConfigRipple);
		};
		var stopWatchers = function stopWatchers(el) {
			var watchers = el._$instances[name].$watchersCallback;
			if (watchers) {
				PrimeVueService.off("config:change", watchers.config);
				PrimeVueService.off("config:ripple:change", watchers["config.ripple"]);
				el._$instances[name].$watchersCallback = void 0;
			}
		};
		return {
			created: function created(el, binding, vnode, prevVnode) {
				el.$pd || (el.$pd = {});
				el.$pd[name] = {
					name,
					attrSelector: s("pd")
				};
				handleHook("created", el, binding, vnode, prevVnode);
			},
			beforeMount: function beforeMount(el, binding, vnode, prevVnode) {
				var _el$$pd$name;
				BaseDirective._loadStyles((_el$$pd$name = el.$pd[name]) === null || _el$$pd$name === void 0 ? void 0 : _el$$pd$name.instance, binding, vnode);
				handleHook("beforeMount", el, binding, vnode, prevVnode);
				handleWatchers(el);
			},
			mounted: function mounted(el, binding, vnode, prevVnode) {
				var _el$$pd$name2;
				BaseDirective._loadStyles((_el$$pd$name2 = el.$pd[name]) === null || _el$$pd$name2 === void 0 ? void 0 : _el$$pd$name2.instance, binding, vnode);
				handleHook("mounted", el, binding, vnode, prevVnode);
			},
			beforeUpdate: function beforeUpdate(el, binding, vnode, prevVnode) {
				handleHook("beforeUpdate", el, binding, vnode, prevVnode);
			},
			updated: function updated(el, binding, vnode, prevVnode) {
				var _el$$pd$name3;
				BaseDirective._loadStyles((_el$$pd$name3 = el.$pd[name]) === null || _el$$pd$name3 === void 0 ? void 0 : _el$$pd$name3.instance, binding, vnode);
				handleHook("updated", el, binding, vnode, prevVnode);
			},
			beforeUnmount: function beforeUnmount(el, binding, vnode, prevVnode) {
				var _el$$pd$name4;
				stopWatchers(el);
				BaseDirective._removeThemeListeners((_el$$pd$name4 = el.$pd[name]) === null || _el$$pd$name4 === void 0 ? void 0 : _el$$pd$name4.instance);
				handleHook("beforeUnmount", el, binding, vnode, prevVnode);
			},
			unmounted: function unmounted(el, binding, vnode, prevVnode) {
				var _el$$pd$name5;
				(_el$$pd$name5 = el.$pd[name]) === null || _el$$pd$name5 === void 0 || (_el$$pd$name5 = _el$$pd$name5.instance) === null || _el$$pd$name5 === void 0 || (_el$$pd$name5 = _el$$pd$name5.scopedStyleEl) === null || _el$$pd$name5 === void 0 || (_el$$pd$name5 = _el$$pd$name5.value) === null || _el$$pd$name5 === void 0 || _el$$pd$name5.remove();
				handleHook("unmounted", el, binding, vnode, prevVnode);
			}
		};
	},
	extend: function extend() {
		var _BaseDirective$_getMe2 = _slicedToArray(BaseDirective._getMeta.apply(BaseDirective, arguments), 2), name = _BaseDirective$_getMe2[0], options = _BaseDirective$_getMe2[1];
		return _objectSpread$6({ extend: function extend() {
			var _BaseDirective$_getMe4 = _slicedToArray(BaseDirective._getMeta.apply(BaseDirective, arguments), 2), _name = _BaseDirective$_getMe4[0], _options = _BaseDirective$_getMe4[1];
			return BaseDirective.extend(_name, _objectSpread$6(_objectSpread$6(_objectSpread$6({}, options), options === null || options === void 0 ? void 0 : options.methods), _options));
		} }, BaseDirective._extend(name, options));
	}
};

//#region node_modules/@primevue/core/baseeditableholder/index.mjs
var script$i = {
	name: "BaseEditableHolder",
	"extends": script$j,
	emits: ["update:modelValue", "value-change"],
	props: {
		modelValue: {
			type: null,
			"default": void 0
		},
		defaultValue: {
			type: null,
			"default": void 0
		},
		name: {
			type: String,
			"default": void 0
		},
		invalid: {
			type: Boolean,
			"default": void 0
		},
		disabled: {
			type: Boolean,
			"default": false
		},
		formControl: {
			type: Object,
			"default": void 0
		}
	},
	inject: {
		$parentInstance: { "default": void 0 },
		$pcForm: { "default": void 0 },
		$pcFormField: { "default": void 0 }
	},
	data: function data() {
		return { d_value: this.defaultValue !== void 0 ? this.defaultValue : this.modelValue };
	},
	watch: {
		modelValue: {
			deep: true,
			handler: function handler(newValue) {
				this.d_value = newValue;
			}
		},
		defaultValue: function defaultValue(newValue) {
			this.d_value = newValue;
		},
		$formName: {
			immediate: true,
			handler: function handler(newValue) {
				var _this$$pcForm, _this$$pcForm$registe;
				this.formField = ((_this$$pcForm = this.$pcForm) === null || _this$$pcForm === void 0 || (_this$$pcForm$registe = _this$$pcForm.register) === null || _this$$pcForm$registe === void 0 ? void 0 : _this$$pcForm$registe.call(_this$$pcForm, newValue, this.$formControl)) || {};
			}
		},
		$formControl: {
			immediate: true,
			handler: function handler(newValue) {
				var _this$$pcForm2, _this$$pcForm2$regist;
				this.formField = ((_this$$pcForm2 = this.$pcForm) === null || _this$$pcForm2 === void 0 || (_this$$pcForm2$regist = _this$$pcForm2.register) === null || _this$$pcForm2$regist === void 0 ? void 0 : _this$$pcForm2$regist.call(_this$$pcForm2, this.$formName, newValue)) || {};
			}
		},
		$formDefaultValue: {
			immediate: true,
			handler: function handler(newValue) {
				this.d_value !== newValue && (this.d_value = newValue);
			}
		},
		$formValue: {
			immediate: false,
			handler: function handler(newValue) {
				var _this$$pcForm3;
				if ((_this$$pcForm3 = this.$pcForm) !== null && _this$$pcForm3 !== void 0 && _this$$pcForm3.getFieldState(this.$formName) && newValue !== this.d_value) this.d_value = newValue;
			}
		}
	},
	formField: {},
	methods: {
		writeValue: function writeValue(value, event) {
			var _this$formField$onCha, _this$formField;
			if (this.controlled) {
				this.d_value = value;
				this.$emit("update:modelValue", value);
			}
			this.$emit("value-change", value);
			(_this$formField$onCha = (_this$formField = this.formField).onChange) === null || _this$formField$onCha === void 0 || _this$formField$onCha.call(_this$formField, {
				originalEvent: event,
				value
			});
		},
		findNonEmpty: function findNonEmpty() {
			for (var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++) values[_key] = arguments[_key];
			return values.find(isNotEmpty);
		}
	},
	computed: {
		$filled: function $filled() {
			return isNotEmpty(this.d_value);
		},
		$invalid: function $invalid() {
			var _this$$pcFormField, _this$$pcForm4;
			return !this.$formNovalidate && this.findNonEmpty(this.invalid, (_this$$pcFormField = this.$pcFormField) === null || _this$$pcFormField === void 0 || (_this$$pcFormField = _this$$pcFormField.$field) === null || _this$$pcFormField === void 0 ? void 0 : _this$$pcFormField.invalid, (_this$$pcForm4 = this.$pcForm) === null || _this$$pcForm4 === void 0 || (_this$$pcForm4 = _this$$pcForm4.getFieldState(this.$formName)) === null || _this$$pcForm4 === void 0 ? void 0 : _this$$pcForm4.invalid);
		},
		$formName: function $formName() {
			var _this$$formControl;
			return !this.$formNovalidate ? this.name || ((_this$$formControl = this.$formControl) === null || _this$$formControl === void 0 ? void 0 : _this$$formControl.name) : void 0;
		},
		$formControl: function $formControl() {
			var _this$$pcFormField2;
			return this.formControl || ((_this$$pcFormField2 = this.$pcFormField) === null || _this$$pcFormField2 === void 0 ? void 0 : _this$$pcFormField2.formControl);
		},
		$formNovalidate: function $formNovalidate() {
			var _this$$formControl2;
			return (_this$$formControl2 = this.$formControl) === null || _this$$formControl2 === void 0 ? void 0 : _this$$formControl2.novalidate;
		},
		$formDefaultValue: function $formDefaultValue() {
			var _this$$pcFormField3, _this$$pcForm5;
			return this.findNonEmpty(this.d_value, (_this$$pcFormField3 = this.$pcFormField) === null || _this$$pcFormField3 === void 0 ? void 0 : _this$$pcFormField3.initialValue, (_this$$pcForm5 = this.$pcForm) === null || _this$$pcForm5 === void 0 || (_this$$pcForm5 = _this$$pcForm5.initialValues) === null || _this$$pcForm5 === void 0 ? void 0 : _this$$pcForm5[this.$formName]);
		},
		$formValue: function $formValue() {
			var _this$$pcFormField4, _this$$pcForm6;
			return this.findNonEmpty((_this$$pcFormField4 = this.$pcFormField) === null || _this$$pcFormField4 === void 0 || (_this$$pcFormField4 = _this$$pcFormField4.$field) === null || _this$$pcFormField4 === void 0 ? void 0 : _this$$pcFormField4.value, (_this$$pcForm6 = this.$pcForm) === null || _this$$pcForm6 === void 0 || (_this$$pcForm6 = _this$$pcForm6.getFieldState(this.$formName)) === null || _this$$pcForm6 === void 0 ? void 0 : _this$$pcForm6.value);
		},
		controlled: function controlled() {
			return this.$inProps.hasOwnProperty("modelValue") || !this.$inProps.hasOwnProperty("modelValue") && !this.$inProps.hasOwnProperty("defaultValue");
		},
		filled: function filled() {
			return this.$filled;
		}
	}
};

//#region node_modules/@primevue/core/baseinput/index.mjs
var script$h = {
	name: "BaseInput",
	"extends": script$i,
	props: {
		size: {
			type: String,
			"default": null
		},
		fluid: {
			type: Boolean,
			"default": null
		},
		variant: {
			type: String,
			"default": null
		}
	},
	inject: {
		$parentInstance: { "default": void 0 },
		$pcFluid: { "default": void 0 }
	},
	computed: {
		$variant: function $variant() {
			var _this$variant;
			return (_this$variant = this.variant) !== null && _this$variant !== void 0 ? _this$variant : this.$primevue.config.inputStyle || this.$primevue.config.inputVariant;
		},
		$fluid: function $fluid() {
			var _this$fluid;
			return (_this$fluid = this.fluid) !== null && _this$fluid !== void 0 ? _this$fluid : !!this.$pcFluid;
		},
		hasFluid: function hasFluid() {
			return this.$fluid;
		}
	}
};

//#region node_modules/@primevue/icons/baseicon/style/index.mjs
var BaseIconStyle = BaseStyle.extend({
	name: "baseicon",
	css: "\n.p-icon {\n    display: inline-block;\n    vertical-align: baseline;\n    flex-shrink: 0;\n}\n\n.p-icon-spin {\n    -webkit-animation: p-icon-spin 2s infinite linear;\n    animation: p-icon-spin 2s infinite linear;\n}\n\n@-webkit-keyframes p-icon-spin {\n    0% {\n        -webkit-transform: rotate(0deg);\n        transform: rotate(0deg);\n    }\n    100% {\n        -webkit-transform: rotate(359deg);\n        transform: rotate(359deg);\n    }\n}\n\n@keyframes p-icon-spin {\n    0% {\n        -webkit-transform: rotate(0deg);\n        transform: rotate(0deg);\n    }\n    100% {\n        -webkit-transform: rotate(359deg);\n        transform: rotate(359deg);\n    }\n}\n"
});
//#endregion
//#region node_modules/@primevue/icons/baseicon/index.mjs
function _typeof$f(o) {
	"@babel/helpers - typeof";
	return _typeof$f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$f(o);
}
function ownKeys$5(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$5(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$5(Object(t), true).forEach(function(r) {
			_defineProperty$f(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$5(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$f(e, r, t) {
	return (r = _toPropertyKey$f(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$f(t) {
	var i = _toPrimitive$f(t, "string");
	return "symbol" == _typeof$f(i) ? i : i + "";
}
function _toPrimitive$f(t, r) {
	if ("object" != _typeof$f(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$f(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$g = {
	name: "BaseIcon",
	"extends": script$j,
	props: {
		label: {
			type: String,
			"default": void 0
		},
		spin: {
			type: Boolean,
			"default": false
		}
	},
	style: BaseIconStyle,
	provide: function provide() {
		return {
			$pcIcon: this,
			$parentInstance: this
		};
	},
	methods: { pti: function pti() {
		var isLabelEmpty = l(this.label);
		return _objectSpread$5(_objectSpread$5({}, !this.isUnstyled && { "class": ["p-icon", { "p-icon-spin": this.spin }] }), {}, {
			role: !isLabelEmpty ? "img" : void 0,
			"aria-label": !isLabelEmpty ? this.label : void 0,
			"aria-hidden": isLabelEmpty
		});
	} }
};

var style$b="\n    .p-ink {\n        display: block;\n        position: absolute;\n        background: dt('ripple.background');\n        border-radius: 100%;\n        transform: scale(0);\n        pointer-events: none;\n    }\n\n    .p-ink-active {\n        animation: ripple 0.4s linear;\n    }\n\n    @keyframes ripple {\n        100% {\n            opacity: 0;\n            transform: scale(2.5);\n        }\n    }\n";

//#region node_modules/primevue/ripple/style/index.mjs
var RippleStyle = BaseStyle.extend({
	name: "ripple-directive",
	style: style$b,
	classes: { root: "p-ink" }
});
//#endregion
//#region node_modules/primevue/ripple/index.mjs
var BaseRipple = BaseDirective.extend({ style: RippleStyle });
function _typeof$e(o) {
	"@babel/helpers - typeof";
	return _typeof$e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$e(o);
}
function _toConsumableArray$b(r) {
	return _arrayWithoutHoles$b(r) || _iterableToArray$b(r) || _unsupportedIterableToArray$c(r) || _nonIterableSpread$b();
}
function _nonIterableSpread$b() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$c(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$c(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$c(r, a) : void 0;
	}
}
function _iterableToArray$b(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$b(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$c(r);
}
function _arrayLikeToArray$c(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _defineProperty$e(e, r, t) {
	return (r = _toPropertyKey$e(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$e(t) {
	var i = _toPrimitive$e(t, "string");
	return "symbol" == _typeof$e(i) ? i : i + "";
}
function _toPrimitive$e(t, r) {
	if ("object" != _typeof$e(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$e(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Ripple = BaseRipple.extend("ripple", {
	watch: { "config.ripple": function configRipple(newValue) {
		if (newValue) {
			this.createRipple(this.$host);
			this.bindEvents(this.$host);
			this.$host.setAttribute("data-pd-ripple", true);
			this.$host.style["overflow"] = "hidden";
			this.$host.style["position"] = "relative";
		} else {
			this.remove(this.$host);
			this.$host.removeAttribute("data-pd-ripple");
		}
	} },
	unmounted: function unmounted(el) {
		this.remove(el);
	},
	timeout: void 0,
	methods: {
		bindEvents: function bindEvents(el) {
			el.addEventListener("mousedown", this.onMouseDown.bind(this));
		},
		unbindEvents: function unbindEvents(el) {
			el.removeEventListener("mousedown", this.onMouseDown.bind(this));
		},
		createRipple: function createRipple(el) {
			var ink = this.getInk(el);
			if (!ink) {
				ink = U("span", _defineProperty$e(_defineProperty$e({
					role: "presentation",
					"aria-hidden": true,
					"data-p-ink": true,
					"data-p-ink-active": false,
					"class": !this.isUnstyled() && this.cx("root"),
					onAnimationEnd: this.onAnimationEnd.bind(this)
				}, this.$attrSelector, ""), "p-bind", this.ptm("root")));
				el.appendChild(ink);
				this.$el = ink;
			}
		},
		remove: function remove(el) {
			var ink = this.getInk(el);
			if (ink) {
				this.$host.style["overflow"] = "";
				this.$host.style["position"] = "";
				this.unbindEvents(el);
				ink.removeEventListener("animationend", this.onAnimationEnd);
				ink.remove();
			}
		},
		onMouseDown: function onMouseDown(event) {
			var _this = this;
			var target = event.currentTarget;
			var ink = this.getInk(target);
			if (!ink || getComputedStyle(ink, null).display === "none") return;
			!this.isUnstyled() && P(ink, "p-ink-active");
			ink.setAttribute("data-p-ink-active", "false");
			if (!Tt(ink) && !Rt(ink)) {
				var d = Math.max(v(target), C$1(target));
				ink.style.height = d + "px";
				ink.style.width = d + "px";
			}
			var offset = K(target);
			var x = event.pageX - offset.left + (void 0).body.scrollTop - Rt(ink) / 2;
			var y = event.pageY - offset.top + (void 0).body.scrollLeft - Tt(ink) / 2;
			ink.style.top = y + "px";
			ink.style.left = x + "px";
			!this.isUnstyled() && W(ink, "p-ink-active");
			ink.setAttribute("data-p-ink-active", "true");
			this.timeout = setTimeout(function() {
				if (ink) {
					!_this.isUnstyled() && P(ink, "p-ink-active");
					ink.setAttribute("data-p-ink-active", "false");
				}
			}, 401);
		},
		onAnimationEnd: function onAnimationEnd(event) {
			if (this.timeout) clearTimeout(this.timeout);
			!this.isUnstyled() && P(event.currentTarget, "p-ink-active");
			event.currentTarget.setAttribute("data-p-ink-active", "false");
		},
		getInk: function getInk(el) {
			return el && el.children ? _toConsumableArray$b(el.children).find(function(child) {
				return Q(child, "data-pc-name") === "ripple";
			}) : void 0;
		}
	}
});

//#region node_modules/@primevue/icons/spinner/index.mjs
var script$f = {
	name: "SpinnerIcon",
	"extends": script$g
};
function _toConsumableArray$a(r) {
	return _arrayWithoutHoles$a(r) || _iterableToArray$a(r) || _unsupportedIterableToArray$b(r) || _nonIterableSpread$a();
}
function _nonIterableSpread$a() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$b(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$b(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$b(r, a) : void 0;
	}
}
function _iterableToArray$a(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$a(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$b(r);
}
function _arrayLikeToArray$b(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$f(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$a(_cache[0] || (_cache[0] = [createElementVNode("path", {
		d: "M6.99701 14C5.85441 13.999 4.72939 13.7186 3.72012 13.1832C2.71084 12.6478 1.84795 11.8737 1.20673 10.9284C0.565504 9.98305 0.165424 8.89526 0.041387 7.75989C-0.0826496 6.62453 0.073125 5.47607 0.495122 4.4147C0.917119 3.35333 1.59252 2.4113 2.46241 1.67077C3.33229 0.930247 4.37024 0.413729 5.4857 0.166275C6.60117 -0.0811796 7.76026 -0.0520535 8.86188 0.251112C9.9635 0.554278 10.9742 1.12227 11.8057 1.90555C11.915 2.01493 11.9764 2.16319 11.9764 2.31778C11.9764 2.47236 11.915 2.62062 11.8057 2.73C11.7521 2.78503 11.688 2.82877 11.6171 2.85864C11.5463 2.8885 11.4702 2.90389 11.3933 2.90389C11.3165 2.90389 11.2404 2.8885 11.1695 2.85864C11.0987 2.82877 11.0346 2.78503 10.9809 2.73C9.9998 1.81273 8.73246 1.26138 7.39226 1.16876C6.05206 1.07615 4.72086 1.44794 3.62279 2.22152C2.52471 2.99511 1.72683 4.12325 1.36345 5.41602C1.00008 6.70879 1.09342 8.08723 1.62775 9.31926C2.16209 10.5513 3.10478 11.5617 4.29713 12.1803C5.48947 12.7989 6.85865 12.988 8.17414 12.7157C9.48963 12.4435 10.6711 11.7264 11.5196 10.6854C12.3681 9.64432 12.8319 8.34282 12.8328 7C12.8328 6.84529 12.8943 6.69692 13.0038 6.58752C13.1132 6.47812 13.2616 6.41667 13.4164 6.41667C13.5712 6.41667 13.7196 6.47812 13.8291 6.58752C13.9385 6.69692 14 6.84529 14 7C14 8.85651 13.2622 10.637 11.9489 11.9497C10.6356 13.2625 8.85432 14 6.99701 14Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$f.render = render$f;

var style$a="\n    .p-badge {\n        display: inline-flex;\n        border-radius: dt('badge.border.radius');\n        align-items: center;\n        justify-content: center;\n        padding: dt('badge.padding');\n        background: dt('badge.primary.background');\n        color: dt('badge.primary.color');\n        font-size: dt('badge.font.size');\n        font-weight: dt('badge.font.weight');\n        min-width: dt('badge.min.width');\n        height: dt('badge.height');\n    }\n\n    .p-badge-dot {\n        width: dt('badge.dot.size');\n        min-width: dt('badge.dot.size');\n        height: dt('badge.dot.size');\n        border-radius: 50%;\n        padding: 0;\n    }\n\n    .p-badge-circle {\n        padding: 0;\n        border-radius: 50%;\n    }\n\n    .p-badge-secondary {\n        background: dt('badge.secondary.background');\n        color: dt('badge.secondary.color');\n    }\n\n    .p-badge-success {\n        background: dt('badge.success.background');\n        color: dt('badge.success.color');\n    }\n\n    .p-badge-info {\n        background: dt('badge.info.background');\n        color: dt('badge.info.color');\n    }\n\n    .p-badge-warn {\n        background: dt('badge.warn.background');\n        color: dt('badge.warn.color');\n    }\n\n    .p-badge-danger {\n        background: dt('badge.danger.background');\n        color: dt('badge.danger.color');\n    }\n\n    .p-badge-contrast {\n        background: dt('badge.contrast.background');\n        color: dt('badge.contrast.color');\n    }\n\n    .p-badge-sm {\n        font-size: dt('badge.sm.font.size');\n        min-width: dt('badge.sm.min.width');\n        height: dt('badge.sm.height');\n    }\n\n    .p-badge-lg {\n        font-size: dt('badge.lg.font.size');\n        min-width: dt('badge.lg.min.width');\n        height: dt('badge.lg.height');\n    }\n\n    .p-badge-xl {\n        font-size: dt('badge.xl.font.size');\n        min-width: dt('badge.xl.min.width');\n        height: dt('badge.xl.height');\n    }\n";

//#region node_modules/primevue/badge/style/index.mjs
var BadgeStyle = BaseStyle.extend({
	name: "badge",
	style: style$a,
	classes: { root: function root(_ref) {
		var props = _ref.props, instance = _ref.instance;
		return ["p-badge p-component", {
			"p-badge-circle": s$2(props.value) && String(props.value).length === 1,
			"p-badge-dot": l(props.value) && !instance.$slots["default"],
			"p-badge-sm": props.size === "small",
			"p-badge-lg": props.size === "large",
			"p-badge-xl": props.size === "xlarge",
			"p-badge-info": props.severity === "info",
			"p-badge-success": props.severity === "success",
			"p-badge-warn": props.severity === "warn",
			"p-badge-danger": props.severity === "danger",
			"p-badge-secondary": props.severity === "secondary",
			"p-badge-contrast": props.severity === "contrast"
		}];
	} }
});
//#endregion
//#region node_modules/primevue/badge/index.mjs
var badge_exports = /* @__PURE__ */ __exportAll({ default: () => script$e });
var script$1$2 = {
	name: "BaseBadge",
	"extends": script$j,
	props: {
		value: {
			type: [String, Number],
			"default": null
		},
		severity: {
			type: String,
			"default": null
		},
		size: {
			type: String,
			"default": null
		}
	},
	style: BadgeStyle,
	provide: function provide() {
		return {
			$pcBadge: this,
			$parentInstance: this
		};
	}
};
function _typeof$d(o) {
	"@babel/helpers - typeof";
	return _typeof$d = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$d(o);
}
function _defineProperty$d(e, r, t) {
	return (r = _toPropertyKey$d(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$d(t) {
	var i = _toPrimitive$d(t, "string");
	return "symbol" == _typeof$d(i) ? i : i + "";
}
function _toPrimitive$d(t, r) {
	if ("object" != _typeof$d(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$d(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$e = {
	name: "Badge",
	"extends": script$1$2,
	inheritAttrs: false,
	computed: { dataP: function dataP() {
		return cn(_defineProperty$d(_defineProperty$d({
			circle: this.value != null && String(this.value).length === 1,
			empty: this.value == null && !this.$slots["default"]
		}, this.severity, this.severity), this.size, this.size));
	} }
};
var _hoisted_1$9 = ["data-p"];
function render$e(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("span", mergeProps({
		"class": _ctx.cx("root"),
		"data-p": $options.dataP
	}, _ctx.ptmi("root")), [renderSlot(_ctx.$slots, "default", {}, function() {
		return [createTextVNode(toDisplayString(_ctx.value), 1)];
	})], 16, _hoisted_1$9);
}
script$e.render = render$e;

const badgeDf1CDU2B = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  n: script$e,
  t: badge_exports
}, Symbol.toStringTag, { value: 'Module' }));

var style$9="\n    .p-button {\n        display: inline-flex;\n        cursor: pointer;\n        user-select: none;\n        align-items: center;\n        justify-content: center;\n        overflow: hidden;\n        position: relative;\n        color: dt('button.primary.color');\n        background: dt('button.primary.background');\n        border: 1px solid dt('button.primary.border.color');\n        padding: dt('button.padding.y') dt('button.padding.x');\n        font-size: 1rem;\n        font-family: inherit;\n        font-feature-settings: inherit;\n        transition:\n            background dt('button.transition.duration'),\n            color dt('button.transition.duration'),\n            border-color dt('button.transition.duration'),\n            outline-color dt('button.transition.duration'),\n            box-shadow dt('button.transition.duration');\n        border-radius: dt('button.border.radius');\n        outline-color: transparent;\n        gap: dt('button.gap');\n    }\n\n    .p-button:disabled {\n        cursor: default;\n    }\n\n    .p-button-icon-right {\n        order: 1;\n    }\n\n    .p-button-icon-right:dir(rtl) {\n        order: -1;\n    }\n\n    .p-button:not(.p-button-vertical) .p-button-icon:not(.p-button-icon-right):dir(rtl) {\n        order: 1;\n    }\n\n    .p-button-icon-bottom {\n        order: 2;\n    }\n\n    .p-button-icon-only {\n        width: dt('button.icon.only.width');\n        padding-inline-start: 0;\n        padding-inline-end: 0;\n        gap: 0;\n    }\n\n    .p-button-icon-only.p-button-rounded {\n        border-radius: 50%;\n        height: dt('button.icon.only.width');\n    }\n\n    .p-button-icon-only .p-button-label {\n        visibility: hidden;\n        width: 0;\n    }\n\n    .p-button-icon-only::after {\n        content: \" \";\n        visibility: hidden;\n        width: 0;\n    }\n\n    .p-button-sm {\n        font-size: dt('button.sm.font.size');\n        padding: dt('button.sm.padding.y') dt('button.sm.padding.x');\n    }\n\n    .p-button-sm .p-button-icon {\n        font-size: dt('button.sm.font.size');\n    }\n\n    .p-button-sm.p-button-icon-only {\n        width: dt('button.sm.icon.only.width');\n    }\n\n    .p-button-sm.p-button-icon-only.p-button-rounded {\n        height: dt('button.sm.icon.only.width');\n    }\n\n    .p-button-lg {\n        font-size: dt('button.lg.font.size');\n        padding: dt('button.lg.padding.y') dt('button.lg.padding.x');\n    }\n\n    .p-button-lg .p-button-icon {\n        font-size: dt('button.lg.font.size');\n    }\n\n    .p-button-lg.p-button-icon-only {\n        width: dt('button.lg.icon.only.width');\n    }\n\n    .p-button-lg.p-button-icon-only.p-button-rounded {\n        height: dt('button.lg.icon.only.width');\n    }\n\n    .p-button-vertical {\n        flex-direction: column;\n    }\n\n    .p-button-label {\n        font-weight: dt('button.label.font.weight');\n    }\n\n    .p-button-fluid {\n        width: 100%;\n    }\n\n    .p-button-fluid.p-button-icon-only {\n        width: dt('button.icon.only.width');\n    }\n\n    .p-button:not(:disabled):hover {\n        background: dt('button.primary.hover.background');\n        border: 1px solid dt('button.primary.hover.border.color');\n        color: dt('button.primary.hover.color');\n    }\n\n    .p-button:not(:disabled):active {\n        background: dt('button.primary.active.background');\n        border: 1px solid dt('button.primary.active.border.color');\n        color: dt('button.primary.active.color');\n    }\n\n    .p-button:focus-visible {\n        box-shadow: dt('button.primary.focus.ring.shadow');\n        outline: dt('button.focus.ring.width') dt('button.focus.ring.style') dt('button.primary.focus.ring.color');\n        outline-offset: dt('button.focus.ring.offset');\n    }\n\n    .p-button .p-badge {\n        min-width: dt('button.badge.size');\n        height: dt('button.badge.size');\n        line-height: dt('button.badge.size');\n    }\n\n    .p-button-raised {\n        box-shadow: dt('button.raised.shadow');\n    }\n\n    .p-button-rounded {\n        border-radius: dt('button.rounded.border.radius');\n    }\n\n    .p-button-secondary {\n        background: dt('button.secondary.background');\n        border: 1px solid dt('button.secondary.border.color');\n        color: dt('button.secondary.color');\n    }\n\n    .p-button-secondary:not(:disabled):hover {\n        background: dt('button.secondary.hover.background');\n        border: 1px solid dt('button.secondary.hover.border.color');\n        color: dt('button.secondary.hover.color');\n    }\n\n    .p-button-secondary:not(:disabled):active {\n        background: dt('button.secondary.active.background');\n        border: 1px solid dt('button.secondary.active.border.color');\n        color: dt('button.secondary.active.color');\n    }\n\n    .p-button-secondary:focus-visible {\n        outline-color: dt('button.secondary.focus.ring.color');\n        box-shadow: dt('button.secondary.focus.ring.shadow');\n    }\n\n    .p-button-success {\n        background: dt('button.success.background');\n        border: 1px solid dt('button.success.border.color');\n        color: dt('button.success.color');\n    }\n\n    .p-button-success:not(:disabled):hover {\n        background: dt('button.success.hover.background');\n        border: 1px solid dt('button.success.hover.border.color');\n        color: dt('button.success.hover.color');\n    }\n\n    .p-button-success:not(:disabled):active {\n        background: dt('button.success.active.background');\n        border: 1px solid dt('button.success.active.border.color');\n        color: dt('button.success.active.color');\n    }\n\n    .p-button-success:focus-visible {\n        outline-color: dt('button.success.focus.ring.color');\n        box-shadow: dt('button.success.focus.ring.shadow');\n    }\n\n    .p-button-info {\n        background: dt('button.info.background');\n        border: 1px solid dt('button.info.border.color');\n        color: dt('button.info.color');\n    }\n\n    .p-button-info:not(:disabled):hover {\n        background: dt('button.info.hover.background');\n        border: 1px solid dt('button.info.hover.border.color');\n        color: dt('button.info.hover.color');\n    }\n\n    .p-button-info:not(:disabled):active {\n        background: dt('button.info.active.background');\n        border: 1px solid dt('button.info.active.border.color');\n        color: dt('button.info.active.color');\n    }\n\n    .p-button-info:focus-visible {\n        outline-color: dt('button.info.focus.ring.color');\n        box-shadow: dt('button.info.focus.ring.shadow');\n    }\n\n    .p-button-warn {\n        background: dt('button.warn.background');\n        border: 1px solid dt('button.warn.border.color');\n        color: dt('button.warn.color');\n    }\n\n    .p-button-warn:not(:disabled):hover {\n        background: dt('button.warn.hover.background');\n        border: 1px solid dt('button.warn.hover.border.color');\n        color: dt('button.warn.hover.color');\n    }\n\n    .p-button-warn:not(:disabled):active {\n        background: dt('button.warn.active.background');\n        border: 1px solid dt('button.warn.active.border.color');\n        color: dt('button.warn.active.color');\n    }\n\n    .p-button-warn:focus-visible {\n        outline-color: dt('button.warn.focus.ring.color');\n        box-shadow: dt('button.warn.focus.ring.shadow');\n    }\n\n    .p-button-help {\n        background: dt('button.help.background');\n        border: 1px solid dt('button.help.border.color');\n        color: dt('button.help.color');\n    }\n\n    .p-button-help:not(:disabled):hover {\n        background: dt('button.help.hover.background');\n        border: 1px solid dt('button.help.hover.border.color');\n        color: dt('button.help.hover.color');\n    }\n\n    .p-button-help:not(:disabled):active {\n        background: dt('button.help.active.background');\n        border: 1px solid dt('button.help.active.border.color');\n        color: dt('button.help.active.color');\n    }\n\n    .p-button-help:focus-visible {\n        outline-color: dt('button.help.focus.ring.color');\n        box-shadow: dt('button.help.focus.ring.shadow');\n    }\n\n    .p-button-danger {\n        background: dt('button.danger.background');\n        border: 1px solid dt('button.danger.border.color');\n        color: dt('button.danger.color');\n    }\n\n    .p-button-danger:not(:disabled):hover {\n        background: dt('button.danger.hover.background');\n        border: 1px solid dt('button.danger.hover.border.color');\n        color: dt('button.danger.hover.color');\n    }\n\n    .p-button-danger:not(:disabled):active {\n        background: dt('button.danger.active.background');\n        border: 1px solid dt('button.danger.active.border.color');\n        color: dt('button.danger.active.color');\n    }\n\n    .p-button-danger:focus-visible {\n        outline-color: dt('button.danger.focus.ring.color');\n        box-shadow: dt('button.danger.focus.ring.shadow');\n    }\n\n    .p-button-contrast {\n        background: dt('button.contrast.background');\n        border: 1px solid dt('button.contrast.border.color');\n        color: dt('button.contrast.color');\n    }\n\n    .p-button-contrast:not(:disabled):hover {\n        background: dt('button.contrast.hover.background');\n        border: 1px solid dt('button.contrast.hover.border.color');\n        color: dt('button.contrast.hover.color');\n    }\n\n    .p-button-contrast:not(:disabled):active {\n        background: dt('button.contrast.active.background');\n        border: 1px solid dt('button.contrast.active.border.color');\n        color: dt('button.contrast.active.color');\n    }\n\n    .p-button-contrast:focus-visible {\n        outline-color: dt('button.contrast.focus.ring.color');\n        box-shadow: dt('button.contrast.focus.ring.shadow');\n    }\n\n    .p-button-outlined {\n        background: transparent;\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined:not(:disabled):hover {\n        background: dt('button.outlined.primary.hover.background');\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined:not(:disabled):active {\n        background: dt('button.outlined.primary.active.background');\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined.p-button-secondary {\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-secondary:not(:disabled):hover {\n        background: dt('button.outlined.secondary.hover.background');\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-secondary:not(:disabled):active {\n        background: dt('button.outlined.secondary.active.background');\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-success {\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-success:not(:disabled):hover {\n        background: dt('button.outlined.success.hover.background');\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-success:not(:disabled):active {\n        background: dt('button.outlined.success.active.background');\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-info {\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-info:not(:disabled):hover {\n        background: dt('button.outlined.info.hover.background');\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-info:not(:disabled):active {\n        background: dt('button.outlined.info.active.background');\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-warn {\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-warn:not(:disabled):hover {\n        background: dt('button.outlined.warn.hover.background');\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-warn:not(:disabled):active {\n        background: dt('button.outlined.warn.active.background');\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-help {\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-help:not(:disabled):hover {\n        background: dt('button.outlined.help.hover.background');\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-help:not(:disabled):active {\n        background: dt('button.outlined.help.active.background');\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-danger {\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-danger:not(:disabled):hover {\n        background: dt('button.outlined.danger.hover.background');\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-danger:not(:disabled):active {\n        background: dt('button.outlined.danger.active.background');\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-contrast {\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-contrast:not(:disabled):hover {\n        background: dt('button.outlined.contrast.hover.background');\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-contrast:not(:disabled):active {\n        background: dt('button.outlined.contrast.active.background');\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-plain {\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-outlined.p-button-plain:not(:disabled):hover {\n        background: dt('button.outlined.plain.hover.background');\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-outlined.p-button-plain:not(:disabled):active {\n        background: dt('button.outlined.plain.active.background');\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-text {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text:not(:disabled):hover {\n        background: dt('button.text.primary.hover.background');\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text:not(:disabled):active {\n        background: dt('button.text.primary.active.background');\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text.p-button-secondary {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-secondary:not(:disabled):hover {\n        background: dt('button.text.secondary.hover.background');\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-secondary:not(:disabled):active {\n        background: dt('button.text.secondary.active.background');\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-success {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-success:not(:disabled):hover {\n        background: dt('button.text.success.hover.background');\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-success:not(:disabled):active {\n        background: dt('button.text.success.active.background');\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-info {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-info:not(:disabled):hover {\n        background: dt('button.text.info.hover.background');\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-info:not(:disabled):active {\n        background: dt('button.text.info.active.background');\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-warn {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-warn:not(:disabled):hover {\n        background: dt('button.text.warn.hover.background');\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-warn:not(:disabled):active {\n        background: dt('button.text.warn.active.background');\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-help {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-help:not(:disabled):hover {\n        background: dt('button.text.help.hover.background');\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-help:not(:disabled):active {\n        background: dt('button.text.help.active.background');\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-danger {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-danger:not(:disabled):hover {\n        background: dt('button.text.danger.hover.background');\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-danger:not(:disabled):active {\n        background: dt('button.text.danger.active.background');\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-contrast {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-contrast:not(:disabled):hover {\n        background: dt('button.text.contrast.hover.background');\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-contrast:not(:disabled):active {\n        background: dt('button.text.contrast.active.background');\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-plain {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-text.p-button-plain:not(:disabled):hover {\n        background: dt('button.text.plain.hover.background');\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-text.p-button-plain:not(:disabled):active {\n        background: dt('button.text.plain.active.background');\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-link {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.color');\n    }\n\n    .p-button-link:not(:disabled):hover {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.hover.color');\n    }\n\n    .p-button-link:not(:disabled):hover .p-button-label {\n        text-decoration: underline;\n    }\n\n    .p-button-link:not(:disabled):active {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.active.color');\n    }\n";

//#region node_modules/primevue/button/style/index.mjs
function _typeof$1$2(o) {
	"@babel/helpers - typeof";
	return _typeof$1$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1$2(o);
}
function _defineProperty$1$1(e, r, t) {
	return (r = _toPropertyKey$1$2(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$1$2(t) {
	var i = _toPrimitive$1$2(t, "string");
	return "symbol" == _typeof$1$2(i) ? i : i + "";
}
function _toPrimitive$1$2(t, r) {
	if ("object" != _typeof$1$2(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$1$2(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ButtonStyle = BaseStyle.extend({
	name: "button",
	style: style$9,
	classes: {
		root: function root(_ref) {
			var instance = _ref.instance, props = _ref.props;
			return ["p-button p-component", _defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1(_defineProperty$1$1({
				"p-button-icon-only": instance.hasIcon && !props.label && !props.badge,
				"p-button-vertical": (props.iconPos === "top" || props.iconPos === "bottom") && props.label,
				"p-button-loading": props.loading,
				"p-button-link": props.link || props.variant === "link"
			}, "p-button-".concat(props.severity), props.severity), "p-button-raised", props.raised), "p-button-rounded", props.rounded), "p-button-text", props.text || props.variant === "text"), "p-button-outlined", props.outlined || props.variant === "outlined"), "p-button-sm", props.size === "small"), "p-button-lg", props.size === "large"), "p-button-plain", props.plain), "p-button-fluid", instance.hasFluid)];
		},
		loadingIcon: "p-button-loading-icon",
		icon: function icon(_ref3) {
			var props = _ref3.props;
			return ["p-button-icon", _defineProperty$1$1({}, "p-button-icon-".concat(props.iconPos), props.label)];
		},
		label: "p-button-label"
	}
});
//#endregion
//#region node_modules/primevue/button/index.mjs
var button_exports = /* @__PURE__ */ __exportAll({ default: () => script$d });
var script$1$1 = {
	name: "BaseButton",
	"extends": script$j,
	props: {
		label: {
			type: String,
			"default": null
		},
		icon: {
			type: String,
			"default": null
		},
		iconPos: {
			type: String,
			"default": "left"
		},
		iconClass: {
			type: [String, Object],
			"default": null
		},
		badge: {
			type: String,
			"default": null
		},
		badgeClass: {
			type: [String, Object],
			"default": null
		},
		badgeSeverity: {
			type: String,
			"default": "secondary"
		},
		loading: {
			type: Boolean,
			"default": false
		},
		loadingIcon: {
			type: String,
			"default": void 0
		},
		as: {
			type: [String, Object],
			"default": "BUTTON"
		},
		asChild: {
			type: Boolean,
			"default": false
		},
		link: {
			type: Boolean,
			"default": false
		},
		severity: {
			type: String,
			"default": null
		},
		raised: {
			type: Boolean,
			"default": false
		},
		rounded: {
			type: Boolean,
			"default": false
		},
		text: {
			type: Boolean,
			"default": false
		},
		outlined: {
			type: Boolean,
			"default": false
		},
		size: {
			type: String,
			"default": null
		},
		variant: {
			type: String,
			"default": null
		},
		plain: {
			type: Boolean,
			"default": false
		},
		fluid: {
			type: Boolean,
			"default": null
		}
	},
	style: ButtonStyle,
	provide: function provide() {
		return {
			$pcButton: this,
			$parentInstance: this
		};
	}
};
function _typeof$c(o) {
	"@babel/helpers - typeof";
	return _typeof$c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$c(o);
}
function _defineProperty$c(e, r, t) {
	return (r = _toPropertyKey$c(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$c(t) {
	var i = _toPrimitive$c(t, "string");
	return "symbol" == _typeof$c(i) ? i : i + "";
}
function _toPrimitive$c(t, r) {
	if ("object" != _typeof$c(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$c(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$d = {
	name: "Button",
	"extends": script$1$1,
	inheritAttrs: false,
	inject: { $pcFluid: { "default": null } },
	methods: { getPTOptions: function getPTOptions(key) {
		return (key === "root" ? this.ptmi : this.ptm)(key, { context: { disabled: this.disabled } });
	} },
	computed: {
		disabled: function disabled() {
			return this.$attrs.disabled || this.$attrs.disabled === "" || this.loading;
		},
		defaultAriaLabel: function defaultAriaLabel() {
			return this.label ? this.label + (this.badge ? " " + this.badge : "") : this.$attrs.ariaLabel;
		},
		hasIcon: function hasIcon() {
			return this.icon || this.$slots.icon;
		},
		attrs: function attrs() {
			return mergeProps(this.asAttrs, this.a11yAttrs, this.getPTOptions("root"));
		},
		asAttrs: function asAttrs() {
			return this.as === "BUTTON" ? {
				type: "button",
				disabled: this.disabled
			} : void 0;
		},
		a11yAttrs: function a11yAttrs() {
			return {
				"aria-label": this.defaultAriaLabel,
				"data-pc-name": "button",
				"data-p-disabled": this.disabled,
				"data-p-severity": this.severity
			};
		},
		hasFluid: function hasFluid() {
			return l(this.fluid) ? !!this.$pcFluid : this.fluid;
		},
		dataP: function dataP() {
			return cn(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c(_defineProperty$c({}, this.size, this.size), "icon-only", this.hasIcon && !this.label && !this.badge), "loading", this.loading), "fluid", this.hasFluid), "rounded", this.rounded), "raised", this.raised), "outlined", this.outlined || this.variant === "outlined"), "text", this.text || this.variant === "text"), "link", this.link || this.variant === "link"), "vertical", (this.iconPos === "top" || this.iconPos === "bottom") && this.label));
		},
		dataIconP: function dataIconP() {
			return cn(_defineProperty$c(_defineProperty$c({}, this.iconPos, this.iconPos), this.size, this.size));
		},
		dataLabelP: function dataLabelP() {
			return cn(_defineProperty$c(_defineProperty$c({}, this.size, this.size), "icon-only", this.hasIcon && !this.label && !this.badge));
		}
	},
	components: {
		SpinnerIcon: script$f,
		Badge: script$e
	},
	directives: { ripple: Ripple }
};
var _hoisted_1$8 = ["data-p"];
var _hoisted_2$5 = ["data-p"];
function render$d(_ctx, _cache, $props, $setup, $data, $options) {
	var _component_SpinnerIcon = resolveComponent("SpinnerIcon");
	var _component_Badge = resolveComponent("Badge");
	var _directive_ripple = resolveDirective("ripple");
	return !_ctx.asChild ? withDirectives((openBlock(), createBlock(resolveDynamicComponent(_ctx.as), mergeProps({
		key: 0,
		"class": _ctx.cx("root"),
		"data-p": $options.dataP
	}, $options.attrs), {
		"default": withCtx(function() {
			return [renderSlot(_ctx.$slots, "default", {}, function() {
				return [
					_ctx.loading ? renderSlot(_ctx.$slots, "loadingicon", mergeProps({
						key: 0,
						"class": [_ctx.cx("loadingIcon"), _ctx.cx("icon")]
					}, _ctx.ptm("loadingIcon")), function() {
						return [_ctx.loadingIcon ? (openBlock(), createElementBlock("span", mergeProps({
							key: 0,
							"class": [
								_ctx.cx("loadingIcon"),
								_ctx.cx("icon"),
								_ctx.loadingIcon
							]
						}, _ctx.ptm("loadingIcon")), null, 16)) : (openBlock(), createBlock(_component_SpinnerIcon, mergeProps({
							key: 1,
							"class": [_ctx.cx("loadingIcon"), _ctx.cx("icon")],
							spin: ""
						}, _ctx.ptm("loadingIcon")), null, 16, ["class"]))];
					}) : renderSlot(_ctx.$slots, "icon", mergeProps({
						key: 1,
						"class": [_ctx.cx("icon")]
					}, _ctx.ptm("icon")), function() {
						return [_ctx.icon ? (openBlock(), createElementBlock("span", mergeProps({
							key: 0,
							"class": [
								_ctx.cx("icon"),
								_ctx.icon,
								_ctx.iconClass
							],
							"data-p": $options.dataIconP
						}, _ctx.ptm("icon")), null, 16, _hoisted_1$8)) : createCommentVNode("", true)];
					}),
					_ctx.label ? (openBlock(), createElementBlock("span", mergeProps({
						key: 2,
						"class": _ctx.cx("label")
					}, _ctx.ptm("label"), { "data-p": $options.dataLabelP }), toDisplayString(_ctx.label), 17, _hoisted_2$5)) : createCommentVNode("", true),
					_ctx.badge ? (openBlock(), createBlock(_component_Badge, {
						key: 3,
						value: _ctx.badge,
						"class": normalizeClass(_ctx.badgeClass),
						severity: _ctx.badgeSeverity,
						unstyled: _ctx.unstyled,
						pt: _ctx.ptm("pcBadge")
					}, null, 8, [
						"value",
						"class",
						"severity",
						"unstyled",
						"pt"
					])) : createCommentVNode("", true)
				];
			})];
		}),
		_: 3
	}, 16, ["class", "data-p"])), [[_directive_ripple]]) : renderSlot(_ctx.$slots, "default", {
		key: 1,
		"class": normalizeClass(_ctx.cx("root")),
		a11yAttrs: $options.a11yAttrs
	});
}
script$d.render = render$d;

const buttonDjYJPz0o = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  n: script$d,
  t: button_exports
}, Symbol.toStringTag, { value: 'Module' }));

//#region node_modules/@primevue/core/utils/index.mjs
function _typeof$1$1(o) {
	"@babel/helpers - typeof";
	return _typeof$1$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1$1(o);
}
function _classCallCheck$1(a, n) {
	if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$1(e, r) {
	for (var t = 0; t < r.length; t++) {
		var o = r[t];
		o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey$1$1(o.key), o);
	}
}
function _createClass$1(e, r, t) {
	return r && _defineProperties$1(e.prototype, r), Object.defineProperty(e, "prototype", { writable: false }), e;
}
function _toPropertyKey$1$1(t) {
	var i = _toPrimitive$1$1(t, "string");
	return "symbol" == _typeof$1$1(i) ? i : i + "";
}
function _toPrimitive$1$1(t, r) {
	if ("object" != _typeof$1$1(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$1$1(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return String(t);
}
var ConnectedOverlayScrollHandler = /*#__PURE__*/ function() {
	function ConnectedOverlayScrollHandler(element) {
		var listener = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : function() {};
		_classCallCheck$1(this, ConnectedOverlayScrollHandler);
		this.element = element;
		this.listener = listener;
	}
	return _createClass$1(ConnectedOverlayScrollHandler, [
		{
			key: "bindScrollListener",
			value: function bindScrollListener() {
				this.scrollableParents = At(this.element);
				for (var i = 0; i < this.scrollableParents.length; i++) this.scrollableParents[i].addEventListener("scroll", this.listener);
			}
		},
		{
			key: "unbindScrollListener",
			value: function unbindScrollListener() {
				if (this.scrollableParents) for (var i = 0; i < this.scrollableParents.length; i++) this.scrollableParents[i].removeEventListener("scroll", this.listener);
			}
		},
		{
			key: "destroy",
			value: function destroy() {
				this.unbindScrollListener();
				this.element = null;
				this.listener = null;
				this.scrollableParents = null;
			}
		}
	]);
}();
function _typeof$b(o) {
	"@babel/helpers - typeof";
	return _typeof$b = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$b(o);
}
function _toConsumableArray$9(r) {
	return _arrayWithoutHoles$9(r) || _iterableToArray$9(r) || _unsupportedIterableToArray$a(r) || _nonIterableSpread$9();
}
function _nonIterableSpread$9() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$a(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$a(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$a(r, a) : void 0;
	}
}
function _iterableToArray$9(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$9(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$a(r);
}
function _arrayLikeToArray$a(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _classCallCheck(a, n) {
	if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
	for (var t = 0; t < r.length; t++) {
		var o = r[t];
		o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey$b(o.key), o);
	}
}
function _createClass(e, r, t) {
	return r && _defineProperties(e.prototype, r), Object.defineProperty(e, "prototype", { writable: false }), e;
}
function _defineProperty$b(e, r, t) {
	return (r = _toPropertyKey$b(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$b(t) {
	var i = _toPrimitive$b(t, "string");
	return "symbol" == _typeof$b(i) ? i : i + "";
}
function _toPrimitive$b(t, r) {
	if ("object" != _typeof$b(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$b(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return String(t);
}
var _default = /*#__PURE__*/ function() {
	function _default(_ref) {
		var init = _ref.init, type = _ref.type;
		_classCallCheck(this, _default);
		_defineProperty$b(this, "helpers", void 0);
		_defineProperty$b(this, "type", void 0);
		this.helpers = new Set(init);
		this.type = type;
	}
	return _createClass(_default, [
		{
			key: "add",
			value: function add(instance) {
				this.helpers.add(instance);
			}
		},
		{
			key: "update",
			value: function update() {}
		},
		{
			key: "delete",
			value: function _delete(instance) {
				this.helpers["delete"](instance);
			}
		},
		{
			key: "clear",
			value: function clear() {
				this.helpers.clear();
			}
		},
		{
			key: "get",
			value: function get(parentInstance, slots) {
				var children = this._get(parentInstance, slots);
				var computed = children ? this._recursive(_toConsumableArray$9(this.helpers), children) : null;
				return s$2(computed) ? computed : null;
			}
		},
		{
			key: "_isMatched",
			value: function _isMatched(instance, key) {
				var _parent$vnode;
				var parent = instance === null || instance === void 0 ? void 0 : instance.parent;
				return (parent === null || parent === void 0 || (_parent$vnode = parent.vnode) === null || _parent$vnode === void 0 ? void 0 : _parent$vnode.key) === key || parent && this._isMatched(parent, key) || false;
			}
		},
		{
			key: "_get",
			value: function _get(parentInstance, slots) {
				var _ref2, _ref2$default;
				return ((_ref2 = slots || (parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$slots)) === null || _ref2 === void 0 || (_ref2$default = _ref2["default"]) === null || _ref2$default === void 0 ? void 0 : _ref2$default.call(_ref2)) || null;
			}
		},
		{
			key: "_recursive",
			value: function _recursive() {
				var _this = this;
				var helpers = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
				var children = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
				var components = [];
				children.forEach(function(child) {
					if (child.children instanceof Array) components = components.concat(_this._recursive(helpers, child.children));
					else if (child.type.name === _this.type) components.push(child);
					else if (s$2(child.key)) components = components.concat(helpers.filter(function(c) {
						return _this._isMatched(c, child.key);
					}).map(function(c) {
						return c.vnode;
					}));
				});
				return components;
			}
		}
	]);
}();
function getVNodeProp(vnode, prop) {
	if (vnode) {
		var props = vnode.props;
		if (props) {
			var kebabProp = prop.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
			var propName = Object.prototype.hasOwnProperty.call(props, kebabProp) ? kebabProp : prop;
			return vnode.type["extends"].props[prop].type === Boolean && props[propName] === "" ? true : props[propName];
		}
	}
	return null;
}

//#region node_modules/primevue/focustrap/style/index.mjs
var FocusTrapStyle = BaseStyle.extend({ name: "focustrap-directive" });
//#endregion
//#region node_modules/primevue/focustrap/index.mjs
var BaseFocusTrap = BaseDirective.extend({ style: FocusTrapStyle });
function _typeof$a(o) {
	"@babel/helpers - typeof";
	return _typeof$a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$a(o);
}
function ownKeys$4(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$4(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$4(Object(t), true).forEach(function(r) {
			_defineProperty$a(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$4(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$a(e, r, t) {
	return (r = _toPropertyKey$a(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$a(t) {
	var i = _toPrimitive$a(t, "string");
	return "symbol" == _typeof$a(i) ? i : i + "";
}
function _toPrimitive$a(t, r) {
	if ("object" != _typeof$a(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$a(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var FocusTrap = BaseFocusTrap.extend("focustrap", {
	mounted: function mounted(el, binding) {
		if (!(binding.value || {}).disabled) {
			this.createHiddenFocusableElements(el, binding);
			this.bind(el, binding);
			this.autoElementFocus(el, binding);
		}
		el.setAttribute("data-pd-focustrap", true);
		this.$el = el;
	},
	updated: function updated(el, binding) {
		(binding.value || {}).disabled && this.unbind(el);
	},
	unmounted: function unmounted(el) {
		this.unbind(el);
	},
	methods: {
		getComputedSelector: function getComputedSelector(selector) {
			return ":not(.p-hidden-focusable):not([data-p-hidden-focusable=\"true\"])".concat(selector !== null && selector !== void 0 ? selector : "");
		},
		bind: function bind(el, binding) {
			var _this = this;
			var _ref3 = binding.value || {}, onFocusIn = _ref3.onFocusIn, onFocusOut = _ref3.onFocusOut;
			el.$_pfocustrap_mutationobserver = new MutationObserver(function(mutationList) {
				mutationList.forEach(function(mutation) {
					if (mutation.type === "childList" && !el.contains((void 0).activeElement)) {
						var _findNextFocusableElement = function findNextFocusableElement(_el) {
							var focusableElement = It(_el) ? It(_el, _this.getComputedSelector(el.$_pfocustrap_focusableselector)) ? _el : vt(el, _this.getComputedSelector(el.$_pfocustrap_focusableselector)) : vt(_el);
							return s$2(focusableElement) ? focusableElement : _el.nextSibling && _findNextFocusableElement(_el.nextSibling);
						};
						bt(_findNextFocusableElement(mutation.nextSibling));
					}
				});
			});
			el.$_pfocustrap_mutationobserver.disconnect();
			el.$_pfocustrap_mutationobserver.observe(el, { childList: true });
			el.$_pfocustrap_focusinlistener = function(event) {
				return onFocusIn && onFocusIn(event);
			};
			el.$_pfocustrap_focusoutlistener = function(event) {
				return onFocusOut && onFocusOut(event);
			};
			el.addEventListener("focusin", el.$_pfocustrap_focusinlistener);
			el.addEventListener("focusout", el.$_pfocustrap_focusoutlistener);
		},
		unbind: function unbind(el) {
			el.$_pfocustrap_mutationobserver && el.$_pfocustrap_mutationobserver.disconnect();
			el.$_pfocustrap_focusinlistener && el.removeEventListener("focusin", el.$_pfocustrap_focusinlistener) && (el.$_pfocustrap_focusinlistener = null);
			el.$_pfocustrap_focusoutlistener && el.removeEventListener("focusout", el.$_pfocustrap_focusoutlistener) && (el.$_pfocustrap_focusoutlistener = null);
		},
		autoFocus: function autoFocus(options) {
			this.autoElementFocus(this.$el, { value: _objectSpread$4(_objectSpread$4({}, options), {}, { autoFocus: true }) });
		},
		autoElementFocus: function autoElementFocus(el, binding) {
			var _ref4 = binding.value || {}, _ref4$autoFocusSelect = _ref4.autoFocusSelector, autoFocusSelector = _ref4$autoFocusSelect === void 0 ? "" : _ref4$autoFocusSelect, _ref4$firstFocusableS = _ref4.firstFocusableSelector, firstFocusableSelector = _ref4$firstFocusableS === void 0 ? "" : _ref4$firstFocusableS, _ref4$autoFocus = _ref4.autoFocus, autoFocus = _ref4$autoFocus === void 0 ? false : _ref4$autoFocus;
			var focusableElement = vt(el, "[autofocus]".concat(this.getComputedSelector(autoFocusSelector)));
			autoFocus && !focusableElement && (focusableElement = vt(el, this.getComputedSelector(firstFocusableSelector)));
			bt(focusableElement);
		},
		onFirstHiddenElementFocus: function onFirstHiddenElementFocus(event) {
			var _this$$el;
			var currentTarget = event.currentTarget, relatedTarget = event.relatedTarget;
			var focusableElement = relatedTarget === currentTarget.$_pfocustrap_lasthiddenfocusableelement || !((_this$$el = this.$el) !== null && _this$$el !== void 0 && _this$$el.contains(relatedTarget)) ? vt(currentTarget.parentElement, this.getComputedSelector(currentTarget.$_pfocustrap_focusableselector)) : currentTarget.$_pfocustrap_lasthiddenfocusableelement;
			bt(focusableElement);
		},
		onLastHiddenElementFocus: function onLastHiddenElementFocus(event) {
			var _this$$el2;
			var currentTarget = event.currentTarget, relatedTarget = event.relatedTarget;
			var focusableElement = relatedTarget === currentTarget.$_pfocustrap_firsthiddenfocusableelement || !((_this$$el2 = this.$el) !== null && _this$$el2 !== void 0 && _this$$el2.contains(relatedTarget)) ? Lt(currentTarget.parentElement, this.getComputedSelector(currentTarget.$_pfocustrap_focusableselector)) : currentTarget.$_pfocustrap_firsthiddenfocusableelement;
			bt(focusableElement);
		},
		createHiddenFocusableElements: function createHiddenFocusableElements(el, binding) {
			var _this2 = this;
			var _ref5 = binding.value || {}, _ref5$tabIndex = _ref5.tabIndex, tabIndex = _ref5$tabIndex === void 0 ? 0 : _ref5$tabIndex, _ref5$firstFocusableS = _ref5.firstFocusableSelector, firstFocusableSelector = _ref5$firstFocusableS === void 0 ? "" : _ref5$firstFocusableS, _ref5$lastFocusableSe = _ref5.lastFocusableSelector, lastFocusableSelector = _ref5$lastFocusableSe === void 0 ? "" : _ref5$lastFocusableSe;
			var createFocusableElement = function createFocusableElement(onFocus) {
				return U("span", {
					"class": "p-hidden-accessible p-hidden-focusable",
					tabIndex,
					role: "presentation",
					"aria-hidden": true,
					"data-p-hidden-accessible": true,
					"data-p-hidden-focusable": true,
					onFocus: onFocus === null || onFocus === void 0 ? void 0 : onFocus.bind(_this2)
				});
			};
			var firstFocusableElement = createFocusableElement(this.onFirstHiddenElementFocus);
			var lastFocusableElement = createFocusableElement(this.onLastHiddenElementFocus);
			firstFocusableElement.$_pfocustrap_lasthiddenfocusableelement = lastFocusableElement;
			firstFocusableElement.$_pfocustrap_focusableselector = firstFocusableSelector;
			firstFocusableElement.setAttribute("data-pc-section", "firstfocusableelement");
			lastFocusableElement.$_pfocustrap_firsthiddenfocusableelement = firstFocusableElement;
			lastFocusableElement.$_pfocustrap_focusableselector = lastFocusableSelector;
			lastFocusableElement.setAttribute("data-pc-section", "lastfocusableelement");
			el.prepend(firstFocusableElement);
			el.append(lastFocusableElement);
		}
	}
});

//#region node_modules/primevue/overlayeventbus/index.mjs
var OverlayEventBus = s$1();

//#region node_modules/primevue/portal/index.mjs
var script$c = {
	name: "Portal",
	props: {
		appendTo: {
			type: [String, Object],
			"default": "body"
		},
		disabled: {
			type: Boolean,
			"default": false
		}
	},
	data: function data() {
		return { mounted: false };
	},
	mounted: function mounted() {
		this.mounted = tt();
	},
	computed: { inline: function inline() {
		return this.disabled || this.appendTo === "self";
	} }
};
function render$c(_ctx, _cache, $props, $setup, $data, $options) {
	return $options.inline ? renderSlot(_ctx.$slots, "default", { key: 0 }) : $data.mounted ? (openBlock(), createBlock(Teleport, {
		key: 1,
		to: $props.appendTo
	}, [renderSlot(_ctx.$slots, "default")], 8, ["to"])) : createCommentVNode("", true);
}
script$c.render = render$c;

//#region node_modules/@primevue/icons/times/index.mjs
var script$b = {
	name: "TimesIcon",
	"extends": script$g
};
function _toConsumableArray$8(r) {
	return _arrayWithoutHoles$8(r) || _iterableToArray$8(r) || _unsupportedIterableToArray$9(r) || _nonIterableSpread$8();
}
function _nonIterableSpread$8() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$9(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$9(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$9(r, a) : void 0;
	}
}
function _iterableToArray$8(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$8(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$9(r);
}
function _arrayLikeToArray$9(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$b(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$8(_cache[0] || (_cache[0] = [createElementVNode("path", {
		d: "M8.01186 7.00933L12.27 2.75116C12.341 2.68501 12.398 2.60524 12.4375 2.51661C12.4769 2.42798 12.4982 2.3323 12.4999 2.23529C12.5016 2.13827 12.4838 2.0419 12.4474 1.95194C12.4111 1.86197 12.357 1.78024 12.2884 1.71163C12.2198 1.64302 12.138 1.58893 12.0481 1.55259C11.9581 1.51625 11.8617 1.4984 11.7647 1.50011C11.6677 1.50182 11.572 1.52306 11.4834 1.56255C11.3948 1.60204 11.315 1.65898 11.2488 1.72997L6.99067 5.98814L2.7325 1.72997C2.59553 1.60234 2.41437 1.53286 2.22718 1.53616C2.03999 1.53946 1.8614 1.61529 1.72901 1.74767C1.59663 1.88006 1.5208 2.05865 1.5175 2.24584C1.5142 2.43303 1.58368 2.61419 1.71131 2.75116L5.96948 7.00933L1.71131 11.2675C1.576 11.403 1.5 11.5866 1.5 11.7781C1.5 11.9696 1.576 12.1532 1.71131 12.2887C1.84679 12.424 2.03043 12.5 2.2219 12.5C2.41338 12.5 2.59702 12.424 2.7325 12.2887L6.99067 8.03052L11.2488 12.2887C11.3843 12.424 11.568 12.5 11.7594 12.5C11.9509 12.5 12.1346 12.424 12.27 12.2887C12.4053 12.1532 12.4813 11.9696 12.4813 11.7781C12.4813 11.5866 12.4053 11.403 12.27 11.2675L8.01186 7.00933Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$b.render = render$b;

//#region node_modules/@primevue/icons/chevronup/index.mjs
var script$a = {
	name: "ChevronUpIcon",
	"extends": script$g
};
function _toConsumableArray$7(r) {
	return _arrayWithoutHoles$7(r) || _iterableToArray$7(r) || _unsupportedIterableToArray$8(r) || _nonIterableSpread$7();
}
function _nonIterableSpread$7() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$8(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$8(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$8(r, a) : void 0;
	}
}
function _iterableToArray$7(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$7(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$8(r);
}
function _arrayLikeToArray$8(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$a(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$7(_cache[0] || (_cache[0] = [createElementVNode("path", {
		d: "M12.2097 10.4113C12.1057 10.4118 12.0027 10.3915 11.9067 10.3516C11.8107 10.3118 11.7237 10.2532 11.6506 10.1792L6.93602 5.46461L2.22139 10.1476C2.07272 10.244 1.89599 10.2877 1.71953 10.2717C1.54307 10.2556 1.3771 10.1808 1.24822 10.0593C1.11933 9.93766 1.035 9.77633 1.00874 9.6011C0.982477 9.42587 1.0158 9.2469 1.10338 9.09287L6.37701 3.81923C6.52533 3.6711 6.72639 3.58789 6.93602 3.58789C7.14565 3.58789 7.3467 3.6711 7.49502 3.81923L12.7687 9.09287C12.9168 9.24119 13 9.44225 13 9.65187C13 9.8615 12.9168 10.0626 12.7687 10.2109C12.616 10.3487 12.4151 10.4207 12.2097 10.4113Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$a.render = render$a;

const VueResolver = (_, value) => {
  return isRef(value) ? toValue(value) : value;
};

const headSymbol = "usehead";

// @__NO_SIDE_EFFECTS__
function injectHead() {
  if (hasInjectionContext()) {
    const instance = inject(headSymbol);
    if (instance) {
      return instance;
    }
  }
  throw new Error("useHead() was called without provide context, ensure you call it through the setup() function.");
}
function useHead(input, options = {}) {
  const head = options.head || /* @__PURE__ */ injectHead();
  return head.ssr ? head.push(input || {}, options) : clientUseHead(head, input, options);
}
function clientUseHead(head, input, options = {}) {
  const scope = getCurrentScope();
  if (scope && !scope.active)
    return { patch() {
    }, dispose() {
    }, _poll() {
    } };
  const deactivated = ref(false);
  let entry;
  watchEffect(() => {
    const i = deactivated.value ? {} : walkResolver(input, VueResolver);
    if (entry) {
      entry.patch(i);
    } else {
      entry = head.push(i, options);
    }
  });
  const vm = getCurrentInstance();
  if (vm) {
    onBeforeUnmount(() => {
      entry.dispose();
    });
    onDeactivated(() => {
      deactivated.value = true;
    });
    onActivated(() => {
      deactivated.value = false;
    });
  }
  return entry;
}
function useSeoMeta(input = {}, options = {}) {
  const head = options.head || /* @__PURE__ */ injectHead();
  head.use(FlatMetaPlugin);
  const entry = useHead(normalizeSeoMetaInput(input), options);
  const corePatch = entry.patch;
  entry.patch = (input2) => corePatch(normalizeSeoMetaInput(input2));
  return entry;
}
function normalizeSeoMetaInput(input) {
  if (input._flatMeta)
    return input;
  const meta = {};
  for (const key in input) {
    if (!Object.prototype.hasOwnProperty.call(input, key) || key === "title" || key === "titleTemplate")
      continue;
    meta[key] = input[key];
  }
  return {
    title: input.title,
    titleTemplate: input.titleTemplate,
    _flatMeta: meta
  };
}
function useServerSeoMeta(input, options = {}) {
  return useSeoMeta(input, { ...options, mode: "server" });
}

var style$8="\n    .p-toggleswitch {\n        display: inline-block;\n        width: dt('toggleswitch.width');\n        height: dt('toggleswitch.height');\n    }\n\n    .p-toggleswitch-input {\n        cursor: pointer;\n        appearance: none;\n        position: absolute;\n        top: 0;\n        inset-inline-start: 0;\n        width: 100%;\n        height: 100%;\n        padding: 0;\n        margin: 0;\n        opacity: 0;\n        z-index: 1;\n        outline: 0 none;\n        border-radius: dt('toggleswitch.border.radius');\n    }\n\n    .p-toggleswitch-slider {\n        cursor: pointer;\n        width: 100%;\n        height: 100%;\n        border-width: dt('toggleswitch.border.width');\n        border-style: solid;\n        border-color: dt('toggleswitch.border.color');\n        background: dt('toggleswitch.background');\n        transition:\n            background dt('toggleswitch.transition.duration'),\n            color dt('toggleswitch.transition.duration'),\n            border-color dt('toggleswitch.transition.duration'),\n            outline-color dt('toggleswitch.transition.duration'),\n            box-shadow dt('toggleswitch.transition.duration');\n        border-radius: dt('toggleswitch.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('toggleswitch.shadow');\n    }\n\n    .p-toggleswitch-handle {\n        position: absolute;\n        top: 50%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        background: dt('toggleswitch.handle.background');\n        color: dt('toggleswitch.handle.color');\n        width: dt('toggleswitch.handle.size');\n        height: dt('toggleswitch.handle.size');\n        inset-inline-start: dt('toggleswitch.gap');\n        margin-block-start: calc(-1 * calc(dt('toggleswitch.handle.size') / 2));\n        border-radius: dt('toggleswitch.handle.border.radius');\n        transition:\n            background dt('toggleswitch.transition.duration'),\n            color dt('toggleswitch.transition.duration'),\n            inset-inline-start dt('toggleswitch.slide.duration'),\n            box-shadow dt('toggleswitch.slide.duration');\n    }\n\n    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-slider {\n        background: dt('toggleswitch.checked.background');\n        border-color: dt('toggleswitch.checked.border.color');\n    }\n\n    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.checked.background');\n        color: dt('toggleswitch.handle.checked.color');\n        inset-inline-start: calc(dt('toggleswitch.width') - calc(dt('toggleswitch.handle.size') + dt('toggleswitch.gap')));\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-slider {\n        background: dt('toggleswitch.hover.background');\n        border-color: dt('toggleswitch.hover.border.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.hover.background');\n        color: dt('toggleswitch.handle.hover.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-slider {\n        background: dt('toggleswitch.checked.hover.background');\n        border-color: dt('toggleswitch.checked.hover.border.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.checked.hover.background');\n        color: dt('toggleswitch.handle.checked.hover.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:focus-visible) .p-toggleswitch-slider {\n        box-shadow: dt('toggleswitch.focus.ring.shadow');\n        outline: dt('toggleswitch.focus.ring.width') dt('toggleswitch.focus.ring.style') dt('toggleswitch.focus.ring.color');\n        outline-offset: dt('toggleswitch.focus.ring.offset');\n    }\n\n    .p-toggleswitch.p-invalid > .p-toggleswitch-slider {\n        border-color: dt('toggleswitch.invalid.border.color');\n    }\n\n    .p-toggleswitch.p-disabled {\n        opacity: 1;\n    }\n\n    .p-toggleswitch.p-disabled .p-toggleswitch-slider {\n        background: dt('toggleswitch.disabled.background');\n    }\n\n    .p-toggleswitch.p-disabled .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.disabled.background');\n    }\n";

var style$7="\n    .p-divider-horizontal {\n        display: flex;\n        width: 100%;\n        position: relative;\n        align-items: center;\n        margin: dt('divider.horizontal.margin');\n        padding: dt('divider.horizontal.padding');\n    }\n\n    .p-divider-horizontal:before {\n        position: absolute;\n        display: block;\n        inset-block-start: 50%;\n        inset-inline-start: 0;\n        width: 100%;\n        content: '';\n        border-block-start: 1px solid dt('divider.border.color');\n    }\n\n    .p-divider-horizontal .p-divider-content {\n        padding: dt('divider.horizontal.content.padding');\n    }\n\n    .p-divider-vertical {\n        min-height: 100%;\n        display: flex;\n        position: relative;\n        justify-content: center;\n        margin: dt('divider.vertical.margin');\n        padding: dt('divider.vertical.padding');\n    }\n\n    .p-divider-vertical:before {\n        position: absolute;\n        display: block;\n        inset-block-start: 0;\n        inset-inline-start: 50%;\n        height: 100%;\n        content: '';\n        border-inline-start: 1px solid dt('divider.border.color');\n    }\n\n    .p-divider.p-divider-vertical .p-divider-content {\n        padding: dt('divider.vertical.content.padding');\n    }\n\n    .p-divider-content {\n        z-index: 1;\n        background: dt('divider.content.background');\n        color: dt('divider.content.color');\n    }\n\n    .p-divider-solid.p-divider-horizontal:before {\n        border-block-start-style: solid;\n    }\n\n    .p-divider-solid.p-divider-vertical:before {\n        border-inline-start-style: solid;\n    }\n\n    .p-divider-dashed.p-divider-horizontal:before {\n        border-block-start-style: dashed;\n    }\n\n    .p-divider-dashed.p-divider-vertical:before {\n        border-inline-start-style: dashed;\n    }\n\n    .p-divider-dotted.p-divider-horizontal:before {\n        border-block-start-style: dotted;\n    }\n\n    .p-divider-dotted.p-divider-vertical:before {\n        border-inline-start-style: dotted;\n    }\n\n    .p-divider-left:dir(rtl),\n    .p-divider-right:dir(rtl) {\n        flex-direction: row-reverse;\n    }\n";

var style$6="\n    .p-inputtext {\n        font-family: inherit;\n        font-feature-settings: inherit;\n        font-size: 1rem;\n        color: dt('inputtext.color');\n        background: dt('inputtext.background');\n        padding-block: dt('inputtext.padding.y');\n        padding-inline: dt('inputtext.padding.x');\n        border: 1px solid dt('inputtext.border.color');\n        transition:\n            background dt('inputtext.transition.duration'),\n            color dt('inputtext.transition.duration'),\n            border-color dt('inputtext.transition.duration'),\n            outline-color dt('inputtext.transition.duration'),\n            box-shadow dt('inputtext.transition.duration');\n        appearance: none;\n        border-radius: dt('inputtext.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('inputtext.shadow');\n    }\n\n    .p-inputtext:enabled:hover {\n        border-color: dt('inputtext.hover.border.color');\n    }\n\n    .p-inputtext:enabled:focus {\n        border-color: dt('inputtext.focus.border.color');\n        box-shadow: dt('inputtext.focus.ring.shadow');\n        outline: dt('inputtext.focus.ring.width') dt('inputtext.focus.ring.style') dt('inputtext.focus.ring.color');\n        outline-offset: dt('inputtext.focus.ring.offset');\n    }\n\n    .p-inputtext.p-invalid {\n        border-color: dt('inputtext.invalid.border.color');\n    }\n\n    .p-inputtext.p-variant-filled {\n        background: dt('inputtext.filled.background');\n    }\n\n    .p-inputtext.p-variant-filled:enabled:hover {\n        background: dt('inputtext.filled.hover.background');\n    }\n\n    .p-inputtext.p-variant-filled:enabled:focus {\n        background: dt('inputtext.filled.focus.background');\n    }\n\n    .p-inputtext:disabled {\n        opacity: 1;\n        background: dt('inputtext.disabled.background');\n        color: dt('inputtext.disabled.color');\n    }\n\n    .p-inputtext::placeholder {\n        color: dt('inputtext.placeholder.color');\n    }\n\n    .p-inputtext.p-invalid::placeholder {\n        color: dt('inputtext.invalid.placeholder.color');\n    }\n\n    .p-inputtext-sm {\n        font-size: dt('inputtext.sm.font.size');\n        padding-block: dt('inputtext.sm.padding.y');\n        padding-inline: dt('inputtext.sm.padding.x');\n    }\n\n    .p-inputtext-lg {\n        font-size: dt('inputtext.lg.font.size');\n        padding-block: dt('inputtext.lg.padding.y');\n        padding-inline: dt('inputtext.lg.padding.x');\n    }\n\n    .p-inputtext-fluid {\n        width: 100%;\n    }\n";

var style$5="\n    .p-inputgroup,\n    .p-inputgroup .p-iconfield,\n    .p-inputgroup .p-floatlabel,\n    .p-inputgroup .p-iftalabel {\n        display: flex;\n        align-items: stretch;\n        width: 100%;\n    }\n\n    .p-inputgroup .p-floatlabel .p-inputwrapper,\n    .p-inputgroup .p-iftalabel .p-inputwrapper {\n        display: inline-flex;\n    }\n\n    .p-inputgroup .p-inputtext,\n    .p-inputgroup .p-inputwrapper {\n        flex: 1 1 auto;\n        width: 1%;\n    }\n\n    .p-inputgroupaddon {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        padding: dt('inputgroup.addon.padding');\n        background: dt('inputgroup.addon.background');\n        color: dt('inputgroup.addon.color');\n        border-block-start: 1px solid dt('inputgroup.addon.border.color');\n        border-block-end: 1px solid dt('inputgroup.addon.border.color');\n        min-width: dt('inputgroup.addon.min.width');\n    }\n\n    .p-inputgroupaddon:first-child,\n    .p-inputgroupaddon + .p-inputgroupaddon {\n        border-inline-start: 1px solid dt('inputgroup.addon.border.color');\n    }\n\n    .p-inputgroupaddon:last-child {\n        border-inline-end: 1px solid dt('inputgroup.addon.border.color');\n    }\n\n    .p-inputgroupaddon:has(.p-button) {\n        padding: 0;\n        overflow: hidden;\n    }\n\n    .p-inputgroupaddon .p-button {\n        border-radius: 0;\n    }\n\n    .p-inputgroup > .p-component,\n    .p-inputgroup > .p-inputwrapper > .p-component,\n    .p-inputgroup > .p-iconfield > .p-component,\n    .p-inputgroup > .p-floatlabel > .p-component,\n    .p-inputgroup > .p-floatlabel > .p-inputwrapper > .p-component,\n    .p-inputgroup > .p-iftalabel > .p-component,\n    .p-inputgroup > .p-iftalabel > .p-inputwrapper > .p-component {\n        border-radius: 0;\n        margin: 0;\n    }\n\n    .p-inputgroupaddon:first-child,\n    .p-inputgroup > .p-component:first-child,\n    .p-inputgroup > .p-inputwrapper:first-child > .p-component,\n    .p-inputgroup > .p-iconfield:first-child > .p-component,\n    .p-inputgroup > .p-floatlabel:first-child > .p-component,\n    .p-inputgroup > .p-floatlabel:first-child > .p-inputwrapper > .p-component,\n    .p-inputgroup > .p-iftalabel:first-child > .p-component,\n    .p-inputgroup > .p-iftalabel:first-child > .p-inputwrapper > .p-component {\n        border-start-start-radius: dt('inputgroup.addon.border.radius');\n        border-end-start-radius: dt('inputgroup.addon.border.radius');\n    }\n\n    .p-inputgroupaddon:last-child,\n    .p-inputgroup > .p-component:last-child,\n    .p-inputgroup > .p-inputwrapper:last-child > .p-component,\n    .p-inputgroup > .p-iconfield:last-child > .p-component,\n    .p-inputgroup > .p-floatlabel:last-child > .p-component,\n    .p-inputgroup > .p-floatlabel:last-child > .p-inputwrapper > .p-component,\n    .p-inputgroup > .p-iftalabel:last-child > .p-component,\n    .p-inputgroup > .p-iftalabel:last-child > .p-inputwrapper > .p-component {\n        border-start-end-radius: dt('inputgroup.addon.border.radius');\n        border-end-end-radius: dt('inputgroup.addon.border.radius');\n    }\n\n    .p-inputgroup .p-component:focus,\n    .p-inputgroup .p-component.p-focus,\n    .p-inputgroup .p-inputwrapper-focus,\n    .p-inputgroup .p-component:focus ~ label,\n    .p-inputgroup .p-component.p-focus ~ label,\n    .p-inputgroup .p-inputwrapper-focus ~ label,\n    .p-inputgroup .p-floatlabel .p-inputwrapper ~ label,\n    .p-inputgroup .p-iftalabel .p-inputwrapper ~ label {\n        z-index: 1;\n    }\n\n    .p-inputgroup > .p-button:not(.p-button-icon-only) {\n        width: auto;\n    }\n\n    .p-inputgroup .p-iconfield + .p-iconfield .p-inputtext {\n        border-inline-start: 0;\n    }\n";

function g(){let r=[],i=(e,n,t=999)=>{let s=u(e,n,t),o=s.value+(s.key===e?0:t)+1;return r.push({key:e,value:o}),o},d=e=>{r=r.filter(n=>n.value!==e);},a=(e,n)=>u(e).value,u=(e,n,t=0)=>[...r].reverse().find(s=>true)||{key:e,value:t},l=e=>e&&parseInt(e.style.zIndex,10)||0;return {get:l,set:(e,n,t)=>{n&&(n.style.zIndex=String(i(e,true,t)));},clear:e=>{e&&(d(l(e)),e.style.zIndex="");},getCurrent:e=>a(e)}}var x=g();

var style$4="\n    .p-popover {\n        margin-block-start: dt('popover.gutter');\n        background: dt('popover.background');\n        color: dt('popover.color');\n        border: 1px solid dt('popover.border.color');\n        border-radius: dt('popover.border.radius');\n        box-shadow: dt('popover.shadow');\n        will-change: transform;\n    }\n\n    .p-popover-content {\n        padding: dt('popover.content.padding');\n    }\n\n    .p-popover-flipped {\n        margin-block-start: calc(dt('popover.gutter') * -1);\n        margin-block-end: dt('popover.gutter');\n    }\n\n    .p-popover:after,\n    .p-popover:before {\n        bottom: 100%;\n        left: calc(dt('popover.arrow.offset') + dt('popover.arrow.left'));\n        content: ' ';\n        height: 0;\n        width: 0;\n        position: absolute;\n        pointer-events: none;\n    }\n\n    .p-popover:after {\n        border-width: calc(dt('popover.gutter') - 2px);\n        margin-left: calc(-1 * (dt('popover.gutter') - 2px));\n        border-style: solid;\n        border-color: transparent;\n        border-bottom-color: dt('popover.background');\n    }\n\n    .p-popover:before {\n        border-width: dt('popover.gutter');\n        margin-left: calc(-1 * dt('popover.gutter'));\n        border-style: solid;\n        border-color: transparent;\n        border-bottom-color: dt('popover.border.color');\n    }\n\n    .p-popover-flipped:after,\n    .p-popover-flipped:before {\n        bottom: auto;\n        top: 100%;\n    }\n\n    .p-popover.p-popover-flipped:after {\n        border-bottom-color: transparent;\n        border-top-color: dt('popover.background');\n    }\n\n    .p-popover.p-popover-flipped:before {\n        border-bottom-color: transparent;\n        border-top-color: dt('popover.border.color');\n    }\n";

var style$3="\n    .p-avatar {\n        display: inline-flex;\n        align-items: center;\n        justify-content: center;\n        width: dt('avatar.width');\n        height: dt('avatar.height');\n        font-size: dt('avatar.font.size');\n        background: dt('avatar.background');\n        color: dt('avatar.color');\n        border-radius: dt('avatar.border.radius');\n    }\n\n    .p-avatar-image {\n        background: transparent;\n    }\n\n    .p-avatar-circle {\n        border-radius: 50%;\n    }\n\n    .p-avatar-circle img {\n        border-radius: 50%;\n    }\n\n    .p-avatar-icon {\n        font-size: dt('avatar.icon.size');\n        width: dt('avatar.icon.size');\n        height: dt('avatar.icon.size');\n    }\n\n    .p-avatar img {\n        width: 100%;\n        height: 100%;\n    }\n\n    .p-avatar-lg {\n        width: dt('avatar.lg.width');\n        height: dt('avatar.lg.width');\n        font-size: dt('avatar.lg.font.size');\n    }\n\n    .p-avatar-lg .p-avatar-icon {\n        font-size: dt('avatar.lg.icon.size');\n        width: dt('avatar.lg.icon.size');\n        height: dt('avatar.lg.icon.size');\n    }\n\n    .p-avatar-xl {\n        width: dt('avatar.xl.width');\n        height: dt('avatar.xl.width');\n        font-size: dt('avatar.xl.font.size');\n    }\n\n    .p-avatar-xl .p-avatar-icon {\n        font-size: dt('avatar.xl.icon.size');\n        width: dt('avatar.xl.icon.size');\n        height: dt('avatar.xl.icon.size');\n    }\n\n    .p-avatar-group {\n        display: flex;\n        align-items: center;\n    }\n\n    .p-avatar-group .p-avatar + .p-avatar {\n        margin-inline-start: dt('avatar.group.offset');\n    }\n\n    .p-avatar-group .p-avatar {\n        border: 2px solid dt('avatar.group.border.color');\n    }\n\n    .p-avatar-group .p-avatar-lg + .p-avatar-lg {\n        margin-inline-start: dt('avatar.lg.group.offset');\n    }\n\n    .p-avatar-group .p-avatar-xl + .p-avatar-xl {\n        margin-inline-start: dt('avatar.xl.group.offset');\n    }\n";

var style$2="\n    .p-dialog {\n        max-height: 90%;\n        transform: scale(1);\n        border-radius: dt('dialog.border.radius');\n        box-shadow: dt('dialog.shadow');\n        background: dt('dialog.background');\n        border: 1px solid dt('dialog.border.color');\n        color: dt('dialog.color');\n        will-change: transform;\n    }\n\n    .p-dialog-content {\n        overflow-y: auto;\n        padding: dt('dialog.content.padding');\n        flex-grow: 1;\n    }\n\n    .p-dialog-header {\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n        flex-shrink: 0;\n        padding: dt('dialog.header.padding');\n    }\n\n    .p-dialog-title {\n        font-weight: dt('dialog.title.font.weight');\n        font-size: dt('dialog.title.font.size');\n    }\n\n    .p-dialog-footer {\n        flex-shrink: 0;\n        padding: dt('dialog.footer.padding');\n        display: flex;\n        justify-content: flex-end;\n        gap: dt('dialog.footer.gap');\n    }\n\n    .p-dialog-header-actions {\n        display: flex;\n        align-items: center;\n        gap: dt('dialog.header.gap');\n    }\n\n    .p-dialog-top .p-dialog,\n    .p-dialog-bottom .p-dialog,\n    .p-dialog-left .p-dialog,\n    .p-dialog-right .p-dialog,\n    .p-dialog-topleft .p-dialog,\n    .p-dialog-topright .p-dialog,\n    .p-dialog-bottomleft .p-dialog,\n    .p-dialog-bottomright .p-dialog {\n        margin: 1rem;\n    }\n\n    .p-dialog-maximized {\n        width: 100vw !important;\n        height: 100vh !important;\n        top: 0px !important;\n        left: 0px !important;\n        max-height: 100%;\n        height: 100%;\n        border-radius: 0;\n    }\n\n    .p-dialog .p-resizable-handle {\n        position: absolute;\n        font-size: 0.1px;\n        display: block;\n        cursor: se-resize;\n        width: 12px;\n        height: 12px;\n        right: 1px;\n        bottom: 1px;\n    }\n\n    .p-dialog-enter-active {\n        animation: p-animate-dialog-enter 300ms cubic-bezier(.19,1,.22,1);\n    }\n\n    .p-dialog-leave-active {\n        animation: p-animate-dialog-leave 300ms cubic-bezier(.19,1,.22,1);\n    }\n\n    @keyframes p-animate-dialog-enter {\n        from {\n            opacity: 0;\n            transform: scale(0.93);\n        }\n    }\n\n    @keyframes p-animate-dialog-leave {\n        to {\n            opacity: 0;\n            transform: scale(0.93);\n        }\n    }\n";

var style$1="\n    .p-scrolltop.p-button {\n        position: fixed !important;\n        inset-block-end: 20px;\n        inset-inline-end: 20px;\n    }\n\n    .p-scrolltop-sticky.p-button {\n        position: sticky !important;\n        display: flex;\n        margin-inline-start: auto;\n    }\n\n    .p-scrolltop-enter-from {\n        opacity: 0;\n    }\n\n    .p-scrolltop-enter-active {\n        transition: opacity 300ms;\n    }\n\n    .p-scrolltop-leave-to {\n        opacity: 0;\n    }\n\n    .p-scrolltop-leave-active {\n        transition: opacity 300ms;\n    }\n";

var style="\n    .p-toast {\n        width: dt('toast.width');\n        white-space: pre-line;\n        word-break: break-word;\n    }\n\n    .p-toast-message {\n        margin: 0 0 1rem 0;\n        display: grid;\n        grid-template-rows: 1fr;\n    }\n\n    .p-toast-message-icon {\n        flex-shrink: 0;\n        font-size: dt('toast.icon.size');\n        width: dt('toast.icon.size');\n        height: dt('toast.icon.size');\n    }\n\n    .p-toast-message-content {\n        display: flex;\n        align-items: flex-start;\n        padding: dt('toast.content.padding');\n        gap: dt('toast.content.gap');\n        min-height: 0;\n        overflow: hidden;\n        transition: padding 250ms ease-in;\n    }\n\n    .p-toast-message-text {\n        flex: 1 1 auto;\n        display: flex;\n        flex-direction: column;\n        gap: dt('toast.text.gap');\n    }\n\n    .p-toast-summary {\n        font-weight: dt('toast.summary.font.weight');\n        font-size: dt('toast.summary.font.size');\n    }\n\n    .p-toast-detail {\n        font-weight: dt('toast.detail.font.weight');\n        font-size: dt('toast.detail.font.size');\n    }\n\n    .p-toast-close-button {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        overflow: hidden;\n        position: relative;\n        cursor: pointer;\n        background: transparent;\n        transition:\n            background dt('toast.transition.duration'),\n            color dt('toast.transition.duration'),\n            outline-color dt('toast.transition.duration'),\n            box-shadow dt('toast.transition.duration');\n        outline-color: transparent;\n        color: inherit;\n        width: dt('toast.close.button.width');\n        height: dt('toast.close.button.height');\n        border-radius: dt('toast.close.button.border.radius');\n        margin: -25% 0 0 0;\n        right: -25%;\n        padding: 0;\n        border: none;\n        user-select: none;\n    }\n\n    .p-toast-close-button:dir(rtl) {\n        margin: -25% 0 0 auto;\n        left: -25%;\n        right: auto;\n    }\n\n    .p-toast-message-info,\n    .p-toast-message-success,\n    .p-toast-message-warn,\n    .p-toast-message-error,\n    .p-toast-message-secondary,\n    .p-toast-message-contrast {\n        border-width: dt('toast.border.width');\n        border-style: solid;\n        backdrop-filter: blur(dt('toast.blur'));\n        border-radius: dt('toast.border.radius');\n    }\n\n    .p-toast-close-icon {\n        font-size: dt('toast.close.icon.size');\n        width: dt('toast.close.icon.size');\n        height: dt('toast.close.icon.size');\n    }\n\n    .p-toast-close-button:focus-visible {\n        outline-width: dt('focus.ring.width');\n        outline-style: dt('focus.ring.style');\n        outline-offset: dt('focus.ring.offset');\n    }\n\n    .p-toast-message-info {\n        background: dt('toast.info.background');\n        border-color: dt('toast.info.border.color');\n        color: dt('toast.info.color');\n        box-shadow: dt('toast.info.shadow');\n    }\n\n    .p-toast-message-info .p-toast-detail {\n        color: dt('toast.info.detail.color');\n    }\n\n    .p-toast-message-info .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.info.close.button.focus.ring.color');\n        box-shadow: dt('toast.info.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-info .p-toast-close-button:hover {\n        background: dt('toast.info.close.button.hover.background');\n    }\n\n    .p-toast-message-success {\n        background: dt('toast.success.background');\n        border-color: dt('toast.success.border.color');\n        color: dt('toast.success.color');\n        box-shadow: dt('toast.success.shadow');\n    }\n\n    .p-toast-message-success .p-toast-detail {\n        color: dt('toast.success.detail.color');\n    }\n\n    .p-toast-message-success .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.success.close.button.focus.ring.color');\n        box-shadow: dt('toast.success.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-success .p-toast-close-button:hover {\n        background: dt('toast.success.close.button.hover.background');\n    }\n\n    .p-toast-message-warn {\n        background: dt('toast.warn.background');\n        border-color: dt('toast.warn.border.color');\n        color: dt('toast.warn.color');\n        box-shadow: dt('toast.warn.shadow');\n    }\n\n    .p-toast-message-warn .p-toast-detail {\n        color: dt('toast.warn.detail.color');\n    }\n\n    .p-toast-message-warn .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.warn.close.button.focus.ring.color');\n        box-shadow: dt('toast.warn.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-warn .p-toast-close-button:hover {\n        background: dt('toast.warn.close.button.hover.background');\n    }\n\n    .p-toast-message-error {\n        background: dt('toast.error.background');\n        border-color: dt('toast.error.border.color');\n        color: dt('toast.error.color');\n        box-shadow: dt('toast.error.shadow');\n    }\n\n    .p-toast-message-error .p-toast-detail {\n        color: dt('toast.error.detail.color');\n    }\n\n    .p-toast-message-error .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.error.close.button.focus.ring.color');\n        box-shadow: dt('toast.error.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-error .p-toast-close-button:hover {\n        background: dt('toast.error.close.button.hover.background');\n    }\n\n    .p-toast-message-secondary {\n        background: dt('toast.secondary.background');\n        border-color: dt('toast.secondary.border.color');\n        color: dt('toast.secondary.color');\n        box-shadow: dt('toast.secondary.shadow');\n    }\n\n    .p-toast-message-secondary .p-toast-detail {\n        color: dt('toast.secondary.detail.color');\n    }\n\n    .p-toast-message-secondary .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.secondary.close.button.focus.ring.color');\n        box-shadow: dt('toast.secondary.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-secondary .p-toast-close-button:hover {\n        background: dt('toast.secondary.close.button.hover.background');\n    }\n\n    .p-toast-message-contrast {\n        background: dt('toast.contrast.background');\n        border-color: dt('toast.contrast.border.color');\n        color: dt('toast.contrast.color');\n        box-shadow: dt('toast.contrast.shadow');\n    }\n    \n    .p-toast-message-contrast .p-toast-detail {\n        color: dt('toast.contrast.detail.color');\n    }\n\n    .p-toast-message-contrast .p-toast-close-button:focus-visible {\n        outline-color: dt('toast.contrast.close.button.focus.ring.color');\n        box-shadow: dt('toast.contrast.close.button.focus.ring.shadow');\n    }\n\n    .p-toast-message-contrast .p-toast-close-button:hover {\n        background: dt('toast.contrast.close.button.hover.background');\n    }\n\n    .p-toast-top-center {\n        transform: translateX(-50%);\n    }\n\n    .p-toast-bottom-center {\n        transform: translateX(-50%);\n    }\n\n    .p-toast-center {\n        min-width: 20vw;\n        transform: translate(-50%, -50%);\n    }\n\n    .p-toast-message-enter-active {\n        animation: p-animate-toast-enter 300ms ease-out;\n    }\n\n    .p-toast-message-leave-active {\n        animation: p-animate-toast-leave 250ms ease-in;\n    }\n\n    .p-toast-message-leave-to .p-toast-message-content {\n        padding-top: 0;\n        padding-bottom: 0;\n    }\n\n    @keyframes p-animate-toast-enter {\n        from {\n            opacity: 0;\n            transform: scale(0.6);\n        }\n        to {\n            opacity: 1;\n            grid-template-rows: 1fr;\n        }\n    }\n\n     @keyframes p-animate-toast-leave {\n        from {\n            opacity: 1;\n        }\n        to {\n            opacity: 0;\n            margin-bottom: 0;\n            grid-template-rows: 0fr;\n            transform: translateY(-100%) scale(0.6);\n        }\n    }\n";

//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fglobal-polyfills.mjs
if (!("global" in globalThis)) globalThis.global = globalThis;
//#endregion
//#region node_modules/@pinia/nuxt/dist/runtime/payload-plugin.js
var payloadPlugin = definePayloadPlugin(() => {
	definePayloadReducer("skipHydrate", (data) => !shouldHydrate(data) && 1);
});
//#endregion
//#region node_modules/site-config-stack/dist/index.mjs
var SiteConfigPriority = {
	i18n: -2};
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/plugins/0.siteConfig.js
var _0_siteConfig_default = defineNuxtPlugin({
	name: "nuxt-site-config:init",
	enforce: "pre",
	async setup(nuxtApp) {
		const stack = useRequestEvent()?.context?.siteConfig;
		const state = useState("site-config");
		nuxtApp.hooks.hook("app:rendered", () => {
			state.value = stack?.get({
				debug: useRuntimeConfig()["nuxt-site-config"].debug,
				resolveRefs: true
			});
		});
		return { provide: { nuxtSiteConfig: stack } };
	}
});
//#endregion
//#region node_modules/nuxt/dist/head/runtime/island-head.js
/**
* No-op `head.push` until the returned `unfreeze` runs. Plugin/transformer
* augmentations on the same head are unaffected.
*/
function freezeHead(head) {
	const realPush = head.push;
	head.push = () => ({
		dispose: () => {},
		patch: () => {},
		_i: 0
	});
	return () => {
		head.push = realPush;
	};
}
//#endregion
//#region node_modules/nuxt/dist/head/runtime/plugins/unhead.server.js
var plugin$3 = defineNuxtPlugin({
	name: "nuxt:head",
	enforce: "pre",
	setup(nuxtApp) {
		const head = nuxtApp.ssrContext.head;
		if (nuxtApp.ssrContext.islandContext) {
			const unfreeze = freezeHead(head);
			nuxtApp.hooks.hookOnce("app:created", unfreeze);
		}
		nuxtApp.vueApp.use(head);
	}
});
//#endregion
//#region node_modules/nuxt/dist/pages/runtime/utils.js
var ROUTE_KEY_PARENTHESES_RE = /(:\w+)\([^)]+\)/g;
var ROUTE_KEY_SYMBOLS_RE = /(:\w+)[?+*]/g;
var ROUTE_KEY_NORMAL_RE = /:\w+/g;
var interpolatePath = (route, match) => {
	return match.path.replace(ROUTE_KEY_PARENTHESES_RE, "$1").replace(ROUTE_KEY_SYMBOLS_RE, "$1").replace(ROUTE_KEY_NORMAL_RE, (r) => route.params[r.slice(1)]?.toString() || "");
};
var generateRouteKey = (routeProps, override) => {
	const matchedRoute = routeProps.route.matched.find((m) => m.components?.default === routeProps.Component.type);
	const source = matchedRoute?.meta.key ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
	return typeof source === "function" ? source(routeProps.route) : source;
};
/** @since 3.9.0 */
function toArray(value) {
	return Array.isArray(value) ? value : [value];
}
Object.assign(Object.create(null), {});
var pageIslandRoutes = Object.assign(Object.create(null), {});
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fmiddleware.mjs
var globalMiddleware = [defineNuxtRouteMiddleware(async (to) => {
	let __temp, __restore;
	if (!to.meta?.validate) return;
	const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
	if (result === true) return;
	return createError$1({
		fatal: false,
		status: result && (result.status || result.statusCode) || 404,
		statusText: result && (result.statusText || result.statusMessage) || `Page Not Found: ${to.fullPath}`,
		data: { path: to.fullPath }
	});
}), /* @__PURE__ */ defineNuxtRouteMiddleware((to) => {})];
var namedMiddleware = {};
//#endregion
//#region node_modules/nuxt/dist/pages/runtime/component-stub.js
var component_stub_default = {};
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Froutes.mjs
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froutes_default = [
	{
		name: "recipient___en",
		path: "/recipient",
		component: () => import('../build/recipient-B8dGlJr8.mjs')
	},
	{
		name: "recipient___zh",
		path: "/zh/recipient",
		component: () => import('../build/recipient-B8dGlJr8.mjs')
	},
	{
		name: "sender___en",
		path: "/sender",
		component: () => import('../build/sender-DkstukO1.mjs')
	},
	{
		name: "sender___zh",
		path: "/zh/sender",
		component: () => import('../build/sender-DkstukO1.mjs')
	},
	{
		name: "index___en",
		path: "/",
		component: () => import('../build/pages-DEzGHykJ.mjs')
	},
	{
		name: "index___zh",
		path: "/zh",
		component: () => import('../build/pages-DEzGHykJ.mjs')
	},
	{
		name: void 0,
		path: "/sitemap.xml",
		component: component_stub_default
	},
	{
		name: void 0,
		path: "/zh/sitemap.xml",
		component: component_stub_default
	}
];
//#endregion
//#region node_modules/nuxt/dist/pages/runtime/plugins/router.js
var plugin$2 = defineNuxtPlugin({
	name: "nuxt:router",
	enforce: "pre",
	async setup(nuxtApp) {
		let __temp, __restore;
		let routerBase = useRuntimeConfig().app.baseURL;
		const history = virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.history?.(routerBase) ?? createMemoryHistory(routerBase);
		const routes = virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.routes ? ([__temp, __restore] = executeAsync(() => virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.routes(virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froutes_default)), __temp = await __temp, __restore(), __temp) ?? virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froutes_default : virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Froutes_default;
		let startPosition;
		const router = createRouter({
			...virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default,
			scrollBehavior: (to, from, savedPosition) => {
				if (from === START_LOCATION) {
					startPosition = savedPosition;
					return;
				}
				if (virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.scrollBehavior) {
					router.options.scrollBehavior = virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.scrollBehavior;
					if ("scrollRestoration" in (void 0).history) {
						const unsub = router.beforeEach(() => {
							unsub();
							(void 0).history.scrollRestoration = "manual";
						});
					}
					return virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.scrollBehavior(to, START_LOCATION, startPosition || savedPosition);
				}
			},
			history,
			routes
		});
		nuxtApp.vueApp.use(router);
		const previousRoute = shallowRef(router.currentRoute.value);
		router.afterEach((_to, from) => {
			previousRoute.value = from;
		});
		Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", { get: () => previousRoute.value });
		const initialURL = nuxtApp.ssrContext.url;
		const _route = shallowRef(router.currentRoute.value);
		const syncCurrentRoute = () => {
			_route.value = router.currentRoute.value;
		};
		router.afterEach((to, from) => {
			const lastTo = to.matched.at(-1)?.components?.default;
			const lastFrom = from.matched.at(-1)?.components?.default;
			if (lastTo === lastFrom) {
				if (generateRouteKey({
					route: to,
					Component: { type: lastTo }
				}) === generateRouteKey({
					route: from,
					Component: { type: lastFrom }
				})) syncCurrentRoute();
				return;
			}
			if (to.matched.length < from.matched.length && to.matched.every((m, i) => m.components?.default === from.matched[i]?.components?.default)) syncCurrentRoute();
		});
		const route = { sync: syncCurrentRoute };
		for (const key in _route.value) Object.defineProperty(route, key, {
			get: () => _route.value[key],
			enumerable: true
		});
		nuxtApp._route = shallowReactive(route);
		nuxtApp._middleware ||= {
			global: [],
			named: {}
		};
		const error = useError();
		const isServerPage = nuxtApp.ssrContext?.islandContext?.name?.startsWith("page_");
		if (!nuxtApp.ssrContext?.islandContext || isServerPage) router.afterEach(async (to, _from, failure) => {
			delete nuxtApp._processingMiddleware;
			delete nuxtApp._middlewareTo;
			if (failure) await nuxtApp.callHook("page:loading:end");
			if (failure?.type === 4) return;
			if (to.redirectedFrom && to.fullPath !== initialURL) await nuxtApp.runWithContext(() => navigateTo(to.fullPath || "/"));
		});
		try {
			[__temp, __restore] = executeAsync(() => router.push(initialURL)), __temp = await __temp, __restore();
			[__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
		} catch (error) {
			[__temp, __restore] = executeAsync(() => _showErrorUnlessCrawler(nuxtApp, error)), await __temp, __restore();
		}
		const resolvedInitialRoute = router.currentRoute.value;
		syncCurrentRoute();
		if (nuxtApp.ssrContext?.islandContext && !isServerPage) return { provide: { router } };
		const initialLayout = nuxtApp.payload.state._layout;
		router.beforeEach(async (to, from) => {
			await nuxtApp.callHook("page:loading:start");
			to.meta = reactive(to.meta);
			if (nuxtApp.isHydrating && initialLayout && !isReadonly(to.meta.layout)) to.meta.layout = initialLayout;
			nuxtApp._processingMiddleware = true;
			nuxtApp._middlewareTo = to;
			if (!nuxtApp.ssrContext?.islandContext || isServerPage) {
				const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
				for (const component of to.matched) {
					const componentMiddleware = component.meta.middleware;
					if (!componentMiddleware) continue;
					for (const entry of toArray(componentMiddleware)) middlewareEntries.add(entry);
				}
				const routeRules = getRouteRules({ path: to.path });
				if (routeRules.appMiddleware) for (const key in routeRules.appMiddleware) if (routeRules.appMiddleware[key]) middlewareEntries.add(key);
				else middlewareEntries.delete(key);
				for (const entry of middlewareEntries) {
					const middleware = typeof entry === "string" ? nuxtApp._middleware.named[entry] || await namedMiddleware[entry]?.().then((r) => r.default || r) : entry;
					if (!middleware) throw navigationDiagnostics.NUXT_E2004({
						entry: String(entry),
						validMiddleware: void 0
					});
					try {
						const result = await nuxtApp.runWithContext(() => middleware(to, from));
						if (result === false || result instanceof Error) {
							const error = result || createError$1({
								status: 404,
								statusText: `Page Not Found: ${initialURL}`
							});
							await nuxtApp.runWithContext(() => showError(error));
							return false;
						}
						if (result === true) continue;
						if (result === false) return result;
						if (result) {
							if (isNuxtError(result) && result.fatal) await nuxtApp.runWithContext(() => showError(result));
							return result;
						}
					} catch (err) {
						const error = createError$1(err);
						if (error.fatal) await nuxtApp.runWithContext(() => showError(error));
						return error;
					}
				}
			}
		});
		if (isServerPage) router.beforeResolve((to) => {
			const expected = pageIslandRoutes[nuxtApp.ssrContext.islandContext.name];
			const actual = to.matched.find((m) => (m.components?.default)?.__nuxt_island)?.components?.default;
			if (!expected || expected !== actual?.__nuxt_island) {
				nuxtApp.ssrContext["~renderResponse"] = {
					statusCode: 400,
					statusMessage: "Invalid island request path"
				};
				return false;
			}
		});
		router.onError(async () => {
			delete nuxtApp._processingMiddleware;
			delete nuxtApp._middlewareTo;
			await nuxtApp.callHook("page:loading:end");
		});
		router.afterEach((to) => {
			if (to.matched.length === 0 && !error.value) return nuxtApp.runWithContext(() => showError(createError$1({
				status: 404,
				fatal: false,
				statusText: `Page not found: ${to.fullPath}`,
				data: { path: to.fullPath }
			})));
		});
		nuxtApp.hooks.hookOnce("app:created", async () => {
			try {
				if ("name" in resolvedInitialRoute) resolvedInitialRoute.name = void 0;
				await router.replace({
					...resolvedInitialRoute,
					force: true
				});
				router.options.scrollBehavior = virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Frouter_options_default.scrollBehavior;
			} catch (error) {
				await _showErrorUnlessCrawler(nuxtApp, error);
			}
		});
		return { provide: { router } };
	}
});
//#endregion
//#region node_modules/nuxt/dist/app/plugins/revive-payload.server.js
var reducers = [
	["NuxtError", (data) => isNuxtError(data) && data.toJSON()],
	["EmptyShallowRef", (data) => isRef(data) && isShallow(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_")],
	["EmptyRef", (data) => isRef(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_")],
	["ShallowRef", (data) => isRef(data) && isShallow(data) && data.value],
	["ShallowReactive", (data) => isReactive(data) && isShallow(data) && toRaw(data)],
	["Ref", (data) => isRef(data) && data.value],
	["Reactive", (data) => isReactive(data) && toRaw(data)]
];
var plugin$1 = /* @__PURE__ */ defineNuxtPlugin({
	name: "nuxt:revive-payload:server",
	setup() {
		for (const [reducer, fn] of reducers) definePayloadReducer(reducer, fn);
	}
});
//#endregion
//#region node_modules/@pinia/nuxt/dist/runtime/plugin.vue3.js
var plugin = defineNuxtPlugin({
	name: "pinia",
	setup(nuxtApp) {
		const pinia = createPinia();
		nuxtApp.vueApp.use(pinia);
		setActivePinia(pinia);
		if (nuxtApp.payload && nuxtApp.payload.pinia) pinia.state.value = nuxtApp.payload.pinia;
		return { provide: { pinia } };
	},
	hooks: { "app:rendered"() {
		const nuxtApp = useNuxtApp();
		nuxtApp.payload.pinia = toRaw(nuxtApp.$pinia).state.value;
		setActivePinia(void 0);
	} }
});
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/composables/useSiteConfig.js
function useSiteConfig(options) {
	const stack = useRequestEvent()?.context.siteConfig.get(defu({ resolveRefs: true }, options));
	delete stack._priority;
	return stack;
}
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/siteConfig.js
var siteConfig_default = defineNuxtPlugin(() => {
	const head = injectHead$1();
	if (!head) return;
	const { tagPriority } = useRuntimeConfig().public["seo-utils"];
	const siteConfig = useSiteConfig();
	const input = {
		meta: [],
		templateParams: {
			site: siteConfig,
			siteUrl: siteConfig.url,
			siteName: siteConfig.name
		}
	};
	if (siteConfig.separator) input.templateParams.separator = siteConfig.separator;
	if (siteConfig.titleSeparator) input.templateParams.titleSeparator = siteConfig.titleSeparator;
	if (siteConfig.description) {
		input.templateParams.siteDescription = siteConfig.description;
		input.meta.push({
			name: "description",
			content: "%site.description",
			tagPriority
		});
	}
	head.push(input);
});
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/inferSeoMetaPlugin.js
var inferSeoMetaPlugin_default = defineNuxtPlugin(() => {
	const head = injectHead$1();
	if (!head) return;
	head.use(TemplateParamsPlugin);
	head.use(InferSeoMetaPlugin());
});
//#endregion
//#region node_modules/@nuxtjs/robots/dist/runtime/app/plugins/robot-meta.server.js
var robot_meta_server_default = defineNuxtPlugin({ setup() {
	const event = useRequestEvent();
	const ctx = event?.context?.robots;
	event?.context?.robotsProduction;
	if (!ctx) return;
	useHead$1({ meta: [{
		"name": "robots",
		"content": () => ctx.rule || "",
		"data-hint": () => void 0,
		"data-production-content": () => void 0
	}] });
} });
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fnuxt-site-config%2Fi18n-plugin-deps.mjs
var i18nPluginDeps = [
	"i18n:plugin",
	"i18n:plugin:ssg-detect",
	"i18n:plugin:route-locale-detect"
];
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/plugins/i18n-shared.js
function getSiteConfigStack() {
	return useRequestEvent()?.context.siteConfig;
}
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/plugins/i18n.js
function resolveDefaultLocale(i18n) {
	const locale = toValue(i18n.locales).find((l) => l.code === i18n.defaultLocale);
	return locale?.language || locale?.iso || i18n.defaultLocale;
}
function resolveI18nUrl(i18n) {
	return toValue(i18n.baseUrl) || void 0;
}
function resolveCurrentLocale(i18n) {
	const properties = toValue(i18n.localeProperties);
	if (properties.language) return properties.language;
	return resolveDefaultLocale(i18n);
}
function resolveDescription(i18n) {
	return i18n.te("nuxtSiteConfig.description") ? i18n.t("nuxtSiteConfig.description") : void 0;
}
function resolveName(i18n) {
	return i18n.te("nuxtSiteConfig.name") ? i18n.t("nuxtSiteConfig.name") : void 0;
}
var i18n_default$1 = defineNuxtPlugin({
	name: "nuxt-site-config:i18n",
	dependsOn: i18nPluginDeps,
	setup(nuxtApp) {
		const i18n = nuxtApp.$i18n;
		if (!i18n) return;
		const stack = getSiteConfigStack();
		const i18nBaseUrl = toValue(i18n.baseUrl);
		if (i18nBaseUrl) {
			const siteConfig = stack.get({ resolveRefs: true });
			const currentUrl = siteConfig.url;
			if (currentUrl && !currentUrl.includes("localhost")) {
				const i18nURL = parseURL$1(i18nBaseUrl, "https://");
				const siteConfigURL = parseURL$1(currentUrl, "https://");
				if (i18nURL.host !== siteConfigURL.host) {
					if (siteConfig.env === "production") console.error(`[Nuxt Site Config] Your I18n baseUrl \`${i18nURL.host}\` doesn't match your site url ${siteConfigURL.host}. This will cause production SEO issues. Either provide a matching baseUrl or remove the site url config.`);
				}
			}
		}
		stack.push({
			_priority: SiteConfigPriority.i18n,
			_context: "@nuxtjs/i18n",
			url: () => resolveI18nUrl(i18n),
			defaultLocale: () => resolveDefaultLocale(i18n),
			currentLocale: () => resolveCurrentLocale(i18n),
			description: () => resolveDescription(i18n),
			name: () => resolveName(i18n)
		});
	}
});
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/composables/useFallbackTitle.js
function useFallbackTitle() {
	const route = useRoute$1();
	const err = useError();
	let i18n;
	try {
		i18n = useI18n();
	} catch {}
	return computed(() => {
		if (err.value?.statusCode && [404, 500].includes(err.value.statusCode)) return `${err.value.statusCode} - ${err.value.message}`;
		if (typeof route.meta?.title === "string") return route.meta?.title;
		const lastSegment = withoutTrailingSlash$1(route.path || "/").split("/").pop();
		let fallback = lastSegment ? titleCase(lastSegment) : null;
		const matched = route.matched?.at(-1);
		if (matched) {
			const routeName = String(matched.name).split("___")?.[0];
			if (routeName && i18n) fallback = i18n.t(`pages.${routeName}.title`, fallback || "", { missingWarn: false }) || fallback;
		}
		return fallback;
	});
}
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/titlesWaitI18n.js
var titlesWaitI18n_default = defineNuxtPlugin({
	name: "nuxt-seo:fallback-titles",
	env: { islands: false },
	dependsOn: ["nuxt-site-config:i18n"],
	setup() {
		const title = useFallbackTitle();
		useHead$1({ title: () => title.value }, { tagPriority: 101 });
	}
});
//#endregion
//#region node_modules/site-config-stack/dist/urls.mjs
var FILE_EXT_RE = /\.[0-9a-z]+$/i;
function resolveSitePath(pathOrUrl, options) {
	let path = pathOrUrl;
	if (hasProtocol$1(pathOrUrl, {
		strict: false,
		acceptRelative: true
	})) path = parseURL$1(pathOrUrl).pathname;
	const base = withLeadingSlash(options.base || "/");
	if (base !== "/" && path.startsWith(base)) path = path.slice(base.length);
	let origin = withoutTrailingSlash$1(options.absolute ? options.siteUrl : "");
	if (base !== "/" && origin.endsWith(base)) origin = origin.slice(0, origin.indexOf(base));
	const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
	const resolvedUrl = withBase(path, baseWithOrigin);
	return path === "/" && !options.withBase ? withTrailingSlash$1(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
var fileExtensions = [
	"jpg",
	"jpeg",
	"png",
	"gif",
	"bmp",
	"webp",
	"svg",
	"ico",
	"pdf",
	"doc",
	"docx",
	"xls",
	"xlsx",
	"ppt",
	"pptx",
	"txt",
	"md",
	"markdown",
	"zip",
	"rar",
	"7z",
	"tar",
	"gz",
	"mp3",
	"wav",
	"flac",
	"ogg",
	"opus",
	"m4a",
	"aac",
	"midi",
	"mid",
	"mp4",
	"avi",
	"mkv",
	"mov",
	"wmv",
	"flv",
	"webm",
	"html",
	"css",
	"js",
	"json",
	"xml",
	"tsx",
	"jsx",
	"ts",
	"vue",
	"svelte",
	"xsl",
	"rss",
	"atom",
	"php",
	"py",
	"rb",
	"java",
	"c",
	"cpp",
	"h",
	"go",
	"csv",
	"tsv",
	"sql",
	"yaml",
	"yml",
	"woff",
	"woff2",
	"ttf",
	"otf",
	"eot",
	"exe",
	"msi",
	"apk",
	"ipa",
	"dmg",
	"iso",
	"bin",
	"bat",
	"cmd",
	"sh",
	"env",
	"htaccess",
	"conf",
	"toml",
	"ini",
	"deb",
	"rpm",
	"jar",
	"war",
	"epub",
	"mobi",
	"log",
	"tmp",
	"bak",
	"old",
	"sav"
];
function isPathFile(path) {
	const ext = (path.split("/").pop() || path).match(FILE_EXT_RE)?.[0];
	return !!(ext && fileExtensions.includes(ext.replace(".", "")));
}
function fixSlashes(trailingSlash, pathOrUrl) {
	const $url = parseURL$1(pathOrUrl);
	if (isPathFile($url.pathname)) return pathOrUrl;
	const fixedPath = trailingSlash ? withTrailingSlash$1($url.pathname) : withoutTrailingSlash$1($url.pathname);
	return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/composables/getNitroOrigin.js
function getNitroOrigin(e) {
	e = e || useRequestEvent();
	return e?.context?.siteConfigNitroOrigin || "";
}
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/composables/useNitroOrigin.js
function useNitroOrigin(e) {
	return getNitroOrigin(e);
}
//#endregion
//#region node_modules/nuxt-site-config/dist/runtime/app/composables/utils.js
function createSitePathResolver(options = {}) {
	const siteConfig = useSiteConfig();
	const nitroOrigin = useNitroOrigin();
	const nuxtBase = useRuntimeConfig().app.baseURL || "/";
	return (path) => {
		return computed(() => resolveSitePath(unref(path), {
			absolute: unref(options.absolute),
			withBase: unref(options.withBase),
			siteUrl: unref(options.canonical) !== false || false ? siteConfig.url : nitroOrigin,
			trailingSlash: siteConfig.trailingSlash,
			base: nuxtBase
		}));
	};
}
//#endregion
//#region node_modules/@unhead/vue/dist/plugins.mjs
var plugins_exports = /* @__PURE__ */ __exportAll({});
__reExport(plugins_exports, import_unhead_plugins);
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/logic/applyDefaults.js
var LOCALE_UNDERSCORE_RE = /_/g;
function applyDefaults() {
	const siteConfig = useSiteConfig({ resolveRefs: false });
	const resolveCurrentLocale = () => {
		return (toValue(siteConfig.currentLocale) || toValue(siteConfig.defaultLocale) || "en").replace(LOCALE_UNDERSCORE_RE, "-");
	};
	injectHead$1().use(plugins_exports.TemplateParamsPlugin);
	const { canonicalQueryWhitelist, canonicalLowercase, tagPriority } = useRuntimeConfig().public["seo-utils"];
	const route = useRoute$1();
	const resolveUrl = createSitePathResolver({
		withBase: true,
		absolute: true
	});
	const err = useError();
	const canonicalUrl = computed(() => {
		if (err.value) return false;
		const { query } = route;
		let url = resolveUrl(route.path || "/").value || route.path;
		if (canonicalLowercase) try {
			url = url.toLocaleLowerCase(resolveCurrentLocale());
		} catch {
			url = url.toLowerCase();
		}
		const filteredQuery = Object.fromEntries(Object.entries(query).filter(([key]) => canonicalQueryWhitelist.includes(key)).sort(([a], [b]) => a.localeCompare(b)));
		return {
			rel: "canonical",
			href: Object.keys(filteredQuery).length ? `${url}?${stringifyQuery$1(filteredQuery)}` : url
		};
	});
	const minimalPriority = { tagPriority: "low" };
	const seoMetaPriority = { tagPriority };
	useHead$1({
		htmlAttrs: { lang: resolveCurrentLocale },
		templateParams: {
			site: () => siteConfig,
			siteName: () => siteConfig.name
		},
		titleTemplate: () => err.value ? "%s" : "%s %separator %siteName",
		link: [() => canonicalUrl.value]
	}, minimalPriority);
	useSeoMeta$1({ ogLocale: () => {
		const locale = resolveCurrentLocale();
		if (locale) {
			const l = locale.replace("-", "_");
			if (l.includes("_")) return l;
		}
		return false;
	} }, minimalPriority);
	const seoMeta = {
		ogType: "website",
		ogUrl: () => {
			const url = canonicalUrl.value;
			return url ? url.href : false;
		},
		ogSiteName: siteConfig.name
	};
	if (siteConfig.description) useServerSeoMeta({ description: siteConfig.description }, minimalPriority);
	if (siteConfig.twitter) {
		const id = siteConfig.twitter.startsWith("@") ? siteConfig.twitter : `@${siteConfig.twitter}`;
		seoMeta.twitterCreator = id;
		seoMeta.twitterSite = id;
	}
	useSeoMeta$1(seoMeta, seoMetaPriority);
}
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/defaultsWaitI18n.js
var defaultsWaitI18n_default = defineNuxtPlugin({
	name: "nuxt-seo:defaults",
	env: { islands: false },
	dependsOn: ["nuxt-site-config:i18n"],
	setup() {
		applyDefaults();
	}
});
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/components/index.js?nuxt_component=async&nuxt_component_name=Icon&nuxt_component_export=default
var components_default = defineAsyncComponent(() => Promise.resolve().then(function () { return componentsDAaOEnvX; }).then((n) => n.n).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/autocomplete/index.mjs?nuxt_component=async&nuxt_component_name=AutoComplete&nuxt_component_export=default
var autocomplete_default$1 = defineAsyncComponent(() => import('../build/autocomplete-D-8FSE9q.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/calendar/index.mjs?nuxt_component=async&nuxt_component_name=Calendar&nuxt_component_export=default
var calendar_default = defineAsyncComponent(() => import('../build/calendar-DvDN59uB.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/cascadeselect/index.mjs?nuxt_component=async&nuxt_component_name=CascadeSelect&nuxt_component_export=default
var cascadeselect_default$1 = defineAsyncComponent(() => import('../build/cascadeselect-BDOdTA2X.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/checkbox/index.mjs?nuxt_component=async&nuxt_component_name=Checkbox&nuxt_component_export=default
var checkbox_default$1 = defineAsyncComponent(() => import('../build/checkbox-Bl5m-a9c.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/checkboxgroup/index.mjs?nuxt_component=async&nuxt_component_name=CheckboxGroup&nuxt_component_export=default
var checkboxgroup_default = defineAsyncComponent(() => import('../build/checkboxgroup-B6YaheYe.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/chips/index.mjs?nuxt_component=async&nuxt_component_name=Chips&nuxt_component_export=default
var chips_default = defineAsyncComponent(() => import('../build/chips-B39NQM4Y.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/colorpicker/index.mjs?nuxt_component=async&nuxt_component_name=ColorPicker&nuxt_component_export=default
var colorpicker_default$1 = defineAsyncComponent(() => import('../build/colorpicker-BpkoIij5.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/datepicker/index.mjs?nuxt_component=async&nuxt_component_name=DatePicker&nuxt_component_export=default
var datepicker_default$1 = defineAsyncComponent(() => import('../build/datepicker-Be7Izsnv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/dropdown/index.mjs?nuxt_component=async&nuxt_component_name=Dropdown&nuxt_component_export=default
var dropdown_default = defineAsyncComponent(() => import('../build/dropdown-Dnbx17ua.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/floatlabel/index.mjs?nuxt_component=async&nuxt_component_name=FloatLabel&nuxt_component_export=default
var floatlabel_default$1 = defineAsyncComponent(() => import('../build/floatlabel-DSx1MZgL.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/fluid/index.mjs?nuxt_component=async&nuxt_component_name=Fluid&nuxt_component_export=default
var fluid_default = defineAsyncComponent(() => import('../build/fluid-B_IDvHte.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/iconfield/index.mjs?nuxt_component=async&nuxt_component_name=IconField&nuxt_component_export=default
var iconfield_default$1 = defineAsyncComponent(() => import('../build/iconfield-BEzRtRtO.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/iftalabel/index.mjs?nuxt_component=async&nuxt_component_name=IftaLabel&nuxt_component_export=default
var iftalabel_default = defineAsyncComponent(() => import('../build/iftalabel-BhecqSDy.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputchips/index.mjs?nuxt_component=async&nuxt_component_name=InputChips&nuxt_component_export=default
var inputchips_default = defineAsyncComponent(() => import('../build/inputchips-BrH77aII.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputgroup/index.mjs?nuxt_component=async&nuxt_component_name=InputGroup&nuxt_component_export=default
var inputgroup_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => inputgroup_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputgroupaddon/index.mjs?nuxt_component=async&nuxt_component_name=InputGroupAddon&nuxt_component_export=default
var inputgroupaddon_default$1 = defineAsyncComponent(() => import('../build/inputgroupaddon-d9gQx-M_.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputicon/index.mjs?nuxt_component=async&nuxt_component_name=InputIcon&nuxt_component_export=default
var inputicon_default = defineAsyncComponent(() => import('../build/inputicon-CyBapg9-.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputmask/index.mjs?nuxt_component=async&nuxt_component_name=InputMask&nuxt_component_export=default
var inputmask_default$1 = defineAsyncComponent(() => import('../build/inputmask-B-IsE50R.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputnumber/index.mjs?nuxt_component=async&nuxt_component_name=InputNumber&nuxt_component_export=default
var inputnumber_default$1 = defineAsyncComponent(() => import('../build/inputnumber-BY4u3qXC.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputotp/index.mjs?nuxt_component=async&nuxt_component_name=InputOtp&nuxt_component_export=default
var inputotp_default$1 = defineAsyncComponent(() => import('../build/inputotp-Bj9LdnIB.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputswitch/index.mjs?nuxt_component=async&nuxt_component_name=InputSwitch&nuxt_component_export=default
var inputswitch_default = defineAsyncComponent(() => import('../build/inputswitch-8DEGlqhz.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inputtext/index.mjs?nuxt_component=async&nuxt_component_name=InputText&nuxt_component_export=default
var inputtext_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => inputtext_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/knob/index.mjs?nuxt_component=async&nuxt_component_name=Knob&nuxt_component_export=default
var knob_default$1 = defineAsyncComponent(() => import('../build/knob-DOMMKZ3s.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/listbox/index.mjs?nuxt_component=async&nuxt_component_name=Listbox&nuxt_component_export=default
var listbox_default$1 = defineAsyncComponent(() => import('../build/listbox-Huthdowd.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/multiselect/index.mjs?nuxt_component=async&nuxt_component_name=MultiSelect&nuxt_component_export=default
var multiselect_default$1 = defineAsyncComponent(() => import('../build/multiselect-CNCQZywo.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/password/index.mjs?nuxt_component=async&nuxt_component_name=Password&nuxt_component_export=default
var password_default$1 = defineAsyncComponent(() => import('../build/password-Do0KNeM8.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/radiobutton/index.mjs?nuxt_component=async&nuxt_component_name=RadioButton&nuxt_component_export=default
var radiobutton_default$1 = defineAsyncComponent(() => import('../build/radiobutton-DpQ6BcTz.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/radiobuttongroup/index.mjs?nuxt_component=async&nuxt_component_name=RadioButtonGroup&nuxt_component_export=default
var radiobuttongroup_default = defineAsyncComponent(() => import('../build/radiobuttongroup-NQOfENWv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/rating/index.mjs?nuxt_component=async&nuxt_component_name=Rating&nuxt_component_export=default
var rating_default$1 = defineAsyncComponent(() => import('../build/rating-BVwO0F8o.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/select/index.mjs?nuxt_component=async&nuxt_component_name=Select&nuxt_component_export=default
var select_default$1 = defineAsyncComponent(() => import('../build/select-CiHnyRAx.mjs').then((n) => n.n).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/selectbutton/index.mjs?nuxt_component=async&nuxt_component_name=SelectButton&nuxt_component_export=default
var selectbutton_default$1 = defineAsyncComponent(() => import('../build/selectbutton-IIaO1GdS.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/slider/index.mjs?nuxt_component=async&nuxt_component_name=Slider&nuxt_component_export=default
var slider_default$1 = defineAsyncComponent(() => import('../build/slider-BrYy0Gqk.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/textarea/index.mjs?nuxt_component=async&nuxt_component_name=Textarea&nuxt_component_export=default
var textarea_default$1 = defineAsyncComponent(() => import('../build/textarea-BOP1pvII.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/togglebutton/index.mjs?nuxt_component=async&nuxt_component_name=ToggleButton&nuxt_component_export=default
var togglebutton_default$1 = defineAsyncComponent(() => import('../build/togglebutton-zhvAD5af.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/toggleswitch/index.mjs?nuxt_component=async&nuxt_component_name=ToggleSwitch&nuxt_component_export=default
var toggleswitch_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => toggleswitch_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/treeselect/index.mjs?nuxt_component=async&nuxt_component_name=TreeSelect&nuxt_component_export=default
var treeselect_default$1 = defineAsyncComponent(() => import('../build/treeselect-CA2_8VMv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/button/index.mjs?nuxt_component=async&nuxt_component_name=Button&nuxt_component_export=default
var button_default$1 = defineAsyncComponent(() => Promise.resolve().then(function () { return buttonDjYJPz0o; }).then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/buttongroup/index.mjs?nuxt_component=async&nuxt_component_name=ButtonGroup&nuxt_component_export=default
var buttongroup_default$1 = defineAsyncComponent(() => import('../build/buttongroup-BRluYty5.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/speeddial/index.mjs?nuxt_component=async&nuxt_component_name=SpeedDial&nuxt_component_export=default
var speeddial_default$1 = defineAsyncComponent(() => import('../build/speeddial-DESxUumc.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/splitbutton/index.mjs?nuxt_component=async&nuxt_component_name=SplitButton&nuxt_component_export=default
var splitbutton_default$1 = defineAsyncComponent(() => import('../build/splitbutton-D2nfnUDJ.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/column/index.mjs?nuxt_component=async&nuxt_component_name=Column&nuxt_component_export=default
var column_default = defineAsyncComponent(() => import('../build/column-CbD-Y4u9.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/row/index.mjs?nuxt_component=async&nuxt_component_name=Row&nuxt_component_export=default
var row_default = defineAsyncComponent(() => import('../build/row-BCZ1Vg3X.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/columngroup/index.mjs?nuxt_component=async&nuxt_component_name=ColumnGroup&nuxt_component_export=default
var columngroup_default = defineAsyncComponent(() => import('../build/columngroup-CzGSlOa2.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/datatable/index.mjs?nuxt_component=async&nuxt_component_name=DataTable&nuxt_component_export=default
var datatable_default$1 = defineAsyncComponent(() => import('../build/datatable-DUV-3b29.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/dataview/index.mjs?nuxt_component=async&nuxt_component_name=DataView&nuxt_component_export=default
var dataview_default$1 = defineAsyncComponent(() => import('../build/dataview-DSOPaUV0.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/orderlist/index.mjs?nuxt_component=async&nuxt_component_name=OrderList&nuxt_component_export=default
var orderlist_default$1 = defineAsyncComponent(() => import('../build/orderlist-CsVUX8Zq.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/organizationchart/index.mjs?nuxt_component=async&nuxt_component_name=OrganizationChart&nuxt_component_export=default
var organizationchart_default$1 = defineAsyncComponent(() => import('../build/organizationchart-i5HyVka0.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/paginator/index.mjs?nuxt_component=async&nuxt_component_name=Paginator&nuxt_component_export=default
var paginator_default$1 = defineAsyncComponent(() => import('../build/paginator-BM1cu9lI.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/picklist/index.mjs?nuxt_component=async&nuxt_component_name=PickList&nuxt_component_export=default
var picklist_default$1 = defineAsyncComponent(() => import('../build/picklist-DaONqsbL.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tree/index.mjs?nuxt_component=async&nuxt_component_name=Tree&nuxt_component_export=default
var tree_default$1 = defineAsyncComponent(() => import('../build/tree-78CcLT8X.mjs').then((n) => n.n).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/treetable/index.mjs?nuxt_component=async&nuxt_component_name=TreeTable&nuxt_component_export=default
var treetable_default$1 = defineAsyncComponent(() => import('../build/treetable-DS9itQdv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/timeline/index.mjs?nuxt_component=async&nuxt_component_name=Timeline&nuxt_component_export=default
var timeline_default$1 = defineAsyncComponent(() => import('../build/timeline-DVeXjAdG.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/virtualscroller/index.mjs?nuxt_component=async&nuxt_component_name=VirtualScroller&nuxt_component_export=default
var virtualscroller_default = defineAsyncComponent(() => import('../build/virtualscroller-DyQ5qHvj.mjs').then((n) => n.n).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/accordion/index.mjs?nuxt_component=async&nuxt_component_name=Accordion&nuxt_component_export=default
var accordion_default$1 = defineAsyncComponent(() => import('../build/accordion-DXi-tNtS.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/accordionpanel/index.mjs?nuxt_component=async&nuxt_component_name=AccordionPanel&nuxt_component_export=default
var accordionpanel_default$1 = defineAsyncComponent(() => import('../build/accordionpanel-CefKR3-f.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/accordionheader/index.mjs?nuxt_component=async&nuxt_component_name=AccordionHeader&nuxt_component_export=default
var accordionheader_default$1 = defineAsyncComponent(() => import('../build/accordionheader-Sb4lau2S.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/accordioncontent/index.mjs?nuxt_component=async&nuxt_component_name=AccordionContent&nuxt_component_export=default
var accordioncontent_default$1 = defineAsyncComponent(() => import('../build/accordioncontent-8A2pAPLo.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/accordiontab/index.mjs?nuxt_component=async&nuxt_component_name=AccordionTab&nuxt_component_export=default
var accordiontab_default = defineAsyncComponent(() => import('../build/accordiontab-BfMolaar.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/card/index.mjs?nuxt_component=async&nuxt_component_name=Card&nuxt_component_export=default
var card_default$1 = defineAsyncComponent(() => import('../build/card-CTlfqPcJ.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/deferredcontent/index.mjs?nuxt_component=async&nuxt_component_name=DeferredContent&nuxt_component_export=default
var deferredcontent_default = defineAsyncComponent(() => import('../build/deferredcontent-DU80LoR8.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/divider/index.mjs?nuxt_component=async&nuxt_component_name=Divider&nuxt_component_export=default
var divider_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => divider_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/fieldset/index.mjs?nuxt_component=async&nuxt_component_name=Fieldset&nuxt_component_export=default
var fieldset_default$1 = defineAsyncComponent(() => import('../build/fieldset-CT2OwAoB.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/panel/index.mjs?nuxt_component=async&nuxt_component_name=Panel&nuxt_component_export=default
var panel_default$1 = defineAsyncComponent(() => import('../build/panel-DxI356bW.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/scrollpanel/index.mjs?nuxt_component=async&nuxt_component_name=ScrollPanel&nuxt_component_export=default
var scrollpanel_default$1 = defineAsyncComponent(() => import('../build/scrollpanel-BrU7U3QR.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/splitter/index.mjs?nuxt_component=async&nuxt_component_name=Splitter&nuxt_component_export=default
var splitter_default$1 = defineAsyncComponent(() => import('../build/splitter-Bsn78PLY.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/splitterpanel/index.mjs?nuxt_component=async&nuxt_component_name=SplitterPanel&nuxt_component_export=default
var splitterpanel_default$1 = defineAsyncComponent(() => import('../build/splitterpanel-BfHaRDRv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/stepper/index.mjs?nuxt_component=async&nuxt_component_name=Stepper&nuxt_component_export=default
var stepper_default$1 = defineAsyncComponent(() => import('../build/stepper-ClKi_Hur.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/steplist/index.mjs?nuxt_component=async&nuxt_component_name=StepList&nuxt_component_export=default
var steplist_default$1 = defineAsyncComponent(() => import('../build/steplist-BrbL4zgR.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/step/index.mjs?nuxt_component=async&nuxt_component_name=Step&nuxt_component_export=default
var step_default$1 = defineAsyncComponent(() => import('../build/step-BxB4O5jR.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/stepitem/index.mjs?nuxt_component=async&nuxt_component_name=StepItem&nuxt_component_export=default
var stepitem_default$1 = defineAsyncComponent(() => import('../build/stepitem-DOcDfJQY.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/steppanels/index.mjs?nuxt_component=async&nuxt_component_name=StepPanels&nuxt_component_export=default
var steppanels_default$1 = defineAsyncComponent(() => import('../build/steppanels-D_gPmz44.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/steppanel/index.mjs?nuxt_component=async&nuxt_component_name=StepPanel&nuxt_component_export=default
var steppanel_default = defineAsyncComponent(() => import('../build/steppanel-BYsr-EHi.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tabview/index.mjs?nuxt_component=async&nuxt_component_name=TabView&nuxt_component_export=default
var tabview_default$1 = defineAsyncComponent(() => import('../build/tabview-Cu4avT2t.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tabs/index.mjs?nuxt_component=async&nuxt_component_name=Tabs&nuxt_component_export=default
var tabs_default$1 = defineAsyncComponent(() => import('../build/tabs-D2NNszZ7.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tablist/index.mjs?nuxt_component=async&nuxt_component_name=TabList&nuxt_component_export=default
var tablist_default$1 = defineAsyncComponent(() => import('../build/tablist-BmFGmSjX.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tab/index.mjs?nuxt_component=async&nuxt_component_name=Tab&nuxt_component_export=default
var tab_default$1 = defineAsyncComponent(() => import('../build/tab-XaxXOl9u.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tabpanels/index.mjs?nuxt_component=async&nuxt_component_name=TabPanels&nuxt_component_export=default
var tabpanels_default$1 = defineAsyncComponent(() => import('../build/tabpanels-D2ddBJJ5.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tabpanel/index.mjs?nuxt_component=async&nuxt_component_name=TabPanel&nuxt_component_export=default
var tabpanel_default$1 = defineAsyncComponent(() => import('../build/tabpanel-CIfVRz8e.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/toolbar/index.mjs?nuxt_component=async&nuxt_component_name=Toolbar&nuxt_component_export=default
var toolbar_default$1 = defineAsyncComponent(() => import('../build/toolbar-vrG9goeM.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/confirmdialog/index.mjs?nuxt_component=async&nuxt_component_name=ConfirmDialog&nuxt_component_export=default
var confirmdialog_default$1 = defineAsyncComponent(() => import('../build/confirmdialog-C5_MN3KA.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/confirmpopup/index.mjs?nuxt_component=async&nuxt_component_name=ConfirmPopup&nuxt_component_export=default
var confirmpopup_default$1 = defineAsyncComponent(() => import('../build/confirmpopup-BntJ936r.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/dialog/index.mjs?nuxt_component=async&nuxt_component_name=Dialog&nuxt_component_export=default
var dialog_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => dialog_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/drawer/index.mjs?nuxt_component=async&nuxt_component_name=Drawer&nuxt_component_export=default
var drawer_default$1 = defineAsyncComponent(() => import('../build/drawer-Dl20Z_NR.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/dynamicdialog/index.mjs?nuxt_component=async&nuxt_component_name=DynamicDialog&nuxt_component_export=default
var dynamicdialog_default = defineAsyncComponent(() => import('../build/dynamicdialog-B9kfxD2f.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/overlaypanel/index.mjs?nuxt_component=async&nuxt_component_name=OverlayPanel&nuxt_component_export=default
var overlaypanel_default = defineAsyncComponent(() => import('../build/overlaypanel-DnQfdrvk.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/popover/index.mjs?nuxt_component=async&nuxt_component_name=Popover&nuxt_component_export=default
var popover_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => popover_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/sidebar/index.mjs?nuxt_component=async&nuxt_component_name=Sidebar&nuxt_component_export=default
var sidebar_default = defineAsyncComponent(() => import('../build/sidebar-CD5FFEF5.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/fileupload/index.mjs?nuxt_component=async&nuxt_component_name=FileUpload&nuxt_component_export=default
var fileupload_default$1 = defineAsyncComponent(() => import('../build/fileupload-D4K4oQm4.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/breadcrumb/index.mjs?nuxt_component=async&nuxt_component_name=Breadcrumb&nuxt_component_export=default
var breadcrumb_default$1 = defineAsyncComponent(() => import('../build/breadcrumb-DPaKJ8Z1.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/contextmenu/index.mjs?nuxt_component=async&nuxt_component_name=ContextMenu&nuxt_component_export=default
var contextmenu_default$1 = defineAsyncComponent(() => import('../build/contextmenu-DVMxAdvI.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/dock/index.mjs?nuxt_component=async&nuxt_component_name=Dock&nuxt_component_export=default
var dock_default$1 = defineAsyncComponent(() => import('../build/dock-BJCTJePi.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/menu/index.mjs?nuxt_component=async&nuxt_component_name=Menu&nuxt_component_export=default
var menu_default$1 = defineAsyncComponent(() => import('../build/menu-DGacLapm.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/menubar/index.mjs?nuxt_component=async&nuxt_component_name=Menubar&nuxt_component_export=default
var menubar_default$1 = defineAsyncComponent(() => import('../build/menubar-BuNtqXlm.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/megamenu/index.mjs?nuxt_component=async&nuxt_component_name=MegaMenu&nuxt_component_export=default
var megamenu_default$1 = defineAsyncComponent(() => import('../build/megamenu-CVpu_E3E.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/panelmenu/index.mjs?nuxt_component=async&nuxt_component_name=PanelMenu&nuxt_component_export=default
var panelmenu_default$1 = defineAsyncComponent(() => import('../build/panelmenu-CmUEO0kS.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/steps/index.mjs?nuxt_component=async&nuxt_component_name=Steps&nuxt_component_export=default
var steps_default$1 = defineAsyncComponent(() => import('../build/steps-ClJI3KvY.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tabmenu/index.mjs?nuxt_component=async&nuxt_component_name=TabMenu&nuxt_component_export=default
var tabmenu_default$1 = defineAsyncComponent(() => import('../build/tabmenu-HKCCOns9.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tieredmenu/index.mjs?nuxt_component=async&nuxt_component_name=TieredMenu&nuxt_component_export=default
var tieredmenu_default$1 = defineAsyncComponent(() => import('../build/tieredmenu-CgUFgTrW.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/message/index.mjs?nuxt_component=async&nuxt_component_name=Message&nuxt_component_export=default
var message_default$1 = defineAsyncComponent(() => import('../build/message-DhvZHWIr.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inlinemessage/index.mjs?nuxt_component=async&nuxt_component_name=InlineMessage&nuxt_component_export=default
var inlinemessage_default = defineAsyncComponent(() => import('../build/inlinemessage-BpsMUkdL.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/toast/index.mjs?nuxt_component=async&nuxt_component_name=Toast&nuxt_component_export=default
var toast_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => toast_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/carousel/index.mjs?nuxt_component=async&nuxt_component_name=Carousel&nuxt_component_export=default
var carousel_default$1 = defineAsyncComponent(() => import('../build/carousel-C-AgsCFl.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/galleria/index.mjs?nuxt_component=async&nuxt_component_name=Galleria&nuxt_component_export=default
var galleria_default$1 = defineAsyncComponent(() => import('../build/galleria-Dhni3yp6.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/image/index.mjs?nuxt_component=async&nuxt_component_name=Image&nuxt_component_export=default
var image_default$1 = defineAsyncComponent(() => import('../build/image-Cp728IPk.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/imagecompare/index.mjs?nuxt_component=async&nuxt_component_name=ImageCompare&nuxt_component_export=default
var imagecompare_default = defineAsyncComponent(() => import('../build/imagecompare-WKMgRAO5.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/avatar/index.mjs?nuxt_component=async&nuxt_component_name=Avatar&nuxt_component_export=default
var avatar_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => avatar_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/avatargroup/index.mjs?nuxt_component=async&nuxt_component_name=AvatarGroup&nuxt_component_export=default
var avatargroup_default$1 = defineAsyncComponent(() => import('../build/avatargroup-BslA9KIm.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/badge/index.mjs?nuxt_component=async&nuxt_component_name=Badge&nuxt_component_export=default
var badge_default$1 = defineAsyncComponent(() => Promise.resolve().then(function () { return badgeDf1CDU2B; }).then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/blockui/index.mjs?nuxt_component=async&nuxt_component_name=BlockUI&nuxt_component_export=default
var blockui_default$1 = defineAsyncComponent(() => import('../build/blockui-DwipHjMH.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/chip/index.mjs?nuxt_component=async&nuxt_component_name=Chip&nuxt_component_export=default
var chip_default$1 = defineAsyncComponent(() => import('../build/chip-BvW_S30Y.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/inplace/index.mjs?nuxt_component=async&nuxt_component_name=Inplace&nuxt_component_export=default
var inplace_default$1 = defineAsyncComponent(() => import('../build/inplace-Bat6VCnn.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/metergroup/index.mjs?nuxt_component=async&nuxt_component_name=MeterGroup&nuxt_component_export=default
var metergroup_default$1 = defineAsyncComponent(() => import('../build/metergroup-BlgchZz-.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/overlaybadge/index.mjs?nuxt_component=async&nuxt_component_name=OverlayBadge&nuxt_component_export=default
var overlaybadge_default$1 = defineAsyncComponent(() => import('../build/overlaybadge-BG9zh3Zf.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/scrolltop/index.mjs?nuxt_component=async&nuxt_component_name=ScrollTop&nuxt_component_export=default
var scrolltop_default$1 = defineAsyncComponent(() => Promise.resolve().then(() => scrolltop_exports).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/skeleton/index.mjs?nuxt_component=async&nuxt_component_name=Skeleton&nuxt_component_export=default
var skeleton_default$1 = defineAsyncComponent(() => import('../build/skeleton-CHCF4gxa.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/progressbar/index.mjs?nuxt_component=async&nuxt_component_name=ProgressBar&nuxt_component_export=default
var progressbar_default$1 = defineAsyncComponent(() => import('../build/progressbar-Dc4XIgTM.mjs').then((n) => n.t).then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/progressspinner/index.mjs?nuxt_component=async&nuxt_component_name=ProgressSpinner&nuxt_component_export=default
var progressspinner_default$1 = defineAsyncComponent(() => import('../build/progressspinner-DNaElTSv.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/tag/index.mjs?nuxt_component=async&nuxt_component_name=Tag&nuxt_component_export=default
var tag_default$1 = defineAsyncComponent(() => import('../build/tag-C1prwNU8.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/primevue/terminal/index.mjs?nuxt_component=async&nuxt_component_name=Terminal&nuxt_component_export=default
var terminal_default$1 = defineAsyncComponent(() => import('../build/terminal-BReox5xC.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/@primevue/forms/form/index.mjs?nuxt_component=async&nuxt_component_name=Form&nuxt_component_export=default
var form_default = defineAsyncComponent(() => import('../build/form-Dhc595M8.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region node_modules/@primevue/forms/formfield/index.mjs?nuxt_component=async&nuxt_component_name=FormField&nuxt_component_export=default
var formfield_default = defineAsyncComponent(() => import('../build/formfield-BTG8Mrq4.mjs').then((r) => r["default"] || r.default || r));
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fcomponents.plugin.mjs
var lazyGlobalComponents = [
	["Icon", components_default],
	["AutoComplete", autocomplete_default$1],
	["Calendar", calendar_default],
	["CascadeSelect", cascadeselect_default$1],
	["Checkbox", checkbox_default$1],
	["CheckboxGroup", checkboxgroup_default],
	["Chips", chips_default],
	["ColorPicker", colorpicker_default$1],
	["DatePicker", datepicker_default$1],
	["Dropdown", dropdown_default],
	["FloatLabel", floatlabel_default$1],
	["Fluid", fluid_default],
	["IconField", iconfield_default$1],
	["IftaLabel", iftalabel_default],
	["InputChips", inputchips_default],
	["InputGroup", inputgroup_default$1],
	["InputGroupAddon", inputgroupaddon_default$1],
	["InputIcon", inputicon_default],
	["InputMask", inputmask_default$1],
	["InputNumber", inputnumber_default$1],
	["InputOtp", inputotp_default$1],
	["InputSwitch", inputswitch_default],
	["InputText", inputtext_default$1],
	["Knob", knob_default$1],
	["Listbox", listbox_default$1],
	["MultiSelect", multiselect_default$1],
	["Password", password_default$1],
	["RadioButton", radiobutton_default$1],
	["RadioButtonGroup", radiobuttongroup_default],
	["Rating", rating_default$1],
	["Select", select_default$1],
	["SelectButton", selectbutton_default$1],
	["Slider", slider_default$1],
	["Textarea", textarea_default$1],
	["ToggleButton", togglebutton_default$1],
	["ToggleSwitch", toggleswitch_default$1],
	["TreeSelect", treeselect_default$1],
	["Button", button_default$1],
	["ButtonGroup", buttongroup_default$1],
	["SpeedDial", speeddial_default$1],
	["SplitButton", splitbutton_default$1],
	["Column", column_default],
	["Row", row_default],
	["ColumnGroup", columngroup_default],
	["DataTable", datatable_default$1],
	["DataView", dataview_default$1],
	["OrderList", orderlist_default$1],
	["OrganizationChart", organizationchart_default$1],
	["Paginator", paginator_default$1],
	["PickList", picklist_default$1],
	["Tree", tree_default$1],
	["TreeTable", treetable_default$1],
	["Timeline", timeline_default$1],
	["VirtualScroller", virtualscroller_default],
	["Accordion", accordion_default$1],
	["AccordionPanel", accordionpanel_default$1],
	["AccordionHeader", accordionheader_default$1],
	["AccordionContent", accordioncontent_default$1],
	["AccordionTab", accordiontab_default],
	["Card", card_default$1],
	["DeferredContent", deferredcontent_default],
	["Divider", divider_default$1],
	["Fieldset", fieldset_default$1],
	["Panel", panel_default$1],
	["ScrollPanel", scrollpanel_default$1],
	["Splitter", splitter_default$1],
	["SplitterPanel", splitterpanel_default$1],
	["Stepper", stepper_default$1],
	["StepList", steplist_default$1],
	["Step", step_default$1],
	["StepItem", stepitem_default$1],
	["StepPanels", steppanels_default$1],
	["StepPanel", steppanel_default],
	["TabView", tabview_default$1],
	["Tabs", tabs_default$1],
	["TabList", tablist_default$1],
	["Tab", tab_default$1],
	["TabPanels", tabpanels_default$1],
	["TabPanel", tabpanel_default$1],
	["Toolbar", toolbar_default$1],
	["ConfirmDialog", confirmdialog_default$1],
	["ConfirmPopup", confirmpopup_default$1],
	["Dialog", dialog_default$1],
	["Drawer", drawer_default$1],
	["DynamicDialog", dynamicdialog_default],
	["OverlayPanel", overlaypanel_default],
	["Popover", popover_default$1],
	["Sidebar", sidebar_default],
	["FileUpload", fileupload_default$1],
	["Breadcrumb", breadcrumb_default$1],
	["ContextMenu", contextmenu_default$1],
	["Dock", dock_default$1],
	["Menu", menu_default$1],
	["Menubar", menubar_default$1],
	["MegaMenu", megamenu_default$1],
	["PanelMenu", panelmenu_default$1],
	["Steps", steps_default$1],
	["TabMenu", tabmenu_default$1],
	["TieredMenu", tieredmenu_default$1],
	["Message", message_default$1],
	["InlineMessage", inlinemessage_default],
	["Toast", toast_default$1],
	["Carousel", carousel_default$1],
	["Galleria", galleria_default$1],
	["Image", image_default$1],
	["ImageCompare", imagecompare_default],
	["Avatar", avatar_default$1],
	["AvatarGroup", avatargroup_default$1],
	["Badge", badge_default$1],
	["BlockUI", blockui_default$1],
	["Chip", chip_default$1],
	["Inplace", inplace_default$1],
	["MeterGroup", metergroup_default$1],
	["OverlayBadge", overlaybadge_default$1],
	["ScrollTop", scrolltop_default$1],
	["Skeleton", skeleton_default$1],
	["ProgressBar", progressbar_default$1],
	["ProgressSpinner", progressspinner_default$1],
	["Tag", tag_default$1],
	["Terminal", terminal_default$1],
	["Form", form_default],
	["FormField", formfield_default]
];
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fcomponents_plugin_default = defineNuxtPlugin({
	name: "nuxt:global-components",
	setup(nuxtApp) {
		for (const [name, component] of lazyGlobalComponents) {
			nuxtApp.vueApp.component(name, component);
			nuxtApp.vueApp.component("Lazy" + name, component);
		}
	}
});
//#endregion
//#region node_modules/@primevue/core/api/index.mjs
var FilterMatchMode = {
	STARTS_WITH: "startsWith",
	CONTAINS: "contains",
	NOT_CONTAINS: "notContains",
	ENDS_WITH: "endsWith",
	EQUALS: "equals",
	NOT_EQUALS: "notEquals",
	LESS_THAN: "lt",
	LESS_THAN_OR_EQUAL_TO: "lte",
	GREATER_THAN: "gt",
	GREATER_THAN_OR_EQUAL_TO: "gte",
	DATE_IS: "dateIs",
	DATE_IS_NOT: "dateIsNot",
	DATE_BEFORE: "dateBefore",
	DATE_AFTER: "dateAfter"
};
var FilterOperator = {
	AND: "and",
	OR: "or"
};
function _createForOfIteratorHelper(r, e) {
	var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (!t) {
		if (Array.isArray(r) || (t = _unsupportedIterableToArray$7(r)) || e) {
			t && (r = t);
			var _n = 0, F = function F() {};
			return {
				s: F,
				n: function n() {
					return _n >= r.length ? { done: true } : {
						done: false,
						value: r[_n++]
					};
				},
				e: function e(r) {
					throw r;
				},
				f: F
			};
		}
		throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
	}
	var o, a = true, u = false;
	return {
		s: function s() {
			t = t.call(r);
		},
		n: function n() {
			var r = t.next();
			return a = r.done, r;
		},
		e: function e(r) {
			u = true, o = r;
		},
		f: function f() {
			try {
				a || null == t["return"] || t["return"]();
			} finally {
				if (u) throw o;
			}
		}
	};
}
function _unsupportedIterableToArray$7(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$7(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$7(r, a) : void 0;
	}
}
function _arrayLikeToArray$7(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
var FilterService = {
	filter: function filter(value, fields, filterValue, filterMatchMode, filterLocale) {
		var filteredItems = [];
		if (!value) return filteredItems;
		var _iterator = _createForOfIteratorHelper(value), _step;
		try {
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var item = _step.value;
				if (typeof item === "string") {
					if (this.filters[filterMatchMode](item, filterValue, filterLocale)) {
						filteredItems.push(item);
						continue;
					}
				} else {
					var _iterator2 = _createForOfIteratorHelper(fields), _step2;
					try {
						for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
							var field = _step2.value;
							var fieldValue = p(item, field);
							if (this.filters[filterMatchMode](fieldValue, filterValue, filterLocale)) {
								filteredItems.push(item);
								break;
							}
						}
					} catch (err) {
						_iterator2.e(err);
					} finally {
						_iterator2.f();
					}
				}
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		return filteredItems;
	},
	filters: {
		startsWith: function startsWith(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return true;
			if (value === void 0 || value === null) return false;
			var filterValue = X(filter.toString()).toLocaleLowerCase(filterLocale);
			return X(value.toString()).toLocaleLowerCase(filterLocale).slice(0, filterValue.length) === filterValue;
		},
		contains: function contains(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return true;
			if (value === void 0 || value === null) return false;
			var filterValue = X(filter.toString()).toLocaleLowerCase(filterLocale);
			return X(value.toString()).toLocaleLowerCase(filterLocale).indexOf(filterValue) !== -1;
		},
		notContains: function notContains(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return true;
			if (value === void 0 || value === null) return false;
			var filterValue = X(filter.toString()).toLocaleLowerCase(filterLocale);
			return X(value.toString()).toLocaleLowerCase(filterLocale).indexOf(filterValue) === -1;
		},
		endsWith: function endsWith(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return true;
			if (value === void 0 || value === null) return false;
			var filterValue = X(filter.toString()).toLocaleLowerCase(filterLocale);
			var stringValue = X(value.toString()).toLocaleLowerCase(filterLocale);
			return stringValue.indexOf(filterValue, stringValue.length - filterValue.length) !== -1;
		},
		equals: function equals(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime && filter.getTime) return value.getTime() === filter.getTime();
			else return X(value.toString()).toLocaleLowerCase(filterLocale) == X(filter.toString()).toLocaleLowerCase(filterLocale);
		},
		notEquals: function notEquals(value, filter, filterLocale) {
			if (filter === void 0 || filter === null || filter === "") return false;
			if (value === void 0 || value === null) return true;
			if (value.getTime && filter.getTime) return value.getTime() !== filter.getTime();
			else return X(value.toString()).toLocaleLowerCase(filterLocale) != X(filter.toString()).toLocaleLowerCase(filterLocale);
		},
		"in": function _in(value, filter) {
			if (filter === void 0 || filter === null || filter.length === 0) return true;
			for (var i = 0; i < filter.length; i++) if (k(value, filter[i])) return true;
			return false;
		},
		between: function between(value, filter) {
			if (filter == null || filter[0] == null || filter[1] == null) return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime) return filter[0].getTime() <= value.getTime() && value.getTime() <= filter[1].getTime();
			else return filter[0] <= value && value <= filter[1];
		},
		lt: function lt(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime && filter.getTime) return value.getTime() < filter.getTime();
			else return value < filter;
		},
		lte: function lte(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime && filter.getTime) return value.getTime() <= filter.getTime();
			else return value <= filter;
		},
		gt: function gt(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime && filter.getTime) return value.getTime() > filter.getTime();
			else return value > filter;
		},
		gte: function gte(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (value.getTime && filter.getTime) return value.getTime() >= filter.getTime();
			else return value >= filter;
		},
		dateIs: function dateIs(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (typeof value === "string") value = new Date(value);
			if (typeof filter === "string") filter = new Date(filter);
			return value.toDateString() === filter.toDateString();
		},
		dateIsNot: function dateIsNot(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (typeof value === "string") value = new Date(value);
			if (typeof filter === "string") filter = new Date(filter);
			return value.toDateString() !== filter.toDateString();
		},
		dateBefore: function dateBefore(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (typeof value === "string") value = new Date(value);
			if (typeof filter === "string") filter = new Date(filter);
			return value.getTime() < filter.getTime();
		},
		dateAfter: function dateAfter(value, filter) {
			if (filter === void 0 || filter === null) return true;
			if (value === void 0 || value === null) return false;
			if (typeof value === "string") value = new Date(value);
			if (typeof filter === "string") filter = new Date(filter);
			return value.getTime() > filter.getTime();
		}
	},
	register: function register(rule, fn) {
		this.filters[rule] = fn;
	}
};
//#endregion
//#region node_modules/@primevue/core/config/index.mjs
function _typeof$9(o) {
	"@babel/helpers - typeof";
	return _typeof$9 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$9(o);
}
function ownKeys$3(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$3(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$3(Object(t), true).forEach(function(r) {
			_defineProperty$9(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$3(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$9(e, r, t) {
	return (r = _toPropertyKey$9(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$9(t) {
	var i = _toPrimitive$9(t, "string");
	return "symbol" == _typeof$9(i) ? i : i + "";
}
function _toPrimitive$9(t, r) {
	if ("object" != _typeof$9(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$9(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var defaultOptions = {
	ripple: false,
	inputStyle: null,
	inputVariant: null,
	locale: {
		startsWith: "Starts with",
		contains: "Contains",
		notContains: "Not contains",
		endsWith: "Ends with",
		equals: "Equals",
		notEquals: "Not equals",
		noFilter: "No Filter",
		lt: "Less than",
		lte: "Less than or equal to",
		gt: "Greater than",
		gte: "Greater than or equal to",
		dateIs: "Date is",
		dateIsNot: "Date is not",
		dateBefore: "Date is before",
		dateAfter: "Date is after",
		clear: "Clear",
		apply: "Apply",
		matchAll: "Match All",
		matchAny: "Match Any",
		addRule: "Add Rule",
		removeRule: "Remove Rule",
		accept: "Yes",
		reject: "No",
		choose: "Choose",
		upload: "Upload",
		cancel: "Cancel",
		completed: "Completed",
		pending: "Pending",
		fileSizeTypes: [
			"B",
			"KB",
			"MB",
			"GB",
			"TB",
			"PB",
			"EB",
			"ZB",
			"YB"
		],
		dayNames: [
			"Sunday",
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday"
		],
		dayNamesShort: [
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		],
		dayNamesMin: [
			"Su",
			"Mo",
			"Tu",
			"We",
			"Th",
			"Fr",
			"Sa"
		],
		monthNames: [
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
		],
		monthNamesShort: [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		],
		chooseYear: "Choose Year",
		chooseMonth: "Choose Month",
		chooseDate: "Choose Date",
		prevDecade: "Previous Decade",
		nextDecade: "Next Decade",
		prevYear: "Previous Year",
		nextYear: "Next Year",
		prevMonth: "Previous Month",
		nextMonth: "Next Month",
		prevHour: "Previous Hour",
		nextHour: "Next Hour",
		prevMinute: "Previous Minute",
		nextMinute: "Next Minute",
		prevSecond: "Previous Second",
		nextSecond: "Next Second",
		am: "am",
		pm: "pm",
		today: "Today",
		weekHeader: "Wk",
		firstDayOfWeek: 0,
		showMonthAfterYear: false,
		dateFormat: "mm/dd/yy",
		weak: "Weak",
		medium: "Medium",
		strong: "Strong",
		passwordPrompt: "Enter a password",
		emptyFilterMessage: "No results found",
		searchMessage: "{0} results are available",
		selectionMessage: "{0} items selected",
		emptySelectionMessage: "No selected item",
		emptySearchMessage: "No results found",
		fileChosenMessage: "{0} files",
		noFileChosenMessage: "No file chosen",
		emptyMessage: "No available options",
		aria: {
			trueLabel: "True",
			falseLabel: "False",
			nullLabel: "Not Selected",
			star: "1 star",
			stars: "{star} stars",
			selectAll: "All items selected",
			unselectAll: "All items unselected",
			close: "Close",
			previous: "Previous",
			next: "Next",
			navigation: "Navigation",
			scrollTop: "Scroll Top",
			moveTop: "Move Top",
			moveUp: "Move Up",
			moveDown: "Move Down",
			moveBottom: "Move Bottom",
			moveToTarget: "Move to Target",
			moveToSource: "Move to Source",
			moveAllToTarget: "Move All to Target",
			moveAllToSource: "Move All to Source",
			pageLabel: "Page {page}",
			firstPageLabel: "First Page",
			lastPageLabel: "Last Page",
			nextPageLabel: "Next Page",
			prevPageLabel: "Previous Page",
			rowsPerPageLabel: "Rows per page",
			jumpToPageDropdownLabel: "Jump to Page Dropdown",
			jumpToPageInputLabel: "Jump to Page Input",
			selectRow: "Row Selected",
			unselectRow: "Row Unselected",
			expandRow: "Row Expanded",
			collapseRow: "Row Collapsed",
			showFilterMenu: "Show Filter Menu",
			hideFilterMenu: "Hide Filter Menu",
			filterOperator: "Filter Operator",
			filterConstraint: "Filter Constraint",
			editRow: "Row Edit",
			saveEdit: "Save Edit",
			cancelEdit: "Cancel Edit",
			listView: "List View",
			gridView: "Grid View",
			slide: "Slide",
			slideNumber: "{slideNumber}",
			zoomImage: "Zoom Image",
			zoomIn: "Zoom In",
			zoomOut: "Zoom Out",
			rotateRight: "Rotate Right",
			rotateLeft: "Rotate Left",
			listLabel: "Option List"
		}
	},
	filterMatchModeOptions: {
		text: [
			FilterMatchMode.STARTS_WITH,
			FilterMatchMode.CONTAINS,
			FilterMatchMode.NOT_CONTAINS,
			FilterMatchMode.ENDS_WITH,
			FilterMatchMode.EQUALS,
			FilterMatchMode.NOT_EQUALS
		],
		numeric: [
			FilterMatchMode.EQUALS,
			FilterMatchMode.NOT_EQUALS,
			FilterMatchMode.LESS_THAN,
			FilterMatchMode.LESS_THAN_OR_EQUAL_TO,
			FilterMatchMode.GREATER_THAN,
			FilterMatchMode.GREATER_THAN_OR_EQUAL_TO
		],
		date: [
			FilterMatchMode.DATE_IS,
			FilterMatchMode.DATE_IS_NOT,
			FilterMatchMode.DATE_BEFORE,
			FilterMatchMode.DATE_AFTER
		]
	},
	zIndex: {
		modal: 1100,
		overlay: 1e3,
		menu: 1e3,
		tooltip: 1100
	},
	theme: void 0,
	unstyled: false,
	pt: void 0,
	ptOptions: {
		mergeSections: true,
		mergeProps: false
	},
	csp: { nonce: void 0 }
};
var PrimeVueSymbol = Symbol();
function setup(app, options) {
	var PrimeVue = { config: reactive(options) };
	app.config.globalProperties.$primevue = PrimeVue;
	app.provide(PrimeVueSymbol, PrimeVue);
	clearConfig();
	setupConfig(app, PrimeVue);
	return PrimeVue;
}
var stopWatchers = [];
function clearConfig() {
	ThemeService.clear();
	stopWatchers.forEach(function(fn) {
		return fn === null || fn === void 0 ? void 0 : fn();
	});
	stopWatchers = [];
}
function setupConfig(app, PrimeVue) {
	var isThemeChanged = ref(false);
	/*** Methods and Services ***/
	var loadCommonTheme = function loadCommonTheme() {
		var _PrimeVue$config;
		if (((_PrimeVue$config = PrimeVue.config) === null || _PrimeVue$config === void 0 ? void 0 : _PrimeVue$config.theme) === "none") return;
		if (!Theme.isStyleNameLoaded("common")) {
			var _BaseStyle$getCommonT, _PrimeVue$config2;
			var _ref = ((_BaseStyle$getCommonT = BaseStyle.getCommonTheme) === null || _BaseStyle$getCommonT === void 0 ? void 0 : _BaseStyle$getCommonT.call(BaseStyle)) || {}, primitive = _ref.primitive, semantic = _ref.semantic, global = _ref.global, style = _ref.style;
			var styleOptions = { nonce: (_PrimeVue$config2 = PrimeVue.config) === null || _PrimeVue$config2 === void 0 || (_PrimeVue$config2 = _PrimeVue$config2.csp) === null || _PrimeVue$config2 === void 0 ? void 0 : _PrimeVue$config2.nonce };
			BaseStyle.load(primitive === null || primitive === void 0 ? void 0 : primitive.css, _objectSpread$3({ name: "primitive-variables" }, styleOptions));
			BaseStyle.load(semantic === null || semantic === void 0 ? void 0 : semantic.css, _objectSpread$3({ name: "semantic-variables" }, styleOptions));
			BaseStyle.load(global === null || global === void 0 ? void 0 : global.css, _objectSpread$3({ name: "global-variables" }, styleOptions));
			BaseStyle.loadStyle(_objectSpread$3({ name: "global-style" }, styleOptions), style);
			Theme.setLoadedStyleName("common");
		}
	};
	ThemeService.on("theme:change", function(newTheme) {
		if (!isThemeChanged.value) {
			app.config.globalProperties.$primevue.config.theme = newTheme;
			isThemeChanged.value = true;
		}
	});
	/*** Watchers ***/
	var stopConfigWatcher = watch(PrimeVue.config, function(newValue, oldValue) {
		PrimeVueService.emit("config:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	var stopRippleWatcher = watch(function() {
		return PrimeVue.config.ripple;
	}, function(newValue, oldValue) {
		PrimeVueService.emit("config:ripple:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	var stopThemeWatcher = watch(function() {
		return PrimeVue.config.theme;
	}, function(newValue, oldValue) {
		if (!isThemeChanged.value) Theme.setTheme(newValue);
		if (!PrimeVue.config.unstyled) loadCommonTheme();
		isThemeChanged.value = false;
		PrimeVueService.emit("config:theme:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: false
	});
	var stopUnstyledWatcher = watch(function() {
		return PrimeVue.config.unstyled;
	}, function(newValue, oldValue) {
		if (!newValue && PrimeVue.config.theme) loadCommonTheme();
		PrimeVueService.emit("config:unstyled:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	stopWatchers.push(stopConfigWatcher);
	stopWatchers.push(stopRippleWatcher);
	stopWatchers.push(stopThemeWatcher);
	stopWatchers.push(stopUnstyledWatcher);
}
var PrimeVue = { install: function install(app, options) {
	setup(app, mergeKeys(defaultOptions, options));
} };
//#endregion
//#region node_modules/primevue/confirmationeventbus/index.mjs
var ConfirmationEventBus = s$1();
//#endregion
//#region node_modules/primevue/useconfirm/index.mjs
var PrimeVueConfirmSymbol = Symbol();
//#endregion
//#region node_modules/primevue/confirmationservice/index.mjs
var ConfirmationService = { install: function install(app) {
	var ConfirmationService = {
		require: function require(options) {
			ConfirmationEventBus.emit("confirm", options);
		},
		close: function close() {
			ConfirmationEventBus.emit("close");
		}
	};
	app.config.globalProperties.$confirm = ConfirmationService;
	app.provide(PrimeVueConfirmSymbol, ConfirmationService);
} };
//#endregion
//#region node_modules/primevue/dynamicdialogeventbus/index.mjs
var DynamicDialogEventBus = s$1();
//#endregion
//#region node_modules/primevue/usedialog/index.mjs
var PrimeVueDialogSymbol = Symbol();
//#endregion
//#region node_modules/primevue/dialogservice/index.mjs
var DialogService = { install: function install(app) {
	var DialogService = { open: function open(content, options) {
		var instance = {
			content: content && markRaw(content),
			options: options || {},
			data: options && options.data,
			close: function close(params) {
				DynamicDialogEventBus.emit("close", {
					instance,
					params
				});
			}
		};
		DynamicDialogEventBus.emit("open", { instance });
		return instance;
	} };
	app.config.globalProperties.$dialog = DialogService;
	app.provide(PrimeVueDialogSymbol, DialogService);
} };
//#endregion
//#region node_modules/primevue/toasteventbus/index.mjs
var ToastEventBus = s$1();
//#endregion
//#region node_modules/primevue/toastservice/index.mjs
var ToastService = { install: function install(app) {
	var ToastService = {
		add: function add(message) {
			ToastEventBus.emit("add", message);
		},
		remove: function remove(message) {
			ToastEventBus.emit("remove", message);
		},
		removeGroup: function removeGroup(group) {
			ToastEventBus.emit("remove-group", group);
		},
		removeAllGroups: function removeAllGroups() {
			ToastEventBus.emit("remove-all-groups");
		}
	};
	app.config.globalProperties.$toast = ToastService;
	app.provide(PrimeVueToastSymbol, ToastService);
} };
//#endregion
//#region presets/aura/accordion/index.js
var accordion_default = { accordiontab: {
	root: { class: ["mb-0", "border-b border-surface-200 dark:border-surface-700"] },
	header: ({ props }) => ({ class: [{ "select-none pointer-events-none cursor-default opacity-60": props?.disabled }] }),
	headerAction: { class: [
		"font-semibold",
		"leading-none",
		"flex justify-between items-center",
		"flex-row-reverse",
		"relative",
		"p-[1.125rem]",
		"rounded-md",
		"border-0",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-600 dark:text-surface-0/80",
		"transition duration-200 ease-in-out",
		"transition-shadow duration-200",
		"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
		"cursor-pointer no-underline select-none"
	] },
	headerIcon: ({ context }) => ({ class: ["inline-block ml-2", { "text-surface-900 dark:text-surface-0": context.active }] }),
	headerTitle: { class: "leading-none" },
	content: { class: [
		"p-[1.125rem] pt-0",
		"border-0 rounded-none",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-600 dark:text-surface-0/70"
	] },
	transition: {
		enterFromClass: "max-h-0",
		enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
		enterToClass: "max-h-[1000px]",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
		leaveToClass: "max-h-0"
	}
} };
//#endregion
//#region presets/aura/accordioncontent/index.js
var accordioncontent_default = { content: "p-5 pt-0 bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-surface-0/70" };
//#endregion
//#region presets/aura/accordionheader/index.js
var accordionheader_default = {
	root: ({ context }) => ({ class: ["flex items-center justify-between bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-surface-0/70 p-[1.125rem] font-semibold outline-transparent", { "focus-visible:outline-offset-2 focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400": !context.disabled }] }),
	toggleIcon: "inline-block text-surface-900 dark:text-surface-0 w-4 h-4"
};
//#endregion
//#region presets/aura/accordionpanel/index.js
var accordionpanel_default = { root: ({ props, context }) => ({ class: [
	"flex flex-col border-b border-surface-200 dark:border-surface-700",
	{
		"[&>[data-pc-name=accordionheader]]:select-none [&>[data-pc-name=accordionheader]]:pointer-events-none [&>[data-pc-name=accordionheader]]:cursor-default [&>[data-pc-name=accordionheader]]:opacity-60": props?.disabled,
		"[&>[data-pc-name=accordionheader]]:text-surface-700 dark:[&>[data-pc-name=accordionheader]]:text-surface-100 hover:[&>[data-pc-name=accordionheader]]:text-surface-800 dark:hover:[&>[data-pc-name=accordionheader]]:text-surface-0": !props.disabled && context.active,
		"[&>[data-pc-section=toggleicon]]:text-surface-700 dark:[&>[data-pc-section=toggleicon]]:text-surface-100 hover:[&>[data-pc-section=toggleicon]]:text-surface-800 dark:hover:[&>[data-pc-section=toggleicon]]:text-surface-0": !props.disabled && context.active,
		"[&:last-child>[data-pc-name=accordioncontent]>[data-pc-section=content]]:rounded-b-md": !props.disabled && context.active,
		"[&:last-child>[data-pc-name=accordionheader]]:rounded-b-md": !props.disabled && !context.active
	},
	"[&:nth-child(n+2)>[data-pc-name=accordionheader]]:border-t-0",
	"[&:first-child>[data-pc-name=accordionheader]]:rounded-t-md"
] }) };
//#endregion
//#region presets/aura/autocomplete/index.js
var autocomplete_default = {
	root: ({ props }) => ({ class: [
		"relative",
		{
			flex: props.fluid,
			"inline-flex": !props.fluid
		},
		{ "w-full": props.multiple },
		"text-surface-900 dark:text-surface-0",
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	inputMultiple: ({ props, state }) => ({ class: [
		"leading-none",
		"flex items-center flex-wrap",
		"gap-2",
		"m-0 list-none",
		"py-1 px-1",
		"w-full",
		"appearance-none rounded-md",
		"text-surface-700 dark:text-white/80",
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
		"border",
		{ "border-surface-300 dark:border-surface-700": !props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		{ "hover:border-surface-400 dark:hover:border-surface-700": !props.invalid },
		{ "outline-none outline-offset-0 z-10 ring-1 ring-primary-500 dark:ring-primary-400": state.focused },
		"transition duration-200 ease-in-out",
		"cursor-text overflow-hidden"
	] }),
	inputToken: { class: ["py-1 px-0 ml-2", "inline-flex flex-auto"] },
	inputChip: { class: "flex-auto inline-flex pt-1 pb-1" },
	input: { class: "border-none outline-none bg-transparent m-0 p-0 shadow-none rounded-none w-full" },
	dropdown: { class: [
		"relative",
		"items-center inline-flex justify-center text-center align-bottom",
		"rounded-r-md",
		"py-2 leading-none",
		"w-10",
		"text-primary-contrast",
		"bg-primary",
		"border border-primary",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 ",
		"hover:bg-primary-emphasis hover:border-primary-emphasis",
		"focus:ring-primary-500 dark:focus:ring-primary-400"
	] },
	loader: { class: ["text-surface-500 dark:text-surface-0/70", "absolute top-[50%] right-[0.5rem] -mt-2 animate-spin"] },
	overlay: { class: [
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-300 dark:border-surface-700",
		"rounded-md",
		"shadow-md",
		"overflow-auto"
	] },
	list: { class: "p-1 list-none m-0" },
	option: ({ context }) => ({ class: [
		"relative",
		"leading-none",
		"m-0 px-3 py-2",
		"first:mt-0 mt-[2px]",
		"border-0 rounded",
		{
			"text-surface-700 dark:text-white/80": !context.focused && !context.selected,
			"bg-surface-200 dark:bg-surface-600/60": context.focused && !context.selected,
			"text-surface-700 dark:text-white/80": context.focused && !context.selected,
			"bg-highlight": context.selected
		},
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.focused && !context.selected },
		{ "hover:bg-highlight-emphasis": context.selected },
		{ "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": context.focused && !context.selected },
		"transition-shadow duration-200",
		"cursor-pointer overflow-hidden whitespace-nowrap"
	] }),
	optionGroup: { class: [
		"font-semibold",
		"m-0 py-2 px-3",
		"text-surface-400 dark:text-surface-500",
		"cursor-auto"
	] },
	emptyMessage: { class: [
		"leading-none",
		"py-2 px-3",
		"text-surface-800 dark:text-white/80",
		"bg-transparent"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/avatar/index.js
var avatar_default = {
	root: ({ props, parent }) => ({ class: [
		{
			"text-xl": props.size == "large",
			"text-2xl": props.size == "xlarge"
		},
		"inline-flex items-center justify-center",
		"relative",
		{
			"h-8 w-8": props.size == null || props.size == "normal",
			"w-12 h-12": props.size == "large",
			"w-16 h-16": props.size == "xlarge"
		},
		{ "-ml-4": parent.instance.$style?.name == "avatargroup" },
		{
			"rounded-lg": props.shape == "square",
			"rounded-full": props.shape == "circle"
		},
		{ "border-2": parent.instance.$style?.name == "avatargroup" },
		"bg-surface-300 dark:bg-surface-700",
		{ "border-white dark:border-surface-800": parent.instance.$style?.name == "avatargroup" }
	] }),
	image: ({ props }) => ({ class: ["h-full w-full", {
		"rounded-lg": props.shape == "square",
		"rounded-full": props.shape == "circle"
	}] })
};
//#endregion
//#region presets/aura/avatargroup/index.js
var avatargroup_default = { root: { class: "flex items-center" } };
//#endregion
//#region presets/aura/badge/index.js
var badge_default = { root: ({ props }) => ({ class: [
	"font-bold",
	{
		"text-xs leading-[1.5rem]": props.size === null,
		"text-[0.625rem] leading-[1.25rem]": props.size === "small",
		"text-lg leading-[2.25rem]": props.size === "large",
		"text-2xl leading-[3rem]": props.size === "xlarge"
	},
	"text-center inline-block",
	"p-0 px-1",
	{
		"w-2 h-2": props.value === null,
		"min-w-[1.5rem] h-[1.5rem]": props.value !== null && props.size === null,
		"min-w-[1.25rem] h-[1.25rem]": props.size === "small",
		"min-w-[2.25rem] h-[2.25rem]": props.size === "large",
		"min-w-[3rem] h-[3rem]": props.size === "xlarge"
	},
	{
		"rounded-full": props.value?.length === 1,
		"rounded-[0.71rem]": props.value?.length !== 1
	},
	"text-primary-contrast",
	{
		"bg-primary": props.severity == null || props.severity === "primary",
		"bg-surface-500 dark:bg-surface-400": props.severity === "secondary",
		"bg-green-500 dark:bg-green-400": props.severity === "success",
		"bg-blue-500 dark:bg-blue-400": props.severity === "info",
		"bg-orange-500 dark:bg-orange-400": props.severity === "warn",
		"bg-purple-500 dark:bg-purple-400": props.severity === "help",
		"bg-red-500 dark:bg-red-400": props.severity === "danger",
		"text-surface-0 dark:text-surface-900 bg-surface-900 dark:bg-surface-0": props.severity === "contrast"
	}
] }) };
//#endregion
//#region presets/aura/badgedirective/index.js
var badgedirective_default = { root: ({ context }) => ({ class: [
	"font-bold",
	"text-xs leading-5",
	"flex items-center justify-center",
	"text-center",
	"absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 origin-top-right",
	"m-0",
	{
		"p-0": context.nogutter || context.dot,
		"px-2": !context.nogutter && !context.dot,
		"min-w-[0.5rem] w-2 h-2": context.dot,
		"min-w-[1.5rem] h-6": !context.dot
	},
	{
		"rounded-full": context.nogutter || context.dot,
		"rounded-[10px]": !context.nogutter && !context.dot
	},
	"text-primary-contrast",
	{
		"bg-primary": !context.info && !context.success && !context.warning && !context.danger && !context.help && !context.secondary,
		"bg-surface-500 dark:bg-surface-400": context.secondary,
		"bg-green-500 dark:bg-green-400": context.success,
		"bg-blue-500 dark:bg-blue-400": context.info,
		"bg-orange-500 dark:bg-orange-400": context.warning,
		"bg-purple-500 dark:bg-purple-400": context.help,
		"bg-red-500 dark:bg-red-400": context.danger
	}
] }) };
//#endregion
//#region presets/aura/blockui/index.js
var blockui_default = {
	root: "relative",
	mask: "bg-black/40 rounded-md"
};
//#endregion
//#region presets/aura/breadcrumb/index.js
var breadcrumb_default = {
	root: { class: [
		"rounded-md",
		"p-4",
		"bg-surface-0 dark:bg-surface-900",
		"overflow-x-auto"
	] },
	list: { class: ["flex items-center flex-nowrap", "m-0 p-0 list-none leading-none"] },
	itemLink: { class: [
		"flex items-center gap-2",
		"rounded-md",
		"text-surface-600 dark:text-white/70",
		"focus-visible:outline-none focus-visible:outline-offset-0",
		"focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
		"transition-shadow duration-200",
		"text-decoration-none"
	] },
	itemIcon: { class: "text-surface-600 dark:text-white/70" },
	separator: { class: [
		"flex items-center",
		"mx-2",
		"text-surface-600 dark:text-white/70"
	] }
};
//#endregion
//#region presets/aura/button/index.js
var button_default = {
	root: ({ props, context, parent, instance }) => ({ class: [
		"relative",
		"items-center inline-flex text-center align-bottom justify-center",
		{ "flex-col": (props.iconPos === "top" || props.iconPos === "bottom") && props.label },
		"leading-[normal]",
		{
			"px-3 py-2": props.size === null,
			"text-sm py-1.5 px-3": props.size === "small",
			"text-xl py-3 px-4": props.size === "large"
		},
		{ "gap-2": props.label !== null },
		{ "w-10 px-0 py-2": props.label == null && props.icon !== null },
		{
			"w-10 px-0 gap-0": instance.hasIcon && !props.label && !props.badge,
			"rounded-[50%] h-10 [&>[data-pc-section=label]]:w-0 [&>[data-pc-section=label]]:invisible": instance.hasIcon && !props.label && !props.badge && props.rounded
		},
		{ "shadow-lg": props.raised },
		{
			"rounded-md": !props.rounded,
			"rounded-full": props.rounded
		},
		{ "rounded-none first:rounded-l-md last:rounded-r-md": parent.instance.$name == "InputGroup" },
		{ "text-primary-600 bg-transparent border-transparent": props.link },
		{ "text-white bg-gray-500 border border-gray-500": props.plain && !props.outlined && !props.text },
		{ "text-surface-500": props.plain && props.text },
		{ "text-surface-500 border border-gray-500": props.plain && props.outlined },
		{ "bg-transparent border-transparent": props.text && !props.plain },
		{ "bg-transparent border": props.outlined && !props.plain },
		{
			"text-primary-contrast": !props.link && props.severity === null && !props.text && !props.outlined && !props.plain,
			"bg-primary": !props.link && props.severity === null && !props.text && !props.outlined && !props.plain,
			"border border-primary": !props.link && props.severity === null && !props.text && !props.outlined && !props.plain
		},
		{ "text-primary": props.text && props.severity === null && !props.plain },
		{ "text-primary border border-primary": props.outlined && props.severity === null && !props.plain },
		{
			"text-surface-900 dark:text-white": props.severity === "secondary" && !props.text && !props.outlined && !props.plain,
			"bg-surface-100 dark:bg-surface-700": props.severity === "secondary" && !props.text && !props.outlined && !props.plain,
			"border border-surface-100 dark:border-surface-700": props.severity === "secondary" && !props.text && !props.outlined && !props.plain
		},
		{ "text-surface-500 dark:text-surface-300": props.text && props.severity === "secondary" && !props.plain },
		{ "text-surface-500 dark:text-surface-300 border border-surface-500 hover:bg-surface-300/10": props.outlined && props.severity === "secondary" && !props.plain },
		{
			"text-white dark:text-green-900": props.severity === "success" && !props.text && !props.outlined && !props.plain,
			"bg-green-500 dark:bg-green-400": props.severity === "success" && !props.text && !props.outlined && !props.plain,
			"border border-green-500 dark:border-green-400": props.severity === "success" && !props.text && !props.outlined && !props.plain
		},
		{ "text-green-500 dark:text-green-400": props.text && props.severity === "success" && !props.plain },
		{ "text-green-500 border border-green-500 hover:bg-green-300/10": props.outlined && props.severity === "success" && !props.plain },
		{
			"text-white dark:text-surface-900": props.severity === "info" && !props.text && !props.outlined && !props.plain,
			"bg-blue-500 dark:bg-blue-400": props.severity === "info" && !props.text && !props.outlined && !props.plain,
			"border border-blue-500 dark:border-blue-400": props.severity === "info" && !props.text && !props.outlined && !props.plain
		},
		{ "text-blue-500 dark:text-blue-400": props.text && props.severity === "info" && !props.plain },
		{ "text-blue-500 border border-blue-500 hover:bg-blue-300/10 ": props.outlined && props.severity === "info" && !props.plain },
		{
			"text-white dark:text-surface-900": props.severity === "warn" && !props.text && !props.outlined && !props.plain,
			"bg-orange-500 dark:bg-orange-400": props.severity === "warn" && !props.text && !props.outlined && !props.plain,
			"border border-orange-500 dark:border-orange-400": props.severity === "warn" && !props.text && !props.outlined && !props.plain
		},
		{ "text-orange-500 dark:text-orange-400": props.text && props.severity === "warn" && !props.plain },
		{ "text-orange-500 border border-orange-500 hover:bg-orange-300/10": props.outlined && props.severity === "warn" && !props.plain },
		{
			"text-white dark:text-surface-900": props.severity === "help" && !props.text && !props.outlined && !props.plain,
			"bg-purple-500 dark:bg-purple-400": props.severity === "help" && !props.text && !props.outlined && !props.plain,
			"border border-purple-500 dark:border-purple-400": props.severity === "help" && !props.text && !props.outlined && !props.plain
		},
		{ "text-purple-500 dark:text-purple-400": props.text && props.severity === "help" && !props.plain },
		{ "text-purple-500 border border-purple-500 hover:bg-purple-300/10": props.outlined && props.severity === "help" && !props.plain },
		{
			"text-white dark:text-surface-900": props.severity === "danger" && !props.text && !props.outlined && !props.plain,
			"bg-red-500 dark:bg-red-400": props.severity === "danger" && !props.text && !props.outlined && !props.plain,
			"border border-red-500 dark:border-red-400": props.severity === "danger" && !props.text && !props.outlined && !props.plain
		},
		{ "text-red-500 dark:text-red-400": props.text && props.severity === "danger" && !props.plain },
		{ "text-red-500 border border-red-500 hover:bg-red-300/10": props.outlined && props.severity === "danger" && !props.plain },
		{
			"text-white dark:text-surface-900": props.severity === "contrast" && !props.text && !props.outlined && !props.plain,
			"bg-surface-900 dark:bg-surface-0": props.severity === "contrast" && !props.text && !props.outlined && !props.plain,
			"border border-surface-900 dark:border-surface-0": props.severity === "contrast" && !props.text && !props.outlined && !props.plain
		},
		{ "text-surface-900 dark:text-surface-0": props.text && props.severity === "contrast" && !props.plain },
		{ "text-surface-900 dark:text-surface-0 border border-surface-900 dark:border-surface-0": props.outlined && props.severity === "contrast" && !props.plain },
		"focus:outline-none focus:outline-offset-0 focus:ring-0",
		{ "focus:ring-primary": props.link },
		{ "hover:bg-gray-600 hover:border-gray-600": props.plain && !props.outlined && !props.text },
		{ "hover:bg-surface-300/10": props.plain && (props.text || props.outlined) },
		{ "hover:bg-primary-emphasis hover:border-primary-emphasis": !props.link && props.severity === null && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-primary": props.severity === null },
		{ "hover:bg-primary-300/10": (props.text || props.outlined) && props.severity === null && !props.plain },
		{ "hover:bg-surface-200 dark:hover:bg-surface-600 hover:border-surface-200 dark:hover:border-surface-600": props.severity === "secondary" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-surface-500 dark:focus:ring-surface-400": props.severity === "secondary" },
		{ "hover:bg-surface-300/10": (props.text || props.outlined) && props.severity === "secondary" && !props.plain },
		{ "hover:bg-green-600 dark:hover:bg-green-300 hover:border-green-600 dark:hover:border-green-300": props.severity === "success" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-green-500 dark:focus:ring-green-400": props.severity === "success" },
		{ "hover:bg-green-300/10": (props.text || props.outlined) && props.severity === "success" && !props.plain },
		{ "hover:bg-blue-600 dark:hover:bg-blue-300 hover:border-blue-600 dark:hover:border-blue-300": props.severity === "info" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-blue-500 dark:focus:ring-blue-400": props.severity === "info" },
		{ "hover:bg-blue-300/10": (props.text || props.outlined) && props.severity === "info" && !props.plain },
		{ "hover:bg-orange-600 dark:hover:bg-orange-300 hover:border-orange-600 dark:hover:border-orange-300": props.severity === "warn" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-orange-500 dark:focus:ring-orange-400": props.severity === "warn" },
		{ "hover:bg-orange-300/10": (props.text || props.outlined) && props.severity === "warn" && !props.plain },
		{ "hover:bg-purple-600 dark:hover:bg-purple-300 hover:border-purple-600 dark:hover:border-purple-300": props.severity === "help" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-purple-500 dark:focus:ring-purple-400": props.severity === "help" },
		{ "hover:bg-purple-300/10": (props.text || props.outlined) && props.severity === "help" && !props.plain },
		{ "hover:bg-red-600 dark:hover:bg-red-300 hover:border-red-600 dark:hover:border-red-300": props.severity === "danger" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-red-500 dark:focus:ring-red-400": props.severity === "danger" },
		{ "hover:bg-red-300/10": (props.text || props.outlined) && props.severity === "danger" && !props.plain },
		{ "hover:bg-surface-800 dark:hover:bg-surface-100 hover:border-surface-800 dark:hover:border-surface-100": props.severity === "contrast" && !props.text && !props.outlined && !props.plain },
		{ "focus:ring-surface-500 dark:focus:ring-surface-400": props.severity === "contrast" },
		{ "hover:bg-surface-900/10 dark:hover:bg-[rgba(255,255,255,0.03)]": (props.text || props.outlined) && props.severity === "contrast" && !props.plain },
		{ "opacity-60 pointer-events-none cursor-default": context.disabled },
		"transition duration-200 ease-in-out",
		"cursor-pointer overflow-hidden select-none",
		"[&>[data-pc-name=badge]]:min-w-4 [&>[data-pc-name=badge]]:h-4 [&>[data-pc-name=badge]]:leading-4"
	] }),
	label: ({ props }) => ({ class: [
		"duration-200",
		"font-medium",
		{ "hover:underline": props.link },
		{
			"flex-1": props.label !== null,
			"invisible w-0": props.label == null
		}
	] }),
	icon: ({ props }) => ({ class: [
		"text-base leading-4",
		"mx-0",
		{
			"mr-2": props.iconPos == "left" && props.label != null,
			"ml-2 order-1": props.iconPos == "right" && props.label != null,
			"order-2": props.iconPos == "bottom" && props.label != null
		}
	] }),
	loadingIcon: ({ props }) => ({ class: [
		"h-4 w-4",
		"mx-0",
		{
			"mr-2": props.iconPos == "left" && props.label != null,
			"ml-2 order-1": props.iconPos == "right" && props.label != null,
			"mb-2": props.iconPos == "top" && props.label != null,
			"mt-2": props.iconPos == "bottom" && props.label != null
		},
		"animate-spin"
	] }),
	badge: ({ props }) => ({ class: [{ "ml-2 w-4 h-4 leading-none flex items-center justify-center": props.badge }] })
};
//#endregion
//#region presets/aura/buttongroup/index.js
var buttongroup_default = { root: { class: [
	"[&>[data-pc-name=button]]:m-0",
	"[&>[data-pc-name=button]]:border-r-none",
	"[&>[data-pc-name=button]:nth-last-child(n+2)]:rounded-tr-none",
	"[&>[data-pc-name=button]:nth-last-child(n+2)]:rounded-br-none",
	"[&>[data-pc-name=button]:nth-child(n+2)]:rounded-tl-none",
	"[&>[data-pc-name=button]:nth-child(n+2)]:rounded-bl-none"
] } };
//#endregion
//#region presets/aura/card/index.js
var card_default = {
	root: { class: [
		"flex flex-col",
		"rounded-[12px]",
		"shadow-md",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0"
	] },
	body: { class: [
		"flex flex-col",
		"gap-4",
		"p-6"
	] },
	caption: { class: ["flex flex-col", "gap-2"] },
	title: { class: "text-xl font-semibold mb-0" },
	subtitle: { class: [
		"font-normal",
		"mb-0",
		"text-surface-600 dark:text-surface-0/60"
	] },
	content: { class: "p-0" },
	footer: { class: "p-0" }
};
//#endregion
//#region presets/aura/carousel/index.js
var carousel_default = {
	root: { class: ["flex flex-col"] },
	contentContainer: { class: ["flex flex-col overflow-auto"] },
	content: ({ props }) => ({ class: [
		"flex",
		{
			"flex-row": props.orientation !== "vertical",
			"flex-col": props.orientation == "vertical"
		},
		"[&>[data-pc-extend=button]]:self-center"
	] }),
	viewport: { class: ["overflow-hidden w-full"] },
	itemList: ({ props }) => ({ class: ["flex", {
		"flex-row": props.orientation !== "vertical",
		"flex-col h-full": props.orientation == "vertical"
	}] }),
	item: ({ props }) => ({ class: ["flex shrink-0 grow ", {
		"w-full sm:w-[50%] md:w-[33.333333333333336%]": props.orientation !== "vertical",
		"w-full h-full": props.orientation == "vertical"
	}] }),
	itemClone: ({ props }) => ({ class: [
		"flex shrink-0 grow",
		"unvisible",
		{
			"w-full sm:w-[50%] md:w-[33.333333333333336%]": props.orientation !== "vertical",
			"w-full h-full": props.orientation == "vertical"
		}
	] }),
	indicatorList: { class: ["flex flex-row justify-center flex-wrap"] },
	indicator: { class: ["mr-2 mb-2"] },
	indicatorButton: ({ context }) => ({ class: [
		"w-8 h-2 rounded-md",
		"transition duration-200",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		{
			"bg-surface-200 hover:bg-surface-300 dark:bg-surface-700 dark:hover:bg-surface-600": !context.highlighted,
			"bg-primary hover:bg-primary-emphasis": context.highlighted
		}
	] })
};
//#endregion
//#region presets/aura/cascadeselect/index.js
var cascadeselect_default = {
	root: ({ props, state }) => ({ class: [
		"relative",
		{
			flex: props.fluid,
			"inline-flex": !props.fluid
		},
		"rounded-md",
		{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
		"border",
		{ "border-surface-300 dark:border-surface-600": !props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		"transition-all",
		"duration-200",
		{ "hover:border-surface-400 dark:hover:border-surface-600": !props.invalid },
		{ "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-primary-400": state.focused },
		"cursor-pointer",
		"select-none",
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	label: ({ props }) => ({ class: [
		"leading-none",
		"flex flex-auto",
		"w-[1%]",
		"py-2 px-3",
		"rounded-none",
		"bg-transparent",
		"border-0",
		{
			"text-surface-800 dark:text-white/80": props.modelValue,
			"text-surface-400 dark:text-surface-500": !props.modelValue
		},
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		"transition",
		"duration-200",
		"focus:outline-none focus:shadow-none",
		"relative",
		"cursor-pointer",
		"overflow-hidden overflow-ellipsis",
		"whitespace-nowrap",
		"appearance-none"
	] }),
	dropdown: { class: [
		"flex items-center justify-center",
		"shrink-0",
		"bg-transparent",
		"text-surface-500",
		"w-12",
		"rounded-r-md"
	] },
	overlay: { class: [
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-300 dark:border-surface-700",
		"rounded-md",
		"shadow-md"
	] },
	list: { class: "flex flex-col list-none p-0 m-0 gap-[2px] min-w-full" },
	option: ({ context }) => ({ class: [
		"rounded-[4px]",
		"first:mt-0 mt-[2px]",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		"transition-shadow",
		"duration-200",
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		{ "opacity-60 pointer-events-none cursor-default": context.disabled }
	] }),
	optionContent: { class: [
		"relative",
		"leading-[normal]",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		"no-underline",
		"overflow-hidden",
		"cursor-pointer",
		"select-none"
	] },
	groupIcon: { class: ["ml-auto"] },
	optionList: { class: [
		"min-w-full",
		"p-1",
		"m-0",
		"list-none",
		"shadow-none sm:shadow-md",
		"rounded-md",
		"border border-surface-200 dark:border-surface-700",
		"static sm:absolute",
		"z-10",
		"bg-surface-0 dark:bg-surface-900"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/checkbox/index.js
var checkbox_default = {
	root: { class: [
		"relative",
		"inline-flex",
		"align-bottom",
		"w-5",
		"h-5",
		"cursor-pointer",
		"select-none"
	] },
	box: ({ props, context }) => ({ class: [
		"flex",
		"items-center",
		"justify-center",
		"w-5",
		"h-5",
		"rounded",
		"border",
		{
			"border-surface-300 dark:border-surface-700": !context.checked && !props.invalid,
			"bg-surface-0 dark:bg-surface-950": !context.checked && !props.invalid && !props.disabled,
			"border-primary bg-primary": context.checked
		},
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		{
			"peer-hover:border-surface-400 dark:peer-hover:border-surface-600": !props.disabled && !context.checked && !props.invalid,
			"peer-hover:bg-primary-emphasis peer-hover:border-primary-emphasis": !props.disabled && context.checked,
			"peer-focus-visible:z-10 peer-focus-visible:outline-none peer-focus-visible:outline-offset-0 peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-primary-400": !props.disabled,
			"bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled
		},
		"transition-colors",
		"duration-200"
	] }),
	input: { class: [
		"peer",
		"w-full ",
		"h-full",
		"absolute",
		"top-0 left-0",
		"z-10",
		"p-0",
		"m-0",
		"opacity-0",
		"rounded",
		"outline-none",
		"border border-surface-300 dark:border-surface-700",
		"appearance-none",
		"cursor-pointer"
	] },
	icon: ({ context, state }) => ({ class: [
		"w-[0.875rem]",
		"h-[0.875rem]",
		{
			"text-white dark:text-surface-950": context.checked,
			"text-primary": state.d_indeterminate
		},
		"transition-all",
		"duration-200"
	] })
};
//#endregion
//#region presets/aura/chip/index.js
var chip_default = {
	root: { class: [
		"inline-flex items-center",
		"px-3 py-1 gap-2",
		"rounded-[16px]",
		"text-surface-700 dark:text-white",
		"bg-surface-100 dark:bg-surface-700"
	] },
	label: { class: "leading-6 m-0" },
	icon: { class: "leading-6 mr-2" },
	image: { class: ["w-8 h-8 -ml-2 mr-2", "rounded-full"] },
	removeIcon: { class: [
		"inline-block",
		"rounded-md leading-6",
		"w-4 h-4",
		"transition duration-200 ease-in-out",
		"cursor-pointer"
	] }
};
//#endregion
//#region presets/aura/colorpicker/index.js
var colorpicker_default = {
	root: ({ props }) => ({ class: ["inline-block", { "opacity-60 select-none pointer-events-none cursor-default": props.disabled }] }),
	preview: { class: [
		"text-base leading-none",
		"m-0",
		"p-0",
		"w-6 h-6",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-300 dark:border-surface-700",
		"hover:border-surface-400 dark:hover:border-surface-600",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		"transition-colors duration-200",
		"cursor-pointer"
	] },
	panel: ({ props }) => ({ class: [
		{
			"relative h-[166px] w-[193px]": props.inline,
			"absolute h-[166px] w-[193px]": !props.inline
		},
		"shadow-md border",
		"bg-surface-800 dark:bg-surface-900 border-surface-600 dark:border-surface-700"
	] }),
	colorSelector: { class: ["absolute top-[8px] left-[8px]", "h-[150px] w-[150px]"] },
	color: {
		class: ["h-[150px] w-[150px]"],
		style: "background: linear-gradient(to top, #000 0%, rgb(0 0 0 / 0) 100%), linear-gradient(to right, #fff 0%, rgb(255 255 255 / 0) 100%)"
	},
	colorHandle: { class: [
		"absolute",
		"rounded-full border border-solid",
		"h-[10px] w-[10px]",
		"-ml-[5px] -mt-[5px]",
		"border-white",
		"cursor-pointer opacity-85"
	] },
	hue: {
		class: [
			"absolute top-[8px] left-[167px]",
			"h-[150px] w-[17px]",
			"opacity-85"
		],
		style: "background: linear-gradient(0deg, red 0, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, red)"
	},
	hueHandle: { class: [
		"absolute left-0 -ml-[2px] -mt-[5px]",
		"h-[10px] w-[21px]",
		"border-solid border-2",
		"cursor-pointer opacity-85"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/confirmdialog/index.js
var confirmdialog_default = { icon: "w-8 h-8 text-[2rem] mr-2" };
//#endregion
//#region presets/aura/confirmpopup/index.js
var confirmpopup_default = {
	root: { class: [
		"rounded-lg",
		"shadow-lg",
		"border-0",
		"z-40 transform origin-center",
		"mt-3 absolute left-0 top-0",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80",
		"before:absolute before:w-0 before:-top-3 before:h-0 before:border-transparent before:border-solid before:ml-[calc(var(--overlayArrowLeft,0)+1.25rem)] before:border-x-[10px] before:border-b-[10px] before:border-t-0 before:border-b-surface-200 dark:before:border-b-surface-700",
		"after:absolute after:w-0 after:-top-[0.54rem] after:h-0 after:border-transparent after:border-solid after:ml-[calc(var(--overlayArrowLeft,0)+1.3rem)] after:border-x-[9px] after:border-b-[8px] after:border-t-0 after:border-b-surface-0 dark:after:border-b-surface-900"
	] },
	content: { class: [
		"p-4 items-center flex",
		"rounded-t-lg",
		"border-x border-t last:border-b border-surface-200 dark:border-surface-700"
	] },
	icon: { class: "text-2xl mr-4" },
	footer: { class: [
		"flex items-center justify-end",
		"shrink-0",
		"text-right",
		"gap-2",
		"px-4",
		"pb-4",
		"border-t-0",
		"rounded-b-lg",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80",
		"border-x border-b border-surface-200 dark:border-surface-700"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/contextmenu/index.js
var contextmenu_default = {
	root: { class: [
		"min-w-[12.5rem]",
		"rounded-md",
		"shadow-md",
		"p-1",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-200 dark:border-surface-700"
	] },
	rootList: { class: [
		"flex flex-col",
		"list-none",
		"m-0",
		"p-0",
		"outline-none"
	] },
	item: { class: "relative my-[2px] [&:first-child]:mt-0" },
	itemContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		"transition-shadow",
		"duration-200",
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		{ "opacity-60 pointer-events-none cursor-default": context.disabled }
	] }),
	itemLink: { class: [
		"relative",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		"text-surface-700 dark:text-white/80",
		"no-underline",
		"overflow-hidden",
		"cursor-pointer",
		"select-none"
	] },
	itemIcon: { class: ["mr-2", "text-surface-600 dark:text-white/70"] },
	itemLabel: { class: ["leading-none"] },
	submenu: ({ props }) => ({ class: [
		"flex flex-col",
		"w-full sm:w-48",
		"p-1",
		"m-0",
		"list-none",
		"shadow-md",
		"rounded-md",
		"dark:border dark:border-surface-700",
		"static sm:absolute",
		"z-10",
		{ "sm:absolute sm:left-full sm:top-0": props.level > 1 },
		"bg-surface-0 dark:bg-surface-900"
	] }),
	submenuIcon: { class: ["ml-auto"] },
	separator: { class: "border-t border-surface-200 dark:border-surface-600 my-1" },
	transition: {
		enterFromClass: "opacity-0",
		enterActiveClass: "transition-opacity duration-250"
	}
};
//#endregion
//#region presets/aura/datatable/index.js
var datatable_default = {
	root: ({ props }) => ({ class: [
		"relative",
		{ "flex flex-col": props.scrollable && props.scrollHeight === "flex" },
		{ "h-full": props.scrollable && props.scrollHeight === "flex" }
	] }),
	mask: { class: [
		"absolute",
		"top-0 left-0",
		"z-20",
		"flex items-center justify-center",
		"w-full h-full",
		"bg-surface-100/40 dark:bg-surface-900/40",
		"transition duration-200"
	] },
	loadingIcon: { class: "w-8 h-8 animate-spin" },
	tableContainer: ({ props }) => ({ class: [{
		relative: props.scrollable,
		"flex flex-col grow": props.scrollable && props.scrollHeight === "flex"
	}, { "h-full": props.scrollable && props.scrollHeight === "flex" }] }),
	header: ({ props }) => ({ class: [
		"font-bold",
		props.showGridlines ? "border-x border-t border-b-0" : "border-y border-x-0",
		"p-4",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-200 dark:border-surface-700",
		"text-surface-700 dark:text-white/80"
	] }),
	table: { class: "w-full border-spacing-0 border-separate" },
	thead: ({ context }) => ({ class: [{ "bg-surface-0 dark:bg-surface-900 top-0 z-40 sticky": context.scrollable }] }),
	tbody: ({ instance, context }) => ({ class: [{ "sticky z-20": instance.frozenRow && context.scrollable }, "bg-surface-0 dark:bg-surface-900"] }),
	tfoot: ({ context }) => ({ class: [{ "bg-surface-0 bottom-0 z-0": context.scrollable }] }),
	footer: { class: [
		"font-bold",
		"border-t-0 border-b border-x-0",
		"p-4",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-200 dark:border-surface-700",
		"text-surface-700 dark:text-white/80"
	] },
	column: {
		headerCell: ({ context, props }) => ({ class: [
			"font-semibold",
			"leading-[normal]",
			{ "sticky z-20 border-b": props.frozen || props.frozen === "" },
			{ relative: context.resizable },
			"text-left",
			{ "first:border-l border-y border-r": context?.showGridlines },
			"border-0 border-b border-solid",
			context?.size === "small" ? "py-[0.375rem] px-2" : context?.size === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
			(props.sortable === "" || props.sortable) && context.sorted ? "bg-highlight" : "bg-surface-50 text-surface-700 dark:text-white/80 dark:bg-surface-800",
			"border-surface-200 dark:border-surface-700 ",
			{ "hover:bg-surface-100 dark:hover:bg-surface-800/50": (props.sortable === "" || props.sortable) && !context?.sorted },
			"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
			{ "transition duration-200": props.sortable === "" || props.sortable },
			{ "cursor-pointer": props.sortable === "" || props.sortable },
			{ "overflow-hidden whitespace-nowrap border-y bg-clip-padding": context?.resizable }
		] }),
		columnHeaderContent: { class: "flex items-center gap-2" },
		sort: ({ context }) => ({ class: [context.sorted ? "text-primary-500" : "text-surface-700", context.sorted ? "dark:text-primary-400" : "dark:text-white/80"] }),
		bodyCell: ({ props, context, state, parent }) => ({ class: [
			"leading-[normal]",
			{ "sticky box-border border-b": parent.instance.frozenRow },
			{ "sticky box-border border-b z-20": props.frozen || props.frozen === "" },
			"text-left",
			"border-0 border-b border-solid",
			{ "first:border-l border-r border-b": context?.showGridlines },
			{ "bg-surface-0 dark:bg-surface-900": parent.instance.frozenRow || props.frozen || props.frozen === "" },
			{ "py-[0.375rem] px-2": context?.size === "small" && !state["d_editing"] },
			{ "py-[0.9375rem] px-5": context?.size === "large" && !state["d_editing"] },
			{ "py-3 px-4": context?.size !== "large" && context?.size !== "small" && !state["d_editing"] },
			{ "py-[0.6rem] px-2": state["d_editing"] },
			"border-surface-200 dark:border-surface-700",
			{ "overflow-hidden whitespace-nowrap border-y bg-clip-padding": parent.instance?.$parentInstance?.$parentInstance?.resizableColumns }
		] }),
		footerCell: ({ context }) => ({ class: [
			"font-bold",
			"text-left",
			"border-0 border-b border-solid",
			{ "border-x border-y": context?.showGridlines },
			context?.size === "small" ? "p-2" : context?.size === "large" ? "p-5" : "p-4",
			"border-surface-200 dark:border-surface-700",
			"text-surface-700 dark:text-white/80",
			"bg-surface-0 dark:bg-surface-900"
		] }),
		sortIcon: ({ context }) => ({ class: ["ml-2", context.sorted ? "text-inherit" : "text-surface-700 dark:text-white/70"] }),
		columnFilter: { class: "inline-flex items-center ml-auto font-normal" },
		filterOverlay: { class: [
			"flex flex-col gap-2",
			"absolute top-0 left-0",
			"border-0 dark:border",
			"rounded-md",
			"shadow-md",
			"min-w-[12.5rem]",
			"bg-surface-0 dark:bg-surface-900",
			"text-surface-800 dark:text-white/80",
			"dark:border-surface-700"
		] },
		filterConstraintList: { class: "m-0 p-0 py-3 list-none" },
		filterConstraint: ({ context }) => ({ class: [
			"font-normal",
			"leading-none",
			"relative",
			"border-0",
			"rounded-none",
			"m-0",
			"py-3 px-5",
			{ "text-surface-700 dark:text-white/80": !context?.highlighted },
			{ "bg-surface-0 dark:bg-surface-900 text-surface-700 dark:text-white/80": !context?.highlighted },
			{ "bg-highlight": context?.highlighted },
			{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context?.highlighted },
			{ "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": !context?.highlighted },
			"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
			"transition-shadow",
			"duration-200",
			"cursor-pointer",
			"overflow-hidden",
			"whitespace-nowrap"
		] }),
		filterOperator: { class: [
			"rounded-t-md",
			"text-surface-700 dark:text-white/80",
			"bg-surface-0 dark:bg-surface-700",
			"[&>[data-pc-name=pcfilteroperatordropdown]]:w-full"
		] },
		filter: ({ instance }) => ({ class: [{
			"flex items-center w-full gap-2": instance.display === "row",
			"inline-flex ml-auto": instance.display === "menu"
		}] }),
		filterRule: "flex flex-col gap-2",
		filterButtonbar: "flex items-center justify-between p-0",
		filterAddButtonContainer: "[&>[data-pc-name=pcfilteraddrulebutton]]:w-full",
		rowToggleButton: { class: [
			"relative",
			"inline-flex items-center justify-center",
			"text-left",
			"m-0 p-0",
			"w-8 h-8",
			"border-0 rounded-full",
			"text-surface-500 dark:text-white/70",
			"bg-transparent",
			"focus-visible:outline-none focus-visible:outline-offset-0",
			"focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
			"transition duration-200",
			"overflow-hidden",
			"cursor-pointer select-none"
		] },
		columnResizer: { class: [
			"block",
			"absolute top-0 right-0",
			"w-2 h-full",
			"m-0 p-0",
			"border border-transparent",
			"cursor-col-resize"
		] },
		transition: {
			class: "p-4 flex flex-col gap-2",
			enterFromClass: "opacity-0 scale-y-[0.8]",
			enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
			leaveActiveClass: "transition-opacity duration-100 ease-linear",
			leaveToClass: "opacity-0"
		}
	},
	bodyRow: ({ context, props }) => ({ class: [
		"dark:text-white/80",
		{ "bg-highlight": context.selected && props.highlightOnSelect },
		{ "bg-surface-0 text-surface-600 dark:bg-surface-900": !context.selected },
		{ "font-bold bg-surface-0 dark:bg-surface-900 z-20": props.frozenRow },
		{ "odd:bg-surface-0 odd:text-surface-600 dark:odd:bg-surface-900 even:bg-surface-50 even:text-surface-600 dark:even:bg-surface-800/50": context.stripedRows },
		{ "hover:bg-surface-300/20 dark:hover:bg-surface-800/50 hover:text-surface-600": props.selectionMode && !context.selected },
		{ "transition duration-200": props.selectionMode && !context.selected || props.rowHover },
		{ "cursor-pointer": props.selectionMode }
	] }),
	rowExpansion: { class: "bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-white/80" },
	rowGroupHeader: { class: [
		"sticky z-20",
		"bg-surface-0 text-surface-600 dark:text-white/70",
		"dark:bg-surface-900"
	] },
	rowGroupFooter: { class: [
		"sticky z-20",
		"bg-surface-0 text-surface-600 dark:text-white/70",
		"dark:bg-surface-900"
	] },
	rowToggleButton: { class: [
		"relative",
		"inline-flex items-center justify-center",
		"text-left",
		"m-0 p-0",
		"w-8 h-8",
		"border-0 rounded-full",
		"text-surface-500 dark:text-white/70",
		"bg-transparent",
		"focus-visible:outline-none focus-visible:outline-offset-0",
		"focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
		"transition duration-200",
		"overflow-hidden",
		"cursor-pointer select-none"
	] },
	rowToggleIcon: { class: "inline-block w-4 h-4" },
	columnResizeIndicator: { class: "absolute hidden w-[2px] z-20 bg-primary" }
};
//#endregion
//#region presets/aura/dataview/index.js
var dataview_default = {
	content: { class: [
		"p-0",
		"border-0",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900"
	] },
	header: { class: [
		"font-semibold",
		"py-3 px-4",
		"text-surface-800 dark:text-white/80",
		"bg-surface-00 dark:bg-surface-900",
		"border-b border-surface-200 dark:border-surface-700"
	] }
};
//#endregion
//#region presets/aura/datepicker/index.js
var datepicker_default = {
	root: ({ props }) => ({ class: [
		{
			flex: props.fluid,
			"inline-flex": !props.fluid
		},
		"max-w-full",
		"relative"
	] }),
	pcInput: ({ props, parent }) => ({ root: { class: [
		"flex-auto w-[1%]",
		"leading-none",
		"text-surface-600 dark:text-surface-200",
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
		"border",
		{ "border-surface-300 dark:border-surface-600": !props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		"m-0 py-2 px-3",
		"appearance-none",
		{ "rounded-md": !props.showIcon || props.iconDisplay == "input" },
		{ "rounded-l-md  flex-1 pr-9": props.showIcon && props.iconDisplay !== "input" },
		{ "rounded-md flex-1 pr-9": props.showIcon && props.iconDisplay === "input" },
		"transition-colors",
		"duration-200",
		{
			"hover:border-surface-400 dark:hover:border-surface-600": !props.disabled && !props.invalid,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !props.disabled,
			"bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled
		},
		{ filled: parent.instance?.$name == "FloatLabel" && props.modelValue !== null }
	] } }),
	dropdownIcon: { class: [
		"absolute top-1/2 -mt-2",
		"text-surface-600 dark:text-surface-200",
		"right-3"
	] },
	dropdown: { class: [
		"relative",
		"items-center inline-flex text-center align-bottom justify-center",
		"rounded-r-md",
		"py-2 px-0",
		"w-10",
		"leading-[normal]",
		"border border-l-0 border-surface-300 dark:border-surface-600",
		"focus:outline-none focus:outline-offset-0 focus:ring-1",
		"hover:bg-primary-hover hover:border-primary-hover",
		"focus:ring-primary-500 dark:focus:ring-primary-400"
	] },
	inputIconContainer: "absolute cursor-pointer top-1/2 right-3 -mt-3",
	inputIcon: "inline-block text-base",
	panel: ({ props }) => ({ class: [
		{
			absolute: !props.inline,
			"inline-block": props.inline
		},
		{ "w-auto p-3 ": !props.inline },
		{ "min-w-[80vw] w-auto p-3 ": props.touchUI },
		{ "p-3 min-w-full": props.inline },
		"border rounded-lg",
		{ "shadow-md": !props.inline },
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-200 dark:border-surface-700",
		{ "overflow-x-auto": props.inline }
	] }),
	header: { class: [
		"font-medium",
		"flex items-center justify-between",
		"p-0 pb-2",
		"m-0",
		"border-b",
		"rounded-t-md",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-200 dark:border-surface-700"
	] },
	title: { class: ["leading-7", "mx-auto my-0"] },
	selectMonth: { class: [
		"text-base leading-[normal]",
		"font-medium",
		"rounded-md",
		"text-surface-700 dark:text-white/80",
		"transition duration-200",
		"p-1",
		"m-0 mr-2",
		"hover:text-primary-500 dark:hover:text-primary-400",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		"cursor-pointer"
	] },
	selectYear: { class: [
		"text-base leading-[normal]",
		"font-medium",
		"rounded-md",
		"text-surface-700 dark:text-white/80",
		"transition duration-200",
		"p-1",
		"m-0 mr-2",
		"hover:text-primary-500 dark:hover:text-primary-400",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		"cursor-pointer"
	] },
	table: { class: [
		"text-base leading-[normal]",
		"border-collapse",
		"w-full",
		"m-0 mt-2"
	] },
	tableHeaderCell: { class: ["p-1", "font-medium"] },
	weekHeader: { class: [
		"leading-5",
		"text-surface-600 dark:text-white/70",
		"opacity-60 cursor-default"
	] },
	weekNumber: { class: ["text-surface-600 dark:text-white/70", "opacity-60 cursor-default"] },
	weekday: { class: ["text-surface-500 dark:text-white/60", "p-1"] },
	dayCell: { class: ["p-1"] },
	weekLabelContainer: { class: [
		"flex items-center justify-center",
		"mx-auto",
		"w-8 h-8",
		"rounded-full",
		"border-transparent border",
		"leading-[normal]",
		"opacity-60 cursor-default"
	] },
	dayView: "w-full",
	day: ({ context }) => ({ class: [
		"flex items-center justify-center",
		"mx-auto",
		"w-8 h-8",
		"rounded-full",
		"border-transparent border",
		"leading-[normal]",
		{
			"bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-white/70": context.date.today && !context.selected && !context.disabled,
			"bg-transparent text-surface-600 dark:text-white/70": !context.selected && !context.disabled && !context.date.today,
			"bg-highlight": context.selected && !context.disabled
		},
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		{ "hover:bg-surface-50 dark:hover:bg-surface-500/10": !context.selected && !context.disabled },
		{
			"opacity-60 cursor-default": context.disabled,
			"cursor-pointer": !context.disabled
		}
	] }),
	monthView: { class: ["mt-2"] },
	month: ({ context }) => ({ class: [
		"inline-flex items-center justify-center",
		"w-1/3",
		"p-1",
		"rounded-md",
		{
			"text-surface-600 dark:text-white/70 bg-transparent": !context.selected && !context.disabled,
			"bg-highlight": context.selected && !context.disabled
		},
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.selected && !context.disabled },
		"cursor-pointer"
	] }),
	yearView: { class: ["mt-2"] },
	year: ({ context }) => ({ class: [
		"inline-flex items-center justify-center",
		"w-1/2",
		"p-1",
		"rounded-md",
		{
			"text-surface-600 dark:text-white/70 bg-transparent": !context.selected && !context.disabled,
			"bg-highlight": context.selected && !context.disabled
		},
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.selected && !context.disabled },
		"cursor-pointer"
	] }),
	timePicker: { class: [
		"flex",
		"justify-center items-center",
		"border-t-1",
		"border-solid border-surface-200",
		"pt-2 mt-2"
	] },
	separatorContainer: { class: [
		"flex",
		"items-center",
		"flex-col",
		"px-2"
	] },
	separator: { class: ["text-xl"] },
	hourPicker: { class: [
		"flex",
		"items-center",
		"flex-col",
		"px-2"
	] },
	minutePicker: { class: [
		"flex",
		"items-center",
		"flex-col",
		"px-2"
	] },
	secondPicker: { class: [
		"flex",
		"items-center",
		"flex-col",
		"px-2"
	] },
	ampmPicker: { class: [
		"flex",
		"items-center",
		"flex-col",
		"px-2"
	] },
	calendarContainer: "flex",
	calendar: "flex-auto border-l first:border-l-0 border-surface-200",
	buttonbar: { class: [
		"flex justify-between items-center",
		"pt-2",
		"border-t border-surface-200 dark:border-surface-700"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/deferred/index.js
var deferred_default = { root: {} };
//#endregion
//#region presets/aura/dialog/index.js
var dialog_default = {
	root: ({ state }) => ({ class: [
		"rounded-lg",
		"shadow-lg",
		"border-0",
		"max-h-[90vh]",
		"m-0",
		"bg-surface-0 dark:bg-surface-900",
		"[&:last-child]:border-b",
		"border-surface-200 dark:border-surface-700",
		"transform",
		"scale-100",
		{
			"transition-none": state.maximized,
			"transform-none": state.maximized,
			"!w-screen": state.maximized,
			"!h-screen": state.maximized,
			"!max-h-full": state.maximized,
			"!top-0": state.maximized,
			"!left-0": state.maximized
		}
	] }),
	header: { class: [
		"flex items-center justify-between",
		"shrink-0",
		"p-6",
		"rounded-tl-lg",
		"rounded-tr-lg",
		"text-surface-700 dark:text-surface-0/80",
		"border border-b-0",
		"border-surface-200 dark:border-surface-700"
	] },
	title: { class: ["font-semibold text-xl leading-[normal]"] },
	headerActions: { class: ["flex items-center"] },
	content: ({ state, instance }) => ({ class: [
		"px-6",
		"pb-6",
		"pt-0",
		{
			grow: state.maximized,
			"rounded-bl-lg": !instance.$slots.footer,
			"rounded-br-lg": !instance.$slots.footer
		},
		"text-surface-700 dark:text-surface-0/80",
		"border border-t-0 border-b-0",
		"border-surface-200 dark:border-surface-700",
		"overflow-y-auto"
	] }),
	footer: { class: [
		"flex items-center justify-end",
		"shrink-0",
		"text-right",
		"gap-2",
		"px-6",
		"pb-6",
		"border-t-0",
		"rounded-b-lg",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80",
		"border border-t-0 border-b-0",
		"border-surface-200 dark:border-surface-700"
	] },
	mask: ({ props }) => ({ class: [
		"transition-all",
		"duration-300",
		{ "p-5": !props.position == "full" },
		{ "has-[.mask-active]:bg-transparent bg-black/40": props.modal }
	] }),
	transition: ({ props }) => {
		return props.position === "top" ? {
			enterFromClass: "opacity-0 scale-75 translate-x-0 -translate-y-full translate-z-0 mask-active",
			enterActiveClass: "transition-all duration-200 ease-out",
			leaveActiveClass: "transition-all duration-200 ease-out",
			leaveToClass: "opacity-0 scale-75 translate-x-0 -translate-y-full translate-z-0 mask-active"
		} : props.position === "bottom" ? {
			enterFromClass: "opacity-0 scale-75 translate-y-full mask-active",
			enterActiveClass: "transition-all duration-200 ease-out",
			leaveActiveClass: "transition-all duration-200 ease-out",
			leaveToClass: "opacity-0 scale-75 translate-x-0 translate-y-full translate-z-0 mask-active"
		} : props.position === "left" || props.position === "topleft" || props.position === "bottomleft" ? {
			enterFromClass: "opacity-0 scale-75 -translate-x-full translate-y-0 translate-z-0 mask-active",
			enterActiveClass: "transition-all duration-200 ease-out",
			leaveActiveClass: "transition-all duration-200 ease-out",
			leaveToClass: "opacity-0 scale-75  -translate-x-full translate-y-0 translate-z-0 mask-active"
		} : props.position === "right" || props.position === "topright" || props.position === "bottomright" ? {
			enterFromClass: "opacity-0 scale-75 translate-x-full translate-y-0 translate-z-0 mask-active",
			enterActiveClass: "transition-all duration-200 ease-out",
			leaveActiveClass: "transition-all duration-200 ease-out",
			leaveToClass: "opacity-0 scale-75 translate-x-full translate-y-0 translate-z-0 mask-active"
		} : {
			enterFromClass: "opacity-0 scale-75 mask-active",
			enterActiveClass: "transition-all duration-200 ease-out",
			leaveActiveClass: "transition-all duration-200 ease-out",
			leaveToClass: "opacity-0 scale-75 mask-active"
		};
	}
};
//#endregion
//#region presets/aura/divider/index.js
var divider_default = {
	root: ({ props }) => ({ class: [
		"flex relative",
		{ "justify-center": props.layout == "vertical" },
		{ "items-center": props.layout == "vertical" },
		{
			"justify-start": props?.align == "left" && props.layout == "horizontal",
			"justify-center": props?.align == "center" && props.layout == "horizontal",
			"justify-end": props?.align == "right" && props.layout == "horizontal",
			"items-center": props?.align == "top" && props.layout == "vertical",
			"items-start": props?.align == "center" && props.layout == "vertical",
			"items-end": props?.align == "bottom" && props.layout == "vertical"
		},
		{
			"my-5 mx-0 py-0 px-5": props.layout == "horizontal",
			"mx-4 md:mx-5 py-5": props.layout == "vertical"
		},
		{
			"w-full": props.layout == "horizontal",
			"min-h-full": props.layout == "vertical"
		},
		"before:block",
		{
			"before:absolute before:left-0 before:top-1/2": props.layout == "horizontal",
			"before:absolute before:left-1/2 before:top-0 before:transform before:-translate-x-1/2": props.layout == "vertical"
		},
		{
			"before:w-full": props.layout == "horizontal",
			"before:min-h-full": props.layout == "vertical"
		},
		{
			"before:border-solid": props.type == "solid",
			"before:border-dotted": props.type == "dotted",
			"before:border-dashed": props.type == "dashed"
		},
		{
			"before:border-t before:border-surface-200 before:dark:border-surface-600": props.layout == "horizontal",
			"before:border-l before:border-surface-200 before:dark:border-surface-600": props.layout == "vertical"
		}
	] }),
	content: { class: ["px-1 z-10", "bg-surface-0 dark:bg-surface-800"] }
};
//#endregion
//#region presets/aura/dock/index.js
var dock_default = {
	root: ({ props }) => ({ class: [
		"absolute z-1",
		{
			"left-0 bottom-0 w-full": props.position == "bottom",
			"left-0 top-0 w-full": props.position == "top",
			"left-0 top-0 h-full": props.position == "left",
			"right-0 top-0 h-full": props.position == "right"
		},
		"flex justify-center items-center",
		"pointer-events-none"
	] }),
	listContainer: { class: [
		"flex",
		"rounded-md",
		"bg-surface-0/10 dark:bg-surface-900/20 border border-surface-0/20",
		"backdrop-blur-sm",
		"p-2",
		"pointer-events-auto"
	] },
	list: ({ props }) => ({ class: [
		"flex items-center justify-center",
		{ "flex-col": props.position == "left" || props.position == "right" },
		"m-0 p-0 list-none",
		"outline-none"
	] }),
	item: ({ props, context, instance }) => ({ class: [
		"p-2 rounded-md",
		{
			"origin-bottom": props.position == "bottom",
			"origin-top": props.position == "top",
			"origin-left": props.position == "left",
			"origin-right": props.position == "right"
		},
		"transition-all duration-200 ease-cubic-bezier-will-change-transform transform"
	] }),
	itemLink: { class: [
		"flex flex-col items-center justify-center",
		"relative",
		"w-16 h-16",
		"cursor-default overflow-hidden"
	] }
};
//#endregion
//#region presets/aura/drawer/index.js
var drawer_default = {
	root: ({ props }) => ({ class: [
		"flex flex-col",
		"relative",
		{ "!transition-none !transform-none !w-screen !h-screen !max-h-full !top-0 !left-0": props.position == "full" },
		{
			"h-full w-80": props.position == "left" || props.position == "right",
			"h-auto w-full": props.position == "top" || props.position == "bottom"
		},
		"border-0 dark:border",
		"shadow-lg",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"dark:border-surface-700",
		"transition-transform",
		"duration-300",
		"pointer-events-auto"
	] }),
	header: { class: [
		"flex items-center justify-between",
		"shrink-0",
		"p-[1.125rem]",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80"
	] },
	title: { class: ["font-semibold text-xl"] },
	icons: { class: ["flex items-center"] },
	closeButton: { class: [
		"relative",
		"flex items-center justify-center",
		"mr-2",
		"last:mr-0",
		"w-7 h-7",
		"border-0",
		"rounded-full",
		"text-surface-500",
		"bg-transparent",
		"transition duration-200 ease-in-out",
		"hover:text-surface-700 dark:hover:text-white/80",
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0 focus:ring-1",
		"focus:ring-primary-500 dark:focus:ring-primary-400",
		"overflow-hidden"
	] },
	closeButtonIcon: { class: [
		"inline-block",
		"w-4",
		"h-4"
	] },
	content: { class: [
		"p-[1.125rem]",
		"pt-0",
		"h-full",
		"w-full",
		"grow",
		"overflow-y-auto"
	] },
	mask: ({ props }) => ({ class: [
		"transition-all",
		"duration-300",
		{ "p-5": !props.position == "full" },
		{ "has-[.mask-active]:bg-transparent bg-black/40": props.modal }
	] }),
	transition: ({ props }) => {
		return props.position === "top" ? {
			enterFromClass: "translate-x-0 -translate-y-full translate-z-0 mask-active",
			leaveToClass: "translate-x-0 -translate-y-full translate-z-0 mask-active"
		} : props.position === "bottom" ? {
			enterFromClass: "translate-x-0 translate-y-full translate-z-0 mask-active",
			leaveToClass: "translate-x-0 translate-y-full translate-z-0 mask-active"
		} : props.position === "left" ? {
			enterFromClass: "-translate-x-full translate-y-0 translate-z-0 mask-active",
			leaveToClass: "-translate-x-full translate-y-0 translate-z-0 mask-active"
		} : props.position === "right" ? {
			enterFromClass: "translate-x-full translate-y-0 translate-z-0 mask-active",
			leaveToClass: "translate-x-full translate-y-0 translate-z-0 mask-active"
		} : {
			enterFromClass: "opacity-0 mask-active",
			enterActiveClass: "transition-opacity duration-400 ease-in",
			leaveActiveClass: "transition-opacity duration-400 ease-in",
			leaveToClass: "opacity-0 mask-active"
		};
	}
};
//#endregion
//#region presets/aura/fieldset/index.js
var fieldset_default = {
	root: { class: [
		"p-[1.125rem] pt-0",
		"rounded-md",
		"border border-surface-200 dark:border-surface-700",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80"
	] },
	legend: ({ props }) => ({ class: [
		"font-semibold",
		"leading-none",
		"p-0 mb-[0.375rem]",
		"rounded-md",
		"text-surface-700 dark:text-surface-0/80",
		"bg-surface-0 dark:bg-surface-900",
		"transition-none",
		{ "hover:bg-surface-100 dark:hover:bg-surface-800": props.toggleable }
	] }),
	toggleButton: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"relative",
		{ "py-2 px-3": props.toggleable },
		{ "rounded-md": props.toggleable },
		{ "text-surface-700 dark:text-surface-200 hover:text-surface-900": props.toggleable },
		{ "hover:text-surface-900 dark:hover:text-surface-100": props.toggleable },
		{ "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300": props.toggleable },
		{ "transition-none cursor-pointer overflow-hidden select-none": props.toggleable }
	] }),
	toggleIcon: { class: "mr-2 inline-block" },
	legendLabel: ({ props }) => ({ class: ["flex items-center justify-center leading-none", { "py-2 px-3": !props.toggleable }] }),
	content: { class: "p-0" },
	transition: {
		enterFromClass: "max-h-0",
		enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
		enterToClass: "max-h-[1000px]",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
		leaveToClass: "max-h-0"
	}
};
//#endregion
//#region presets/aura/fileupload/index.js
var fileupload_default = {
	root: ({ props }) => ({ class: [{ "flex flex-wrap items-center justify-center gap-2": props.mode === "basic" }] }),
	input: { class: "hidden" },
	header: { class: [
		"flex",
		"flex-wrap",
		"bg-surface-0",
		"dark:bg-surface-900",
		"text-surface-700",
		"dark:text-white/80",
		"p-[1.125rem]",
		"gap-2",
		"border",
		"border-solid",
		"border-surface-200",
		"dark:border-surface-700",
		"border-b-0",
		"rounded-tr-lg",
		"rounded-tl-lg"
	] },
	content: { class: [
		"relative",
		"bg-surface-0",
		"dark:bg-surface-900",
		"text-surface-700",
		"dark:text-white/80",
		"p-[1.125rem]",
		"border border-t-0",
		"border-surface-200",
		"dark:border-surface-700",
		"rounded-b-lg",
		"[&>[data-pc-name=pcprogressbar]]:absolute",
		"[&>[data-pc-name=pcprogressbar]]:w-full",
		"[&>[data-pc-name=pcprogressbar]]:top-0",
		"[&>[data-pc-name=pcprogressbar]]:left-0",
		"[&>[data-pc-name=pcprogressbar]]:h-1"
	] },
	file: { class: [
		"flex",
		"items-center",
		"flex-wrap",
		"p-4",
		"mb-2",
		"last:mb-0",
		"border",
		"border-surface-200",
		"dark:border-surface-700",
		"gap-2",
		"rounded"
	] },
	fileThumbnail: "shrink-0",
	fileName: "mb-2 break-all",
	fileSize: "mr-2"
};
//#endregion
//#region presets/aura/floatlabel/index.js
var floatlabel_default = { root: { class: [
	"block relative",
	"[&>*:last-child]:text-surface-900/60 dark:[&>*:last-child]:text-white/60",
	"[&>*:last-child]:absolute",
	"[&>*:last-child]:top-1/2",
	"[&>*:last-child]:-translate-y-1/2",
	"[&>*:last-child]:left-3",
	"[&>*:last-child]:pointer-events-none",
	"[&>*:last-child]:transition-all",
	"[&>*:last-child]:duration-200",
	"[&>*:last-child]:ease",
	"[&>*:last-child]:has-[:focus]:-top-3",
	"[&>*:last-child]:has-[:focus]:text-sm",
	"[&>*:last-child]:has-[.filled]:-top-3",
	"[&>*:last-child]:has-[.filled]:text-sm"
] } };
//#endregion
//#region presets/aura/galleria/index.js
var galleria_default = {
	content: ({ parent, props }) => ({ class: [
		"flex",
		{ "flex-col": props.fullScreen },
		{
			"flex-col": parent.props.thumbnailsPosition === "top" || parent.props.thumbnailsPosition === "bottom",
			"flex-row": parent.props.thumbnailsPosition === "right" || parent.props.thumbnailsPosition === "left"
		}
	] }),
	itemsContainer: ({ parent, props }) => ({ class: [
		"group",
		"flex relative",
		{ "grow shrink w-0 justify-center": props.fullScreen },
		{
			"flex-col": parent.props.indicatorsPosition === "bottom" || parent.props.indicatorsPosition === "top",
			"flex-row items-center": parent.props.indicatorsPosition === "left" || parent.props.indicatorsPosition === "right"
		},
		{
			"order-2": parent.props.thumbnailsPosition === "top" || parent.props.thumbnailsPosition === "left",
			"flex-row": parent.props.thumbnailsPosition === "right"
		}
	] }),
	items: ({ parent }) => ({ class: ["flex h-full relative", {
		"order-1": parent.props.indicatorsPosition === "bottom" || parent.props.indicatorsPosition === "right",
		"order-2": parent.props.indicatorsPosition === "top" || parent.props.indicatorsPosition === "left"
	}] }),
	item: { class: ["flex justify-center items-center h-full w-full", "h-full w-full"] },
	thumbnails: ({ parent }) => ({ class: [
		"flex flex-col shrink-0",
		{ "order-1": parent.props.thumbnailsPosition === "top" || parent.props.thumbnailsPosition === "left" },
		"overflow-auto"
	] }),
	thumbnailContent: ({ parent }) => ({ class: [
		"flex",
		"py-4 px-1",
		"bg-black/90",
		{
			"flex-row": parent.props.thumbnailsPosition === "top" || parent.props.thumbnailsPosition === "bottom",
			"flex-col grow": parent.props.thumbnailsPosition === "right" || parent.props.thumbnailsPosition === "left"
		}
	] }),
	thumbnailPrevButton: { class: [
		"self-center relative",
		"flex shrink-0 justify-center items-center overflow-hidden",
		"m-2",
		"bg-transparent text-white w-8 h-8 rounded-full transition duration-200 ease-in-out",
		"hover:bg-surface-0/10 hover:text-white",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
	] },
	thumbnailsViewport: { class: "overflow-hidden w-full" },
	thumbnailItems: ({ parent }) => ({ class: ["flex", { "flex-col h-full": parent.props.thumbnailsPosition === "right" || parent.props.thumbnailsPosition === "left" }] }),
	thumbnailItem: ({ parent }) => ({ class: [
		"flex items-center justify-center",
		"grow shrink-0",
		{ "w-full md:w-[25%] lg:w-[20%]": parent.props.thumbnailsPosition === "top" || parent.props.thumbnailsPosition === "bottom" },
		"overflow-auto",
		"cursor-pointer",
		"opacity-50",
		"[&[data-p-active=\"true\"]]:opacity-100",
		"hover:opacity-100",
		"transition-opacity duration-300"
	] }),
	thumbnailNextButton: { class: [
		"self-center relative",
		"flex shrink-0 justify-center items-center overflow-hidden",
		"m-2",
		"bg-transparent text-white w-8 h-8 rounded-full transition duration-200 ease-in-out",
		"hover:bg-surface-0/10 hover:text-white",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
	] },
	indicatorList: ({ parent }) => ({ class: [
		"flex items-center justify-center",
		"p-4",
		{
			"order-2": parent.props.indicatorsPosition == "bottom",
			"order-1": parent.props.indicatorsPosition == "top",
			"order-1 flex-col": parent.props.indicatorsPosition == "left",
			"flex-col order-2": parent.props.indicatorsPosition == "right"
		},
		{ "absolute z-10 bg-black/50": parent.props.showIndicatorsOnItem },
		{
			"bottom-0 left-0 w-full items-start": parent.props.indicatorsPosition == "bottom" && parent.props.showIndicatorsOnItem,
			"top-0 left-0 w-full items-start": parent.props.indicatorsPosition == "top" && parent.props.showIndicatorsOnItem,
			"left-0 top-0 h-full items-start": parent.props.indicatorsPosition == "left" && parent.props.showIndicatorsOnItem,
			"right-0 top-0 h-full items-start": parent.props.indicatorsPosition == "right" && parent.props.showIndicatorsOnItem
		}
	] }),
	indicator: ({ parent }) => ({ class: [{
		"mr-2": parent.props.indicatorsPosition == "bottom" || parent.props.indicatorsPosition == "top",
		"mb-2": parent.props.indicatorsPosition == "left" || parent.props.indicatorsPosition == "right"
	}] }),
	indicatorButton: ({ context }) => ({ class: [
		"w-4 h-4",
		"rounded-full transition duration-200",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		{ "bg-surface-200 hover:bg-surface-300 dark:bg-surface-700 dark:hover:bg-surface-600": !context.highlighted },
		{ "bg-primary hover:bg-primary-emphasis": context.highlighted }
	] }),
	mask: { class: [
		"fixed top-0 left-0 w-full h-full",
		"flex items-center justify-center",
		"bg-black/90"
	] },
	closeButton: { class: [
		"!absolute top-0 right-0",
		"flex justify-center items-center overflow-hidden",
		"m-2",
		"text-white bg-transparent w-12 h-12 rounded-full transition duration-200 ease-in-out",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
	] },
	closeIcon: { class: "w-6 h-6" },
	prevButton: ({ parent }) => ({ class: [
		"inline-flex justify-center items-center overflow-hidden",
		"bg-transparent text-white w-16 h-16 transition duration-200 ease-in-out rounded-md",
		{ "opacity-0 group-hover:opacity-100": parent.props.showItemNavigatorsOnHover },
		"mx-2",
		"top-1/2 mt-[-0.5rem] left-0",
		{
			"!absolute": !parent.state.containerVisible && parent.props.showItemNavigators,
			"!fixed": parent.state.containerVisible
		},
		"hover:bg-surface-0/10 hover:text-white",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
	] }),
	nextButton: ({ parent }) => ({ class: [
		"inline-flex justify-center items-center overflow-hidden",
		"bg-transparent text-white w-16 h-16 transition duration-200 ease-in-out rounded-md",
		{ "opacity-0 group-hover:opacity-100": parent.props.showItemNavigatorsOnHover },
		"mx-2",
		"top-1/2 mt-[-0.5rem] right-0",
		{
			"!absolute": !parent.state.containerVisible && parent.props.showItemNavigators,
			"!fixed": parent.state.containerVisible
		},
		"hover:bg-surface-0/10 hover:text-white",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
	] }),
	caption: { class: ["absolute bottom-0 left-0 w-full", "bg-black/50 text-white p-4"] },
	transition: {
		enterFromClass: "opacity-0 scale-75",
		enterActiveClass: "transition-all duration-150 ease-in-out",
		leaveActiveClass: "transition-all duration-150 ease-in",
		leaveToClass: "opacity-0 scale-75"
	}
};
//#endregion
//#region presets/aura/global.js
var global_default = { css: `
    *[data-pd-ripple="true"]{
        overflow: hidden;
        position: relative;
    }
    span[data-p-ink-active="true"]{
        animation: ripple 0.4s linear;
    }
    @keyframes ripple {
        100% {
            opacity: 0;
            transform: scale(2.5);
        }
    }

    .progress-spinner-circle {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: 0;
        animation: p-progress-spinner-dash 1.5s ease-in-out infinite, p-progress-spinner-color 6s ease-in-out infinite;
        stroke-linecap: round;
    }

    @keyframes p-progress-spinner-dash{
        0% {
            stroke-dasharray: 1, 200;
            stroke-dashoffset: 0;
        }

        50% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -35px;
        }
        100% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -124px;
        }
    }
    @keyframes p-progress-spinner-color {
        100%, 0% {
            stroke: #ff5757;
        }
        40% {
            stroke: #696cff;
        }
        66% {
            stroke: #1ea97c;
        }
        80%, 90% {
            stroke: #cc8925;
        }
    }

    .progressbar-value-animate::after {
        will-change: left, right;
        animation: p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) infinite;
    }
    .progressbar-value-animate::before {
        will-change: left, right;
        animation: p-progressbar-indeterminate-anim 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    }
    @keyframes p-progressbar-indeterminate-anim {
        0% {
            left: -35%;
            right: 100%;
        }
        60% {
            left: 100%;
            right: -90%;
        }
        100% {
            left: 100%;
            right: -90%;
        }
    }

    .p-fadein {
        animation: p-fadein 250ms linear;
    }

    @keyframes p-fadein {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
` };
//#endregion
//#region presets/aura/iconfield/index.js
var iconfield_default = { root: { class: [
	"relative",
	"[&>[data-pc-name=inputicon]]:absolute",
	"[&>[data-pc-name=inputicon]]:top-1/2",
	"[&>[data-pc-name=inputicon]]:-mt-2",
	"[&>[data-pc-name=inputicon]]:text-surface-900/60 dark:[&>[data-pc-name=inputicon]]:text-white/60",
	"[&>[data-pc-name=inputicon]:first-child]:left-3",
	"[&>[data-pc-name=inputicon]:last-child]:right-3",
	"[&>[data-pc-name=inputtext]:first-child]:pr-10",
	"[&>[data-pc-name=inputtext]:last-child]:pl-10",
	"[&>[data-pc-extend=inputicon]]:absolute",
	"[&>[data-pc-extend=inputicon]]:top-1/2",
	"[&>[data-pc-extend=inputicon]]:-mt-2",
	"[&>[data-pc-extend=inputicon]]:text-surface-900/60 dark:[&>[data-pc-extend=inputicon]]:text-white/60",
	"[&>[data-pc-extend=inputicon]:first-child]:left-3",
	"[&>[data-pc-extend=inputicon]:last-child]:right-3"
] } };
//#endregion
//#region presets/aura/image/index.js
var image_default = {
	root: { class: "relative inline-block" },
	previewMask: { class: [
		"flex items-center justify-center",
		"absolute",
		"inset-0 opacity-0 transition-opacity duration-300",
		"bg-transparent text-surface-100",
		"hover:opacity-100 hover:cursor-pointer hover:bg-black/50 hover:bg-opacity-50"
	] },
	mask: { class: [
		"flex items-center justify-center",
		"fixed top-0 left-0",
		"w-full h-full",
		"bg-black/90"
	] },
	toolbar: { class: [
		"flex",
		"absolute top-0 right-0",
		"p-4"
	] },
	rotateRightButton: { class: [
		"z-20",
		"flex justify-center items-center",
		"w-12 h-12",
		"mr-2",
		"rounded-full",
		"text-white bg-transparent",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out"
	] },
	rotateRightIcon: { class: "w-6 h-6" },
	rotateLeftButton: { class: [
		"z-20",
		"flex justify-center items-center",
		"w-12 h-12",
		"mr-2",
		"rounded-full",
		"text-white bg-transparent",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out"
	] },
	rotateLeftIcon: { class: "w-6 h-6" },
	zoomOutButton: { class: [
		"z-20",
		"flex justify-center items-center",
		"w-12 h-12",
		"mr-2",
		"rounded-full",
		"text-white bg-transparent",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out"
	] },
	zoomOutIcon: { class: "w-6 h-6" },
	zoomInButton: { class: [
		"z-20",
		"flex justify-center items-center",
		"w-12 h-12",
		"mr-2",
		"rounded-full",
		"text-white bg-transparent",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out"
	] },
	zoomInIcon: { class: "w-6 h-6" },
	closeButton: { class: [
		"z-20",
		"flex justify-center items-center",
		"w-12 h-12",
		"mr-2",
		"rounded-full",
		"text-white bg-transparent",
		"hover:text-white hover:bg-surface-0/10",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out"
	] },
	closeIcon: { class: "w-6 h-6" },
	transition: {
		enterFromClass: "opacity-0 scale-75",
		enterActiveClass: "transition-all duration-150 ease-in-out",
		leaveActiveClass: "transition-all duration-150 ease-in",
		leaveToClass: "opacity-0 scale-75"
	}
};
//#endregion
//#region presets/aura/inplace/index.js
var inplace_default = { display: { class: [
	"inline",
	"px-3 py-2",
	"rounded-md",
	"text-surface-700 dark:text-white/80",
	"hover:bg-surface-100 hover:text-surface-700 dark:hover:bg-surface-800 dark:hover:text-white/80",
	"transition",
	"duration-200",
	"cursor-pointer"
] } };
//#endregion
//#region presets/aura/inputgroup/index.js
var inputgroup_default = { root: { class: ["flex items-stretch", "w-full"] } };
//#endregion
//#region presets/aura/inputgroupaddon/index.js
var inputgroupaddon_default = { root: { class: [
	"flex items-center justify-center",
	"first:rounded-l-md",
	"last:rounded-r-md",
	"border-y",
	"last:border-r",
	"border-l",
	"border-r-0",
	"p-2",
	"min-w-[2.5rem]",
	"bg-transparent dark:bg-surface-900",
	"text-surface-800 dark:text-white/80",
	"border-surface-300 dark:border-surface-700"
] } };
//#endregion
//#region presets/aura/inputmask/index.js
var inputmask_default = { root: ({ context, props, parent }) => ({ class: [
	"leading-none",
	"m-0 py-2 px-3",
	"text-surface-800 dark:text-white/80",
	"placeholder:text-surface-400 dark:placeholder:text-surface-500",
	{ "bg-surface-0 dark:bg-surface-950": !context.disabled },
	"border",
	{ "border-surface-300 dark:border-surface-700": !props.invalid },
	"invalid:focus:ring-red-200",
	"invalid:hover:border-red-500",
	{ "border-red-500 dark:border-red-400": props.invalid },
	{
		"hover:border-surface-400 dark:hover:border-surface-600": !context.disabled && !props.invalid,
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !context.disabled,
		"bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": context.disabled
	},
	{ filled: parent.instance?.$name == "FloatLabel" && props.modelValue !== null && props.modelValue?.length !== 0 },
	"rounded-md",
	"appearance-none",
	"transition-colors duration-200"
] }) };
//#endregion
//#region presets/aura/inputnumber/index.js
var inputnumber_default = {
	root: ({ props, parent }) => ({ class: [
		"inline-flex",
		"relative",
		{ "flex-col": props.showButtons && props.buttonLayout === "vertical" },
		{ "flex-1 w-[1%]": parent.instance.$name === "InputGroup" },
		{ "w-full": props.fluid },
		{ "first:rounded-l-md rounded-none last:rounded-r-md": parent.instance.$name === "InputGroup" && !props.showButtons },
		{ "border-0 border-y border-l last:border-r border-surface-300 dark:border-surface-700": parent.instance.$name === "InputGroup" && !props.showButtons },
		{ "first:ml-0 -ml-px": parent.instance.$name === "InputGroup" && !props.showButtons },
		{ "!w-16": props.showButtons && props.buttonLayout == "vertical" }
	] }),
	pcInput: { root: ({ parent, context }) => ({ class: [
		"leading-none",
		"flex-auto",
		{ "w-[1%]": parent.props.fluid },
		{ "text-center": parent.props.showButtons && parent.props.buttonLayout == "vertical" },
		"py-2 px-3",
		"m-0",
		"rounded-md",
		{ "rounded-l-none rounded-r-none": parent.props.showButtons && parent.props.buttonLayout === "horizontal" },
		{ "rounded-none": parent.props.showButtons && parent.props.buttonLayout === "vertical" },
		{ "border-0": parent.instance.$parentInstance?.$name === "InputGroup" && !parent.props.showButtons },
		"text-surface-800 dark:text-white/80",
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		{ "bg-surface-0 dark:bg-surface-950": !context.disabled },
		"border",
		{ "border-surface-300 dark:border-surface-700": !parent.props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": parent.props.invalid },
		{ "hover:border-primary": !parent.props.invalid },
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": context.disabled },
		{ filled: parent.instance?.$parentInstance?.$name === "FloatLabel" && parent.state.d_modelValue !== null },
		{ "order-2": parent.props.buttonLayout == "horizontal" || parent.props.buttonLayout === "vertical" }
	] }) },
	buttonGroup: ({ props }) => ({ class: [
		"absolute",
		"flex",
		"flex-col",
		"top-px right-px",
		{ "h-[calc(100%-2px)]": props.showButtons && props.buttonLayout === "stacked" }
	] }),
	incrementButton: ({ props }) => ({ class: [
		{ "flex flex-initial shrink-0": props.showButtons && props.buttonLayout === "horizontal" },
		{ "flex flex-auto": props.showButtons && props.buttonLayout === "stacked" },
		"items-center",
		"justify-center",
		"text-center align-bottom",
		"relative",
		{ "order-3": props.showButtons && props.buttonLayout === "horizontal" },
		{ "order-1": props.showButtons && props.buttonLayout === "vertical" },
		"text-surface-800 dark:text-surface-0",
		"bg-transparent",
		{ "dark:bg-surface-900": props.showButtons && props.buttonLayout !== "stacked" },
		"border border-surface-300 dark:border-surface-700",
		{ "border-0": props.showButtons && props.buttonLayout === "stacked" },
		{ "border-l-0": props.showButtons && props.buttonLayout !== "stacked" && props.buttonLayout === "horizontal" },
		{ "border-b-0": props.showButtons && props.buttonLayout !== "stacked" && props.buttonLayout === "vertical" },
		"w-[3rem]",
		{ "px-3 py-2": props.showButtons && props.buttonLayout !== "stacked" },
		{ "p-0": props.showButtons && props.buttonLayout === "stacked" },
		{ "w-full": props.showButtons && props.buttonLayout === "vertical" },
		"rounded-md",
		{ "rounded-md": props.showButtons && props.buttonLayout == "stacked" },
		{ "rounded-bl-none rounded-tl-none": props.showButtons && props.buttonLayout === "horizontal" },
		{ "rounded-bl-none rounded-br-none": props.showButtons && props.buttonLayout === "vertical" },
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"cursor-pointer overflow-hidden select-none"
	] }),
	incrementIcon: "inline-block w-4 h-4",
	decrementButton: ({ props }) => ({ class: [
		{ "flex flex-initial shrink-0": props.showButtons && props.buttonLayout === "horizontal" },
		{ "flex flex-auto": props.showButtons && props.buttonLayout === "stacked" },
		"items-center",
		"justify-center",
		"text-center align-bottom",
		"relative",
		{ "order-1": props.showButtons && props.buttonLayout === "horizontal" },
		{ "order-3": props.showButtons && props.buttonLayout === "vertical" },
		"text-surface-800 dark:text-surface-0",
		"bg-transparent",
		{ "dark:bg-surface-900": props.showButtons && props.buttonLayout !== "stacked" },
		"border border-surface-300 dark:border-surface-700",
		{ "border-0": props.showButtons && props.buttonLayout === "stacked" },
		{ "border-r-0": props.showButtons && props.buttonLayout !== "stacked" && props.buttonLayout === "horizontal" },
		{ "border-t-0": props.showButtons && props.buttonLayout !== "stacked" && props.buttonLayout === "vertical" },
		"w-[3rem]",
		{ "px-3 py-2": props.showButtons && props.buttonLayout !== "stacked" },
		{ "p-0": props.showButtons && props.buttonLayout === "stacked" },
		{ "w-full": props.showButtons && props.buttonLayout === "vertical" },
		"rounded-md",
		{ "rounded-tr-none rounded-tl-none rounded-bl-none": props.showButtons && props.buttonLayout === "stacked" },
		{ "rounded-tr-none rounded-br-none ": props.showButtons && props.buttonLayout === "horizontal" },
		{ "rounded-tr-none rounded-tl-none ": props.showButtons && props.buttonLayout === "vertical" },
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"cursor-pointer overflow-hidden select-none"
	] }),
	decrementIcon: "inline-block w-4 h-4"
};
//#endregion
//#region presets/aura/inputotp/index.js
var inputotp_default = { root: { class: [
	"flex items-center",
	"gap-2",
	"[&_[data-pc-name=pcinput]]:w-10"
] } };
//#endregion
//#region presets/aura/inputtext/index.js
var inputtext_default = { root: ({ props, context, parent }) => ({ class: [
	"leading-none",
	{ "flex-1 w-[1%]": parent.instance.$name == "InputGroup" },
	"m-0",
	{ "w-full": props.fluid },
	{
		"py-3 px-3.5": props.size == "large",
		"py-1.5 px-2": props.size == "small",
		"py-2 px-3": props.size == null
	},
	{ "rounded-md": parent.instance.$name !== "InputGroup" },
	{ "first:rounded-l-md rounded-none last:rounded-r-md": parent.instance.$name == "InputGroup" },
	{ "border-0 border-y border-l last:border-r": parent.instance.$name == "InputGroup" },
	{ "first:ml-0 -ml-px": parent.instance.$name == "InputGroup" && !props.showButtons },
	"text-surface-800 dark:text-white/80",
	"placeholder:text-surface-400 dark:placeholder:text-surface-500",
	{ "bg-surface-0 dark:bg-surface-950": !context.disabled },
	"border",
	{ "border-surface-300 dark:border-surface-700": !props.invalid },
	"invalid:focus:ring-red-200",
	"invalid:hover:border-red-500",
	{ "border-red-500 dark:border-red-400": props.invalid },
	{
		"hover:border-surface-400 dark:hover:border-surface-600": !context.disabled && !props.invalid,
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !context.disabled,
		"bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": context.disabled
	},
	{ filled: parent.instance?.$name == "FloatLabel" && context.filled },
	"appearance-none",
	"transition-colors duration-200"
] }) };
//#endregion
//#region presets/aura/knob/index.js
var knob_default = {
	root: ({ props }) => ({ class: [{ "opacity-60 select-none pointer-events-none cursor-default": props.disabled }] }),
	range: { class: [
		"stroke-current",
		"stroke-surface-200 dark:stroke-surface-700",
		"fill-none",
		"transition duration-100 ease-in"
	] },
	value: { class: [
		"animate-dash-frame",
		"stroke-primary",
		"fill-none"
	] },
	text: { class: ["text-center text-xl", "fill-surface-600 dark:fill-surface-200"] }
};
//#endregion
//#region presets/aura/listbox/index.js
var listbox_default = {
	root: ({ props }) => ({ class: [
		"rounded-md",
		{ "bg-surface-0 dark:bg-surface-900": !props.disabled },
		"text-surface-700 dark:text-white/80",
		"border",
		{ "border-surface-300 dark:border-surface-700": !props.invalid },
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled },
		{ "border-red-500 dark:border-red-400": props.invalid }
	] }),
	listContainer: "overflow-auto",
	list: { class: "p-1 list-none m-0 outline-none" },
	option: ({ context }) => ({ class: [
		"relative",
		"flex items-center",
		"leading-none",
		"m-0 px-3 py-2",
		"first:mt-0 mt-[2px]",
		"border-0 rounded",
		{
			"text-surface-700 dark:text-white/80": !context.focused && !context.selected,
			"bg-surface-200 dark:bg-surface-600/60": context.focused && !context.selected,
			"text-surface-700 dark:text-white/80": context.focused && !context.selected,
			"bg-highlight": context.selected
		},
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.focused && !context.selected },
		{ "hover:bg-highlight-emphasis": context.selected },
		{ "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": context.focused && !context.selected },
		"transition-shadow duration-200",
		"cursor-pointer overflow-hidden whitespace-nowrap"
	] }),
	optionGroup: { class: [
		"font-semibold",
		"m-0 py-2 px-3",
		"text-surface-400 dark:text-surface-500",
		"cursor-auto"
	] },
	optionCheckIcon: "relative -ms-1.5 me-1.5 text-surface-700 dark:text-white/80 w-4 h-4",
	emptyMessage: { class: [
		"leading-none",
		"py-2 px-3",
		"text-surface-800 dark:text-white/80",
		"bg-transparent"
	] },
	header: { class: [
		"pt-2 px-2 pb-0",
		"m-0",
		"border-b-0",
		"rounded-tl-md",
		"rounded-tr-md",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-300 dark:border-surface-700",
		"[&_[data-pc-name=pcfilter]]:w-full"
	] }
};
//#endregion
//#region presets/aura/megamenu/index.js
var megamenu_default = {
	root: ({ props }) => ({ class: [
		"relative",
		"flex",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700",
		{
			"p-2 items-center": props.orientation == "horizontal",
			"flex-col sm:w-48 p-1": props.orientation !== "horizontal"
		}
	] }),
	rootList: ({ props }) => ({ class: [
		"sm:flex",
		"items-center",
		"flex-wrap",
		"flex-col sm:flex-row",
		{
			hidden: !props?.mobileActive,
			flex: props?.mobileActive
		},
		"absolute sm:relative",
		"top-full left-0",
		"sm:top-auto sm:left-auto",
		"w-full sm:w-auto",
		"m-0",
		"p-1 sm:py-0 sm:p-0",
		"list-none",
		"shadow-md sm:shadow-none",
		"border-0",
		"bg-surface-0 dark:bg-surface-900 sm:bg-transparent dark:sm:bg-transparent",
		"outline-none"
	] }),
	item: ({ props }) => ({ class: ["sm:relative static my-[2px] [&:first-child]:mt-0", {
		"sm:w-auto w-full": props.horizontal,
		"w-full": !props.horizontal
	}] }),
	itemContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		"transition-all",
		"duration-200"
	] }),
	itemLink: { class: [
		"relative",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		"leading-none",
		"select-none",
		"cursor-pointer",
		"no-underline ",
		"overflow-hidden"
	] },
	itemIcon: { class: "mr-2" },
	submenuIcon: ({ props }) => ({ class: [{
		"ml-auto sm:ml-2": props.horizontal,
		"ml-auto": !props.horizontal
	}] }),
	overlay: ({ props }) => ({ class: [
		"w-auto",
		"m-0",
		"shadow-none sm:shadow-md",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"static sm:absolute",
		"z-10",
		{ "sm:left-full top-0": !props.horizontal }
	] }),
	grid: { class: "flex flex-wrap sm:flex-nowrap" },
	column: { class: "w-full sm:w-1/2" },
	submenu: { class: ["m-0 list-none", "p-1 px-2 w-full sm:min-w-[14rem]"] },
	submenuLabel: { class: [
		"font-semibold",
		"py-2 px-3",
		"m-0",
		"text-surface-400 dark:text-surface-500",
		"bg-surface-0 dark:bg-surface-900"
	] },
	separator: { class: "border-t border-surface-200 dark:border-surface-600 my-1" },
	button: { class: [
		"flex sm:hidden",
		"items-center justify-center",
		"w-7",
		"h-7",
		"rounded-full",
		"text-surface-500 dark:text-white/80",
		"hover:text-surface-600 dark:hover:text-white/60",
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0",
		"focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out",
		"cursor-pointer",
		"no-underline"
	] },
	end: { class: "ml-auto self-center" }
};
//#endregion
//#region presets/aura/menu/index.js
var menu_default = {
	root: { class: [
		"min-w-[12.5rem]",
		"rounded-md",
		"p-1",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-200 dark:border-surface-700"
	] },
	list: { class: [
		"list-none",
		"m-0",
		"p-0",
		"outline-none"
	] },
	item: { class: "relative my-[2px] [&:first-child]:mt-0" },
	itemContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		"transition-shadow",
		"duration-200",
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		{ "opacity-60 pointer-events-none cursor-default": context.disabled }
	] }),
	itemLink: { class: [
		"relative",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		"text-surface-700 dark:text-white/80",
		"no-underline",
		"overflow-hidden",
		"cursor-pointer",
		"select-none"
	] },
	itemIcon: { class: ["mr-2", "text-surface-600 dark:text-white/70"] },
	itemLabel: { class: ["leading-[normal]"] },
	submenuLabel: { class: [
		"font-bold",
		"m-0",
		"py-2 px-3",
		"rounded-tl-none",
		"rounded-tr-none",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-400 dark:text-surface-600"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/menubar/index.js
var menubar_default = {
	root: { class: [
		"relative",
		"flex",
		"items-center",
		"p-2",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700"
	] },
	rootList: ({ props }) => ({ class: [
		"sm:flex",
		"items-center",
		"flex-wrap",
		"flex-col sm:flex-row",
		{
			hidden: !props?.mobileActive,
			flex: props?.mobileActive
		},
		"absolute sm:relative",
		"top-full left-0",
		"sm:top-auto sm:left-auto",
		"w-full sm:w-auto",
		"m-0",
		"p-1 sm:py-0 sm:p-0",
		"list-none",
		"shadow-md sm:shadow-none",
		"border-0",
		"bg-surface-0 dark:bg-surface-900 sm:bg-transparent",
		"outline-none"
	] }),
	item: { class: "sm:relative sm:w-auto w-full static my-[2px] [&:first-child]:mt-0" },
	itemContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		"transition-all",
		"duration-200"
	] }),
	itemLink: ({ context }) => ({ class: [
		"relative",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		{
			"pl-9 sm:pl-5": context.level === 1,
			"pl-14 sm:pl-5": context.level === 2
		},
		"leading-none",
		"select-none",
		"cursor-pointer",
		"no-underline ",
		"overflow-hidden"
	] }),
	itemIcon: { class: "mr-2" },
	submenuIcon: ({ props }) => ({ class: [{
		"ml-auto sm:ml-2": props.root,
		"ml-auto": !props.root
	}] }),
	submenu: ({ props }) => ({ class: [
		"flex flex-col",
		"rounded-md",
		"min-w-[12.5rem]",
		"p-1",
		"m-0",
		"list-none",
		"shadow-none sm:shadow-md",
		"border border-surface-200 dark:border-surface-700",
		"static sm:absolute",
		"z-10",
		{ "sm:absolute sm:left-full sm:top-0": props.level > 1 },
		"bg-surface-0 dark:bg-surface-900"
	] }),
	separator: { class: "border-t border-surface-200 dark:border-surface-600 my-[2px]" },
	button: { class: [
		"flex sm:hidden",
		"items-center justify-center",
		"w-7",
		"h-7",
		"rounded-full",
		"text-surface-500 dark:text-white/80",
		"hover:text-surface-600 dark:hover:text-white/60",
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0",
		"focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"transition duration-200 ease-in-out",
		"cursor-pointer",
		"no-underline"
	] },
	end: { class: "ml-auto self-center" }
};
//#endregion
//#region presets/aura/message/index.js
var message_default = {
	root: ({ props }) => ({ class: [
		"rounded-md",
		"outline",
		{
			"bg-blue-100/70 dark:bg-blue-500/20": props.severity == "info",
			"bg-green-100/70 dark:bg-green-500/20": props.severity == "success",
			"bg-surface-100/70 dark:bg-surface-500/20": props.severity == "secondary",
			"bg-orange-100/70 dark:bg-orange-500/20": props.severity == "warn",
			"bg-red-100/70 dark:bg-red-500/20": props.severity == "error",
			"bg-surface-950 dark:bg-surface-0": props.severity == "contrast"
		},
		{
			"outline-blue-200 dark:outline-blue-500/20": props.severity == "info",
			"outline-green-200 dark:outline-green-500/20": props.severity == "success",
			"outline-surface-200 dark:outline-surface-500/20": props.severity == "secondary",
			"outline-orange-200 dark:outline-orange-500/20": props.severity == "warn",
			"outline-red-200 dark:outline-red-500/20": props.severity == "error",
			"outline-surface-950 dark:outline-surface-0": props.severity == "contrast"
		},
		{
			"text-blue-700 dark:text-blue-300": props.severity == "info",
			"text-green-700 dark:text-green-300": props.severity == "success",
			"text-surface-700 dark:text-surface-300": props.severity == "secondary",
			"text-orange-700 dark:text-orange-300": props.severity == "warn",
			"text-red-700 dark:text-red-300": props.severity == "error",
			"text-surface-0 dark:text-surface-950": props.severity == "contrast"
		}
	] }),
	content: { class: ["flex items-center h-full", "py-2 px-3 gap-2"] },
	icon: { class: ["shrink-0 w-[1.125rem] h-[1.125rem]"] },
	text: { class: ["text-base leading-[normal]", "font-medium"] },
	closeButton: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"w-7 h-7",
		"ml-auto relative",
		"rounded-full",
		"bg-transparent",
		"transition duration-200 ease-in-out",
		"hover:bg-surface-0/30 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0 focus:ring-1",
		{
			"focus:ring-blue-500 dark:focus:ring-blue-400": props.severity == "info",
			"focus:ring-green-500 dark:focus:ring-green-400": props.severity == "success",
			"focus:ring-surface-500 dark:focus:ring-surface-400": props.severity == "secondary",
			"focus:ring-orange-500 dark:focus:ring-orange-400": props.severity == "warn",
			"focus:ring-red-500 dark:focus:ring-red-4000": props.severity == "error",
			"focus:ring-surface-0 dark:focus:ring-surface-950": props.severity == "contrast"
		},
		"overflow-hidden"
	] }),
	transition: {
		enterFromClass: "opacity-0",
		enterActiveClass: "transition-opacity duration-300",
		leaveFromClass: "max-h-40",
		leaveActiveClass: "overflow-hidden transition-all duration-300 ease-in",
		leaveToClass: "max-h-0 opacity-0 !m-0"
	}
};
//#endregion
//#region presets/aura/metergroup/index.js
var metergroup_default = {
	root: ({ props }) => ({ class: ["flex gap-4", {
		"flex-col": props.orientation == "horizontal",
		"flex-row": props.orientation == "vertical"
	}] }),
	meters: ({ props }) => ({ class: [
		"flex",
		{ "flex-col": props.orientation === "vertical" },
		{ "w-2 h-full": props.orientation === "vertical" },
		{ "h-2": props.orientation === "horizontal" },
		"bg-gray-200 dark:bg-gray-700",
		"rounded-lg"
	] }),
	meter: ({ props }) => ({ class: [
		"border-0",
		{ "first:rounded-l-lg last:rounded-r-lg": props.orientation === "horizontal" },
		{ "first:rounded-t-lg last:rounded-b-lg": props.orientation === "vertical" },
		"bg-primary"
	] }),
	labelList: ({ props }) => ({ class: [
		"flex flex-wrap",
		{ "gap-4": props.labelOrientation === "horizontal" },
		{ "gap-2": props.labelOrientation === "vertical" },
		{ "flex-col": props.labelOrientation === "vertical" },
		{
			"align-end": props.labelOrientation === "horizontal" && props.labelPosition === "end",
			"align-start": props.labelOrientation === "horizontal" && props.labelPosition === "start"
		},
		{ "justify-start": props.labelOrientation === "vertical" && props.labelPosition === "start" },
		"m-0 p-0 list-none"
	] }),
	label: { class: [
		"inline-flex",
		"items-center",
		"gap-2"
	] },
	labelMarker: { class: [
		"inline-flex",
		"bg-primary",
		"w-2 h-2",
		"rounded-full"
	] }
};
//#endregion
//#region presets/aura/multiselect/index.js
var multiselect_default = {
	root: ({ props, state }) => ({ class: [
		"leading-none",
		"inline-flex",
		"relative",
		"rounded-md",
		{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
		"border",
		{ "border-surface-300 dark:border-surface-600": !props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		"transition-all",
		"duration-200",
		{ "hover:border-surface-400 dark:hover:border-surface-700": !props.invalid },
		{ "outline-none outline-offset-0 z-10 ring-1 ring-primary-500 dark:ring-primary-400": state.focused },
		"cursor-pointer",
		"select-none",
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	labelContainer: "overflow-hidden flex flex-auto cursor-pointer",
	label: ({ props }) => ({ class: [
		"text-base leading-2",
		{
			"py-2 px-3": props.display === "comma" || props.display === "chip" && !props?.modelValue?.length,
			"py-1 px-1": props.display === "chip" && props?.modelValue?.length > 0
		},
		{
			"text-surface-800 dark:text-white/80": props.modelValue?.length,
			"text-surface-400 dark:text-surface-500": !props.modelValue?.length
		},
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		"transition duration-200",
		"overflow-hidden whitespace-nowrap cursor-pointer overflow-ellipsis"
	] }),
	dropdown: { class: [
		"flex items-center justify-center",
		"shrink-0",
		"bg-transparent",
		"text-surface-500",
		"w-12",
		"rounded-r-md"
	] },
	overlay: { class: [
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-300 dark:border-surface-700",
		"rounded-md",
		"shadow-md",
		"mt-[2px]"
	] },
	header: { class: [
		"flex items-center justify-between",
		"pt-2 px-4 pb-0 gap-2",
		"m-0",
		"border-b-0",
		"rounded-tl-md",
		"rounded-tr-md",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-300 dark:border-surface-700",
		"[&_[data-pc-name=pcfiltercontainer]]:!flex-auto",
		"[&_[data-pc-name=pcfilter]]:w-full"
	] },
	listContainer: { class: ["max-h-[200px]", "overflow-auto"] },
	list: { class: "p-1 list-none m-0" },
	option: ({ context }) => ({ class: [
		"relative",
		"flex items-center",
		"leading-none",
		"m-0 px-3 py-2 gap-2",
		"first:mt-0 mt-[2px]",
		"border-0 rounded",
		{
			"text-surface-700 dark:text-white/80": !context.focused && !context.selected,
			"bg-surface-200 dark:bg-surface-600/60": context.focused && !context.selected,
			"text-surface-700 dark:text-white/80": context.focused && !context.selected,
			"bg-highlight": context.selected
		},
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.focused && !context.selected },
		{ "hover:bg-highlight-emphasis": context.selected },
		{ "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": context.focused && !context.selected },
		"transition-shadow duration-200",
		"cursor-pointer overflow-hidden whitespace-nowrap"
	] }),
	optionGroup: { class: [
		"font-semibold",
		"m-0 py-2 px-3",
		"text-surface-400 dark:text-surface-500",
		"cursor-auto"
	] },
	emptyMessage: { class: [
		"leading-none",
		"py-2 px-3",
		"text-surface-800 dark:text-white/80",
		"bg-transparent"
	] },
	loadingIcon: { class: "text-surface-400 dark:text-surface-500 animate-spin" },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/orderlist/index.js
var orderlist_default = {
	root: "flex",
	controls: { class: ["flex xl:flex-col justify-center gap-2", "p-[1.125rem]"] },
	container: { class: [
		"flex-auto",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700",
		"outline-none"
	] }
};
//#endregion
//#region presets/aura/organizationchart/index.js
var organizationchart_default = {
	table: { class: ["mx-auto my-0", "border-spacing-0 border-separate"] },
	cell: { class: ["text-center align-top", "py-0 px-3"] },
	node: ({ context }) => ({ class: [
		"relative inline-block",
		"py-3 px-4",
		"border",
		"rounded-md",
		"border-surface-200 dark:border-surface-700",
		{
			"text-surface-600 dark:text-white/80": !context?.selected,
			"bg-surface-0 dark:bg-surface-900": !context?.selected,
			"bg-highlight": context?.selected
		},
		{
			"hover:bg-surface-100 dark:hover:bg-surface-800": context?.selectable && !context?.selected,
			"hover:bg-highlight-emphasis": context?.selectable && context?.selected
		},
		{ "cursor-pointer": context?.selectable }
	] }),
	lineCell: { class: ["text-center align-top", "py-0 px-3"] },
	connectorDown: { class: [
		"mx-auto my-0",
		"w-px h-[20px]",
		"bg-surface-200 dark:bg-surface-700"
	] },
	connectorLeft: ({ context }) => ({ class: [
		"text-center align-top",
		"py-0 px-3",
		"rounded-none border-r",
		{ "border-t": context.lineTop },
		"border-surface-200 dark:border-surface-700"
	] }),
	connectorRight: ({ context }) => ({ class: [
		"text-center align-top",
		"py-0 px-3",
		"rounded-none",
		{ "border-t border-surface-200 dark:border-surface-700": context.lineTop }
	] }),
	nodeCell: { class: "text-center align-top py-0 px-3" },
	nodeToggleButton: { class: [
		"absolute bottom-[-0.75rem] left-2/4 -ml-3",
		"z-20",
		"flex items-center justify-center",
		"w-6 h-6",
		"rounded-full",
		"border border-surface-200 dark:border-surface-700",
		"bg-inherit text-inherit",
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
		"cursor-pointer no-underline select-none"
	] },
	nodeToggleButtonIcon: { class: ["static inline-block", "w-4 h-4"] }
};
//#endregion
//#region presets/aura/overlaybadge/index.js
var overlaybadge_default = { root: { class: [
	"relative",
	"[&>[data-pc-name=pcbadge]]:absolute",
	"[&>[data-pc-name=pcbadge]]:top-0",
	"[&>[data-pc-name=pcbadge]]:right-0",
	"[&>[data-pc-name=pcbadge]]:translate-x-1/2",
	"[&>[data-pc-name=pcbadge]]:-translate-y-1/2",
	"[&>[data-pc-name=pcbadge]]:m-0",
	"[&>[data-pc-name=pcbadge]]:origin-[100%_0]",
	"[&>[data-pc-name=pcbadge]]:outline",
	"[&>[data-pc-name=pcbadge]]:outline-[2px]",
	"[&>[data-pc-name=pcbadge]]:outline-surface-0",
	"dark:[&>[data-pc-name=pcbadge]]:outline-surface-900"
] } };
//#endregion
//#region presets/aura/paginator/index.js
var paginator_default = {
	root: { class: [
		"flex items-center justify-center flex-wrap",
		"px-4 py-2",
		"border-0 rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-500 dark:text-white/60"
	] },
	first: ({ context }) => ({ class: [
		"relative",
		"inline-flex items-center justify-center",
		"border-0 rounded-full",
		"min-w-[2.5rem] h-10 m-[0.143rem]",
		"leading-none",
		"text-surface-500 dark:text-white/60",
		{
			"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.disabled,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !context.disabled
		},
		"transition duration-200",
		"user-none overflow-hidden",
		{ "cursor-default pointer-events-none opacity-60": context.disabled }
	] }),
	prev: ({ context }) => ({ class: [
		"relative",
		"inline-flex items-center justify-center",
		"border-0 rounded-full",
		"min-w-[2.5rem] h-10 m-[0.143rem]",
		"leading-none",
		"text-surface-500 dark:text-white/60",
		{
			"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.disabled,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !context.disabled
		},
		"transition duration-200",
		"user-none overflow-hidden",
		{ "cursor-default pointer-events-none opacity-60": context.disabled }
	] }),
	next: ({ context }) => ({ class: [
		"relative",
		"inline-flex items-center justify-center",
		"border-0 rounded-full",
		"min-w-[2.5rem] h-10 m-[0.143rem]",
		"leading-none",
		"text-surface-500 dark:text-white/60",
		{
			"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.disabled,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !context.disabled
		},
		"transition duration-200",
		"user-none overflow-hidden",
		{ "cursor-default pointer-events-none opacity-60": context.disabled }
	] }),
	last: ({ context }) => ({ class: [
		"relative",
		"inline-flex items-center justify-center",
		"border-0 rounded-full",
		"min-w-[2.5rem] h-10 m-[0.143rem]",
		"leading-none",
		"text-surface-500 dark:text-white/60",
		{
			"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.disabled,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !context.disabled
		},
		"transition duration-200",
		"user-none overflow-hidden",
		{ "cursor-default pointer-events-none opacity-60": context.disabled }
	] }),
	page: ({ context }) => ({ class: [
		"relative",
		"inline-flex items-center justify-center",
		"border-0 rounded-full",
		"min-w-[2.5rem] h-10 m-[0.143rem]",
		"leading-none",
		"text-surface-500 dark:text-white/60",
		{
			"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.disabled,
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !context.disabled
		},
		"transition duration-200",
		"user-none overflow-hidden",
		{ "cursor-default pointer-events-none opacity-60": context.disabled }
	] }),
	contentStart: "mr-auto",
	contentEnd: "ml-auto"
};
//#endregion
//#region presets/aura/panel/index.js
var panel_default = {
	root: { class: [
		"rounded-md",
		"border border-surface-200 dark:border-surface-700",
		"bg-surface-0 dark:bg-surface-900"
	] },
	header: ({ props }) => ({ class: [
		"flex items-center justify-between",
		"text-surface-700 dark:text-surface-0/80",
		"bg-transparent",
		"rounded-tl-md rounded-tr-md",
		"border-0",
		{
			"p-[1.125rem]": !props.toggleable,
			"py-3 px-[1.125rem]": props.toggleable
		}
	] }),
	title: { class: "leading-none font-semibold" },
	toggler: { class: [
		"inline-flex items-center justify-center",
		"relative",
		"w-7 h-7",
		"m-0 p-0",
		"border-0 rounded-full",
		"bg-transparent",
		"text-surface-600 dark:text-surface-0/80",
		"hover:text-surface-800 dark:hover:text-surface-0",
		"hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
		"transition-all duration-200 ease-in-out",
		"overflow-hidden no-underline",
		"cursor-pointer"
	] },
	togglerIcon: { class: "inline-block w-4 h-4" },
	content: { class: [
		"p-[1.125rem] pt-0",
		"border-0 border-t-0 last:rounded-br-md last:rounded-bl-md",
		"text-surface-700 dark:text-surface-0/80"
	] },
	footer: { class: [
		"p-[1.125rem] pt-0",
		"border-0 border-t-0 rounded-br-lg rounded-bl-lg",
		"text-surface-700 dark:text-surface-0/80"
	] },
	transition: {
		enterFromClass: "max-h-0",
		enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
		enterToClass: "max-h-[1000px]",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
		leaveToClass: "max-h-0"
	}
};
//#endregion
//#region presets/aura/panelmenu/index.js
var panelmenu_default = {
	panel: { class: "p-1 overflow-hidden mb-3 border border-surface-200 dark:border-surface-700 rounded-md" },
	header: { class: ["rounded-[4px]", "outline-none"] },
	headerContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-600 dark:text-surface-0/80",
		{ "text-surface-900": context.active },
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"hover:text-surface-900",
		"transition duration-200 ease-in-out",
		"transition-shadow duration-200"
	] }),
	headerLink: { class: [
		"relative",
		"font-semibold",
		"leading-none",
		"flex items-center",
		"py-2 px-3",
		"select-none cursor-pointer no-underline"
	] },
	headerLabel: { class: "leading-none" },
	headerIcon: { class: "mr-2" },
	submenuIcon: { class: "mr-2" },
	content: { class: [
		"pl-4",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900"
	] },
	rootList: { class: ["outline-none", "m-0 p-0 list-none"] },
	menuitem: { class: "relative my-[2px]" },
	itemContent: { class: [
		"border-none rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		"transition-shadow duration-200"
	] },
	itemLink: ({ context }) => ({ class: [
		"relative",
		"leading-none",
		"flex items-center",
		"py-2 px-3",
		"rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)] hover:text-surface-700 dark:hover:text-white/80",
		{ "bg-surface-200 text-surface-700 dark:text-white/80 dark:bg-surface-0/10": context.focused },
		"cursor-pointer no-underline",
		"select-none overflow-hidden"
	] }),
	itemIcon: { class: "mr-2" },
	submenu: { class: "p-0 pl-4 m-0 list-none" },
	transition: {
		enterFromClass: "max-h-0",
		enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
		enterToClass: "max-h-[1000px]",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
		leaveToClass: "max-h-0"
	}
};
//#endregion
//#region presets/aura/password/index.js
var password_default = {
	root: ({ props }) => ({ class: [
		"relative",
		{ "[&>input]:pr-10": props.toggleMask },
		{
			"flex [&>input]:w-full": props.fluid,
			"inline-flex": !props.fluid
		}
	] }),
	overlay: { class: [
		"p-3",
		"border",
		"shadow-md rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border-surface-200 dark:border-surface-700"
	] },
	meter: { class: [
		"overflow-hidden",
		"relative",
		"border-0",
		"h-[10px]",
		"rounded-md",
		"mb-3",
		"bg-surface-100 dark:bg-surface-700"
	] },
	meterLabel: ({ instance }) => ({ class: [
		"h-full",
		{
			"bg-red-500 dark:bg-red-400/50": instance?.meter?.strength == "weak",
			"bg-orange-500 dark:bg-orange-400/50": instance?.meter?.strength == "medium",
			"bg-green-500 dark:bg-green-400/50": instance?.meter?.strength == "strong"
		},
		"transition-all duration-1000 ease-in-out"
	] }),
	maskIcon: { class: ["absolute top-1/2 right-3 -mt-2 z-10", "text-surface-600 dark:text-white/70"] },
	unmaskIcon: { class: ["absolute top-1/2 right-3 -mt-2 z-10", "text-surface-600 dark:text-white/70"] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/picklist/index.js
var picklist_default = {
	root: "flex [&_[data-pc-name=pclist]]:h-full",
	sourceControls: { class: ["flex xl:flex-col justify-center gap-2", "p-[1.125rem]"] },
	sourceListContainer: { class: [
		"grow shrink basis-2/4",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700",
		"outline-none"
	] },
	transferControls: { class: ["flex xl:flex-col justify-center gap-2", "p-[1.125rem]"] },
	targetListContainer: { class: [
		"grow shrink basis-2/4",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700",
		"outline-none"
	] },
	targetControls: { class: ["flex xl:flex-col justify-center gap-2", "p-[1.125rem]"] },
	transition: {
		enterFromClass: "!transition-none",
		enterActiveClass: "!transition-none",
		leaveActiveClass: "!transition-none",
		leaveToClass: "!transition-none"
	}
};
//#endregion
//#region presets/aura/popover/index.js
var popover_default = {
	root: { class: [
		"rounded-md shadow-lg",
		"absolute left-0 top-0 mt-2",
		"z-40 transform origin-center",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80",
		"before:absolute before:w-0 before:-top-3 before:h-0 before:border-transparent before:border-solid before:ml-[10px] before:border-x-[10px] before:border-b-[10px] before:border-t-0 before:border-b-surface-200 dark:before:border-b-surface-700",
		"after:absolute after:w-0 after:-top-[0.54rem] after:left-[4px] after:h-0 after:border-transparent after:border-solid after:ml-[8px] after:border-x-[8px] after:border-b-[8px] after:border-t-0 after:border-b-surface-0 dark:after:border-b-surface-900"
	] },
	content: { class: [
		"p-0 items-center flex",
		"rounded-lg",
		"border border-surface-200 dark:border-surface-700"
	] },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/progressbar/index.js
var progressbar_default = {
	root: { class: [
		"overflow-hidden",
		"relative",
		"border-0",
		"h-5",
		"rounded-md",
		"bg-surface-100 dark:bg-surface-800"
	] },
	value: ({ props }) => ({ class: [
		{ "absolute flex items-center justify-center overflow-hidden": props.mode !== "indeterminate" },
		"bg-[#18181B] dark:bg-[#FFFFFF]",
		"m-0",
		{ "h-full w-0": props.mode !== "indeterminate" },
		"border-0",
		{
			"transition-width duration-1000 ease-in-out": props.mode !== "indeterminate",
			"progressbar-value-animate": props.mode == "indeterminate"
		},
		{
			"before:absolute before:top-0 before:left-0 before:bottom-0 before:bg-inherit ": props.mode == "indeterminate",
			"after:absolute after:top-0 after:left-0 after:bottom-0 after:bg-inherit after:delay-1000": props.mode == "indeterminate"
		}
	] }),
	label: { class: [
		"text-xs font-semibold",
		"inline-flex",
		"text-white dark:text-surface-900",
		"leading-5"
	] }
};
//#endregion
//#region presets/aura/progressspinner/index.js
var progressspinner_default = {
	root: { class: [
		"relative",
		"mx-auto",
		"w-28",
		"h-28",
		"inline-block",
		"before:block",
		"before:pt-full"
	] },
	spinner: { class: [
		"absolute",
		"top-0",
		"bottom-0",
		"left-0",
		"right-0",
		"m-auto",
		"w-full",
		"h-full",
		"transform",
		"origin-center",
		"animate-spin"
	] },
	circle: { class: ["text-red-500", "progress-spinner-circle"] }
};
//#endregion
//#region presets/aura/radiobutton/index.js
var radiobutton_default = {
	root: { class: [
		"relative",
		"inline-flex",
		"align-bottom",
		"w-5 h-5",
		"cursor-pointer",
		"select-none"
	] },
	box: ({ props, context }) => ({ class: [
		"flex justify-center items-center",
		"w-5 h-5",
		"border outline-transparent",
		"rounded-full",
		"transition duration-200 ease-in-out",
		{
			"text-surface-700 dark:text-white/80": context.checked,
			"border-surface-300 dark:border-surface-700": !context.checked && !props.invalid,
			"border-primary bg-primary": context.checked && !props.disabled
		},
		{ "border-red-500 dark:border-red-400": props.invalid },
		{
			"peer-hover:border-surface-400 dark:peer-hover:border-surface-400": !props.disabled && !props.invalid && !context.checked,
			"peer-hover:border-primary-emphasis": !props.disabled && !context.checked,
			"peer-hover:[&>*:first-child]:bg-primary-600 dark:peer-hover:[&>*:first-child]:bg-primary-300": !props.disabled && !context.checked,
			"peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-primary-400": !props.disabled,
			"bg-surface-200 [&>*:first-child]:bg-surface-600 dark:bg-surface-700 dark:[&>*:first-child]:bg-surface-400 border-surface-300 dark:border-surface-700 select-none pointer-events-none cursor-default": props.disabled
		}
	] }),
	input: { class: [
		"peer",
		"w-full ",
		"h-full",
		"absolute",
		"top-0 left-0",
		"z-10",
		"p-0",
		"m-0",
		"opacity-0",
		"rounded-md",
		"outline-none",
		"border-1 border-surface-200 dark:border-surface-700",
		"appearance-none",
		"cursor-pointer"
	] },
	icon: ({ context }) => ({ class: [
		"block",
		"rounded-full",
		"w-3 h-3",
		{
			"bg-surface-0 dark:bg-surface-900": context.checked,
			"bg-primary": !context.checked,
			"backface-hidden invisible scale-[0.1]": !context.checked,
			"transform visible translate-z-0 scale-[1,1]": context.checked
		},
		"transition duration-200"
	] })
};
//#endregion
//#region presets/aura/rating/index.js
var rating_default = {
	root: ({ props }) => ({ class: [
		"relative",
		"flex items-center",
		"gap-1",
		{ "opacity-60 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	option: ({ props, context }) => ({ class: [
		"inline-flex items-center",
		{ "outline-none ring-1 ring-primary-500/50 dark:ring-primary-500": context.focused },
		{
			"cursor-pointer": !props.readonly,
			"cursor-default": props.readonly
		}
	] }),
	offIcon: ({ props }) => ({ class: [
		"w-4 h-4",
		"text-surface-700 dark:text-surface-0/80",
		{ "hover:text-primary-500 dark:hover:text-primary-400": !props.readonly },
		"transition duration-200 ease-in"
	] }),
	onIcon: ({ props }) => ({ class: [
		"w-4 h-4",
		"text-primary",
		{ "hover:text-primary-600 dark:hover:text-primary-300": !props.readonly },
		"transition duration-200 ease-in"
	] })
};
//#endregion
//#region presets/aura/ripple/index.js
var ripple_default = { root: {
	class: ["block absolute bg-surface-0/50 rounded-full pointer-events-none"],
	style: "transform: scale(0)"
} };
//#endregion
//#region presets/aura/scrollpanel/index.js
var scrollpanel_default = {
	contentContainer: { class: [
		"h-full w-full",
		"z-[1]",
		"overflow-hidden",
		"relative float-left"
	] },
	content: { class: [
		"h-[calc(100%+18px)] w-[calc(100%+18px)] pr-[18px] pb-[18px] pl-0 pt-0",
		"overflow-scroll scrollbar-none",
		"box-border",
		"relative",
		"[&::-webkit-scrollbar]:hidden"
	] },
	barX: { class: [
		"h-[9px] bottom-0",
		"bg-surface-50 dark:bg-surface-700 rounded",
		"cursor-pointer",
		"invisible z-20",
		"transition duration-[250ms] ease-linear",
		"relative"
	] },
	barY: { class: [
		"w-[9px] top-0",
		"bg-surface-50 dark:bg-surface-700 rounded",
		"cursor-pointer",
		"z-20",
		"transition duration-[250ms] ease-linear",
		"relative"
	] }
};
//#endregion
//#region presets/aura/scrolltop/index.js
var scrolltop_default = {
	button: ({ props }) => ({ root: { class: [
		"flex items-center justify-center",
		{
			"!sticky flex ml-auto": props.target === "parent",
			"!fixed": props.target === "window"
		},
		"bottom-[20px] right-[20px]",
		"h-10 w-10 rounded-full shadow-md",
		"text-white dark:text-surface-900 bg-surface-600 dark:bg-surface-700",
		"hover:bg-surface-600 dark:hover:bg-surface-300"
	] } }),
	transition: {
		enterFromClass: "opacity-0",
		enterActiveClass: "transition-opacity duration-150",
		leaveActiveClass: "transition-opacity duration-150",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/select/index.js
var select_default = {
	root: ({ props, state, parent }) => ({ class: [
		"inline-flex",
		"relative",
		{ "rounded-md": parent.instance.$name !== "InputGroup" },
		{ "first:rounded-l-md rounded-none last:rounded-r-md": parent.instance.$name == "InputGroup" },
		{ "border-0 border-y border-l last:border-r": parent.instance.$name == "InputGroup" },
		{ "first:ml-0 ml-[-1px]": parent.instance.$name == "InputGroup" && !props.showButtons },
		{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
		"border",
		{ "dark:border-surface-700": parent.instance.$name != "InputGroup" },
		{ "dark:border-surface-600": parent.instance.$name == "InputGroup" },
		{ "border-surface-300 dark:border-surface-600": !props.invalid },
		"invalid:focus:ring-red-200",
		"invalid:hover:border-red-500",
		{ "border-red-500 dark:border-red-400": props.invalid },
		"transition-all",
		"duration-200",
		{ "hover:border-surface-400 dark:hover:border-surface-600": !props.invalid },
		{ "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-primary-400 z-10": state.focused },
		"cursor-pointer",
		"select-none",
		{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	label: ({ props, parent }) => ({ class: [
		"leading-[normal]",
		"block",
		"flex-auto",
		"bg-transparent",
		"border-0",
		{
			"text-surface-800 dark:text-white/80": props.modelValue != void 0,
			"text-surface-400 dark:text-surface-500": props.modelValue == void 0
		},
		"placeholder:text-surface-400 dark:placeholder:text-surface-500",
		"w-[1%]",
		"py-2 px-3",
		{ "pr-7": props.showClear },
		"rounded-none",
		"transition",
		"duration-200",
		"focus:outline-none focus:shadow-none",
		{ filled: parent.instance?.$name == "FloatLabel" && props.modelValue !== null },
		"relative",
		"cursor-pointer",
		"overflow-hidden overflow-ellipsis",
		"whitespace-nowrap",
		"appearance-none"
	] }),
	dropdown: { class: [
		"flex items-center justify-center",
		"shrink-0",
		"bg-transparent",
		"text-surface-500",
		"w-12",
		"rounded-r-md"
	] },
	overlay: { class: [
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-white/80",
		"border border-surface-300 dark:border-surface-700",
		"rounded-md",
		"shadow-md"
	] },
	listContainer: { class: ["max-h-[200px]", "overflow-auto"] },
	list: { class: "p-1 list-none m-0" },
	option: ({ context }) => ({ class: [
		"relative",
		"flex items-center",
		"leading-none",
		"m-0 px-3 py-2",
		"first:mt-0 mt-[2px]",
		"border-0 rounded",
		{
			"text-surface-700 dark:text-white/80": !context.focused && !context.selected,
			"bg-surface-200 dark:bg-surface-600/60": context.focused && !context.selected,
			"text-surface-700 dark:text-white/80": context.focused && !context.selected,
			"bg-highlight": context.selected
		},
		{ "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.focused && !context.selected },
		{ "hover:bg-highlight-emphasis": context.selected },
		{ "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": context.focused && !context.selected },
		"transition-shadow duration-200",
		"cursor-pointer overflow-hidden whitespace-nowrap"
	] }),
	optionGroup: { class: [
		"font-semibold",
		"m-0 py-2 px-3",
		"text-surface-400 dark:text-surface-500",
		"cursor-auto"
	] },
	optionCheckIcon: "relative -ms-1.5 me-1.5 text-surface-700 dark:text-white/80 w-4 h-4",
	optionBlankIcon: "w-4 h-4",
	emptyMessage: { class: [
		"leading-none",
		"py-2 px-3",
		"text-surface-800 dark:text-white/80",
		"bg-transparent"
	] },
	header: { class: [
		"pt-2 px-2 pb-0",
		"m-0",
		"border-b-0",
		"rounded-tl-md",
		"rounded-tr-md",
		"text-surface-700 dark:text-white/80",
		"bg-surface-0 dark:bg-surface-900",
		"border-surface-300 dark:border-surface-700"
	] },
	clearIcon: { class: [
		"text-surface-400 dark:text-surface-500",
		"absolute",
		"top-1/2",
		"right-12",
		"-mt-2"
	] },
	loadingIcon: { class: "text-surface-400 dark:text-surface-500 animate-spin" },
	transition: {
		enterFromClass: "opacity-0 scale-y-[0.8]",
		enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
		leaveActiveClass: "transition-opacity duration-100 ease-linear",
		leaveToClass: "opacity-0"
	}
};
//#endregion
//#region presets/aura/selectbutton/index.js
var selectbutton_default = { root: ({ props }) => ({ class: [
	"inline-flex select-none align-bottom outline-transparent",
	"border rounded-md [&>button]:rounded-none [&>button]:border-none",
	"[&>button:first-child]:border-r-none [&>button:first-child]:rounded-r-none [&>button:first-child]:rounded-tl-md [&>button:first-child]:rounded-bl-md",
	"[&>button:last-child]:border-l-none [&>button:first-child]:rounded-l-none [&>button:last-child]:rounded-tr-md [&>button:last-child]:rounded-br-md",
	{
		"border-red-500 dark:border-red-400": props.invalid,
		"border-transparent": !props.invalid
	}
] }) };
//#endregion
//#region presets/aura/skeleton/index.js
var skeleton_default = { root: ({ props }) => ({ class: [
	"overflow-hidden",
	{ "animate-pulse": props.animation !== "none" },
	{
		"rounded-full": props.shape === "circle",
		"rounded-md": props.shape !== "circle"
	},
	"bg-surface-200 dark:bg-surface-700"
] }) };
//#endregion
//#region presets/aura/slider/index.js
var slider_default = {
	root: ({ props }) => ({ class: [
		"relative",
		{
			"h-[3px]": props.orientation == "horizontal",
			"w-[3px]": props.orientation == "vertical"
		},
		"border-0",
		"rounded-md",
		"bg-surface-200 dark:bg-surface-800",
		{ "opacity-60 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	range: ({ props }) => ({ class: [
		"block absolute",
		{
			"top-0 left-0": props.orientation == "horizontal",
			"bottom-0 left-0": props.orientation == "vertical"
		},
		{
			"h-full": props.orientation == "horizontal",
			"w-full": props.orientation == "vertical"
		},
		"rounded-md",
		"bg-primary"
	] }),
	handle: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"h-[20px]",
		"w-[20px]",
		{
			"top-[50%] -mt-[10px] -ml-[10px]": props.orientation == "horizontal",
			"left-[50%] -mb-[10px] -ml-[10px]": props.orientation == "vertical"
		},
		"rounded-full",
		"before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
		"bg-surface-200 dark:bg-surface-800",
		"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
		"ring-primary-500 dark:ring-primary-400",
		"transition duration-200",
		"cursor-grab",
		"touch-action-none"
	] }),
	startHandler: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"h-[20px]",
		"w-[20px]",
		{
			"top-[50%] -mt-[10px] -ml-[10px]": props.orientation == "horizontal",
			"left-[50%] -mb-[10px] -ml-[10px]": props.orientation == "vertical"
		},
		"rounded-full",
		"before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
		"bg-surface-200 dark:bg-surface-800",
		"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
		"ring-primary-500 dark:ring-primary-400",
		"transition duration-200",
		"cursor-grab",
		"touch-action-none"
	] }),
	endHandler: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"h-[20px]",
		"w-[20px]",
		{
			"top-[50%] -mt-[10px] -ml-[10px]": props.orientation == "horizontal",
			"left-[50%] -mb-[10px] -ml-[10px]": props.orientation == "vertical"
		},
		"rounded-full",
		"before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
		"bg-surface-200 dark:bg-surface-800",
		"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
		"ring-primary-500 dark:ring-primary-400",
		"transition duration-200",
		"cursor-grab",
		"touch-action-none"
	] })
};
//#endregion
//#region presets/aura/speeddial/index.js
var speeddial_default = {
	root: ({ state }) => ({ class: ["static flex gap-2", {
		"[&_[data-pc-name=pcbutton]]:rotate-45": state.d_visible,
		"[&_[data-pc-name=pcbutton]]:rotate-0": !state.d_visible
	}] }),
	list: { class: [
		"m-0 p-0",
		"list-none flex items-center justify-center",
		"transition delay-200",
		"z-20"
	] },
	item: ({ props, context }) => ({ class: [
		"transform transition-transform duration-200 ease-out transition-opacity duration-800",
		context.hidden ? "opacity-0 scale-0" : "opacity-100 scale-100",
		{
			"my-1 first:mb-2": props.direction == "up" && props.type == "linear",
			"my-1 first:mt-2": props.direction == "down" && props.type == "linear",
			"mx-1 first:mr-2": props.direction == "left" && props.type == "linear",
			"mx-1 first:ml-2": props.direction == "right" && props.type == "linear"
		},
		{ absolute: props.type !== "linear" }
	] }),
	mask: ({ state }) => ({ class: ["absolute left-0 top-0 w-full h-full transition-opacity duration-250 ease-in-out bg-black/40 z-0", {
		"opacity-0 pointer-events-none": !state.d_visible,
		"opacity-100 transition-opacity duration-400 ease-in-out": state.d_visible
	}] })
};
//#endregion
//#region presets/aura/splitbutton/index.js
var splitbutton_default = { root: ({ props }) => ({ class: [
	"inline-flex",
	"relative",
	"rounded-md",
	{ "shadow-lg": props.raised },
	"[&>[data-pc-name=pcbutton]]:rounded-tr-none",
	"[&>[data-pc-name=pcbutton]]:rounded-br-none",
	"[&>[data-pc-name=pcdropdown]]:rounded-tl-none",
	"[&>[data-pc-name=pcdropdown]]:rounded-bl-none",
	"[&>[data-pc-name=pcmenu]]:min-w-full"
] }) };
//#endregion
//#region presets/aura/splitter/index.js
var splitter_default = {
	root: ({ context }) => ({ class: [
		"bg-surface-0",
		"dark:bg-surface-900",
		"text-surface-700",
		"dark:text-surface-0/80",
		"rounded-md",
		{ "border border-solid border-surface-200 dark:border-surface-700": !context.nested },
		{ "flex grow border-0": context.nested }
	] }),
	gutter: ({ props }) => ({ class: [
		"flex",
		"items-center",
		"justify-center",
		"shrink-0",
		"bg-surface-100",
		"dark:bg-surface-700",
		"transition-all",
		"duration-200",
		{
			"cursor-col-resize": props.layout == "horizontal",
			"cursor-row-resize": props.layout !== "horizontal"
		}
	] }),
	gutterhandler: ({ props }) => ({ class: [
		"z-20",
		"bg-surface-100",
		"dark:bg-surface-700",
		"rounded-md",
		"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
		"transition-all",
		"duration-200",
		{
			"h-[1.70rem]": props.layout == "horizontal",
			"w-[1.70rem] h-2": props.layout !== "horizontal"
		}
	] })
};
//#endregion
//#region presets/aura/splitterpanel/index.js
var splitterpanel_default = { root: ({ context }) => ({ class: ["grow", { flex: context.nested }] }) };
//#endregion
//#region presets/aura/step/index.js
var step_default = {
	root: ({ context }) => ({ class: [
		"relative flex flex-auto items-center gap-2 p-2 last-of-type:flex-[initial]",
		{ "cursor-default pointer-events-none select-none opacity-60": context.disabled },
		"[&_[data-pc-section=separator]]:has-[~[data-p-active=true]]:bg-primary"
	] }),
	header: ({ props, context }) => ({ class: [
		"inline-flex items-center border-0 cursor-pointer rounded-md outline-transparent bg-transparent p-0 gap-2",
		"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
		{ "!cursor-default": context.active },
		{ "cursor-auto": props.linear }
	] }),
	number: ({ context }) => ({ class: [
		"flex",
		"items-center",
		"justify-center",
		"border-solid border-2 border-surface-200 dark:border-surface-700",
		context.active ? "text-primary" : "text-surface-900 dark:text-surface-0",
		"min-w-[2rem]",
		"h-[2rem]",
		"line-height-[2rem]",
		"rounded-full",
		"text-lg",
		"transition",
		"transition-colors",
		"transition-shadow",
		"duration-200"
	] }),
	title: ({ context }) => ({ class: [
		"block",
		"whitespace-nowrap",
		"overflow-hidden",
		"text-ellipsis",
		"max-w-full",
		context.active ? "text-primary" : "text-surface-700 dark:text-surface-0/80",
		"font-medium",
		"transition",
		"transition-colors",
		"transition-shadow",
		"duration-200"
	] })
};
//#endregion
//#region presets/aura/stepitem/index.js
var stepitem_default = { root: ({ state }) => ({ class: [
	"flex flex-col flex-[initial] has-[[data-pc-name=steppanels]]:px-2 has-[[data-pc-name=steppanels]]:pt-3.5 has-[[data-pc-name=steppanels]]:pb-[1.125rem]",
	{ "flex-auto": state.isActive },
	"[&>[data-pc-name=step]]:flex-[initial]",
	"[&>[data-pc-name=steppanel]]:flex [&>[data-pc-name=steppanel]]:flex-auto [&>[data-pc-name=steppanel]>[data-pc-section=content]]:w-full [&>[data-pc-name=steppanel]>[data-pc-section=content]]:pl-4 [&:last-child>[data-pc-name=steppanel]>[data-pc-section=content]]:ps-8",
	"[&>[data-pc-name=steppanel]>[data-pc-section=separator]]:relative [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:!flex-initial [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:shrink-0 [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:w-[2px] [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:h-auto [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:m-2 [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:left-[-2px] [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:ml-[1.625rem]"
] }) };
//#endregion
//#region presets/aura/steplist/index.js
var steplist_default = { root: "relative flex justify-between items-center m-0 p-0 list-none overflow-x-auto" };
//#endregion
//#region presets/aura/steppanels/index.js
var steppanels_default = { root: "px-2 pt-3.5 pb-[1.125rem]" };
//#endregion
//#region presets/aura/stepper/index.js
var stepper_default = {
	root: "has-[[data-pc-name=stepitem]]:flex has-[[data-pc-name=stepitem]]:flex-col",
	separator: "flex-1 w-full h-[2px] bg-surface-200 dark:bg-surface-700 transition-shadow duration-200",
	transition: {
		class: [
			"flex flex-1",
			"bg-surface-0 dark:bg-surface-900",
			"text-surface-900 dark:text-surface-0"
		],
		enterFromClass: "max-h-0",
		enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
		enterToClass: "max-h-[1000px]",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
		leaveToClass: "max-h-0"
	}
};
//#endregion
//#region presets/aura/steps/index.js
var steps_default = {
	root: { class: "relative" },
	menu: { class: "p-0 m-0 list-none flex" },
	menuitem: { class: [
		"relative",
		"flex",
		"justify-center",
		"flex-1",
		"overflow-hidden",
		"before:border-t-2",
		"before:border-surface-200",
		"before:dark:border-surface-700",
		"before:w-full",
		"[&:first-child]:before:w-[calc(50%+1rem)]",
		"[&:last-child]:before:w-1/2",
		"before:absolute",
		"before:top-1/2",
		"before:left-0",
		"before:transform",
		"before:mt-[calc(-1rem+1px)]",
		"[&:first-child]:before:translate-x-[100%]"
	] },
	action: ({ props }) => ({ class: [
		"inline-flex items-center",
		"flex-col",
		"transition-shadow",
		"rounded-md",
		"bg-surface-0",
		"dark:bg-transparent",
		"focus:outline-none focus:outline-offset-0 focus:ring",
		"focus:ring-primary-500 dark:focus:ring-primary-400",
		"overflow-hidden",
		{ "cursor-pointer": !props.readonly }
	] }),
	step: ({ context, props }) => ({ class: [
		"flex items-center justify-center",
		"z-20",
		"rounded-full",
		"border-2",
		"w-8",
		"h-8",
		"text-sm",
		"leading-[2rem]",
		"font-medium",
		"bg-surface-0 dark:bg-surface-800",
		"border-surface-100 dark:border-surface-700",
		{
			"text-surface-400 dark:text-white/60": !context.active,
			"text-primary": context.active
		},
		{ "hover:border-surface-300 dark:hover:border-surface-500": !context.active && !props.readonly },
		"transition-colors duration-200 ease-in-out"
	] }),
	label: ({ context }) => ({ class: [
		"leading-[normal]",
		"font-medium",
		"block",
		"mt-2",
		{
			"text-surface-700 dark:text-white/70": !context.active,
			"text-primary": context.active
		},
		"whitespace-nowrap",
		"overflow-hidden",
		"overflow-ellipsis",
		"max-w-full"
	] })
};
//#endregion
//#region presets/aura/tab/index.js
var tab_default = { root: ({ props, context }) => ({ class: [
	"relative shrink-0",
	"border-b",
	"rounded-t-md",
	"py-4 px-[1.125rem]",
	"-mb-px",
	"outline-transparent",
	{
		"border-surface-200 dark:border-surface-700": !context.active,
		"bg-surface-0 dark:bg-surface-900": !context.active,
		"text-surface-700 dark:text-surface-0/80": !context.active,
		"bg-surface-0 dark:bg-surface-900": context.active,
		"text-primary": context.active,
		"opacity-60 cursor-default user-select-none select-none pointer-events-none": props?.disabled
	},
	"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
	"transition-all duration-200",
	"cursor-pointer select-none whitespace-nowrap",
	"user-select-none"
] }) };
//#endregion
//#region presets/aura/tablist/index.js
var tablist_default = {
	root: "relative flex",
	content: "overflow-x-auto overflow-y-hidden scroll-smooth overscroll-x-contain overscroll-y-auto [&::-webkit-scrollbar]:hidden grow",
	tabList: "relative flex border-solid border-b border-surface-200 dark:border-surface-700",
	nextButton: "!absolute top-0 right-0 z-20 h-full w-10 flex items-center justify-center text-surface-700 dark:text-surface-0/80 bg-surface-0 dark:bg-surface-900 outline-transparent cursor-pointer shrink-0",
	prevButton: "!absolute top-0 left-0 z-20 h-full w-10 flex items-center justify-center text-surface-700 dark:text-surface-0/80 bg-surface-0 dark:bg-surface-900 outline-transparent cursor-pointer shrink-0",
	activeBar: "z-10 block absolute h-[1px] bottom-[-1px] bg-primary"
};
//#endregion
//#region presets/aura/tabmenu/index.js
var tabmenu_default = {
	root: { class: "overflow-x-auto" },
	menu: { class: [
		"flex flex-1",
		"list-none",
		"p-0 m-0",
		"bg-surface-0 dark:bg-surface-900",
		"border-b-2 border-surface-200 dark:border-surface-700",
		"text-surface-900 dark:text-surface-0/80"
	] },
	menuitem: { class: "mr-0" },
	action: ({ context, state }) => ({ class: [
		"relative",
		"font-semibold leading-none",
		"flex items-center",
		"py-4 px-[1.125rem]",
		"-mb-px",
		"border-b",
		"rounded-t-md",
		{
			"border-surface-200 dark:border-surface-700": state.d_activeIndex !== context.index,
			"bg-surface-0 dark:bg-surface-900": state.d_activeIndex !== context.index,
			"text-surface-700 dark:text-surface-0/80": state.d_activeIndex !== context.index,
			"bg-surface-0 dark:bg-surface-900": state.d_activeIndex === context.index,
			"border-primary": state.d_activeIndex === context.index,
			"text-primary": state.d_activeIndex === context.index
		},
		"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
		{ "hover:text-surface-900 dark:hover:text-surface-0": state.d_activeIndex !== context.index },
		"transition-all duration-200",
		"cursor-pointer select-none text-decoration-none",
		"overflow-hidden",
		"user-select-none"
	] }),
	icon: { class: "mr-2" }
};
//#endregion
//#region presets/aura/tabpanel/index.js
var tabpanel_default = { root: "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300" };
//#endregion
//#region presets/aura/tabpanels/index.js
var tabpanels_default = { root: "bg-surface-0 dark:bg-surface-900 text-surface-900 dark:text-surface-0/80 outline-0 p-[1.125rem] pt-[0.875rem]" };
//#endregion
//#region presets/aura/tabs/index.js
var tabs_default = { root: ({ props }) => ({ class: ["flex flex-col", { "[&>[data-pc-name=tablist]]:overflow-hidden": props.scrollable }] }) };
//#endregion
//#region presets/aura/tabview/index.js
var tabview_default = {
	navContainer: ({ props }) => ({ class: ["relative", { "overflow-hidden": props.scrollable }] }),
	navContent: ({ instance }) => ({ class: [
		"overflow-y-hidden overscroll-contain",
		"overscroll-auto",
		"scroll-smooth",
		"[&::-webkit-scrollbar]:hidden"
	] }),
	previousButton: { class: [
		"flex items-center justify-center",
		"!absolute",
		"top-0 left-0",
		"z-20",
		"h-full w-10",
		"rounded-none",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-700 dark:text-surface-0/80",
		"shadow-sm"
	] },
	nextButton: { class: [
		"flex items-center justify-center",
		"!absolute",
		"top-0 right-0",
		"z-20",
		"h-full w-10",
		"rounded-none",
		"text-surface-700 dark:text-surface-0/80",
		"bg-surface-0 dark:bg-surface-900",
		"shadow-sm"
	] },
	nav: { class: [
		"flex flex-1",
		"list-none",
		"p-0 m-0",
		"bg-surface-0 dark:bg-surface-900",
		"border-b border-surface-200 dark:border-surface-700",
		"text-surface-900 dark:text-surface-0/80"
	] },
	tabpanel: {
		header: ({ props }) => ({ class: [
			"mr-0",
			"outline-none",
			{ "opacity-60 cursor-default user-select-none select-none pointer-events-none": props?.disabled }
		] }),
		headerAction: ({ parent, context }) => ({ class: [
			"relative",
			"font-semibold",
			"flex items-center",
			"py-4 px-[1.125rem]",
			"-mb-px",
			"border-b-2",
			"rounded-t-md",
			{
				"border-surface-200 dark:border-surface-700": parent.state.d_activeIndex !== context.index,
				"bg-surface-0 dark:bg-surface-900": parent.state.d_activeIndex !== context.index,
				"text-surface-700 dark:text-surface-0/80": parent.state.d_activeIndex !== context.index,
				"bg-surface-0 dark:bg-surface-900": parent.state.d_activeIndex === context.index,
				"border-primary": parent.state.d_activeIndex === context.index,
				"text-primary": parent.state.d_activeIndex === context.index
			},
			"focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
			{
				"hover:bg-surface-0 dark:hover:bg-surface-800/80": parent.state.d_activeIndex !== context.index,
				"hover:text-surface-900 dark:hover:text-surface-0": parent.state.d_activeIndex !== context.index
			},
			"transition-all duration-200",
			"cursor-pointer select-none text-decoration-none",
			"overflow-hidden",
			"user-select-none"
		] }),
		headerTitle: { class: ["leading-none", "whitespace-nowrap"] }
	},
	panelcontainer: { class: [
		"p-[1.125rem] pt-[0.875rem]",
		"border-0 rounded-none",
		"border-br-md border-bl-md",
		"bg-surface-0 dark:bg-surface-900",
		"text-surface-900 dark:text-surface-0/80"
	] }
};
//#endregion
//#region presets/aura/tag/index.js
var tag_default = {
	root: ({ props }) => ({ class: [
		"text-xs font-bold",
		"inline-flex items-center justify-center",
		"px-[0.4rem] py-1",
		{
			"rounded-md": !props.rounded,
			"rounded-full": props.rounded
		},
		{
			"bg-highlight": props.severity === null || props.severity === "primary",
			"text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-500/20": props.severity === "success",
			"text-surface-700 dark:text-surface-300 bg-surface-100 dark:bg-surface-500/20": props.severity === "secondary",
			"text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-500/20": props.severity === "info",
			"text-orange-700 dark:text-orange-300 bg-orange-100 dark:bg-orange-500/20": props.severity === "warn",
			"text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-500/20": props.severity === "danger",
			"text-surface-0 dark:text-surface-900 bg-surface-900 dark:bg-surface-0": props.severity === "contrast"
		}
	] }),
	value: { class: "leading-normal" },
	icon: { class: "mr-1 text-sm" }
};
//#endregion
//#region presets/aura/terminal/index.js
var terminal_default = {
	root: { class: [
		"py-2 px-3",
		"rounded-md",
		"bg-surface-0 dark:bg-surface-950 text-surface-700 dark:text-surface-0",
		"border border-surface-200 dark:border-surface-700",
		"h-72 overflow-auto"
	] },
	container: { class: ["flex items-center"] },
	prompt: { class: ["text-surface-700 dark:text-surface-0"] },
	response: { class: ["text-surface-700 dark:text-surface-0"] },
	command: { class: ["text-surface-700 dark:text-surface-0"] },
	commandtext: { class: [
		"flex-1 shrink grow-0",
		"border-0",
		"p-0",
		"bg-transparent text-inherit",
		"outline-none"
	] }
};
//#endregion
//#region presets/aura/textarea/index.js
var textarea_default = { root: ({ context, props, parent }) => ({ class: [
	"leading-none",
	"m-0",
	"py-2 px-3",
	"rounded-md",
	"text-surface-800 dark:text-white/80",
	"placeholder:text-surface-400 dark:placeholder:text-surface-500",
	{ "bg-surface-0 dark:bg-surface-950": !context.disabled },
	"border",
	{ "border-surface-300 dark:border-surface-600": !props.invalid },
	"invalid:focus:ring-red-200",
	"invalid:hover:border-red-500",
	{ "border-red-500 dark:border-red-400": props.invalid },
	{
		"hover:border-surface-400 dark:hover:border-surface-600": !context.disabled && !props.invalid,
		"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !context.disabled,
		"bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": context.disabled
	},
	{ filled: parent.instance?.$name == "FloatLabel" && props.modelValue !== null && props.modelValue?.length !== 0 },
	"appearance-none",
	"transition-colors duration-200"
] }) };
//#endregion
//#region presets/aura/tieredmenu/index.js
var tieredmenu_default = {
	root: { class: [
		"rounded-md",
		"min-w-[12rem]",
		"p-1",
		"bg-surface-0 dark:bg-surface-900",
		"border border-surface-200 dark:border-surface-700"
	] },
	rootList: { class: [
		"list-none",
		"flex flex-col",
		"m-0 p-0",
		"outline-none"
	] },
	item: { class: "relative my-[2px] [&:first-child]:mt-0" },
	itemContent: ({ context }) => ({ class: [
		"rounded-[4px]",
		"text-surface-700 dark:text-white/80",
		{
			"text-surface-500 dark:text-white/70": !context.focused && !context.active,
			"text-surface-500 dark:text-white/70 bg-surface-200": context.focused && !context.active,
			"bg-highlight": context.focused && context.active || context.active || !context.focused && context.active
		},
		"transition-shadow",
		"duration-200",
		{
			"hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !context.active,
			"hover:bg-highlight-emphasis": context.active
		},
		{ "opacity-60 pointer-events-none cursor-default": context.disabled }
	] }),
	itemLink: { class: [
		"relative",
		"flex",
		"items-center",
		"py-2",
		"px-3",
		"text-surface-700 dark:text-white/80",
		"no-underline",
		"overflow-hidden",
		"cursor-pointer",
		"select-none"
	] },
	itemIcon: { class: ["mr-2", "text-surface-600 dark:text-white/70"] },
	itemLabel: { class: ["leading-none"] },
	submenuIcon: { class: ["ml-auto"] },
	submenu: { class: [
		"flex flex-col",
		"m-0",
		"p-1",
		"list-none",
		"min-w-[12.5rem]",
		"shadow-none sm:shadow-md",
		"border border-surface-200 dark:border-surface-700",
		"static sm:absolute",
		"z-10",
		"bg-surface-0 dark:bg-surface-900"
	] },
	separator: { class: "border-t border-surface-200 dark:border-surface-600 my-[2px]" },
	transition: {
		enterFromClass: "opacity-0",
		enterActiveClass: "transition-opacity duration-250"
	}
};
//#endregion
//#region presets/aura/timeline/index.js
var timeline_default = {
	root: ({ props }) => ({ class: ["flex grow", {
		"flex-col": props.layout === "vertical",
		"flex-row": props.layout === "horizontal"
	}] }),
	event: ({ props, context }) => ({ class: ["flex relative min-h-[70px]", {
		"flex-row-reverse": props.align === "right" || props.layout === "vertical" && props.align === "alternate" && context.index % 2 === 1,
		"flex-col [&:not(:last-child)]:flex-1": props.layout === "horizontal",
		"flex-col-reverse ": props.align === "bottom" || props.layout === "horizontal" && props.align === "alternate" && context.index % 2 === 1
	}] }),
	eventOpposite: ({ props, context }) => ({ class: [
		"flex-1",
		{
			"px-4": props.layout === "vertical",
			"py-4": props.layout === "horizontal"
		},
		{
			"text-right": props.align === "left" || props.layout === "vertical" && props.align === "alternate" && context.index % 2 === 0,
			"text-left": props.align === "right" || props.layout === "vertical" && props.align === "alternate" && context.index % 2 === 1
		}
	] }),
	eventSeparator: ({ props }) => ({ class: ["flex items-center flex-initial", {
		"flex-col": props.layout === "vertical",
		"flex-row": props.layout === "horizontal"
	}] }),
	eventMarker: { class: [
		"relative",
		"inline-flex items-center justify-center",
		"w-[1.125rem] h-[1.125rem]",
		"rounded-full border-2 border-surface-200 bg-surface-0 dark:border-surface-700 dark:bg-surface-950",
		"before:rounded-full before:w-[0.375rem] before:h-[0.375rem] before:bg-primary",
		"after:absolute after:rounded-full after:w-full after:h-full after:shadow-sm"
	] },
	eventConnector: ({ props }) => ({ class: ["grow bg-surface-300 dark:bg-surface-700", {
		"w-[2px]": props.layout === "vertical",
		"w-full h-[2px]": props.layout === "horizontal"
	}] }),
	eventContent: ({ props, context }) => ({ class: [
		"flex-1",
		{
			"px-4": props.layout === "vertical",
			"py-4": props.layout === "horizontal"
		},
		{
			"text-left": props.align === "left" || props.layout === "vertical" && props.align === "alternate" && context.index % 2 === 0,
			"text-right": props.align === "right" || props.layout === "vertical" && props.align === "alternate" && context.index % 2 === 1
		},
		{
			"min-h-0": props.layout === "vertical" && context.index === context.count - 1,
			"grow-0": props.layout === "horizontal" && context.index === context.count - 1
		}
	] })
};
//#endregion
//#region presets/aura/toast/index.js
var toast_default = {
	root: ({ props }) => ({ class: ["w-96 rounded-md", { "-translate-x-2/4": props.position == "top-center" || props.position == "bottom-center" }] }),
	message: ({ props }) => ({ class: [
		"mb-4 rounded-md w-full",
		"border border-transparent",
		"backdrop-blur-[10px] shadow-md",
		{
			"bg-blue-50/90 dark:bg-blue-500/20": props.message.severity == "info",
			"bg-green-50/90 dark:bg-green-500/20": props.message.severity == "success",
			"bg-surface-50 dark:bg-surface-800": props.message.severity == "secondary",
			"bg-orange-50/90 dark:bg-orange-500/20": props.message.severity == "warn",
			"bg-red-50/90 dark:bg-red-500/20": props.message.severity == "error",
			"bg-surface-950 dark:bg-surface-0": props.message.severity == "contrast"
		},
		{
			"border-blue-200 dark:border-blue-500/20": props.message.severity == "info",
			"border-green-200 dark:border-green-500/20": props.message.severity == "success",
			"border-surface-300 dark:border-surface-500/20": props.message.severity == "secondary",
			"border-orange-200 dark:border-orange-500/20": props.message.severity == "warn",
			"border-red-200 dark:border-red-500/20": props.message.severity == "error",
			"border-surface-950 dark:border-surface-0": props.message.severity == "contrast"
		},
		{
			"text-blue-700 dark:text-blue-300": props.message.severity == "info",
			"text-green-700 dark:text-green-300": props.message.severity == "success",
			"text-surface-700 dark:text-surface-300": props.message.severity == "secondary",
			"text-orange-700 dark:text-orange-300": props.message.severity == "warn",
			"text-red-700 dark:text-red-300": props.message.severity == "error",
			"text-surface-0 dark:text-surface-950": props.message.severity == "contrast"
		}
	] }),
	messageContent: ({ props }) => ({ class: ["flex p-3", {
		"items-start": props.message.summary,
		"items-center": !props.message.summary
	}] }),
	messageIcon: ({ props }) => ({ class: [props.message.severity === "contrast" || props.message.severity === "secondary" ? "w-0" : "w-[1.125rem] h-[1.125rem] mr-2", "text-lg leading-[normal]"] }),
	messageText: { class: [
		"text-base leading-[normal]",
		"ml-2",
		"flex-1"
	] },
	summary: { class: "font-medium block" },
	detail: ({ props }) => ({ class: [
		"block",
		"text-sm",
		props.message.severity === "contrast" ? "text-surface-0 dark:text-surface-950" : "text-surface-700 dark:text-surface-0",
		{ "mt-2": props.message.summary }
	] }),
	closeButton: ({ props }) => ({ class: [
		"flex items-center justify-center",
		"w-7 h-7",
		"ml-auto  relative",
		"rounded-full",
		"bg-transparent",
		"transition duration-200 ease-in-out",
		"hover:bg-surface-0/30 dark:hover:bg-[rgba(255,255,255,0.03)]",
		"focus:outline-none focus:outline-offset-0 focus:ring-1",
		{
			"focus:ring-blue-500 dark:focus:ring-blue-400": props.severity == "info",
			"focus:ring-green-500 dark:focus:ring-green-400": props.severity == "success",
			"focus:ring-surface-500 dark:focus:ring-surface-400": props.severity == "secondary",
			"focus:ring-orange-500 dark:focus:ring-orange-400": props.severity == "warn",
			"focus:ring-red-500 dark:focus:ring-red-4000": props.severity == "error",
			"focus:ring-surface-0 dark:focus:ring-surface-950": props.severity == "contrast"
		},
		"overflow-hidden"
	] }),
	transition: {
		enterFromClass: "opacity-0 translate-y-2/4",
		enterActiveClass: "transition-[transform,opacity] duration-300",
		leaveFromClass: "max-h-[1000px]",
		leaveActiveClass: "!transition-[max-height_.45s_cubic-bezier(0,1,0,1),opacity_.3s,margin-bottom_.3s] overflow-hidden",
		leaveToClass: "max-h-0 opacity-0 mb-0"
	}
};
//#endregion
//#region presets/aura/togglebutton/index.js
var togglebutton_default = {
	root: ({ props, context }) => ({ class: [
		"relative",
		"flex items-center justify-center",
		"py-2 px-4",
		"rounded-md border",
		"bg-surface-100 dark:bg-surface-950",
		{
			"text-surface-600 dark:text-white/60 before:bg-transparent": !context.active,
			"text-surface-800 dark:text-white/80 before:bg-surface-0 dark:before:bg-surface-800": context.active
		},
		{
			"hover:text-surface-800 dark:hover:text-white/80": !props.disabled && !props.modelValue,
			"focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400": !props.disabled
		},
		{
			"border-red-500 dark:border-red-400": props.invalid,
			"border-surface-100 dark:border-surface-950": !props.invalid
		},
		"before:absolute before:left-1 before:top-1 before:w-[calc(100%-0.5rem)] before:h-[calc(100%-0.5rem)] before:rounded-[4px] before:z-0",
		"transition-all duration-200",
		{
			"cursor-pointer": !props.disabled,
			"opacity-60 select-none pointer-events-none cursor-default": props.disabled
		}
	] }),
	content: "relative items-center inline-flex justify-center gap-2",
	label: "font-medium leading-[normal] text-center w-full z-10 relative",
	icon: "relative z-10 mr-2"
};
//#endregion
//#region presets/aura/toggleswitch/index.js
var toggleswitch_default = {
	root: ({ props }) => ({ class: [
		"inline-block relative",
		"w-10 h-6",
		"rounded-2xl",
		{ "opacity-60 select-none pointer-events-none cursor-default": props.disabled }
	] }),
	slider: ({ props }) => ({ class: [
		"absolute top-0 left-0 right-0 bottom-0",
		{ "before:transform before:translate-x-4": props.modelValue == props.trueValue },
		"rounded-2xl",
		"before:absolute before:top-1/2 before:left-1",
		"before:-mt-2",
		"before:h-4 before:w-4",
		"before:rounded-full",
		"before:duration-200",
		"before:bg-surface-0 before:dark:bg-surface-500",
		"border",
		{
			"bg-surface-300 dark:bg-surface-800": !(props.modelValue == props.trueValue),
			"bg-black dark:bg-white": props.modelValue == props.trueValue,
			"before:dark:bg-surface-950": props.modelValue == props.trueValue,
			"border-transparent": !props.invalid
		},
		{ "border-red-500 dark:border-red-400": props.invalid },
		{ "peer-hover:bg-surface-400 dark:peer-hover:bg-surface-700": !(props.modelValue == props.trueValue) && !props.disabled && !props.invalid },
		{ "peer-hover:bg-black-hover": props.modelValue == props.trueValue && !props.disabled && !props.invalid },
		"peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-primary-400",
		"transition-colors duration-200",
		"cursor-pointer"
	] }),
	input: { class: [
		"peer",
		"w-full ",
		"h-full",
		"absolute",
		"top-0 left-0",
		"z-10",
		"p-0",
		"m-0",
		"opacity-0",
		"rounded-2xl",
		"outline-none",
		"appearance-none",
		"cursor-pointer"
	] }
};
//#endregion
//#region presets/aura/index.js
var aura_default = {
	global: global_default,
	directives: {
		badge: badgedirective_default,
		ripple: ripple_default,
		tooltip: {
			root: ({ context }) => ({ class: [
				"absolute",
				"shadow-md",
				"p-fadein",
				{
					"py-0 px-1": context?.right || context?.left || !context?.right && !context?.left && !context?.top && !context?.bottom,
					"py-1 px-0": context?.top || context?.bottom
				}
			] }),
			arrow: ({ context }) => ({ class: [
				"absolute",
				"w-0",
				"h-0",
				"border-transparent",
				"border-solid",
				{
					"border-y-[10px] border-r-[10px] border-l-0 border-r-surface-700": context?.right || !context?.right && !context?.left && !context?.top && !context?.bottom,
					"border-y-[10px] border-l-[10px] border-r-0 border-l-surface-700": context?.left,
					"border-x-[10px] border-t-[10px] border-b-0 border-t-surface-700": context?.top,
					"border-x-[10px] border-b-[10px] border-t-0 border-b-surface-700": context?.bottom
				},
				{
					"-mt-[10px] top-1/2": context?.right || context?.left || !context?.right && !context?.left && !context?.top && !context?.bottom,
					"-ml-[10px] left-1/2": context?.top || context?.bottom
				}
			] }),
			text: { class: [
				"p-3",
				"bg-surface-700",
				"text-white",
				"leading-none",
				"rounded-md",
				"whitespace-pre-line",
				"break-words"
			] }
		}
	},
	autocomplete: autocomplete_default,
	select: select_default,
	dropdown: select_default,
	inputnumber: inputnumber_default,
	inputtext: inputtext_default,
	datepicker: datepicker_default,
	calendar: datepicker_default,
	checkbox: checkbox_default,
	radiobutton: radiobutton_default,
	toggleswitch: toggleswitch_default,
	inputswitch: toggleswitch_default,
	selectbutton: selectbutton_default,
	slider: slider_default,
	rating: rating_default,
	multiselect: multiselect_default,
	togglebutton: togglebutton_default,
	cascadeselect: cascadeselect_default,
	listbox: listbox_default,
	colorpicker: colorpicker_default,
	inputgroup: inputgroup_default,
	inputgroupaddon: inputgroupaddon_default,
	inputmask: inputmask_default,
	knob: knob_default,
	treeselect: {
		root: ({ props, state }) => ({ class: [
			"inline-flex",
			"relative",
			"rounded-md",
			{ "bg-surface-0 dark:bg-surface-950": !props.disabled },
			"border",
			{ "border-surface-300 dark:border-surface-700": !props.invalid },
			"invalid:focus:ring-red-200",
			"invalid:hover:border-red-500",
			{ "border-red-500 dark:border-red-400": props.invalid },
			"transition-all",
			"duration-200",
			{ "hover:border-surface-400 dark:hover:border-surface-600": !props.invalid },
			{ "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-primary-400 z-10": state.focused },
			"cursor-pointer",
			"select-none",
			{ "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": props.disabled }
		] }),
		labelContainer: { class: ["overflow-hidden flex flex-auto cursor-pointer"] },
		label: { class: [
			"block leading-[normal]",
			"py-2 px-3",
			"text-surface-800 dark:text-white/80",
			"transition duration-200",
			"overflow-hidden whitespace-nowrap cursor-pointer overflow-ellipsis"
		] },
		dropdown: { class: [
			"flex items-center justify-center",
			"shrink-0",
			"bg-transparent",
			"text-surface-500",
			"w-12",
			"rounded-r-md"
		] },
		panel: { class: [
			"bg-surface-0 dark:bg-surface-900",
			"text-surface-700 dark:text-white/80",
			"border border-surface-300 dark:border-surface-700",
			"rounded-md",
			"shadow-md"
		] },
		treeContainer: { class: ["max-h-[200px]", "overflow-auto"] },
		transition: {
			enterFromClass: "opacity-0 scale-y-[0.8]",
			enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
			leaveActiveClass: "transition-opacity duration-100 ease-linear",
			leaveToClass: "opacity-0"
		}
	},
	textarea: textarea_default,
	password: password_default,
	iconfield: iconfield_default,
	floatlabel: floatlabel_default,
	inputotp: inputotp_default,
	button: button_default,
	buttongroup: buttongroup_default,
	splitbutton: splitbutton_default,
	speeddial: speeddial_default,
	paginator: paginator_default,
	datatable: datatable_default,
	tree: {
		root: { class: [
			"p-4",
			"rounded-md",
			"border-none",
			"bg-surface-100/80 dark:bg-surface-900/60",
			"text-surface-700 dark:text-white/80",
			"[&_[data-pc-name=pcfilter]]:w-full"
		] },
		wrapper: { class: ["overflow-auto", "max-h-[61vh]"] },
		container: { class: ["m-0 p-0", "list-none overflow-auto"] },
		node: { class: [
			"p-0 my-[2px] mx-0 first:mt-0",
			"rounded-md",
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-inset focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10"
		] },
		nodeContent: ({ context, props }) => ({ class: [
			"flex items-center",
			"rounded-md",
			"py-1 px-2 gap-2",
			context.selected ? "bg-highlight text-primary-600 dark:text-white" : "bg-transparent text-surface-600 dark:text-white/70",
			{ "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": (props.selectionMode == "single" || props.selectionMode == "multiple") && !context.selected },
			"transition-shadow duration-200",
			{ "cursor-pointer select-none": props.selectionMode == "single" || props.selectionMode == "multiple" }
		] }),
		nodeToggleButton: ({ context }) => ({ class: [
			"inline-flex items-center justify-center",
			"border-0 rounded-full",
			"w-7 h-7",
			"bg-transparent",
			{
				"text-surface-600 dark:text-white/70": !context.selected,
				"text-primary-600 dark:text-white": context.selected,
				invisible: context.leaf
			},
			"hover:bg-surface-200/20 dark:hover:bg-surface-500/20",
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
			"transition duration-200",
			"cursor-pointer select-none"
		] }),
		nodeIcon: ({ context }) => ({ class: ["mr-2", {
			"text-surface-600 dark:text-white/70": !context.selected,
			"text-primary-600 dark:text-white": context.selected
		}] }),
		nodeLabel: ({ context }) => ({ class: [{
			"text-surface-600 dark:text-white/70": !context.selected,
			"text-primary-600 dark:text-white": context.selected
		}] }),
		nodeChildren: { class: ["m-0 list-none p-0 pl-4 [&:not(ul)]:pl-0 [&:not(ul)]:my-[2px]"] },
		loadingIcon: { class: ["text-surface-500 dark:text-surface-0/70", "absolute top-[50%] right-[50%] -mt-2 -mr-2 animate-spin"] }
	},
	dataview: dataview_default,
	organizationchart: organizationchart_default,
	orderlist: orderlist_default,
	picklist: picklist_default,
	treetable: {
		root: ({ props }) => ({ class: ["relative", { "flex flex-col h-full": props.scrollHeight === "flex" }] }),
		mask: { class: [
			"absolute",
			"top-0 left-0",
			"z-20",
			"flex items-center justify-center",
			"w-full h-full",
			"bg-surface-100/40 dark:bg-surface-800/40",
			"transition duration-200"
		] },
		loadingIcon: { class: "w-8 h-8 animate-spin" },
		tableContainer: ({ props }) => ({ class: [{
			"relative overflow-auto": props.scrollable,
			"overflow-x-auto": props.resizableColumns
		}] }),
		header: ({ props }) => ({ class: [
			"font-semibold",
			props.showGridlines ? "border-x border-t border-b-0" : "border-y border-x-0",
			"p-4",
			"bg-surface-0 dark:bg-surface-900",
			"border-surface-200 dark:border-surface-700",
			"text-surface-700 dark:text-white/80"
		] }),
		footer: { class: [
			"font-semibold",
			"border-t-0 border-b border-x-0",
			"p-4",
			"bg-surface-0 dark:bg-surface-900",
			"border-surface-200 dark:border-surface-700",
			"text-surface-700 dark:text-white/80"
		] },
		table: { class: ["border-collapse table-fixed w-full "] },
		thead: ({ props }) => ({ class: [{ "top-0 z-40 sticky": props.scrollable }] }),
		tbody: ({ props }) => ({ class: [{ block: props.scrollable }] }),
		tfoot: ({ props }) => ({ class: [{ block: props.scrollable }] }),
		headerRow: ({ props }) => ({ class: [{ "flex flex-nowrap w-full": props.scrollable }] }),
		row: ({ context, props }) => ({ class: [
			{ "flex flex-nowrap w-full": context.scrollable },
			"text-surface-700 dark:text-white/80",
			{ "bg-highlight": context.selected },
			{ "bg-surface-0 text-surface-600 dark:bg-surface-900": !context.selected },
			{ "hover:bg-surface-100 dark:bg-surface-800/50": context.selectable && !context.selected },
			"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 ring-inset dark:focus:ring-primary-400",
			{ "transition duration-200": props.selectionMode && !context.selected || props.rowHover }
		] }),
		headerCell: ({ context, props }) => ({ class: [
			"font-semibold",
			"leading-[normal]",
			{ "sticky z-40": context.scrollable && context.scrollDirection === "both" && context.frozen },
			{
				"flex flex-1 items-center": context.scrollable,
				"flex-initial shrink-0": context.scrollable && context.scrollDirection === "both" && !context.frozen
			},
			"text-left",
			{ "first:border-l border-y border-r": context?.showGridlines },
			"border-0 border-b border-solid",
			context?.size === "small" ? "py-[0.375rem] px-2" : context?.size === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
			(props.sortable === "" || props.sortable) && context.sorted ? "bg-highlight" : "bg-surface-0 text-surface-700 dark:text-white/80 dark:bg-surface-900",
			"border-surface-200 dark:border-surface-700",
			{ "hover:bg-surface-100 dark:hover:bg-surface-80/50": (props.sortable === "" || props.sortable) && !context?.sorted },
			"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
			{ "transition duration-200": props.sortable === "" || props.sortable },
			{ "overflow-hidden relative bg-clip-padding": context.resizable && !context.frozen }
		] }),
		column: {
			headerCell: ({ context, props }) => ({ class: [
				"font-semibold",
				"leading-[normal]",
				{ "sticky z-40": context.scrollable && context.scrollDirection === "both" && context.frozen },
				{
					"flex flex-1 items-center": context.scrollable,
					"flex-initial shrink-0": context.scrollable && context.scrollDirection === "both" && !context.frozen
				},
				"text-left",
				{ "first:border-l border-y border-r": context?.showGridlines },
				"border-0 border-b border-solid",
				context?.size === "small" ? "py-[0.375rem] px-2" : context?.size === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
				(props.sortable === "" || props.sortable) && context.sorted ? "bg-highlight" : "bg-surface-0 text-surface-700 dark:text-white/80 dark:bg-surface-900",
				"border-surface-200 dark:border-surface-700",
				{ "hover:bg-surface-100 dark:hover:bg-surface-80/50": (props.sortable === "" || props.sortable) && !context?.sorted },
				"focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
				{ "transition duration-200": props.sortable === "" || props.sortable },
				{ "overflow-hidden relative bg-clip-padding": context.resizable && !context.frozen }
			] }),
			bodyCell: ({ context }) => ({ class: [
				"leading-[normal]",
				{ sticky: context.scrollable && context.scrollDirection === "both" && context.frozen },
				{
					"flex flex-1 items-center": context.scrollable,
					"flex-initial shrink-0": context.scrollable && context.scrollDirection === "both" && !context.frozen
				},
				"text-left",
				"border-0 border-b border-solid",
				"border-surface-200 dark:border-surface-700",
				{ "border-x-0 border-l-0": !context.showGridlines },
				{ "first:border-l border-r border-b": context?.showGridlines },
				context?.size === "small" ? "py-[0.375rem] px-2" : context?.size === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
				{
					"cursor-pointer": context.selectable,
					sticky: context.scrollable && context.scrollDirection === "both" && context.frozen,
					"border-x-0 border-l-0": !context.showGridlines
				}
			] }),
			bodyCellContent: "flex items-center gap-2",
			rowToggleButton: { class: [
				"relative",
				"inline-flex items-center justify-center",
				"text-left align-middle",
				"m-0 mr-2 p-0",
				"w-7 h-7",
				"border-0 rounded-full",
				"text-surface-700 dark:text-white/70",
				"border-transparent",
				"focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
				"hover:text-surface-700 hover:bg-surface-50 dark:hover:bg-surface-800/50",
				"transition duration-200",
				"overflow-hidden",
				"cursor-pointer select-none"
			] },
			sortIcon: ({ context }) => ({ class: ["ml-2 inline-block", context.sorted ? "text-inherit" : "fill-surface-700 dark:fill-white/70"] }),
			columnResizer: { class: [
				"block",
				"absolute top-0 right-0",
				"w-2 h-full",
				"m-0 p-0",
				"border border-transparent",
				"cursor-col-resize"
			] },
			transition: {
				enterFromClass: "opacity-0 scale-y-[0.8]",
				enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
				leaveActiveClass: "transition-opacity duration-100 ease-linear",
				leaveToClass: "opacity-0"
			}
		},
		columnResizeIndicator: { class: "absolute hidden w-[2px] z-20 bg-primary" }
	},
	timeline: timeline_default,
	accordion: accordion_default,
	accordionpanel: accordionpanel_default,
	accordionheader: accordionheader_default,
	accordioncontent: accordioncontent_default,
	panel: panel_default,
	fieldset: fieldset_default,
	card: card_default,
	tabview: tabview_default,
	divider: divider_default,
	toolbar: {
		root: { class: [
			"flex items-center justify-between flex-wrap",
			"gap-2",
			"p-3",
			"rounded-md",
			"bg-surface-0 dark:bg-surface-900",
			"border border-surface-200 dark:border-surface-700"
		] },
		start: { class: "flex items-center" },
		center: { class: "flex items-center" },
		end: { class: "flex items-center" }
	},
	scrollpanel: scrollpanel_default,
	splitter: splitter_default,
	splitterpanel: splitterpanel_default,
	stepper: stepper_default,
	steplist: steplist_default,
	step: step_default,
	stepitem: stepitem_default,
	steppanels: steppanels_default,
	deferred: deferred_default,
	tab: tab_default,
	tabs: tabs_default,
	tablist: tablist_default,
	tabpanels: tabpanels_default,
	tabpanel: tabpanel_default,
	fileupload: fileupload_default,
	contextmenu: contextmenu_default,
	menu: menu_default,
	menubar: menubar_default,
	steps: steps_default,
	tieredmenu: tieredmenu_default,
	breadcrumb: breadcrumb_default,
	panelmenu: panelmenu_default,
	megamenu: megamenu_default,
	dock: dock_default,
	tabmenu: tabmenu_default,
	dialog: dialog_default,
	popover: popover_default,
	sidebar: popover_default,
	drawer: drawer_default,
	overlaypanel: drawer_default,
	confirmpopup: confirmpopup_default,
	confirmdialog: confirmdialog_default,
	message: message_default,
	toast: toast_default,
	carousel: carousel_default,
	galleria: galleria_default,
	image: image_default,
	badge: badge_default,
	overlaybadge: overlaybadge_default,
	avatar: avatar_default,
	avatargroup: avatargroup_default,
	tag: tag_default,
	chip: chip_default,
	progressbar: progressbar_default,
	skeleton: skeleton_default,
	scrolltop: scrolltop_default,
	terminal: terminal_default,
	blockui: blockui_default,
	metergroup: metergroup_default,
	inplace: inplace_default,
	progressspinner: progressspinner_default
};
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fprimevue-plugin.mjs
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fprimevue_plugin_default = defineNuxtPlugin(({ vueApp }) => {
	const { usePrimeVue = true, options = {} } = useRuntimeConfig()?.public?.primevue ?? {};
	const pt = { pt: aura_default };
	const theme = {};
	usePrimeVue && vueApp.use(PrimeVue, {
		...options,
		...pt,
		...theme
	});
	vueApp.use(ConfirmationService);
	vueApp.use(DialogService);
	vueApp.use(ToastService);
});
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fpwa-icons-plugin.ts
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fpwa_icons_plugin_default = defineNuxtPlugin(() => {
	return { provide: { pwaIcons: {
		transparent: {},
		maskable: {},
		favicon: {},
		apple: {},
		appleSplashScreen: {}
	} } };
});
//#endregion
//#region node_modules/@nuxt/icon/dist/runtime/plugin.js
var plugin_default = defineNuxtPlugin({
	name: "@nuxt/icon",
	setup() {
		const configs = useRuntimeConfig();
		const options = useAppConfig().icon;
		_api.setFetch($fetch.native);
		const resources = [];
		if (options.provider === "server") {
			const baseURL = configs.app?.baseURL?.replace(/\/$/, "") ?? "";
			resources.push(baseURL + (options.localApiEndpoint || "/api/_nuxt_icon"));
			if (options.fallbackToApi === true || options.fallbackToApi === "client-only") resources.push(options.iconifyApiEndpoint);
		} else if (options.provider === "none") _api.setFetch(() => Promise.resolve(new Response()));
		else resources.push(options.iconifyApiEndpoint);
		async function customIconLoader(icons, prefix) {
			try {
				const data = await $fetch(resources[0] + "/" + prefix + ".json", { query: { icons: icons.join(",") } });
				if (!data || data.prefix !== prefix || !data.icons) throw new Error("Invalid data" + JSON.stringify(data));
				return data;
			} catch (e) {
				console.error("Failed to load custom icons", e);
				return null;
			}
		}
		addAPIProvider("", { resources });
		for (const prefix of options.customCollections || []) if (prefix) setCustomIconsLoader(customIconLoader, prefix);
	}
});
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/plugins/route-locale-detect.js
var route_locale_detect_default = defineNuxtPlugin({
	name: "i18n:plugin:route-locale-detect",
	dependsOn: ["i18n:plugin"],
	async setup(_nuxt) {
		let __temp, __restore;
		const nuxt = useNuxtApp(_nuxt._id);
		const ctx = useNuxtI18nContext(nuxt);
		const resolvedLocale = useResolvedLocale();
		[__temp, __restore] = executeAsync(() => nuxt.runWithContext(() => loadAndSetLocale(nuxt, ctx.initial && resolvedLocale.value || detectLocale(nuxt, nuxt.$router.currentRoute.value)))), await __temp, __restore();
	}
});
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/routing/i18n.js
function extendI18n(i18n, { extendComposer, extendComposerInstance }) {
	const scope = effectScope();
	const installI18n = i18n.install.bind(i18n);
	i18n.install = (app, ...options) => {
		const pluginOptions = assign({}, options[0]);
		pluginOptions.__composerExtend = (c) => {
			extendComposerInstance(c, getComposer(i18n));
			return () => {};
		};
		if (i18n.mode === "legacy") pluginOptions.__vueI18nExtend = (vueI18n) => {
			extendComposerInstance(vueI18n, getComposer(vueI18n));
			return () => {};
		};
		Reflect.apply(installI18n, i18n, [app, pluginOptions]);
		const globalComposer = getComposer(i18n);
		scope.run(() => {
			extendComposer(globalComposer);
			if (i18n.mode === "legacy" && "__composer" in i18n.global) extendComposerInstance(i18n.global, getComposer(i18n.global));
		});
		if (i18n.mode === "composition" && app.config.globalProperties.$i18n != null) extendComposerInstance(app.config.globalProperties.$i18n, globalComposer);
		if (app.unmount) {
			const unmountApp = app.unmount.bind(app);
			app.unmount = () => {
				scope.stop();
				unmountApp();
			};
		}
	};
}
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/shared/vue-i18n.js
var setupVueI18nOptions = async (defaultLocale) => {
	const options = await loadVueI18nOptions(vueI18nConfigs);
	options.locale = defaultLocale || options.locale || "en-US";
	options.defaultLocale = defaultLocale;
	options.fallbackLocale ??= false;
	options.messages ??= {};
	for (const locale of localeCodes) options.messages[locale] ??= {};
	return options;
};
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/plugins/i18n.js
var i18n_default = defineNuxtPlugin({
	name: "i18n:plugin",
	parallel: false,
	async setup(_nuxt) {
		let __temp, __restore;
		Object.defineProperty(_nuxt.versions, "nuxtI18n", { get: () => "10.2.4" });
		const nuxt = useNuxtApp(_nuxt._id);
		const runtimeI18n = useRuntimeI18n(nuxt);
		const preloadedOptions = nuxt.ssrContext?.event?.context?.nuxtI18n?.vueI18nOptions;
		const _defaultLocale = getDefaultLocaleForDomain(useRequestURL({ xForwardedHost: true }).host) || runtimeI18n.defaultLocale || "";
		const optionsI18n = preloadedOptions || ([__temp, __restore] = executeAsync(() => setupVueI18nOptions(_defaultLocale)), __temp = await __temp, __restore(), __temp);
		const localeConfigs = useLocaleConfigs();
		localeConfigs.value = useRequestEvent().context.nuxtI18n?.localeConfigs || {};
		prerenderRoutes(localeCodes.map((locale) => `/_i18n/2a1cgsZ8/${locale}/messages.json`));
		const i18n = createI18n(optionsI18n);
		const detectors = useDetectors(useRequestEvent(nuxt), useI18nDetection(nuxt), nuxt);
		const ctx = createNuxtI18nContext(nuxt, i18n, optionsI18n.defaultLocale);
		nuxt._nuxtI18n = ctx;
		extendI18n(i18n, {
			extendComposer(composer) {
				composer.locales = computed(() => runtimeI18n.locales);
				composer.localeCodes = computed(() => localeCodes);
				const _baseUrl = ref(ctx.getBaseUrl());
				composer.baseUrl = computed(() => _baseUrl.value);
				composer.strategy = "prefix_except_default";
				composer.localeProperties = computed(() => normalizedLocales.find((l) => l.code === composer.locale.value) || { code: composer.locale.value });
				composer.setLocale = async (locale) => {
					await loadAndSetLocale(nuxt, locale);
					await nuxt.runWithContext(() => navigate(nuxt, nuxt.$router.currentRoute.value, locale));
				};
				composer.loadLocaleMessages = ctx.loadMessages;
				composer.differentDomains = false;
				composer.defaultLocale = optionsI18n.defaultLocale;
				composer.getBrowserLocale = () => resolveSupportedLocale(detectors.header());
				composer.getLocaleCookie = () => resolveSupportedLocale(detectors.cookie());
				composer.setLocaleCookie = ctx.setCookieLocale;
				composer.finalizePendingLocaleChange = async () => {
					if (!i18n.__pendingLocale) return;
					await i18n.__resolvePendingLocalePromise?.();
				};
				composer.waitForPendingLocaleChange = async () => {
					await i18n?.__pendingLocalePromise;
				};
			},
			extendComposerInstance(instance, c) {
				const props = [
					["locales", () => c.locales],
					["localeCodes", () => c.localeCodes],
					["baseUrl", () => c.baseUrl],
					["strategy", () => "prefix_except_default"],
					["localeProperties", () => c.localeProperties],
					["setLocale", () => (locale) => Reflect.apply(c.setLocale, c, [locale])],
					["loadLocaleMessages", () => (locale) => Reflect.apply(c.loadLocaleMessages, c, [locale])],
					["differentDomains", () => false],
					["defaultLocale", () => c.defaultLocale],
					["getBrowserLocale", () => () => Reflect.apply(c.getBrowserLocale, c, [])],
					["getLocaleCookie", () => () => Reflect.apply(c.getLocaleCookie, c, [])],
					["setLocaleCookie", () => (locale) => Reflect.apply(c.setLocaleCookie, c, [locale])],
					["finalizePendingLocaleChange", () => () => Reflect.apply(c.finalizePendingLocaleChange, c, [])],
					["waitForPendingLocaleChange", () => () => Reflect.apply(c.waitForPendingLocaleChange, c, [])]
				];
				for (const [key, get] of props) Object.defineProperty(instance, key, { get });
			}
		});
		nuxt.vueApp.use(i18n);
		Object.defineProperty(nuxt, "$i18n", { get: () => getI18nTarget(i18n) });
		nuxt.provide("localeHead", (options) => localeHead(nuxt._nuxtI18n.composableCtx, options));
		nuxt.provide("localePath", useLocalePath(nuxt));
		nuxt.provide("localeRoute", useLocaleRoute(nuxt));
		nuxt.provide("routeBaseName", useRouteBaseName(nuxt));
		nuxt.provide("getRouteBaseName", useRouteBaseName(nuxt));
		nuxt.provide("switchLocalePath", useSwitchLocalePath(nuxt));
	}
});
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/plugins/switch-locale-path-ssr.js
var identifier = "nuxt-i18n-slp";
var switchLocalePathLinkWrapperExpr = new RegExp([
	`<!--${identifier}-\\[(\\w+)\\]-->`,
	`.+?`,
	`<!--/${identifier}-->`
].join(""), "g");
var switch_locale_path_ssr_default = defineNuxtPlugin({
	name: "i18n:plugin:switch-locale-path-ssr",
	dependsOn: ["i18n:plugin"],
	setup(_nuxt) {
		const nuxt = useNuxtApp(_nuxt._id);
		const switchLocalePath = useSwitchLocalePath(nuxt);
		nuxt.hook("app:rendered", (ctx) => {
			if (ctx.renderResult?.html == null) return;
			ctx.renderResult.html = ctx.renderResult.html.replaceAll(switchLocalePathLinkWrapperExpr, (match, p1) => {
				const encoded = encodeURI(switchLocalePath(p1 ?? ""));
				return match.replace(/href="([^"]+)"/, `href="${encoded || "#"}" `);
			});
		});
	}
});
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/plugins/preload.js
var preload_default = defineNuxtPlugin({
	name: "i18n:plugin:preload",
	dependsOn: ["i18n:plugin"],
	async setup(_nuxt) {}
});
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fcolor-mode-options.mjs
var preference = "system";
//#endregion
//#region node_modules/@nuxtjs/color-mode/dist/runtime/plugin.server.js
var plugin_server_default = defineNuxtPlugin((nuxtApp) => {
	const colorMode = nuxtApp.ssrContext?.islandContext ? ref({}).value : useState("color-mode", () => reactive({
		preference,
		value: preference,
		unknown: true,
		forced: false
	})).value;
	const htmlAttrs = {};
	useHead$1({ htmlAttrs });
	useRouter().afterEach((to) => {
		const forcedColorMode = to.meta.colorMode;
		if (forcedColorMode && forcedColorMode !== "system") {
			htmlAttrs["data-color-mode-forced"] = forcedColorMode;
			colorMode.value = forcedColorMode;
			colorMode.forced = true;
		} else if (forcedColorMode === "system") console.warn("You cannot force the colorMode to system at the page level.");
	});
	nuxtApp.provide("colorMode", colorMode);
});
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/shared/minify.js
function minifyJS(code) {
	let result = "";
	let i = 0;
	const len = code.length;
	while (i < len) {
		const ch = code[i];
		if (ch === "'" || ch === "\"" || ch === "`") {
			const quote = ch;
			result += ch;
			i++;
			while (i < len && code[i] !== quote) {
				if (code[i] === "\\") result += code[i++];
				result += code[i++];
			}
			if (i < len) result += code[i++];
		} else if (ch === "/" && code[i + 1] === "/") {
			i += 2;
			while (i < len && code[i] !== "\n") i++;
		} else if (ch === "/" && code[i + 1] === "*") {
			i += 2;
			while (i < len && !(code[i] === "*" && code[i + 1] === "/")) i++;
			i += 2;
		} else if (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
			let hasNewline = false;
			while (i < len && (code[i] === " " || code[i] === "	" || code[i] === "\n" || code[i] === "\r")) {
				if (code[i] === "\n") hasNewline = true;
				i++;
			}
			const prev = result.at(-1);
			const next = code[i];
			if (hasNewline && prev && next && prev !== "{" && prev !== "}" && prev !== ";" && next !== "}" && next !== ";") result += "\n";
			else if (prev && next && isIdentChar(prev) && isIdentChar(next)) result += " ";
			else if (prev && next && (prev === "+" && next === "+" || prev === "-" && next === "-")) result += " ";
		} else {
			result += ch;
			i++;
		}
	}
	return result.trim();
}
function minifyCSS$1(code) {
	let result = "";
	let i = 0;
	let parenDepth = 0;
	const len = code.length;
	while (i < len) {
		const ch = code[i];
		if (ch === "'" || ch === "\"") {
			const quote = ch;
			result += ch;
			i++;
			while (i < len && code[i] !== quote) {
				if (code[i] === "\\") result += code[i++];
				result += code[i++];
			}
			if (i < len) result += code[i++];
		} else if (ch === "/" && code[i + 1] === "*") {
			i += 2;
			while (i < len && !(code[i] === "*" && code[i + 1] === "/")) i++;
			i += 2;
		} else if (ch === "(") {
			parenDepth++;
			result += ch;
			i++;
		} else if (ch === ")") {
			parenDepth = Math.max(0, parenDepth - 1);
			result += ch;
			i++;
		} else if (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
			while (i < len && (code[i] === " " || code[i] === "	" || code[i] === "\n" || code[i] === "\r")) i++;
			const prev = result.at(-1);
			const next = code[i];
			if (next === "!") continue;
			if (parenDepth > 0) {
				if (prev && next && !isCSSCalcPunctuation(prev) && !isCSSCalcPunctuation(next)) result += " ";
			} else if (prev && next && !isCSSPunctuation(prev) && !isCSSPunctuation(next)) result += " ";
		} else if (ch === ";") {
			let j = i + 1;
			while (j < len && (code[j] === " " || code[j] === "	" || code[j] === "\n" || code[j] === "\r")) j++;
			if (code[j] === "}") i++;
			else {
				result += ch;
				i++;
			}
		} else if (ch === "0" && code[i + 1] === "." && (code[i + 2] ?? "") >= "0" && (code[i + 2] ?? "") <= "9") {
			const prev = result.at(-1);
			if (prev && prev >= "0" && prev <= "9") {
				result += ch;
				i++;
			} else i++;
		} else {
			result += ch;
			i++;
		}
	}
	return result.trim();
}
function isIdentChar(ch) {
	return ch >= "a" && ch <= "z" || ch >= "A" && ch <= "Z" || ch >= "0" && ch <= "9" || ch === "_" || ch === "$";
}
function isCSSBasePunctuation(ch) {
	return ch === "{" || ch === "}" || ch === ";" || ch === ":" || ch === ",";
}
function isCSSPunctuation(ch) {
	return isCSSBasePunctuation(ch) || ch === ">" || ch === "+" || ch === "~";
}
function isCSSCalcPunctuation(ch) {
	return isCSSBasePunctuation(ch) || ch === "*" || ch === "/";
}
function minifyJSON(code) {
	return JSON.stringify(JSON.parse(code));
}
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/minifyScripts.server.js
var JSON_TYPES = /* @__PURE__ */ new Set(["application/json", "application/ld+json"]);
var SKIP_JS_TYPES = /* @__PURE__ */ new Set([
	"application/json",
	"application/ld+json",
	"speculationrules",
	"importmap"
]);
var minifyScripts_server_default = defineNuxtPlugin({
	enforce: "post",
	setup() {
		const head = injectHead$1();
		if (!head) return;
		head.use({
			key: "minify-inline",
			hooks: { "ssr:render": ({ tags }) => {
				for (const tag of tags) {
					const content = tag.innerHTML;
					if (!content) continue;
					if (tag.tag === "script") {
						const type = tag.props.type;
						if (type && JSON_TYPES.has(type)) {
							try {
								const minified = minifyJSON(content);
								if (minified.length < content.length) tag.innerHTML = minified;
							} catch {}
							continue;
						}
						if (type && SKIP_JS_TYPES.has(type)) continue;
						try {
							const minified = minifyJS(content);
							if (minified.length < content.length) tag.innerHTML = minified;
						} catch {}
					} else if (tag.tag === "style") try {
						const minified = minifyCSS$1(content);
						if (minified.length < content.length) tag.innerHTML = minified;
					} catch {}
				}
			} }
		});
	}
});
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/1.absoluteImageUrls.server.js
var _1_absoluteImageUrls_server_default = defineNuxtPlugin({
	enforce: "post",
	setup() {
		const head = injectHead$1();
		if (!head) return;
		const resolver = createSitePathResolver({
			withBase: true,
			absolute: true,
			canonical: true
		});
		head.use({
			key: "absoluteImageUrls",
			hooks: { "tags:resolve": async ({ tags }) => {
				for (const tag of tags) {
					if (tag.tag !== "meta") continue;
					if (tag.props.property !== "og:image:url" && tag.props.property !== "og:image" && tag.props.name !== "twitter:image" && tag.props.name !== "twitter:image:src") continue;
					if (typeof tag.props.content !== "string" || !tag.props.content.trim() || tag.props.content.startsWith("http") || tag.props.content.startsWith("//")) continue;
					tag.props.content = unref(resolver(tag.props.content));
				}
			} }
		});
	}
});
//#endregion
//#region node_modules/nuxt-seo-utils/dist/runtime/app/plugins/0.routeRules.js
var _0_routeRules_default = defineNuxtPlugin({
	enforce: "post",
	env: { islands: false },
	async setup() {
		let __temp, __restore;
		const head = injectHead$1();
		if (!head) return;
		const { tagPriority } = useRuntimeConfig().public["seo-utils"];
		const routeRuleState = useState("nuxt-seo-utils:routeRules", () => null);
		{
			const event = useRequestEvent();
			const rules = ([__temp, __restore] = executeAsync(() => getRouteRules(event)), __temp = await __temp, __restore(), __temp);
			routeRuleState.value = {
				head: rules.head,
				seoMeta: rules.seoMeta
			};
		}
		if (routeRuleState.value) {
			const { head: headInput, seoMeta } = routeRuleState.value;
			if (headInput) head.push(headInput);
			if (seoMeta) useSeoMeta$1(seoMeta, { tagPriority });
		}
	}
});
//#endregion
//#region node_modules/@nuxtjs/i18n/dist/runtime/plugins/ssg-detect.js
var ssg_detect_default = defineNuxtPlugin({
	name: "i18n:plugin:ssg-detect",
	dependsOn: ["i18n:plugin", "i18n:plugin:route-locale-detect"],
	enforce: "post",
	setup(_nuxt) {}
});
//#endregion
//#region node_modules/nuxt-schema-org/dist/runtime/app/utils/config.js
function useSchemaOrgConfig() {
	const runtimeConfig = useRuntimeConfig();
	return defu(runtimeConfig["nuxt-schema-org"], { scriptAttributes: {} });
}
//#endregion
//#region node_modules/nuxt-schema-org/dist/runtime/app/composables/useSchemaOrg.js
function useSchemaOrg(input) {
	const config = useSchemaOrgConfig();
	const nuxtApp = useNuxtApp();
	const script = {
		type: "application/ld+json",
		key: "schema-org-graph",
		nodes: isRef(input) ? computed(() => nuxtApp.runWithContext(() => input.value)) : input,
		tagPriority: "high",
		...config.scriptAttributes
	};
	return useHead$1({ script: [script] });
}
//#endregion
//#region node_modules/nuxt-schema-org/dist/runtime/app/utils/shared.js
function resolvePathDirect(siteConfig, path, options) {
	const nuxtBase = useRuntimeConfig().app.baseURL || "/";
	return resolveSitePath(path, {
		absolute: options.absolute,
		withBase: options.withBase,
		siteUrl: toValue(siteConfig.url),
		trailingSlash: toValue(siteConfig.trailingSlash),
		base: nuxtBase
	});
}
function initPlugin(nuxtApp) {
	const head = injectHead$1();
	const config = useSchemaOrgConfig();
	const route = useRoute$1();
	const siteConfig = useSiteConfig();
	const resolveUrl = (path) => resolvePathDirect(siteConfig, path, {
		absolute: true,
		withBase: true
	});
	function resolveSchemaOrg() {
		const siteConfigResolved = {};
		for (const key in siteConfig) {
			if (key.startsWith("_")) continue;
			siteConfigResolved[key] = toValue(siteConfig[key]);
			if (typeof siteConfigResolved[key] === "object") for (const k in siteConfigResolved[key]) siteConfigResolved[key][k] = toValue(siteConfigResolved[key][k]);
		}
		return {
			...route.meta?.schemaOrg || {},
			...siteConfigResolved,
			url: toValue(resolveUrl(route.path)),
			host: withTrailingSlash$1(toValue(resolveUrl("/"))),
			inLanguage: toValue(siteConfigResolved.currentLocale) || toValue(siteConfigResolved.defaultLocale),
			path: route.path
		};
	}
	useHead$1({ templateParams: { schemaOrg: resolveSchemaOrg() } });
	head.use(SchemaOrgUnheadPlugin({}, async () => {
		const meta = {};
		await nuxtApp.hooks.callHook("schema-org:meta", meta);
		return meta;
	}, {
		minify: config.minify,
		trailingSlash: siteConfig.trailingSlash
	}));
}
function maybeAddIdentitySchemaOrg() {
	const config = useSchemaOrgConfig();
	const siteConfig = useSiteConfig({ resolveRefs: true });
	if (config.identity || siteConfig.identity) {
		const identity = config.identity || siteConfig.identity;
		let identityPayload = {
			name: () => toValue(siteConfig.name),
			url: () => toValue(siteConfig.url)
		};
		let identityType;
		if (typeof identity !== "string") {
			identityPayload = {
				...identityPayload,
				...identity
			};
			identityType = identity.type;
			delete identityPayload.type;
		} else identityType = identity;
		if (siteConfig.twitter) {
			const id = siteConfig.twitter.startsWith("@") ? siteConfig.twitter.slice(1) : siteConfig.twitter;
			identityPayload.sameAs = [`https://twitter.com/${id}`];
		}
		identityPayload._resolver = identityPayload._resolver || camelCase(identityType);
		useSchemaOrg([identityPayload]);
	}
}
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fplugins.server.mjs
var virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fplugins_server_default = [
	payloadPlugin,
	_0_siteConfig_default,
	plugin$3,
	plugin$2,
	plugin$1,
	plugin,
	siteConfig_default,
	inferSeoMetaPlugin_default,
	robot_meta_server_default,
	i18n_default$1,
	titlesWaitI18n_default,
	defaultsWaitI18n_default,
	virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fcomponents_plugin_default,
	virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fprimevue_plugin_default,
	virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fpwa_icons_plugin_default,
	plugin_default,
	route_locale_detect_default,
	i18n_default,
	switch_locale_path_ssr_default,
	preload_default,
	plugin_server_default,
	minifyScripts_server_default,
	_1_absoluteImageUrls_server_default,
	_0_routeRules_default,
	ssg_detect_default,
	defineNuxtPlugin({
		name: "nuxt-schema-org:init",
		order: 999,
		dependsOn: ["i18n:plugin"],
		setup(nuxtApp) {
			initPlugin(nuxtApp);
		}
	}),
	defineNuxtPlugin({
		name: "nuxt-schema-org:defaults",
		dependsOn: ["nuxt-schema-org:init"],
		setup(nuxtApp) {
			if (useError().value?.error) return;
			const siteConfig = useSiteConfig();
			const pathResolver = createSitePathResolver({
				canonical: true,
				absolute: true
			});
			if (!nuxtApp.$i18n) return;
			const localePath = useLocalePath();
			const locales = nuxtApp.$i18n?.locales.value || [];
			const siteUrl = () => pathResolver(localePath("index")).value;
			const websiteId = () => `${siteUrl()}#website`;
			const website = defineWebSite({
				"@id": websiteId,
				"url": siteUrl,
				"name": () => toValue(siteConfig.name) || "",
				"inLanguage": () => toValue(nuxtApp.$i18n.localeProperties.value.language) || "",
				"description": () => toValue(siteConfig.description) || ""
			});
			const nuxtBase = useRuntimeConfig().app.baseURL || "/";
			const resolveIdForLocale = (locale) => {
				if (locale.domain) return resolveSitePath(localePath("index", locale.code), {
					absolute: true,
					siteUrl: hasProtocol$1(locale.domain, { acceptRelative: false }) ? locale.domain : withHttps(locale.domain),
					trailingSlash: siteConfig.trailingSlash,
					base: nuxtBase
				});
				return pathResolver(localePath("index", locale.code)).value;
			};
			if (siteConfig.defaultLocale) {
				if (siteConfig.currentLocale && siteConfig.currentLocale !== siteConfig.defaultLocale) website.translationOfWork = {
					"@type": "WebSite",
					"@id": () => `${resolveIdForLocale({ code: toValue(siteConfig.defaultLocale) })}#website`
				};
				else website.workTranslation = locales.filter((locale) => locale.code !== siteConfig.defaultLocale).map((locale) => {
					return {
						"@type": "WebSite",
						"@id": () => `${resolveIdForLocale(locale)}#website`
					};
				});
			}
			useSchemaOrg([website, defineWebPage({ isPartOf: { "@id": websiteId() } })]);
			maybeAddIdentitySchemaOrg();
		}
	})
];
//#endregion
//#region \0virtual:pwa-info
var pwaInfo = {
	"webManifest": {
		"href": "/manifest.webmanifest"}
};
//#endregion
//#region node_modules/@vite-pwa/nuxt/dist/runtime/components/VitePwaManifest.js
var VitePwaManifest_default = defineComponent({ async setup() {
	if (pwaInfo) {
		const meta = ref({ link: [] });
		useHead$1(meta);
		const { webManifest } = pwaInfo;
		if (webManifest) {
			const { href} = webManifest;
			meta.value.link.push({
				rel: "manifest",
				href
			});
		}
	}
	return () => null;
} });
//#endregion
//#region app/components/FullScreenLoader.vue?vue&type=script&setup=true&lang.ts
var FullScreenLoader_vue_vue_type_script_setup_true_lang_default = /*@__PURE__*/ defineComponent({
	__name: "FullScreenLoader",
	__ssrInlineRender: true,
	setup(__props) {
		const appStore = useAppStore();
		const { isFullScreenLoading } = (0, composables_exports.storeToRefs)(appStore);
		const loaderElm = ref();
		watch(isFullScreenLoading, (isLoad) => {
			if (isLoad) {
				loaderElm.value.style.display = "flex";
				setTimeout(() => {
					loaderElm.value.style.opacity = "1";
				}, 1);
			} else {
				loaderElm.value.style.opacity = "0";
				setTimeout(() => {
					loaderElm.value.style.display = "none";
				}, 500);
			}
		});
		return (_ctx, _push, _parent, _attrs) => {
			_push(`<div${ssrRenderAttrs(mergeProps({
				class: "loader-wrapper",
				ref_key: "loaderElm",
				ref: loaderElm
			}, _attrs))} data-v-8041e257><div class="loader" data-v-8041e257></div></div>`);
		};
	}
});
//#endregion
//#region \0plugin-vue:export-helper
var _plugin_vue_export_helper_default = (sfc, props) => {
	const target = sfc.__vccOpts || sfc;
	for (const [key, val] of props) target[key] = val;
	return target;
};
//#endregion
//#region app/components/FullScreenLoader.vue
var _sfc_setup$7 = FullScreenLoader_vue_vue_type_script_setup_true_lang_default.setup;
FullScreenLoader_vue_vue_type_script_setup_true_lang_default.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FullScreenLoader.vue");
	return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
var FullScreenLoader_default = /*#__PURE__*/ Object.assign(_plugin_vue_export_helper_default(FullScreenLoader_vue_vue_type_script_setup_true_lang_default, [["__scopeId", "data-v-8041e257"]]), { __name: "FullScreenLoader" });
//#endregion
//#region node_modules/@nuxtjs/color-mode/dist/runtime/composables.js
var useColorMode = () => {
	return useState("color-mode").value;
};
//#endregion
//#region app/stores/user.ts
/**
* 用户偏好与身份信息仓库。
* 负责管理昵称、头像以及发送端自动确认配置，并统一做本地持久化。
*/
var useUserStore = (0, composables_exports.defineStore)("user", () => {
	const userInfo = reactive({
		nickname: "",
		avatarURL: ""
	});
	const isConfirmDefault = ref(false);
	const hasInitialized = ref(false);
	function setNickname(nickname) {
		const nextNickname = nickname.trim().substring(0, 16);
		userInfo.nickname = nextNickname || `User_${genRandomString(6)}`;
	}
	function setAvatarURL(url) {
		userInfo.avatarURL = url;
	}
	function setConfirmDefault(value) {
		isConfirmDefault.value = value;
	}
	function initAvatar() {}
	function resetUserInfo() {
		setNickname("");
	}
	function openAvatarPicker() {}
	function initializeFromStorage() {}
	return {
		userInfo,
		isConfirmDefault,
		hasInitialized,
		setNickname,
		setAvatarURL,
		setConfirmDefault,
		initAvatar,
		resetUserInfo,
		openAvatarPicker,
		initializeFromStorage
	};
});
//#endregion
//#region node_modules/primevue/toggleswitch/style/index.mjs
var ToggleSwitchStyle = BaseStyle.extend({
	name: "toggleswitch",
	style: style$8,
	classes: {
		root: function root(_ref) {
			var instance = _ref.instance, props = _ref.props;
			return ["p-toggleswitch p-component", {
				"p-toggleswitch-checked": instance.checked,
				"p-disabled": props.disabled,
				"p-invalid": instance.$invalid
			}];
		},
		input: "p-toggleswitch-input",
		slider: "p-toggleswitch-slider",
		handle: "p-toggleswitch-handle"
	},
	inlineStyles: { root: { position: "relative" } }
});
//#endregion
//#region node_modules/primevue/toggleswitch/index.mjs
var toggleswitch_exports = /* @__PURE__ */ __exportAll({ default: () => script$14 });
var script$14 = {
	name: "ToggleSwitch",
	"extends": {
		name: "BaseToggleSwitch",
		"extends": script$i,
		props: {
			trueValue: {
				type: null,
				"default": true
			},
			falseValue: {
				type: null,
				"default": false
			},
			readonly: {
				type: Boolean,
				"default": false
			},
			tabindex: {
				type: Number,
				"default": null
			},
			inputId: {
				type: String,
				"default": null
			},
			inputClass: {
				type: [String, Object],
				"default": null
			},
			inputStyle: {
				type: Object,
				"default": null
			},
			ariaLabelledby: {
				type: String,
				"default": null
			},
			ariaLabel: {
				type: String,
				"default": null
			}
		},
		style: ToggleSwitchStyle,
		provide: function provide() {
			return {
				$pcToggleSwitch: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false,
	emits: [
		"change",
		"focus",
		"blur"
	],
	methods: {
		getPTOptions: function getPTOptions(key) {
			return (key === "root" ? this.ptmi : this.ptm)(key, { context: {
				checked: this.checked,
				disabled: this.disabled
			} });
		},
		onChange: function onChange(event) {
			if (!this.disabled && !this.readonly) {
				var newValue = this.checked ? this.falseValue : this.trueValue;
				this.writeValue(newValue, event);
				this.$emit("change", event);
			}
		},
		onFocus: function onFocus(event) {
			this.$emit("focus", event);
		},
		onBlur: function onBlur(event) {
			var _this$formField$onBlu, _this$formField;
			this.$emit("blur", event);
			(_this$formField$onBlu = (_this$formField = this.formField).onBlur) === null || _this$formField$onBlu === void 0 || _this$formField$onBlu.call(_this$formField, event);
		}
	},
	computed: {
		checked: function checked() {
			return this.d_value === this.trueValue;
		},
		dataP: function dataP() {
			return cn({
				checked: this.checked,
				disabled: this.disabled,
				invalid: this.$invalid
			});
		}
	}
};
var _hoisted_1$7 = [
	"data-p-checked",
	"data-p-disabled",
	"data-p"
];
var _hoisted_2$4 = [
	"id",
	"checked",
	"tabindex",
	"disabled",
	"readonly",
	"aria-checked",
	"aria-labelledby",
	"aria-label",
	"aria-invalid"
];
var _hoisted_3$3 = ["data-p"];
var _hoisted_4$3 = ["data-p"];
function render$15(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("div", mergeProps({
		"class": _ctx.cx("root"),
		style: _ctx.sx("root")
	}, $options.getPTOptions("root"), {
		"data-p-checked": $options.checked,
		"data-p-disabled": _ctx.disabled,
		"data-p": $options.dataP
	}), [createElementVNode("input", mergeProps({
		id: _ctx.inputId,
		type: "checkbox",
		role: "switch",
		"class": [_ctx.cx("input"), _ctx.inputClass],
		style: _ctx.inputStyle,
		checked: $options.checked,
		tabindex: _ctx.tabindex,
		disabled: _ctx.disabled,
		readonly: _ctx.readonly,
		"aria-checked": $options.checked,
		"aria-labelledby": _ctx.ariaLabelledby,
		"aria-label": _ctx.ariaLabel,
		"aria-invalid": _ctx.invalid || void 0,
		onFocus: _cache[0] || (_cache[0] = function() {
			return $options.onFocus && $options.onFocus.apply($options, arguments);
		}),
		onBlur: _cache[1] || (_cache[1] = function() {
			return $options.onBlur && $options.onBlur.apply($options, arguments);
		}),
		onChange: _cache[2] || (_cache[2] = function() {
			return $options.onChange && $options.onChange.apply($options, arguments);
		})
	}, $options.getPTOptions("input")), null, 16, _hoisted_2$4), createElementVNode("div", mergeProps({ "class": _ctx.cx("slider") }, $options.getPTOptions("slider"), { "data-p": $options.dataP }), [createElementVNode("div", mergeProps({ "class": _ctx.cx("handle") }, $options.getPTOptions("handle"), { "data-p": $options.dataP }), [renderSlot(_ctx.$slots, "handle", { checked: $options.checked })], 16, _hoisted_4$3)], 16, _hoisted_3$3)], 16, _hoisted_1$7);
}
script$14.render = render$15;
//#endregion
//#region node_modules/primevue/divider/style/index.mjs
var DividerStyle = BaseStyle.extend({
	name: "divider",
	style: style$7,
	classes: {
		root: function root(_ref2) {
			var props = _ref2.props;
			return [
				"p-divider p-component",
				"p-divider-" + props.layout,
				"p-divider-" + props.type,
				{ "p-divider-left": props.layout === "horizontal" && (!props.align || props.align === "left") },
				{ "p-divider-center": props.layout === "horizontal" && props.align === "center" },
				{ "p-divider-right": props.layout === "horizontal" && props.align === "right" },
				{ "p-divider-top": props.layout === "vertical" && props.align === "top" },
				{ "p-divider-center": props.layout === "vertical" && (!props.align || props.align === "center") },
				{ "p-divider-bottom": props.layout === "vertical" && props.align === "bottom" }
			];
		},
		content: "p-divider-content"
	},
	inlineStyles: { root: function root(_ref) {
		var props = _ref.props;
		return {
			justifyContent: props.layout === "horizontal" ? props.align === "center" || props.align === null ? "center" : props.align === "left" ? "flex-start" : props.align === "right" ? "flex-end" : null : null,
			alignItems: props.layout === "vertical" ? props.align === "center" || props.align === null ? "center" : props.align === "top" ? "flex-start" : props.align === "bottom" ? "flex-end" : null : null
		};
	} }
});
//#endregion
//#region node_modules/primevue/divider/index.mjs
var divider_exports = /* @__PURE__ */ __exportAll({ default: () => script$17 });
var script$1$16 = {
	name: "BaseDivider",
	"extends": script$j,
	props: {
		align: {
			type: String,
			"default": null
		},
		layout: {
			type: String,
			"default": "horizontal"
		},
		type: {
			type: String,
			"default": "solid"
		}
	},
	style: DividerStyle,
	provide: function provide() {
		return {
			$pcDivider: this,
			$parentInstance: this
		};
	}
};
function _typeof$8(o) {
	"@babel/helpers - typeof";
	return _typeof$8 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$8(o);
}
function _defineProperty$8(e, r, t) {
	return (r = _toPropertyKey$8(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$8(t) {
	var i = _toPrimitive$8(t, "string");
	return "symbol" == _typeof$8(i) ? i : i + "";
}
function _toPrimitive$8(t, r) {
	if ("object" != _typeof$8(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$8(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$17 = {
	name: "Divider",
	"extends": script$1$16,
	inheritAttrs: false,
	computed: { dataP: function dataP() {
		return cn(_defineProperty$8(_defineProperty$8(_defineProperty$8({}, this.align, this.align), this.layout, this.layout), this.type, this.type));
	} }
};
var _hoisted_1$6 = ["aria-orientation", "data-p"];
var _hoisted_2$3 = ["data-p"];
function render$14(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("div", mergeProps({
		"class": _ctx.cx("root"),
		style: _ctx.sx("root"),
		role: "separator",
		"aria-orientation": _ctx.layout,
		"data-p": $options.dataP
	}, _ctx.ptmi("root")), [_ctx.$slots["default"] ? (openBlock(), createElementBlock("div", mergeProps({
		key: 0,
		"class": _ctx.cx("content"),
		"data-p": $options.dataP
	}, _ctx.ptm("content")), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_2$3)) : createCommentVNode("", true)], 16, _hoisted_1$6);
}
script$17.render = render$14;
//#endregion
//#region node_modules/primevue/inputtext/style/index.mjs
var InputTextStyle = BaseStyle.extend({
	name: "inputtext",
	style: style$6,
	classes: { root: function root(_ref) {
		var instance = _ref.instance, props = _ref.props;
		return ["p-inputtext p-component", {
			"p-filled": instance.$filled,
			"p-inputtext-sm p-inputfield-sm": props.size === "small",
			"p-inputtext-lg p-inputfield-lg": props.size === "large",
			"p-invalid": instance.$invalid,
			"p-variant-filled": instance.$variant === "filled",
			"p-inputtext-fluid": instance.$fluid
		}];
	} }
});
//#endregion
//#region node_modules/primevue/inputtext/index.mjs
var inputtext_exports = /* @__PURE__ */ __exportAll({ default: () => script$15 });
var script$1$14 = {
	name: "BaseInputText",
	"extends": script$h,
	style: InputTextStyle,
	provide: function provide() {
		return {
			$pcInputText: this,
			$parentInstance: this
		};
	}
};
function _typeof$7(o) {
	"@babel/helpers - typeof";
	return _typeof$7 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$7(o);
}
function _defineProperty$7(e, r, t) {
	return (r = _toPropertyKey$7(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$7(t) {
	var i = _toPrimitive$7(t, "string");
	return "symbol" == _typeof$7(i) ? i : i + "";
}
function _toPrimitive$7(t, r) {
	if ("object" != _typeof$7(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$7(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$15 = {
	name: "InputText",
	"extends": script$1$14,
	inheritAttrs: false,
	methods: { onInput: function onInput(event) {
		this.writeValue(event.target.value, event);
	} },
	computed: {
		attrs: function attrs() {
			return mergeProps(this.ptmi("root", { context: {
				filled: this.$filled,
				disabled: this.disabled
			} }), this.formField);
		},
		dataP: function dataP() {
			return cn(_defineProperty$7({
				invalid: this.$invalid,
				fluid: this.$fluid,
				filled: this.$variant === "filled"
			}, this.size, this.size));
		}
	}
};
var _hoisted_1$5 = [
	"value",
	"name",
	"disabled",
	"aria-invalid",
	"data-p"
];
function render$13(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("input", mergeProps({
		type: "text",
		"class": _ctx.cx("root"),
		value: _ctx.d_value,
		name: _ctx.name,
		disabled: _ctx.disabled,
		"aria-invalid": _ctx.$invalid || void 0,
		"data-p": $options.dataP,
		onInput: _cache[0] || (_cache[0] = function() {
			return $options.onInput && $options.onInput.apply($options, arguments);
		})
	}, $options.attrs), null, 16, _hoisted_1$5);
}
script$15.render = render$13;
//#endregion
//#region node_modules/primevue/inputgroup/style/index.mjs
var InputGroupStyle = BaseStyle.extend({
	name: "inputgroup",
	style: style$5,
	classes: { root: "p-inputgroup" }
});
//#endregion
//#region node_modules/primevue/inputgroup/index.mjs
var inputgroup_exports = /* @__PURE__ */ __exportAll({ default: () => script$13 });
var script$13 = {
	name: "InputGroup",
	"extends": {
		name: "BaseInputGroup",
		"extends": script$j,
		style: InputGroupStyle,
		provide: function provide() {
			return {
				$pcInputGroup: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false
};
function render$12(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("div", mergeProps({ "class": _ctx.cx("root") }, _ctx.ptmi("root")), [renderSlot(_ctx.$slots, "default")], 16);
}
script$13.render = render$12;
//#endregion
//#region node_modules/primevue/popover/style/index.mjs
var PopoverStyle = BaseStyle.extend({
	name: "popover",
	style: style$4,
	classes: {
		root: "p-popover p-component",
		content: "p-popover-content"
	}
});
//#endregion
//#region node_modules/primevue/popover/index.mjs
var popover_exports = /* @__PURE__ */ __exportAll({ default: () => script$11 });
var script$11 = {
	name: "Popover",
	"extends": {
		name: "BasePopover",
		"extends": script$j,
		props: {
			dismissable: {
				type: Boolean,
				"default": true
			},
			appendTo: {
				type: [String, Object],
				"default": "body"
			},
			baseZIndex: {
				type: Number,
				"default": 0
			},
			autoZIndex: {
				type: Boolean,
				"default": true
			},
			breakpoints: {
				type: Object,
				"default": null
			},
			closeOnEscape: {
				type: Boolean,
				"default": true
			}
		},
		style: PopoverStyle,
		provide: function provide() {
			return {
				$pcPopover: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false,
	emits: ["show", "hide"],
	data: function data() {
		return { visible: false };
	},
	watch: { dismissable: {
		immediate: true,
		handler: function handler(newValue) {
			if (newValue) this.bindOutsideClickListener();
			else this.unbindOutsideClickListener();
		}
	} },
	selfClick: false,
	target: null,
	eventTarget: null,
	outsideClickListener: null,
	scrollHandler: null,
	resizeListener: null,
	container: null,
	styleElement: null,
	overlayEventListener: null,
	documentKeydownListener: null,
	contentResizeObserver: null,
	beforeUnmount: function beforeUnmount() {
		if (this.dismissable) this.unbindOutsideClickListener();
		if (this.scrollHandler) {
			this.scrollHandler.destroy();
			this.scrollHandler = null;
		}
		this.destroyStyle();
		this.unbindResizeListener();
		this.unbindContentResizeListener();
		this.target = null;
		if (this.container && this.autoZIndex) x.clear(this.container);
		if (this.overlayEventListener) {
			OverlayEventBus.off("overlay-click", this.overlayEventListener);
			this.overlayEventListener = null;
		}
		this.container = null;
	},
	mounted: function mounted() {
		if (this.breakpoints) this.createStyle();
	},
	methods: {
		toggle: function toggle(event, target) {
			if (this.visible) this.hide();
			else this.show(event, target);
		},
		show: function show(event, target) {
			this.visible = true;
			this.eventTarget = event.currentTarget;
			this.target = target || event.currentTarget;
		},
		hide: function hide() {
			this.visible = false;
		},
		onContentClick: function onContentClick() {
			this.selfClick = true;
		},
		onEnter: function onEnter(el) {
			var _this = this;
			S(el, {
				position: "absolute",
				top: "0"
			});
			this.alignOverlay();
			if (this.dismissable) this.bindOutsideClickListener();
			this.bindScrollListener();
			this.bindResizeListener();
			if (this.autoZIndex) x.set("overlay", el, this.baseZIndex || this.$primevue.config.zIndex.overlay);
			this.overlayEventListener = function(e) {
				if (_this.container.contains(e.target)) _this.selfClick = true;
			};
			this.bindContentResizeListener();
			this.focus();
			OverlayEventBus.on("overlay-click", this.overlayEventListener);
			this.$emit("show");
			if (this.closeOnEscape) this.bindDocumentKeyDownListener();
		},
		onLeave: function onLeave() {
			this.unbindOutsideClickListener();
			this.unbindScrollListener();
			this.unbindResizeListener();
			this.unbindDocumentKeyDownListener();
			this.unbindContentResizeListener();
			OverlayEventBus.off("overlay-click", this.overlayEventListener);
			this.overlayEventListener = null;
			this.$emit("hide");
		},
		onAfterLeave: function onAfterLeave(el) {
			if (this.autoZIndex) x.clear(el);
		},
		alignOverlay: function alignOverlay() {
			D(this.container, this.target, false);
			var containerOffset = K(this.container);
			var targetOffset = K(this.target);
			var arrowLeft = 0;
			if (containerOffset.left < targetOffset.left) arrowLeft = targetOffset.left - containerOffset.left;
			this.container.style.setProperty($dt("popover.arrow.left").name, "".concat(arrowLeft, "px"));
			if (containerOffset.top < targetOffset.top) {
				this.container.setAttribute("data-p-popover-flipped", "true");
				!this.isUnstyled && W(this.container, "p-popover-flipped");
			}
		},
		onContentKeydown: function onContentKeydown(event) {
			if (event.code === "Escape" && this.closeOnEscape) {
				this.hide();
				bt(this.target);
			}
		},
		onButtonKeydown: function onButtonKeydown(event) {
			switch (event.code) {
				case "ArrowDown":
				case "ArrowUp":
				case "ArrowLeft":
				case "ArrowRight": event.preventDefault();
			}
		},
		focus: function focus() {
			var focusTarget = this.container.querySelector("[autofocus]");
			if (focusTarget) focusTarget.focus();
		},
		onKeyDown: function onKeyDown(event) {
			if (event.code === "Escape" && this.closeOnEscape) this.visible = false;
		},
		bindDocumentKeyDownListener: function bindDocumentKeyDownListener() {
			if (!this.documentKeydownListener) {
				this.documentKeydownListener = this.onKeyDown.bind(this);
				(void 0).document.addEventListener("keydown", this.documentKeydownListener);
			}
		},
		unbindDocumentKeyDownListener: function unbindDocumentKeyDownListener() {
			if (this.documentKeydownListener) {
				(void 0).document.removeEventListener("keydown", this.documentKeydownListener);
				this.documentKeydownListener = null;
			}
		},
		bindOutsideClickListener: function bindOutsideClickListener() {
			if (!this.outsideClickListener && tt()) ;
		},
		unbindOutsideClickListener: function unbindOutsideClickListener() {
			if (this.outsideClickListener) {
				(void 0).removeEventListener("click", this.outsideClickListener);
				this.outsideClickListener = null;
				this.selfClick = false;
			}
		},
		bindScrollListener: function bindScrollListener() {
			var _this3 = this;
			if (!this.scrollHandler) this.scrollHandler = new ConnectedOverlayScrollHandler(this.target, function() {
				if (_this3.visible) _this3.visible = false;
			});
			this.scrollHandler.bindScrollListener();
		},
		unbindScrollListener: function unbindScrollListener() {
			if (this.scrollHandler) this.scrollHandler.unbindScrollListener();
		},
		bindResizeListener: function bindResizeListener() {
			var _this4 = this;
			if (!this.resizeListener) {
				this.resizeListener = function() {
					if (_this4.visible && !Yt()) _this4.visible = false;
				};
				(void 0).addEventListener("resize", this.resizeListener);
			}
		},
		unbindResizeListener: function unbindResizeListener() {
			if (this.resizeListener) {
				(void 0).removeEventListener("resize", this.resizeListener);
				this.resizeListener = null;
			}
		},
		bindContentResizeListener: function bindContentResizeListener() {
			var _this5 = this;
			if (!this.contentResizeObserver) {
				this.contentResizeObserver = new ResizeObserver(function() {
					if (_this5.visible) _this5.alignOverlay();
				});
				this.contentResizeObserver.observe(this.container);
			}
		},
		unbindContentResizeListener: function unbindContentResizeListener() {
			if (this.contentResizeObserver) {
				this.contentResizeObserver.disconnect();
				this.contentResizeObserver = null;
			}
		},
		isTargetClicked: function isTargetClicked(event) {
			return this.eventTarget && (this.eventTarget === event.target || this.eventTarget.contains(event.target));
		},
		containerRef: function containerRef(el) {
			this.container = el;
		},
		createStyle: function createStyle() {
			if (!this.styleElement && !this.isUnstyled) {
				var _this$$primevue;
				this.styleElement = (void 0).createElement("style");
				this.styleElement.type = "text/css";
				_t(this.styleElement, "nonce", (_this$$primevue = this.$primevue) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.config) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.csp) === null || _this$$primevue === void 0 ? void 0 : _this$$primevue.nonce);
				(void 0).head.appendChild(this.styleElement);
				var innerHTML = "";
				for (var breakpoint in this.breakpoints) innerHTML += "\n                        @media screen and (max-width: ".concat(breakpoint, ") {\n                            .p-popover[").concat(this.$attrSelector, "] {\n                                width: ").concat(this.breakpoints[breakpoint], " !important;\n                            }\n                        }\n                    ");
				this.styleElement.innerHTML = innerHTML;
			}
		},
		destroyStyle: function destroyStyle() {
			if (this.styleElement) {
				(void 0).head.removeChild(this.styleElement);
				this.styleElement = null;
			}
		},
		onOverlayClick: function onOverlayClick(event) {
			OverlayEventBus.emit("overlay-click", {
				originalEvent: event,
				target: this.target
			});
		}
	},
	directives: {
		focustrap: FocusTrap,
		ripple: Ripple
	},
	components: { Portal: script$c }
};
var _hoisted_1$4 = ["aria-modal"];
function render$11(_ctx, _cache, $props, $setup, $data, $options) {
	var _component_Portal = resolveComponent("Portal");
	var _directive_focustrap = resolveDirective("focustrap");
	return openBlock(), createBlock(_component_Portal, { appendTo: _ctx.appendTo }, {
		"default": withCtx(function() {
			return [createVNode(Transition, mergeProps({
				name: "p-anchored-overlay",
				onEnter: $options.onEnter,
				onLeave: $options.onLeave,
				onAfterLeave: $options.onAfterLeave
			}, _ctx.ptm("transition")), {
				"default": withCtx(function() {
					return [$data.visible ? withDirectives((openBlock(), createElementBlock("div", mergeProps({
						key: 0,
						ref: $options.containerRef,
						role: "dialog",
						"aria-modal": $data.visible,
						onClick: _cache[3] || (_cache[3] = function() {
							return $options.onOverlayClick && $options.onOverlayClick.apply($options, arguments);
						}),
						"class": _ctx.cx("root")
					}, _ctx.ptmi("root")), [_ctx.$slots.container ? renderSlot(_ctx.$slots, "container", {
						key: 0,
						closeCallback: $options.hide,
						keydownCallback: function keydownCallback(event) {
							return $options.onButtonKeydown(event);
						}
					}) : (openBlock(), createElementBlock("div", mergeProps({
						key: 1,
						"class": _ctx.cx("content"),
						onClick: _cache[0] || (_cache[0] = function() {
							return $options.onContentClick && $options.onContentClick.apply($options, arguments);
						}),
						onMousedown: _cache[1] || (_cache[1] = function() {
							return $options.onContentClick && $options.onContentClick.apply($options, arguments);
						}),
						onKeydown: _cache[2] || (_cache[2] = function() {
							return $options.onContentKeydown && $options.onContentKeydown.apply($options, arguments);
						})
					}, _ctx.ptm("content")), [renderSlot(_ctx.$slots, "default")], 16))], 16, _hoisted_1$4)), [[_directive_focustrap]]) : createCommentVNode("", true)];
				}),
				_: 3
			}, 16, [
				"onEnter",
				"onLeave",
				"onAfterLeave"
			])];
		}),
		_: 3
	}, 8, ["appendTo"]);
}
script$11.render = render$11;
//#endregion
//#region node_modules/primevue/avatar/style/index.mjs
var AvatarStyle = BaseStyle.extend({
	name: "avatar",
	style: style$3,
	classes: {
		root: function root(_ref) {
			var props = _ref.props;
			return ["p-avatar p-component", {
				"p-avatar-image": props.image != null,
				"p-avatar-circle": props.shape === "circle",
				"p-avatar-lg": props.size === "large",
				"p-avatar-xl": props.size === "xlarge"
			}];
		},
		label: "p-avatar-label",
		icon: "p-avatar-icon"
	}
});
//#endregion
//#region node_modules/primevue/avatar/index.mjs
var avatar_exports = /* @__PURE__ */ __exportAll({ default: () => script$12 });
var script$1$11 = {
	name: "BaseAvatar",
	"extends": script$j,
	props: {
		label: {
			type: String,
			"default": null
		},
		icon: {
			type: String,
			"default": null
		},
		image: {
			type: String,
			"default": null
		},
		size: {
			type: String,
			"default": "normal"
		},
		shape: {
			type: String,
			"default": "square"
		},
		ariaLabelledby: {
			type: String,
			"default": null
		},
		ariaLabel: {
			type: String,
			"default": null
		}
	},
	style: AvatarStyle,
	provide: function provide() {
		return {
			$pcAvatar: this,
			$parentInstance: this
		};
	}
};
function _typeof$6(o) {
	"@babel/helpers - typeof";
	return _typeof$6 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$6(o);
}
function _defineProperty$6(e, r, t) {
	return (r = _toPropertyKey$6(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$6(t) {
	var i = _toPrimitive$6(t, "string");
	return "symbol" == _typeof$6(i) ? i : i + "";
}
function _toPrimitive$6(t, r) {
	if ("object" != _typeof$6(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$6(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$12 = {
	name: "Avatar",
	"extends": script$1$11,
	inheritAttrs: false,
	emits: ["error"],
	methods: { onError: function onError(event) {
		this.$emit("error", event);
	} },
	computed: { dataP: function dataP() {
		return cn(_defineProperty$6(_defineProperty$6({}, this.shape, this.shape), this.size, this.size));
	} }
};
var _hoisted_1$3 = [
	"aria-labelledby",
	"aria-label",
	"data-p"
];
var _hoisted_2$2 = ["data-p"];
var _hoisted_3$2 = ["data-p"];
var _hoisted_4$2 = [
	"src",
	"alt",
	"data-p"
];
function render$10(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("div", mergeProps({
		"class": _ctx.cx("root"),
		"aria-labelledby": _ctx.ariaLabelledby,
		"aria-label": _ctx.ariaLabel
	}, _ctx.ptmi("root"), { "data-p": $options.dataP }), [renderSlot(_ctx.$slots, "default", {}, function() {
		return [_ctx.label ? (openBlock(), createElementBlock("span", mergeProps({
			key: 0,
			"class": _ctx.cx("label")
		}, _ctx.ptm("label"), { "data-p": $options.dataP }), toDisplayString(_ctx.label), 17, _hoisted_2$2)) : _ctx.$slots.icon ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.$slots.icon), {
			key: 1,
			"class": normalizeClass(_ctx.cx("icon"))
		}, null, 8, ["class"])) : _ctx.icon ? (openBlock(), createElementBlock("span", mergeProps({
			key: 2,
			"class": [_ctx.cx("icon"), _ctx.icon]
		}, _ctx.ptm("icon"), { "data-p": $options.dataP }), null, 16, _hoisted_3$2)) : _ctx.image ? (openBlock(), createElementBlock("img", mergeProps({
			key: 3,
			src: _ctx.image,
			alt: _ctx.ariaLabel,
			onError: _cache[0] || (_cache[0] = function() {
				return $options.onError && $options.onError.apply($options, arguments);
			})
		}, _ctx.ptm("image"), { "data-p": $options.dataP }), null, 16, _hoisted_4$2)) : createCommentVNode("", true)];
	})], 16, _hoisted_1$3);
}
script$12.render = render$10;
//#endregion
//#region \0virtual:public?%2Ffavicon.webp
var _virtual_public__2Ffavicon_default = publicAssetsURL("/favicon.webp");
//#endregion
//#region app/components/NavBar.vue?vue&type=script&setup=true&lang.ts
var NavBar_vue_vue_type_script_setup_true_lang_default = /*@__PURE__*/ defineComponent({
	__name: "NavBar",
	__ssrInlineRender: true,
	setup(__props) {
		const localePath = useLocalePath();
		const { locale, setLocale } = useI18n();
		const colorMode = useColorMode();
		const isBgBlur = ref(false);
		const userStore = useUserStore();
		const { userInfo, isConfirmDefault } = (0, composables_exports.storeToRefs)(userStore);
		const tmpNickname = ref("");
		const userInfoPopover = ref();
		function switchColorMode() {
			if (colorMode.preference === "light") colorMode.preference = "dark";
			else colorMode.preference = "light";
		}
		function switchI18n() {
			if (locale.value === "en") setLocale("zh");
			else setLocale("en");
		}
		function switchConfirmDefault() {
			userStore.setConfirmDefault(isConfirmDefault.value);
		}
		function showNicknameEditor(event) {
			tmpNickname.value = userInfo.value.nickname;
			userInfoPopover.value.toggle(event);
		}
		function editNickname() {
			userStore.setNickname(tmpNickname.value);
			tmpNickname.value = userInfo.value.nickname;
			userInfoPopover.value.hide();
		}
		function editAvatar() {
			userStore.openAvatarPicker();
		}
		function clearUserInfo() {
			userStore.resetUserInfo();
			tmpNickname.value = userInfo.value.nickname;
		}
		return (_ctx, _push, _parent, _attrs) => {
			const _component_NuxtLink = NuxtLink;
			const _component_Avatar = script$12;
			const _component_Popover = script$11;
			const _component_Button = script$d;
			const _component_Icon = components_default$1;
			const _component_InputGroup = script$13;
			const _component_InputText = script$15;
			const _component_Divider = script$17;
			const _component_ToggleSwitch = script$14;
			_push(`<nav${ssrRenderAttrs(mergeProps({ class: ["flex flex-row items-center py-3 px-4 md:py-4 md:px-[10vw] sticky left-0 right-0 top-0 z-50 nav-bar", { "backdrop-blur": unref(isBgBlur) }] }, _attrs))} data-v-7e5264ac>`);
			_push(ssrRenderComponent(_component_NuxtLink, { to: unref(localePath)("/") }, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) _push(`<div class="tracking-wider" data-v-7e5264ac${_scopeId}><img${ssrRenderAttr("src", _virtual_public__2Ffavicon_default)} class="inline-block size-[32px] mr-1" data-v-7e5264ac${_scopeId}>FastSend </div>`);
					else return [createVNode("div", { class: "tracking-wider" }, [createVNode("img", {
						src: _virtual_public__2Ffavicon_default,
						class: "inline-block size-[32px] mr-1"
					}), createTextVNode("FastSend ")])];
				}),
				_: 1
			}, _parent));
			_push(`<div class="flex-1" data-v-7e5264ac></div><div class="contents text-sm" data-v-7e5264ac>`);
			_push(ssrRenderComponent(_component_Avatar, {
				image: unref(userInfo).avatarURL,
				shape: "circle",
				class: "shadow cursor-pointer",
				onClick: showNicknameEditor
			}, null, _parent));
			_push(`<p class="ml-2 truncate shrink-[1000] hidden md:block" data-v-7e5264ac>${ssrInterpolate(unref(userInfo).nickname)}</p></div>`);
			_push(ssrRenderComponent(_component_Popover, {
				ref_key: "userInfoPopover",
				ref: userInfoPopover
			}, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) {
						_push(`<div class="relative p-3 m-2" data-v-7e5264ac${_scopeId}><div class="absolute top-0 right-0 z-10" data-v-7e5264ac${_scopeId}>`);
						_push(ssrRenderComponent(_component_Button, {
							severity: "secondary",
							text: "",
							onClick: clearUserInfo,
							size: "small",
							class: "py-3",
							"aria-label": "Language"
						}, {
							default: withCtx((_, _push, _parent, _scopeId) => {
								if (_push) _push(ssrRenderComponent(_component_Icon, {
									name: "material-symbols:sync-rounded",
									class: "text-rose-500 dark:text-rose-600"
								}, null, _parent, _scopeId));
								else return [createVNode(_component_Icon, {
									name: "material-symbols:sync-rounded",
									class: "text-rose-500 dark:text-rose-600"
								})];
							}),
							_: 1
						}, _parent, _scopeId));
						_push(`</div><div class="relative flex flex-col items-center gap-4" data-v-7e5264ac${_scopeId}>`);
						_push(ssrRenderComponent(_component_Avatar, {
							image: unref(userInfo).avatarURL,
							shape: "circle",
							class: "shadow-md cursor-pointer",
							size: "xlarge",
							onClick: editAvatar
						}, null, _parent, _scopeId));
						_push(ssrRenderComponent(_component_InputGroup, null, {
							default: withCtx((_, _push, _parent, _scopeId) => {
								if (_push) {
									_push(ssrRenderComponent(_component_InputText, {
										severity: "contrast",
										size: "small",
										placeholder: "昵称",
										"model-value": unref(tmpNickname),
										"onUpdate:modelValue": ($event) => isRef(tmpNickname) ? tmpNickname.value = $event : null,
										onKeydown: editNickname
									}, null, _parent, _scopeId));
									_push(ssrRenderComponent(_component_Button, {
										severity: "contrast",
										size: "small",
										class: "m-0",
										onClick: editNickname
									}, {
										default: withCtx((_, _push, _parent, _scopeId) => {
											if (_push) _push(ssrRenderComponent(_component_Icon, { name: "material-symbols:check-rounded" }, null, _parent, _scopeId));
											else return [createVNode(_component_Icon, { name: "material-symbols:check-rounded" })];
										}),
										_: 1
									}, _parent, _scopeId));
								} else return [createVNode(_component_InputText, {
									severity: "contrast",
									size: "small",
									placeholder: "昵称",
									"model-value": unref(tmpNickname),
									"onUpdate:modelValue": ($event) => isRef(tmpNickname) ? tmpNickname.value = $event : null,
									onKeydown: withKeys(editNickname, ["enter"])
								}, null, 8, ["model-value", "onUpdate:modelValue"]), createVNode(_component_Button, {
									severity: "contrast",
									size: "small",
									class: "m-0",
									onClick: editNickname
								}, {
									default: withCtx(() => [createVNode(_component_Icon, { name: "material-symbols:check-rounded" })]),
									_: 1
								})];
							}),
							_: 1
						}, _parent, _scopeId));
						_push(`</div>`);
						_push(ssrRenderComponent(_component_Divider, null, null, _parent, _scopeId));
						_push(`<div class="flex flex-row items-center justify-between" data-v-7e5264ac${_scopeId}><p class="text-sm" data-v-7e5264ac${_scopeId}>${ssrInterpolate(_ctx.$t("label.autoConfirmBySender"))}</p>`);
						_push(ssrRenderComponent(_component_ToggleSwitch, {
							modelValue: unref(isConfirmDefault),
							"onUpdate:modelValue": ($event) => isRef(isConfirmDefault) ? isConfirmDefault.value = $event : null,
							onChange: switchConfirmDefault
						}, null, _parent, _scopeId));
						_push(`</div></div>`);
					} else return [createVNode("div", { class: "relative p-3 m-2" }, [
						createVNode("div", { class: "absolute top-0 right-0 z-10" }, [createVNode(_component_Button, {
							severity: "secondary",
							text: "",
							onClick: clearUserInfo,
							size: "small",
							class: "py-3",
							"aria-label": "Language"
						}, {
							default: withCtx(() => [createVNode(_component_Icon, {
								name: "material-symbols:sync-rounded",
								class: "text-rose-500 dark:text-rose-600"
							})]),
							_: 1
						})]),
						createVNode("div", { class: "relative flex flex-col items-center gap-4" }, [createVNode(_component_Avatar, {
							image: unref(userInfo).avatarURL,
							shape: "circle",
							class: "shadow-md cursor-pointer",
							size: "xlarge",
							onClick: editAvatar
						}, null, 8, ["image"]), createVNode(_component_InputGroup, null, {
							default: withCtx(() => [createVNode(_component_InputText, {
								severity: "contrast",
								size: "small",
								placeholder: "昵称",
								"model-value": unref(tmpNickname),
								"onUpdate:modelValue": ($event) => isRef(tmpNickname) ? tmpNickname.value = $event : null,
								onKeydown: withKeys(editNickname, ["enter"])
							}, null, 8, ["model-value", "onUpdate:modelValue"]), createVNode(_component_Button, {
								severity: "contrast",
								size: "small",
								class: "m-0",
								onClick: editNickname
							}, {
								default: withCtx(() => [createVNode(_component_Icon, { name: "material-symbols:check-rounded" })]),
								_: 1
							})]),
							_: 1
						})]),
						createVNode(_component_Divider),
						createVNode("div", { class: "flex flex-row items-center justify-between" }, [createVNode("p", { class: "text-sm" }, toDisplayString(_ctx.$t("label.autoConfirmBySender")), 1), createVNode(_component_ToggleSwitch, {
							modelValue: unref(isConfirmDefault),
							"onUpdate:modelValue": ($event) => isRef(isConfirmDefault) ? isConfirmDefault.value = $event : null,
							onChange: switchConfirmDefault
						}, null, 8, ["modelValue", "onUpdate:modelValue"])])
					])];
				}),
				_: 1
			}, _parent));
			_push(`<div class="contents" data-v-7e5264ac>`);
			_push(ssrRenderComponent(_component_Button, {
				severity: "secondary",
				text: "",
				onClick: switchI18n,
				size: "small",
				class: "py-3",
				"aria-label": "Language"
			}, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) {
						if (unref(locale) === "zh") _push(ssrRenderComponent(_component_Icon, {
							name: "icon-park-outline:chinese",
							class: "text-black/90 dark:text-white/90"
						}, null, _parent, _scopeId));
						else if (unref(locale) === "en") _push(ssrRenderComponent(_component_Icon, {
							name: "icon-park-outline:english",
							class: "text-black/90 dark:text-white/90"
						}, null, _parent, _scopeId));
						else _push(`<!---->`);
					} else return [unref(locale) === "zh" ? (openBlock(), createBlock(_component_Icon, {
						key: 0,
						name: "icon-park-outline:chinese",
						class: "text-black/90 dark:text-white/90"
					})) : unref(locale) === "en" ? (openBlock(), createBlock(_component_Icon, {
						key: 1,
						name: "icon-park-outline:english",
						class: "text-black/90 dark:text-white/90"
					})) : createCommentVNode("", true)];
				}),
				_: 1
			}, _parent));
			_push(ssrRenderComponent(_component_Button, {
				severity: "secondary",
				text: "",
				onClick: switchColorMode,
				size: "small",
				class: "py-3",
				"aria-label": "Dark"
			}, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) {
						if (unref(colorMode).preference === "dark") _push(ssrRenderComponent(_component_Icon, {
							name: "solar:moon-linear",
							class: "text-yellow-500/90"
						}, null, _parent, _scopeId));
						else _push(ssrRenderComponent(_component_Icon, {
							name: "solar:sun-broken",
							class: "text-black"
						}, null, _parent, _scopeId));
					} else return [unref(colorMode).preference === "dark" ? (openBlock(), createBlock(_component_Icon, {
						key: 0,
						name: "solar:moon-linear",
						class: "text-yellow-500/90"
					})) : (openBlock(), createBlock(_component_Icon, {
						key: 1,
						name: "solar:sun-broken",
						class: "text-black"
					}))];
				}),
				_: 1
			}, _parent));
			_push(`</div></nav>`);
		};
	}
});
//#endregion
//#region app/components/NavBar.vue
var _sfc_setup$6 = NavBar_vue_vue_type_script_setup_true_lang_default.setup;
NavBar_vue_vue_type_script_setup_true_lang_default.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/NavBar.vue");
	return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
var NavBar_default = /*#__PURE__*/ Object.assign(_plugin_vue_export_helper_default(NavBar_vue_vue_type_script_setup_true_lang_default, [["__scopeId", "data-v-7e5264ac"]]), { __name: "NavBar" });
//#endregion
//#region node_modules/nuxt/dist/app/components/route-provider.js
var defineRouteProvider = (name = "RouteProvider") => defineComponent({
	name,
	props: {
		route: {
			type: Object,
			required: true
		},
		vnode: Object,
		vnodeRef: Object,
		renderKey: String,
		trackRootNodes: Boolean,
		routeRecord: Object
	},
	setup(props) {
		const previousKey = props.renderKey;
		const previousRoute = props.route;
		const route = {};
		for (const key in props.route) Object.defineProperty(route, key, {
			get: () => previousKey === props.renderKey ? props.route[key] : previousRoute[key],
			enumerable: true
		});
		provide(PageRouteSymbol, shallowReactive(route));
		return () => {
			if (!props.vnode) return props.vnode;
			return h(props.vnode, { ref: props.vnodeRef });
		};
	}
});
var RouteProvider = defineRouteProvider();
//#endregion
//#region node_modules/nuxt/dist/pages/runtime/page.js
var page_default = defineComponent({
	name: "NuxtPage",
	inheritAttrs: false,
	props: {
		name: { type: String },
		transition: {
			type: [Boolean, Object],
			default: void 0
		},
		keepalive: {
			type: [Boolean, Object],
			default: void 0
		},
		route: { type: Object },
		pageKey: {
			type: [Function, String],
			default: null
		}
	},
	setup(props, { attrs, slots, expose }) {
		const nuxtApp = useNuxtApp();
		const pageRef = ref();
		inject(PageRouteSymbol, null);
		expose({ pageRef });
		inject(LayoutMetaSymbol, null);
		nuxtApp.deferHydration();
		return () => {
			return h(RouterView, {
				name: props.name,
				route: props.route,
				...attrs
			}, { default: markStableSlot((routeProps) => {
				return h(Suspense, { suspensible: true }, { default() {
					return h(RouteProvider, {
						vnode: slots.default ? normalizeSlot(slots.default, routeProps) : routeProps.Component,
						route: routeProps.route,
						vnodeRef: pageRef
					});
				} });
			}) });
		};
	}
});
function markStableSlot(fn) {
	const wrapped = ((routeProps) => {
		const result = fn(routeProps);
		if (Array.isArray(result)) return result;
		if (result == null || !isVNode(result)) return [createCommentVNode()];
		return [result];
	});
	wrapped._n = true;
	return wrapped;
}
function normalizeSlot(slot, data) {
	const slotContent = slot(data);
	return slotContent.length === 1 ? h(slotContent[0]) : h(Fragment, void 0, slotContent);
}
//#endregion
//#region app/components/AppFooter.vue
var _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
	_push(`<div${ssrRenderAttrs(mergeProps({ class: "my-12" }, _attrs))}><div class="text-center text-sm text-neutral-500/80 flex flex-row items-center justify-center"><a target="_blank" href="https://github.com/ShouChenICU/FastSend" class="underline hover:text-sky-500">Github</a><div class="w-[1px] h-4 bg-neutral-500/80 mx-2"></div><span>fastsend.ing</span><div class="w-[1px] h-4 bg-neutral-500/80 mx-2"></div><span>v0.7.3</span></div></div>`);
}
var _sfc_setup$5 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppFooter.vue");
	return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
var AppFooter_default = /*#__PURE__*/ Object.assign(_plugin_vue_export_helper_default(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]), { __name: "AppFooter" });
//#endregion
//#region app/components/InstallPWA.vue?vue&type=script&setup=true&lang.ts
var InstallPWA_vue_vue_type_script_setup_true_lang_default = /*@__PURE__*/ defineComponent({
	__name: "InstallPWA",
	__ssrInlineRender: true,
	setup(__props) {
		const isPWA = ref(false);
		const appStore = useAppStore();
		const { deferredPrompt } = (0, composables_exports.storeToRefs)(appStore);
		function installPWA() {
			deferredPrompt.value?.prompt();
		}
		return (_ctx, _push, _parent, _attrs) => {
			const _component_Button = script$d;
			const _component_Icon = components_default$1;
			if (!unref(isPWA) && unref(deferredPrompt)) {
				_push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed right-5 bottom-36 z-40" }, _attrs))}>`);
				_push(ssrRenderComponent(_component_Button, {
					text: "",
					raised: "",
					rounded: "",
					severity: "contrast",
					size: "large",
					class: "shadow-sm shadow-black/25 border-0 dark:border border-white/25",
					"aria-label": "Install PWA",
					onClick: installPWA
				}, {
					default: withCtx((_, _push, _parent, _scopeId) => {
						if (_push) _push(ssrRenderComponent(_component_Icon, {
							name: "ic:outline-install-mobile",
							class: "text-black/90 dark:text-white/90"
						}, null, _parent, _scopeId));
						else return [createVNode(_component_Icon, {
							name: "ic:outline-install-mobile",
							class: "text-black/90 dark:text-white/90"
						})];
					}),
					_: 1
				}, _parent));
				_push(`</div>`);
			} else _push(`<!---->`);
		};
	}
});
//#endregion
//#region app/components/InstallPWA.vue
var _sfc_setup$4 = InstallPWA_vue_vue_type_script_setup_true_lang_default.setup;
InstallPWA_vue_vue_type_script_setup_true_lang_default.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/InstallPWA.vue");
	return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
var InstallPWA_default = Object.assign(InstallPWA_vue_vue_type_script_setup_true_lang_default, { __name: "InstallPWA" });
//#endregion
//#region node_modules/@primevue/icons/windowmaximize/index.mjs
var script$10 = {
	name: "WindowMaximizeIcon",
	"extends": script$g
};
function _toConsumableArray$6(r) {
	return _arrayWithoutHoles$6(r) || _iterableToArray$6(r) || _unsupportedIterableToArray$6(r) || _nonIterableSpread$6();
}
function _nonIterableSpread$6() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$6(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$6(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$6(r, a) : void 0;
	}
}
function _iterableToArray$6(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$6(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$6(r);
}
function _arrayLikeToArray$6(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$9(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$6(_cache[0] || (_cache[0] = [createElementVNode("path", {
		"fill-rule": "evenodd",
		"clip-rule": "evenodd",
		d: "M7 14H11.8C12.3835 14 12.9431 13.7682 13.3556 13.3556C13.7682 12.9431 14 12.3835 14 11.8V2.2C14 1.61652 13.7682 1.05694 13.3556 0.644365C12.9431 0.231785 12.3835 0 11.8 0H2.2C1.61652 0 1.05694 0.231785 0.644365 0.644365C0.231785 1.05694 0 1.61652 0 2.2V7C0 7.15913 0.063214 7.31174 0.175736 7.42426C0.288258 7.53679 0.44087 7.6 0.6 7.6C0.75913 7.6 0.911742 7.53679 1.02426 7.42426C1.13679 7.31174 1.2 7.15913 1.2 7V2.2C1.2 1.93478 1.30536 1.68043 1.49289 1.49289C1.68043 1.30536 1.93478 1.2 2.2 1.2H11.8C12.0652 1.2 12.3196 1.30536 12.5071 1.49289C12.6946 1.68043 12.8 1.93478 12.8 2.2V11.8C12.8 12.0652 12.6946 12.3196 12.5071 12.5071C12.3196 12.6946 12.0652 12.8 11.8 12.8H7C6.84087 12.8 6.68826 12.8632 6.57574 12.9757C6.46321 13.0883 6.4 13.2409 6.4 13.4C6.4 13.5591 6.46321 13.7117 6.57574 13.8243C6.68826 13.9368 6.84087 14 7 14ZM9.77805 7.42192C9.89013 7.534 10.0415 7.59788 10.2 7.59995C10.3585 7.59788 10.5099 7.534 10.622 7.42192C10.7341 7.30985 10.798 7.15844 10.8 6.99995V3.94242C10.8066 3.90505 10.8096 3.86689 10.8089 3.82843C10.8079 3.77159 10.7988 3.7157 10.7824 3.6623C10.756 3.55552 10.701 3.45698 10.622 3.37798C10.5099 3.2659 10.3585 3.20202 10.2 3.19995H7.00002C6.84089 3.19995 6.68828 3.26317 6.57576 3.37569C6.46324 3.48821 6.40002 3.64082 6.40002 3.79995C6.40002 3.95908 6.46324 4.11169 6.57576 4.22422C6.68828 4.33674 6.84089 4.39995 7.00002 4.39995H8.80006L6.19997 7.00005C6.10158 7.11005 6.04718 7.25246 6.04718 7.40005C6.04718 7.54763 6.10158 7.69004 6.19997 7.80005C6.30202 7.91645 6.44561 7.98824 6.59997 8.00005C6.75432 7.98824 6.89791 7.91645 6.99997 7.80005L9.60002 5.26841V6.99995C9.6021 7.15844 9.66598 7.30985 9.77805 7.42192ZM1.4 14H3.8C4.17066 13.9979 4.52553 13.8498 4.78763 13.5877C5.04973 13.3256 5.1979 12.9707 5.2 12.6V10.2C5.1979 9.82939 5.04973 9.47452 4.78763 9.21242C4.52553 8.95032 4.17066 8.80215 3.8 8.80005H1.4C1.02934 8.80215 0.674468 8.95032 0.412371 9.21242C0.150274 9.47452 0.00210008 9.82939 0 10.2V12.6C0.00210008 12.9707 0.150274 13.3256 0.412371 13.5877C0.674468 13.8498 1.02934 13.9979 1.4 14ZM1.25858 10.0586C1.29609 10.0211 1.34696 10 1.4 10H3.8C3.85304 10 3.90391 10.0211 3.94142 10.0586C3.97893 10.0961 4 10.147 4 10.2V12.6C4 12.6531 3.97893 12.704 3.94142 12.7415C3.90391 12.779 3.85304 12.8 3.8 12.8H1.4C1.34696 12.8 1.29609 12.779 1.25858 12.7415C1.22107 12.704 1.2 12.6531 1.2 12.6V10.2C1.2 10.147 1.22107 10.0961 1.25858 10.0586Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$10.render = render$9;
//#endregion
//#region node_modules/@primevue/icons/windowminimize/index.mjs
var script$9 = {
	name: "WindowMinimizeIcon",
	"extends": script$g
};
function _toConsumableArray$5(r) {
	return _arrayWithoutHoles$5(r) || _iterableToArray$5(r) || _unsupportedIterableToArray$5(r) || _nonIterableSpread$5();
}
function _nonIterableSpread$5() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$5(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$5(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$5(r, a) : void 0;
	}
}
function _iterableToArray$5(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$5(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$5(r);
}
function _arrayLikeToArray$5(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$8(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$5(_cache[0] || (_cache[0] = [createElementVNode("path", {
		"fill-rule": "evenodd",
		"clip-rule": "evenodd",
		d: "M11.8 0H2.2C1.61652 0 1.05694 0.231785 0.644365 0.644365C0.231785 1.05694 0 1.61652 0 2.2V7C0 7.15913 0.063214 7.31174 0.175736 7.42426C0.288258 7.53679 0.44087 7.6 0.6 7.6C0.75913 7.6 0.911742 7.53679 1.02426 7.42426C1.13679 7.31174 1.2 7.15913 1.2 7V2.2C1.2 1.93478 1.30536 1.68043 1.49289 1.49289C1.68043 1.30536 1.93478 1.2 2.2 1.2H11.8C12.0652 1.2 12.3196 1.30536 12.5071 1.49289C12.6946 1.68043 12.8 1.93478 12.8 2.2V11.8C12.8 12.0652 12.6946 12.3196 12.5071 12.5071C12.3196 12.6946 12.0652 12.8 11.8 12.8H7C6.84087 12.8 6.68826 12.8632 6.57574 12.9757C6.46321 13.0883 6.4 13.2409 6.4 13.4C6.4 13.5591 6.46321 13.7117 6.57574 13.8243C6.68826 13.9368 6.84087 14 7 14H11.8C12.3835 14 12.9431 13.7682 13.3556 13.3556C13.7682 12.9431 14 12.3835 14 11.8V2.2C14 1.61652 13.7682 1.05694 13.3556 0.644365C12.9431 0.231785 12.3835 0 11.8 0ZM6.368 7.952C6.44137 7.98326 6.52025 7.99958 6.6 8H9.8C9.95913 8 10.1117 7.93678 10.2243 7.82426C10.3368 7.71174 10.4 7.55913 10.4 7.4C10.4 7.24087 10.3368 7.08826 10.2243 6.97574C10.1117 6.86321 9.95913 6.8 9.8 6.8H8.048L10.624 4.224C10.73 4.11026 10.7877 3.95982 10.7849 3.80438C10.7822 3.64894 10.7192 3.50063 10.6093 3.3907C10.4994 3.28077 10.3511 3.2178 10.1956 3.21506C10.0402 3.21232 9.88974 3.27002 9.776 3.376L7.2 5.952V4.2C7.2 4.04087 7.13679 3.88826 7.02426 3.77574C6.91174 3.66321 6.75913 3.6 6.6 3.6C6.44087 3.6 6.28826 3.66321 6.17574 3.77574C6.06321 3.88826 6 4.04087 6 4.2V7.4C6.00042 7.47975 6.01674 7.55862 6.048 7.632C6.07656 7.70442 6.11971 7.7702 6.17475 7.82524C6.2298 7.88029 6.29558 7.92344 6.368 7.952ZM1.4 8.80005H3.8C4.17066 8.80215 4.52553 8.95032 4.78763 9.21242C5.04973 9.47452 5.1979 9.82939 5.2 10.2V12.6C5.1979 12.9707 5.04973 13.3256 4.78763 13.5877C4.52553 13.8498 4.17066 13.9979 3.8 14H1.4C1.02934 13.9979 0.674468 13.8498 0.412371 13.5877C0.150274 13.3256 0.00210008 12.9707 0 12.6V10.2C0.00210008 9.82939 0.150274 9.47452 0.412371 9.21242C0.674468 8.95032 1.02934 8.80215 1.4 8.80005ZM3.94142 12.7415C3.97893 12.704 4 12.6531 4 12.6V10.2C4 10.147 3.97893 10.0961 3.94142 10.0586C3.90391 10.0211 3.85304 10 3.8 10H1.4C1.34696 10 1.29609 10.0211 1.25858 10.0586C1.22107 10.0961 1.2 10.147 1.2 10.2V12.6C1.2 12.6531 1.22107 12.704 1.25858 12.7415C1.29609 12.779 1.34696 12.8 1.4 12.8H3.8C3.85304 12.8 3.90391 12.779 3.94142 12.7415Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$9.render = render$8;
//#endregion
//#region node_modules/primevue/utils/index.mjs
function blockBodyScroll() {
	utils.blockBodyScroll({ variableName: $dt("scrollbar.width").name });
}
function unblockBodyScroll() {
	utils.unblockBodyScroll({ variableName: $dt("scrollbar.width").name });
}
//#endregion
//#region node_modules/primevue/dialog/style/index.mjs
var DialogStyle = BaseStyle.extend({
	name: "dialog",
	style: style$2,
	classes: {
		mask: function mask(_ref2) {
			var props = _ref2.props;
			var pos = [
				"left",
				"right",
				"top",
				"topleft",
				"topright",
				"bottom",
				"bottomleft",
				"bottomright"
			].find(function(item) {
				return item === props.position;
			});
			return [
				"p-dialog-mask",
				{ "p-overlay-mask p-overlay-mask-enter-active": props.modal },
				pos ? "p-dialog-".concat(pos) : ""
			];
		},
		root: function root(_ref3) {
			var props = _ref3.props, instance = _ref3.instance;
			return ["p-dialog p-component", { "p-dialog-maximized": props.maximizable && instance.maximized }];
		},
		header: "p-dialog-header",
		title: "p-dialog-title",
		headerActions: "p-dialog-header-actions",
		pcMaximizeButton: "p-dialog-maximize-button",
		pcCloseButton: "p-dialog-close-button",
		content: "p-dialog-content",
		footer: "p-dialog-footer"
	},
	inlineStyles: {
		mask: function mask(_ref) {
			var position = _ref.position, modal = _ref.modal;
			return {
				position: "fixed",
				height: "100%",
				width: "100%",
				left: 0,
				top: 0,
				display: "flex",
				justifyContent: position === "left" || position === "topleft" || position === "bottomleft" ? "flex-start" : position === "right" || position === "topright" || position === "bottomright" ? "flex-end" : "center",
				alignItems: position === "top" || position === "topleft" || position === "topright" ? "flex-start" : position === "bottom" || position === "bottomleft" || position === "bottomright" ? "flex-end" : "center",
				pointerEvents: modal ? "auto" : "none"
			};
		},
		root: {
			display: "flex",
			flexDirection: "column",
			pointerEvents: "auto"
		}
	}
});
//#endregion
//#region node_modules/primevue/dialog/index.mjs
var dialog_exports = /* @__PURE__ */ __exportAll({ default: () => script$8 });
var script$8 = {
	name: "Dialog",
	"extends": {
		name: "BaseDialog",
		"extends": script$j,
		props: {
			header: {
				type: null,
				"default": null
			},
			footer: {
				type: null,
				"default": null
			},
			visible: {
				type: Boolean,
				"default": false
			},
			modal: {
				type: Boolean,
				"default": null
			},
			contentStyle: {
				type: null,
				"default": null
			},
			contentClass: {
				type: String,
				"default": null
			},
			contentProps: {
				type: null,
				"default": null
			},
			maximizable: {
				type: Boolean,
				"default": false
			},
			dismissableMask: {
				type: Boolean,
				"default": false
			},
			closable: {
				type: Boolean,
				"default": true
			},
			closeOnEscape: {
				type: Boolean,
				"default": true
			},
			showHeader: {
				type: Boolean,
				"default": true
			},
			blockScroll: {
				type: Boolean,
				"default": false
			},
			baseZIndex: {
				type: Number,
				"default": 0
			},
			autoZIndex: {
				type: Boolean,
				"default": true
			},
			position: {
				type: String,
				"default": "center"
			},
			breakpoints: {
				type: Object,
				"default": null
			},
			draggable: {
				type: Boolean,
				"default": true
			},
			keepInViewport: {
				type: Boolean,
				"default": true
			},
			minX: {
				type: Number,
				"default": 0
			},
			minY: {
				type: Number,
				"default": 0
			},
			appendTo: {
				type: [String, Object],
				"default": "body"
			},
			closeIcon: {
				type: String,
				"default": void 0
			},
			maximizeIcon: {
				type: String,
				"default": void 0
			},
			minimizeIcon: {
				type: String,
				"default": void 0
			},
			closeButtonProps: {
				type: Object,
				"default": function _default() {
					return {
						severity: "secondary",
						text: true,
						rounded: true
					};
				}
			},
			maximizeButtonProps: {
				type: Object,
				"default": function _default() {
					return {
						severity: "secondary",
						text: true,
						rounded: true
					};
				}
			},
			_instance: null
		},
		style: DialogStyle,
		provide: function provide() {
			return {
				$pcDialog: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false,
	emits: [
		"update:visible",
		"show",
		"hide",
		"after-hide",
		"maximize",
		"unmaximize",
		"dragstart",
		"dragend"
	],
	provide: function provide() {
		var _this = this;
		return { dialogRef: computed(function() {
			return _this._instance;
		}) };
	},
	data: function data() {
		return {
			containerVisible: this.visible,
			maximized: false,
			focusableMax: null,
			focusableClose: null,
			target: null
		};
	},
	documentKeydownListener: null,
	container: null,
	mask: null,
	content: null,
	headerContainer: null,
	footerContainer: null,
	maximizableButton: null,
	closeButton: null,
	styleElement: null,
	dragging: null,
	documentDragListener: null,
	documentDragEndListener: null,
	lastPageX: null,
	lastPageY: null,
	maskMouseDownTarget: null,
	updated: function updated() {
		if (this.visible) this.containerVisible = this.visible;
	},
	beforeUnmount: function beforeUnmount() {
		this.unbindDocumentState();
		this.unbindGlobalListeners();
		this.destroyStyle();
		if (this.mask && this.autoZIndex) x.clear(this.mask);
		this.container = null;
		this.mask = null;
	},
	mounted: function mounted() {
		if (this.breakpoints) this.createStyle();
	},
	methods: {
		close: function close() {
			this.$emit("update:visible", false);
		},
		onEnter: function onEnter() {
			this.$emit("show");
			this.target = (void 0).activeElement;
			this.enableDocumentSettings();
			this.bindGlobalListeners();
			if (this.autoZIndex) x.set("modal", this.mask, this.baseZIndex || this.$primevue.config.zIndex.modal);
		},
		onAfterEnter: function onAfterEnter() {
			this.focus();
		},
		onBeforeLeave: function onBeforeLeave() {
			if (this.modal) !this.isUnstyled && W(this.mask, "p-overlay-mask-leave-active");
			if (this.dragging && this.documentDragEndListener) this.documentDragEndListener();
		},
		onLeave: function onLeave() {
			this.$emit("hide");
			bt(this.target);
			this.target = null;
			this.focusableClose = null;
			this.focusableMax = null;
		},
		onAfterLeave: function onAfterLeave() {
			if (this.autoZIndex) x.clear(this.mask);
			this.containerVisible = false;
			this.unbindDocumentState();
			this.unbindGlobalListeners();
			this.$emit("after-hide");
		},
		onMaskMouseDown: function onMaskMouseDown(event) {
			this.maskMouseDownTarget = event.target;
		},
		onMaskMouseUp: function onMaskMouseUp() {
			if (this.dismissableMask && this.modal && this.mask === this.maskMouseDownTarget) this.close();
		},
		focus: function focus$1() {
			var findFocusableElement = function findFocusableElement(container) {
				return container && container.querySelector("[autofocus]");
			};
			var focusTarget = this.$slots.footer && findFocusableElement(this.footerContainer);
			if (!focusTarget) {
				focusTarget = this.$slots.header && findFocusableElement(this.headerContainer);
				if (!focusTarget) {
					focusTarget = this.$slots["default"] && findFocusableElement(this.content);
					if (!focusTarget) {
						if (this.maximizable) {
							this.focusableMax = true;
							focusTarget = this.maximizableButton;
						} else {
							this.focusableClose = true;
							focusTarget = this.closeButton;
						}
					}
				}
			}
			if (focusTarget) bt(focusTarget, { focusVisible: true });
		},
		maximize: function maximize(event) {
			if (this.maximized) {
				this.maximized = false;
				this.$emit("unmaximize", event);
			} else {
				this.maximized = true;
				this.$emit("maximize", event);
			}
			if (!this.modal) this.maximized ? blockBodyScroll() : unblockBodyScroll();
		},
		enableDocumentSettings: function enableDocumentSettings() {
			if (this.modal || !this.modal && this.blockScroll || this.maximizable && this.maximized) blockBodyScroll();
		},
		unbindDocumentState: function unbindDocumentState() {
			if (this.modal || !this.modal && this.blockScroll || this.maximizable && this.maximized) unblockBodyScroll();
		},
		onKeyDown: function onKeyDown(event) {
			if (event.code === "Escape" && this.closeOnEscape && !event.isComposing) this.close();
		},
		bindDocumentKeyDownListener: function bindDocumentKeyDownListener() {
			if (!this.documentKeydownListener) {
				this.documentKeydownListener = this.onKeyDown.bind(this);
				(void 0).document.addEventListener("keydown", this.documentKeydownListener);
			}
		},
		unbindDocumentKeyDownListener: function unbindDocumentKeyDownListener() {
			if (this.documentKeydownListener) {
				(void 0).document.removeEventListener("keydown", this.documentKeydownListener);
				this.documentKeydownListener = null;
			}
		},
		containerRef: function containerRef(el) {
			this.container = el;
		},
		maskRef: function maskRef(el) {
			this.mask = el;
		},
		contentRef: function contentRef(el) {
			this.content = el;
		},
		headerContainerRef: function headerContainerRef(el) {
			this.headerContainer = el;
		},
		footerContainerRef: function footerContainerRef(el) {
			this.footerContainer = el;
		},
		maximizableRef: function maximizableRef(el) {
			this.maximizableButton = el ? el.$el : void 0;
		},
		closeButtonRef: function closeButtonRef(el) {
			this.closeButton = el ? el.$el : void 0;
		},
		createStyle: function createStyle() {
			if (!this.styleElement && !this.isUnstyled) {
				var _this$$primevue;
				this.styleElement = (void 0).createElement("style");
				this.styleElement.type = "text/css";
				_t(this.styleElement, "nonce", (_this$$primevue = this.$primevue) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.config) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.csp) === null || _this$$primevue === void 0 ? void 0 : _this$$primevue.nonce);
				(void 0).head.appendChild(this.styleElement);
				var innerHTML = "";
				for (var breakpoint in this.breakpoints) innerHTML += "\n                        @media screen and (max-width: ".concat(breakpoint, ") {\n                            .p-dialog[").concat(this.$attrSelector, "] {\n                                width: ").concat(this.breakpoints[breakpoint], " !important;\n                            }\n                        }\n                    ");
				this.styleElement.innerHTML = innerHTML;
			}
		},
		destroyStyle: function destroyStyle() {
			if (this.styleElement) {
				(void 0).head.removeChild(this.styleElement);
				this.styleElement = null;
			}
		},
		initDrag: function initDrag(event) {
			if (event.target.closest("div").getAttribute("data-pc-section") === "headeractions") return;
			if (this.draggable) {
				this.dragging = true;
				this.lastPageX = event.pageX;
				this.lastPageY = event.pageY;
				this.container.style.margin = "0";
				(void 0).body.setAttribute("data-p-unselectable-text", "true");
				!this.isUnstyled && S((void 0).body, { "user-select": "none" });
				this.$emit("dragstart", event);
			}
		},
		bindGlobalListeners: function bindGlobalListeners() {
			if (this.draggable) {
				this.bindDocumentDragListener();
				this.bindDocumentDragEndListener();
			}
			if (this.closeOnEscape) this.bindDocumentKeyDownListener();
		},
		unbindGlobalListeners: function unbindGlobalListeners() {
			this.unbindDocumentDragListener();
			this.unbindDocumentDragEndListener();
			this.unbindDocumentKeyDownListener();
		},
		bindDocumentDragListener: function bindDocumentDragListener() {
			var _this2 = this;
			this.documentDragListener = function(event) {
				if (_this2.dragging) {
					var width = v(_this2.container);
					var height = C$1(_this2.container);
					var deltaX = event.pageX - _this2.lastPageX;
					var deltaY = event.pageY - _this2.lastPageY;
					var offset = _this2.container.getBoundingClientRect();
					var leftPos = offset.left + deltaX;
					var topPos = offset.top + deltaY;
					var viewport = h$1();
					var containerComputedStyle = getComputedStyle(_this2.container);
					var marginLeft = parseFloat(containerComputedStyle.marginLeft);
					var marginTop = parseFloat(containerComputedStyle.marginTop);
					_this2.container.style.position = "fixed";
					if (_this2.keepInViewport) {
						if (leftPos >= _this2.minX && leftPos + width < viewport.width) {
							_this2.lastPageX = event.pageX;
							_this2.container.style.left = leftPos - marginLeft + "px";
						}
						if (topPos >= _this2.minY && topPos + height < viewport.height) {
							_this2.lastPageY = event.pageY;
							_this2.container.style.top = topPos - marginTop + "px";
						}
					} else {
						_this2.lastPageX = event.pageX;
						_this2.container.style.left = leftPos - marginLeft + "px";
						_this2.lastPageY = event.pageY;
						_this2.container.style.top = topPos - marginTop + "px";
					}
				}
			};
			(void 0).document.addEventListener("mousemove", this.documentDragListener);
		},
		unbindDocumentDragListener: function unbindDocumentDragListener() {
			if (this.documentDragListener) {
				(void 0).document.removeEventListener("mousemove", this.documentDragListener);
				this.documentDragListener = null;
			}
		},
		bindDocumentDragEndListener: function bindDocumentDragEndListener() {
			var _this3 = this;
			this.documentDragEndListener = function(event) {
				if (_this3.dragging) {
					_this3.dragging = false;
					(void 0).body.removeAttribute("data-p-unselectable-text");
					!_this3.isUnstyled && ((void 0).body.style["user-select"] = "");
					_this3.$emit("dragend", event);
				}
			};
			(void 0).document.addEventListener("mouseup", this.documentDragEndListener);
		},
		unbindDocumentDragEndListener: function unbindDocumentDragEndListener() {
			if (this.documentDragEndListener) {
				(void 0).document.removeEventListener("mouseup", this.documentDragEndListener);
				this.documentDragEndListener = null;
			}
		}
	},
	computed: {
		maximizeIconComponent: function maximizeIconComponent() {
			return this.maximized ? this.minimizeIcon ? "span" : "WindowMinimizeIcon" : this.maximizeIcon ? "span" : "WindowMaximizeIcon";
		},
		ariaLabelledById: function ariaLabelledById() {
			return this.header != null || this.$attrs["aria-labelledby"] !== null ? this.$id + "_header" : null;
		},
		closeAriaLabel: function closeAriaLabel() {
			return this.$primevue.config.locale.aria ? this.$primevue.config.locale.aria.close : void 0;
		},
		dataP: function dataP() {
			return cn({
				maximized: this.maximized,
				modal: this.modal
			});
		}
	},
	directives: {
		ripple: Ripple,
		focustrap: FocusTrap
	},
	components: {
		Button: script$d,
		Portal: script$c,
		WindowMinimizeIcon: script$9,
		WindowMaximizeIcon: script$10,
		TimesIcon: script$b
	}
};
function _typeof$5(o) {
	"@babel/helpers - typeof";
	return _typeof$5 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$5(o);
}
function ownKeys$2(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$2(Object(t), true).forEach(function(r) {
			_defineProperty$5(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$5(e, r, t) {
	return (r = _toPropertyKey$5(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$5(t) {
	var i = _toPrimitive$5(t, "string");
	return "symbol" == _typeof$5(i) ? i : i + "";
}
function _toPrimitive$5(t, r) {
	if ("object" != _typeof$5(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$5(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var _hoisted_1$2 = ["data-p"];
var _hoisted_2$1 = [
	"aria-labelledby",
	"aria-modal",
	"data-p"
];
var _hoisted_3$1 = ["id"];
var _hoisted_4$1 = ["data-p"];
function render$7(_ctx, _cache, $props, $setup, $data, $options) {
	var _component_Button = resolveComponent("Button");
	var _component_Portal = resolveComponent("Portal");
	var _directive_focustrap = resolveDirective("focustrap");
	return openBlock(), createBlock(_component_Portal, { appendTo: _ctx.appendTo }, {
		"default": withCtx(function() {
			return [$data.containerVisible ? (openBlock(), createElementBlock("div", mergeProps({
				key: 0,
				ref: $options.maskRef,
				"class": _ctx.cx("mask"),
				style: _ctx.sx("mask", true, {
					position: _ctx.position,
					modal: _ctx.modal
				}),
				onMousedown: _cache[1] || (_cache[1] = function() {
					return $options.onMaskMouseDown && $options.onMaskMouseDown.apply($options, arguments);
				}),
				onMouseup: _cache[2] || (_cache[2] = function() {
					return $options.onMaskMouseUp && $options.onMaskMouseUp.apply($options, arguments);
				}),
				"data-p": $options.dataP
			}, _ctx.ptm("mask")), [createVNode(Transition, mergeProps({
				name: "p-dialog",
				onEnter: $options.onEnter,
				onAfterEnter: $options.onAfterEnter,
				onBeforeLeave: $options.onBeforeLeave,
				onLeave: $options.onLeave,
				onAfterLeave: $options.onAfterLeave,
				appear: ""
			}, _ctx.ptm("transition")), {
				"default": withCtx(function() {
					return [_ctx.visible ? withDirectives((openBlock(), createElementBlock("div", mergeProps({
						key: 0,
						ref: $options.containerRef,
						"class": _ctx.cx("root"),
						style: _ctx.sx("root"),
						role: "dialog",
						"aria-labelledby": $options.ariaLabelledById,
						"aria-modal": _ctx.modal,
						"data-p": $options.dataP
					}, _ctx.ptmi("root")), [_ctx.$slots.container ? renderSlot(_ctx.$slots, "container", {
						key: 0,
						closeCallback: $options.close,
						maximizeCallback: function maximizeCallback(event) {
							return $options.maximize(event);
						},
						initDragCallback: $options.initDrag
					}) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
						_ctx.showHeader ? (openBlock(), createElementBlock("div", mergeProps({
							key: 0,
							ref: $options.headerContainerRef,
							"class": _ctx.cx("header"),
							onMousedown: _cache[0] || (_cache[0] = function() {
								return $options.initDrag && $options.initDrag.apply($options, arguments);
							})
						}, _ctx.ptm("header")), [renderSlot(_ctx.$slots, "header", { "class": normalizeClass(_ctx.cx("title")) }, function() {
							return [_ctx.header ? (openBlock(), createElementBlock("span", mergeProps({
								key: 0,
								id: $options.ariaLabelledById,
								"class": _ctx.cx("title")
							}, _ctx.ptm("title")), toDisplayString(_ctx.header), 17, _hoisted_3$1)) : createCommentVNode("", true)];
						}), createElementVNode("div", mergeProps({ "class": _ctx.cx("headerActions") }, _ctx.ptm("headerActions")), [_ctx.maximizable ? renderSlot(_ctx.$slots, "maximizebutton", {
							key: 0,
							maximized: $data.maximized,
							maximizeCallback: function maximizeCallback(event) {
								return $options.maximize(event);
							}
						}, function() {
							return [createVNode(_component_Button, mergeProps({
								ref: $options.maximizableRef,
								autofocus: $data.focusableMax,
								"class": _ctx.cx("pcMaximizeButton"),
								onClick: $options.maximize,
								tabindex: _ctx.maximizable ? "0" : "-1",
								unstyled: _ctx.unstyled
							}, _ctx.maximizeButtonProps, {
								pt: _ctx.ptm("pcMaximizeButton"),
								"data-pc-group-section": "headericon"
							}), {
								icon: withCtx(function(slotProps) {
									return [renderSlot(_ctx.$slots, "maximizeicon", { maximized: $data.maximized }, function() {
										return [(openBlock(), createBlock(resolveDynamicComponent($options.maximizeIconComponent), mergeProps({ "class": [slotProps["class"], $data.maximized ? _ctx.minimizeIcon : _ctx.maximizeIcon] }, _ctx.ptm("pcMaximizeButton")["icon"]), null, 16, ["class"]))];
									})];
								}),
								_: 3
							}, 16, [
								"autofocus",
								"class",
								"onClick",
								"tabindex",
								"unstyled",
								"pt"
							])];
						}) : createCommentVNode("", true), _ctx.closable ? renderSlot(_ctx.$slots, "closebutton", {
							key: 1,
							closeCallback: $options.close
						}, function() {
							return [createVNode(_component_Button, mergeProps({
								ref: $options.closeButtonRef,
								autofocus: $data.focusableClose,
								"class": _ctx.cx("pcCloseButton"),
								onClick: $options.close,
								"aria-label": $options.closeAriaLabel,
								unstyled: _ctx.unstyled
							}, _ctx.closeButtonProps, {
								pt: _ctx.ptm("pcCloseButton"),
								"data-pc-group-section": "headericon"
							}), {
								icon: withCtx(function(slotProps) {
									return [renderSlot(_ctx.$slots, "closeicon", {}, function() {
										return [(openBlock(), createBlock(resolveDynamicComponent(_ctx.closeIcon ? "span" : "TimesIcon"), mergeProps({ "class": [_ctx.closeIcon, slotProps["class"]] }, _ctx.ptm("pcCloseButton")["icon"]), null, 16, ["class"]))];
									})];
								}),
								_: 3
							}, 16, [
								"autofocus",
								"class",
								"onClick",
								"aria-label",
								"unstyled",
								"pt"
							])];
						}) : createCommentVNode("", true)], 16)], 16)) : createCommentVNode("", true),
						createElementVNode("div", mergeProps({
							ref: $options.contentRef,
							"class": [_ctx.cx("content"), _ctx.contentClass],
							style: _ctx.contentStyle,
							"data-p": $options.dataP
						}, _objectSpread$2(_objectSpread$2({}, _ctx.contentProps), _ctx.ptm("content"))), [renderSlot(_ctx.$slots, "default")], 16, _hoisted_4$1),
						_ctx.footer || _ctx.$slots.footer ? (openBlock(), createElementBlock("div", mergeProps({
							key: 1,
							ref: $options.footerContainerRef,
							"class": _ctx.cx("footer")
						}, _ctx.ptm("footer")), [renderSlot(_ctx.$slots, "footer", {}, function() {
							return [createTextVNode(toDisplayString(_ctx.footer), 1)];
						})], 16)) : createCommentVNode("", true)
					], 64))], 16, _hoisted_2$1)), [[_directive_focustrap, { disabled: !_ctx.modal }]]) : createCommentVNode("", true)];
				}),
				_: 3
			}, 16, [
				"onEnter",
				"onAfterEnter",
				"onBeforeLeave",
				"onLeave",
				"onAfterLeave"
			])], 16, _hoisted_1$2)) : createCommentVNode("", true)];
		}),
		_: 3
	}, 8, ["appendTo"]);
}
script$8.render = render$7;
//#endregion
//#region app/components/DocPanel.vue?vue&type=script&setup=true&lang.ts
var DocPanel_vue_vue_type_script_setup_true_lang_default = /*@__PURE__*/ defineComponent({
	__name: "DocPanel",
	__ssrInlineRender: true,
	setup(__props) {
		const { locale } = useI18n();
		const isDocPanelShow = ref(false);
		const curIP = ref("");
		function showDocPanel() {
			isDocPanelShow.value = true;
		}
		return (_ctx, _push, _parent, _attrs) => {
			const _component_Button = script$d;
			const _component_Icon = components_default$1;
			const _component_Dialog = script$8;
			const _component_Divider = script$17;
			_push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed right-5 bottom-20 z-40" }, _attrs))}>`);
			_push(ssrRenderComponent(_component_Button, {
				text: "",
				raised: "",
				rounded: "",
				severity: "contrast",
				size: "large",
				class: "shadow-sm shadow-black/25 border-0 dark:border border-white/25",
				onClick: showDocPanel,
				"aria-label": "Document"
			}, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) _push(ssrRenderComponent(_component_Icon, {
						name: "solar:notebook-bookmark-line-duotone",
						class: "text-black/90 dark:text-white/90"
					}, null, _parent, _scopeId));
					else return [createVNode(_component_Icon, {
						name: "solar:notebook-bookmark-line-duotone",
						class: "text-black/90 dark:text-white/90"
					})];
				}),
				_: 1
			}, _parent));
			_push(ssrRenderComponent(_component_Dialog, {
				visible: unref(isDocPanelShow),
				"onUpdate:visible": ($event) => isRef(isDocPanelShow) ? isDocPanelShow.value = $event : null,
				"dismissable-mask": "",
				modal: "",
				header: "FastSend",
				class: "w-[90vw] md:w-[60vw] max-h-[80vh]"
			}, {
				default: withCtx((_, _push, _parent, _scopeId) => {
					if (_push) {
						if (unref(locale) === "zh") _push(`<article class="post"${_scopeId}><p${_scopeId}> 欢迎使用<b class="underline"${_scopeId}>FastSend</b>，这是一个使用浏览器<code${_scopeId}>\`点对点\`</code>加密传输文件的网页工具 </p><p${_scopeId}> 你的文件数据不会经过第三方服务器，保证隐私安全，相应的，需要发送方在传输过程中保持在线 </p><h2${_scopeId}>一、快速上手</h2><h3${_scopeId}>发送单个文件</h3><p${_scopeId}>1. 发送方点击<b${_scopeId}>发送文件</b>，获取文件<b${_scopeId}>取件码</b>（也可将文件拖放到发送区域）</p><p${_scopeId}>2. 接收方输入<b${_scopeId}>取件码</b>开始点对点配对，配对成功后等待发送方确认</p><p${_scopeId}>3. 发送方点击<b${_scopeId}>确认</b>继续传输（可点开头像设置自动确认）</p><p${_scopeId}> 4. 接收方点击<b${_scopeId}>接收</b>，选择保存路径，然后开始传输（如果浏览器不支持直接访问文件系统，数据将暂存在内存中，传输完毕后触发下载） </p><h3${_scopeId}>发送目录</h3><p${_scopeId}>发送方点击<b${_scopeId}>发送目录</b>，其他步骤同上（目录暂不支持直接拖放）</p><h2${_scopeId}>二、工作原理</h2><p${_scopeId}> 本工具使用<b${_scopeId}>WebRTC</b>提供点对点数据传输，使用<b${_scopeId}>现代文件访问API</b>提供直接文件系统读写 </p><p${_scopeId}> 因此，请确保浏览器开启了<b${_scopeId}>WebRTC</b>功能，<b${_scopeId}>现代文件访问API</b>可选，这个不可用将导致传输<b${_scopeId}>文件大小限制</b>以及<b${_scopeId}>不可接收目录</b></p><p${_scopeId}><b${_scopeId}>WebRTC</b>会遍历所有可行的网络，自动选择最优线路，如果收发双方在<b${_scopeId}>同一局域网</b>，将自动走局域网传输，<b${_scopeId}>不会消耗外部流量</b></p><h2${_scopeId}>三、注意事项</h2><p${_scopeId}> 1. 由于<b${_scopeId}>点对点连接</b>一般需要进行NAT网络穿透，对于复杂的网络环境如开启代理的情况下，可能导致<b${_scopeId}>点对点连接</b>失败，请切换网络或关闭代理再重试 </p><p${_scopeId}> 2. 点对点加密传输能保证文件数据的安全，但可能向对方泄漏你的<b${_scopeId}>出口IP地址</b>，大部分情况下这是一个动态的<b${_scopeId}>NAT出口地址</b>，因此不用担心，你可以在下方看到你当前相对于本站的出口IP地址。<b${_scopeId}>如果您觉得这有风险，请暂停使用本工具</b></p><h2${_scopeId}>四、隐私声明</h2><h3${_scopeId}>1. 信息收集</h3><p${_scopeId}><b${_scopeId}>我们不会收集或存储您的任何个人信息或文件。</b>您在使用我们的工具时，所有文件均通过点对点加密技术直接传输，确保您的数据在传输过程中保持私密和安全。 </p><h3${_scopeId}>2. 文件存储</h3><p${_scopeId}> 我们的工具不会暂存用户的文件。所有传输的文件仅在用户之间直接传递，文件数据不会经过我们的系统。 </p><h3${_scopeId}>3. 数据安全</h3><p${_scopeId}> 我们采用先进的加密技术来保护您的文件在传输过程中的安全性。您的文件在传输过程中将被加密，确保只有您和接收方能够访问。 </p><h3${_scopeId}>4. 用户责任</h3><p${_scopeId}> 请确保您在使用我们的工具时遵循相关法律法规，并对您传输的文件内容负责。我们不对用户传输的文件内容承担任何责任。 </p><h3${_scopeId}>5. 隐私政策的变更</h3><p${_scopeId}> 我们可能会不时更新本隐私声明。任何更改将在本页面上发布，建议您定期查看以了解最新信息。 </p></article>`);
						else _push(`<article class="post"${_scopeId}><p${_scopeId}> Welcome to <b class="underline"${_scopeId}>FastSend</b>, a web tool for securely transferring files using browser <code${_scopeId}>\`peer-to-peer\`</code> encryption. </p><p${_scopeId}> Your file data will not pass through third-party servers, ensuring privacy and security. Accordingly, the sender needs to remain online during the transfer. </p><h2${_scopeId}>I. Quick Start</h2><h3${_scopeId}>Send a Single File</h3><p${_scopeId}> 1. The sender clicks <b${_scopeId}>Send File</b> to obtain the <b${_scopeId}>Pickup Code</b> (files can also be dragged and dropped into the sending area). </p><p${_scopeId}> 2. The receiver enters the <b${_scopeId}>Pickup Code</b> to start peer-to-peer pairing, and waits for the sender to confirm after successful pairing. </p><p${_scopeId}> 3. The sender clicks <b${_scopeId}>Confirm</b> to continue the transfer (the sender can open their profile picture to set automatic confirmation). </p><p${_scopeId}> 4. The receiver clicks <b${_scopeId}>Receive</b>, selects the save path, and then starts the transfer (if the browser does not support direct access to the file system, data will temporarily reside in memory, triggering a download after the transfer is complete). </p><h3${_scopeId}>Send a Directory</h3><p${_scopeId}> The sender clicks <b${_scopeId}>Send Directory</b>, and the other steps are the same (directories do not currently support direct drag and drop). </p><h2${_scopeId}>II. How It Works</h2><p${_scopeId}> This tool uses <b${_scopeId}>WebRTC</b> to provide peer-to-peer data transfer and utilizes <b${_scopeId}>Modern File Access API</b> for direct file system read and write. </p><p${_scopeId}> Therefore, please ensure that the browser has <b${_scopeId}>WebRTC</b> enabled. The <b${_scopeId}>Modern File Access API</b> is optional; if unavailable, it will result in <b${_scopeId}>file size limitations</b> and <b${_scopeId}>inability to receive directories</b>. </p><p${_scopeId}><b${_scopeId}>WebRTC</b> will traverse all available networks and automatically select the optimal route. If both the sender and receiver are on the <b${_scopeId}>same local area network</b>, it will automatically use local network transfer, <b${_scopeId}>which will not consume external bandwidth</b>. </p><h2${_scopeId}>III. Precautions</h2><p${_scopeId}> 1. Since <b${_scopeId}>peer-to-peer connections</b> generally require NAT traversal, in complex network environments such as when using a proxy, it may lead to <b${_scopeId}>peer-to-peer connection</b> failures. Please switch networks or disable the proxy and try again. </p><p${_scopeId}> 2. Peer-to-peer encrypted transfer ensures the security of file data, but it may leak your <b${_scopeId}>outbound IP address</b> to the other party. In most cases, this is a dynamic <b${_scopeId}>NAT outbound address</b>, so there is no need to worry. You can see your current outbound IP address relative to this site below. <b${_scopeId}>If you feel this poses a risk, please suspend the use of this tool.</b></p><h2${_scopeId}>IV. Privacy Statement</h2><h3${_scopeId}>1. Information Collection</h3><p${_scopeId}><b${_scopeId}>We do not collect or store any personal information or files from you.</b> When you use our tools, all files are transmitted directly through peer-to-peer encryption technology, ensuring that your data remains private and secure during transmission. </p><h3${_scopeId}>2. File Storage</h3><p${_scopeId}> Our tools do not temporarily store users&#39; files. All transmitted files are passed directly between users, and file data does not go through our system. </p><h3${_scopeId}>3. Data Security</h3><p${_scopeId}> We use advanced encryption technology to protect the security of your files during transmission. Your files will be encrypted during transmission, ensuring that only you and the recipient can access them. </p><h3${_scopeId}>4. User Responsibility</h3><p${_scopeId}> Please ensure that you comply with relevant laws and regulations when using our tools and are responsible for the content of the files you transmit. We do not assume any responsibility for the content of files transmitted by users. </p><h3${_scopeId}>5. Changes to the Privacy Policy</h3><p${_scopeId}> We may update this privacy statement from time to time. Any changes will be posted on this page, and we recommend that you check regularly for the latest information. </p></article>`);
						_push(ssrRenderComponent(_component_Divider, null, null, _parent, _scopeId));
						if (unref(locale) === "zh") _push(`<div class="text-center tracking-wider"${_scopeId}><p class="text-xs"${_scopeId}>您当前的IP地址为</p><p class="my-1"${_scopeId}>${ssrInterpolate(unref(curIP))}</p><p class="text-xs"${_scopeId}>（相对于本站）</p></div>`);
						else _push(`<div class="text-center tracking-wider"${_scopeId}><p class="text-xs"${_scopeId}>Your current IP address is</p><p class="my-1"${_scopeId}>${ssrInterpolate(unref(curIP))}</p><p class="text-xs"${_scopeId}>（relative to this site）</p></div>`);
					} else return [
						unref(locale) === "zh" ? (openBlock(), createBlock("article", {
							key: 0,
							class: "post"
						}, [
							createVNode("p", null, [
								createTextVNode(" 欢迎使用"),
								createVNode("b", { class: "underline" }, "FastSend"),
								createTextVNode("，这是一个使用浏览器"),
								createVNode("code", null, "`点对点`"),
								createTextVNode("加密传输文件的网页工具 ")
							]),
							createVNode("p", null, " 你的文件数据不会经过第三方服务器，保证隐私安全，相应的，需要发送方在传输过程中保持在线 "),
							createVNode("h2", null, "一、快速上手"),
							createVNode("h3", null, "发送单个文件"),
							createVNode("p", null, [
								createTextVNode("1. 发送方点击"),
								createVNode("b", null, "发送文件"),
								createTextVNode("，获取文件"),
								createVNode("b", null, "取件码"),
								createTextVNode("（也可将文件拖放到发送区域）")
							]),
							createVNode("p", null, [
								createTextVNode("2. 接收方输入"),
								createVNode("b", null, "取件码"),
								createTextVNode("开始点对点配对，配对成功后等待发送方确认")
							]),
							createVNode("p", null, [
								createTextVNode("3. 发送方点击"),
								createVNode("b", null, "确认"),
								createTextVNode("继续传输（可点开头像设置自动确认）")
							]),
							createVNode("p", null, [
								createTextVNode(" 4. 接收方点击"),
								createVNode("b", null, "接收"),
								createTextVNode("，选择保存路径，然后开始传输（如果浏览器不支持直接访问文件系统，数据将暂存在内存中，传输完毕后触发下载） ")
							]),
							createVNode("h3", null, "发送目录"),
							createVNode("p", null, [
								createTextVNode("发送方点击"),
								createVNode("b", null, "发送目录"),
								createTextVNode("，其他步骤同上（目录暂不支持直接拖放）")
							]),
							createVNode("h2", null, "二、工作原理"),
							createVNode("p", null, [
								createTextVNode(" 本工具使用"),
								createVNode("b", null, "WebRTC"),
								createTextVNode("提供点对点数据传输，使用"),
								createVNode("b", null, "现代文件访问API"),
								createTextVNode("提供直接文件系统读写 ")
							]),
							createVNode("p", null, [
								createTextVNode(" 因此，请确保浏览器开启了"),
								createVNode("b", null, "WebRTC"),
								createTextVNode("功能，"),
								createVNode("b", null, "现代文件访问API"),
								createTextVNode("可选，这个不可用将导致传输"),
								createVNode("b", null, "文件大小限制"),
								createTextVNode("以及"),
								createVNode("b", null, "不可接收目录")
							]),
							createVNode("p", null, [
								createVNode("b", null, "WebRTC"),
								createTextVNode("会遍历所有可行的网络，自动选择最优线路，如果收发双方在"),
								createVNode("b", null, "同一局域网"),
								createTextVNode("，将自动走局域网传输，"),
								createVNode("b", null, "不会消耗外部流量")
							]),
							createVNode("h2", null, "三、注意事项"),
							createVNode("p", null, [
								createTextVNode(" 1. 由于"),
								createVNode("b", null, "点对点连接"),
								createTextVNode("一般需要进行NAT网络穿透，对于复杂的网络环境如开启代理的情况下，可能导致"),
								createVNode("b", null, "点对点连接"),
								createTextVNode("失败，请切换网络或关闭代理再重试 ")
							]),
							createVNode("p", null, [
								createTextVNode(" 2. 点对点加密传输能保证文件数据的安全，但可能向对方泄漏你的"),
								createVNode("b", null, "出口IP地址"),
								createTextVNode("，大部分情况下这是一个动态的"),
								createVNode("b", null, "NAT出口地址"),
								createTextVNode("，因此不用担心，你可以在下方看到你当前相对于本站的出口IP地址。"),
								createVNode("b", null, "如果您觉得这有风险，请暂停使用本工具")
							]),
							createVNode("h2", null, "四、隐私声明"),
							createVNode("h3", null, "1. 信息收集"),
							createVNode("p", null, [createVNode("b", null, "我们不会收集或存储您的任何个人信息或文件。"), createTextVNode("您在使用我们的工具时，所有文件均通过点对点加密技术直接传输，确保您的数据在传输过程中保持私密和安全。 ")]),
							createVNode("h3", null, "2. 文件存储"),
							createVNode("p", null, " 我们的工具不会暂存用户的文件。所有传输的文件仅在用户之间直接传递，文件数据不会经过我们的系统。 "),
							createVNode("h3", null, "3. 数据安全"),
							createVNode("p", null, " 我们采用先进的加密技术来保护您的文件在传输过程中的安全性。您的文件在传输过程中将被加密，确保只有您和接收方能够访问。 "),
							createVNode("h3", null, "4. 用户责任"),
							createVNode("p", null, " 请确保您在使用我们的工具时遵循相关法律法规，并对您传输的文件内容负责。我们不对用户传输的文件内容承担任何责任。 "),
							createVNode("h3", null, "5. 隐私政策的变更"),
							createVNode("p", null, " 我们可能会不时更新本隐私声明。任何更改将在本页面上发布，建议您定期查看以了解最新信息。 ")
						])) : (openBlock(), createBlock("article", {
							key: 1,
							class: "post"
						}, [
							createVNode("p", null, [
								createTextVNode(" Welcome to "),
								createVNode("b", { class: "underline" }, "FastSend"),
								createTextVNode(", a web tool for securely transferring files using browser "),
								createVNode("code", null, "`peer-to-peer`"),
								createTextVNode(" encryption. ")
							]),
							createVNode("p", null, " Your file data will not pass through third-party servers, ensuring privacy and security. Accordingly, the sender needs to remain online during the transfer. "),
							createVNode("h2", null, "I. Quick Start"),
							createVNode("h3", null, "Send a Single File"),
							createVNode("p", null, [
								createTextVNode(" 1. The sender clicks "),
								createVNode("b", null, "Send File"),
								createTextVNode(" to obtain the "),
								createVNode("b", null, "Pickup Code"),
								createTextVNode(" (files can also be dragged and dropped into the sending area). ")
							]),
							createVNode("p", null, [
								createTextVNode(" 2. The receiver enters the "),
								createVNode("b", null, "Pickup Code"),
								createTextVNode(" to start peer-to-peer pairing, and waits for the sender to confirm after successful pairing. ")
							]),
							createVNode("p", null, [
								createTextVNode(" 3. The sender clicks "),
								createVNode("b", null, "Confirm"),
								createTextVNode(" to continue the transfer (the sender can open their profile picture to set automatic confirmation). ")
							]),
							createVNode("p", null, [
								createTextVNode(" 4. The receiver clicks "),
								createVNode("b", null, "Receive"),
								createTextVNode(", selects the save path, and then starts the transfer (if the browser does not support direct access to the file system, data will temporarily reside in memory, triggering a download after the transfer is complete). ")
							]),
							createVNode("h3", null, "Send a Directory"),
							createVNode("p", null, [
								createTextVNode(" The sender clicks "),
								createVNode("b", null, "Send Directory"),
								createTextVNode(", and the other steps are the same (directories do not currently support direct drag and drop). ")
							]),
							createVNode("h2", null, "II. How It Works"),
							createVNode("p", null, [
								createTextVNode(" This tool uses "),
								createVNode("b", null, "WebRTC"),
								createTextVNode(" to provide peer-to-peer data transfer and utilizes "),
								createVNode("b", null, "Modern File Access API"),
								createTextVNode(" for direct file system read and write. ")
							]),
							createVNode("p", null, [
								createTextVNode(" Therefore, please ensure that the browser has "),
								createVNode("b", null, "WebRTC"),
								createTextVNode(" enabled. The "),
								createVNode("b", null, "Modern File Access API"),
								createTextVNode(" is optional; if unavailable, it will result in "),
								createVNode("b", null, "file size limitations"),
								createTextVNode(" and "),
								createVNode("b", null, "inability to receive directories"),
								createTextVNode(". ")
							]),
							createVNode("p", null, [
								createVNode("b", null, "WebRTC"),
								createTextVNode(" will traverse all available networks and automatically select the optimal route. If both the sender and receiver are on the "),
								createVNode("b", null, "same local area network"),
								createTextVNode(", it will automatically use local network transfer, "),
								createVNode("b", null, "which will not consume external bandwidth"),
								createTextVNode(". ")
							]),
							createVNode("h2", null, "III. Precautions"),
							createVNode("p", null, [
								createTextVNode(" 1. Since "),
								createVNode("b", null, "peer-to-peer connections"),
								createTextVNode(" generally require NAT traversal, in complex network environments such as when using a proxy, it may lead to "),
								createVNode("b", null, "peer-to-peer connection"),
								createTextVNode(" failures. Please switch networks or disable the proxy and try again. ")
							]),
							createVNode("p", null, [
								createTextVNode(" 2. Peer-to-peer encrypted transfer ensures the security of file data, but it may leak your "),
								createVNode("b", null, "outbound IP address"),
								createTextVNode(" to the other party. In most cases, this is a dynamic "),
								createVNode("b", null, "NAT outbound address"),
								createTextVNode(", so there is no need to worry. You can see your current outbound IP address relative to this site below. "),
								createVNode("b", null, "If you feel this poses a risk, please suspend the use of this tool.")
							]),
							createVNode("h2", null, "IV. Privacy Statement"),
							createVNode("h3", null, "1. Information Collection"),
							createVNode("p", null, [createVNode("b", null, "We do not collect or store any personal information or files from you."), createTextVNode(" When you use our tools, all files are transmitted directly through peer-to-peer encryption technology, ensuring that your data remains private and secure during transmission. ")]),
							createVNode("h3", null, "2. File Storage"),
							createVNode("p", null, " Our tools do not temporarily store users' files. All transmitted files are passed directly between users, and file data does not go through our system. "),
							createVNode("h3", null, "3. Data Security"),
							createVNode("p", null, " We use advanced encryption technology to protect the security of your files during transmission. Your files will be encrypted during transmission, ensuring that only you and the recipient can access them. "),
							createVNode("h3", null, "4. User Responsibility"),
							createVNode("p", null, " Please ensure that you comply with relevant laws and regulations when using our tools and are responsible for the content of the files you transmit. We do not assume any responsibility for the content of files transmitted by users. "),
							createVNode("h3", null, "5. Changes to the Privacy Policy"),
							createVNode("p", null, " We may update this privacy statement from time to time. Any changes will be posted on this page, and we recommend that you check regularly for the latest information. ")
						])),
						createVNode(_component_Divider),
						unref(locale) === "zh" ? (openBlock(), createBlock("div", {
							key: 2,
							class: "text-center tracking-wider"
						}, [
							createVNode("p", { class: "text-xs" }, "您当前的IP地址为"),
							createVNode("p", { class: "my-1" }, toDisplayString(unref(curIP)), 1),
							createVNode("p", { class: "text-xs" }, "（相对于本站）")
						])) : (openBlock(), createBlock("div", {
							key: 3,
							class: "text-center tracking-wider"
						}, [
							createVNode("p", { class: "text-xs" }, "Your current IP address is"),
							createVNode("p", { class: "my-1" }, toDisplayString(unref(curIP)), 1),
							createVNode("p", { class: "text-xs" }, "（relative to this site）")
						]))
					];
				}),
				_: 1
			}, _parent));
			_push(`</div>`);
		};
	}
});
//#endregion
//#region app/components/DocPanel.vue
var _sfc_setup$3 = DocPanel_vue_vue_type_script_setup_true_lang_default.setup;
DocPanel_vue_vue_type_script_setup_true_lang_default.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/DocPanel.vue");
	return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
var DocPanel_default = Object.assign(DocPanel_vue_vue_type_script_setup_true_lang_default, { __name: "DocPanel" });
//#endregion
//#region node_modules/primevue/scrolltop/style/index.mjs
var ScrollTopStyle = BaseStyle.extend({
	name: "scrolltop",
	style: style$1,
	classes: {
		root: function root(_ref) {
			return ["p-scrolltop", { "p-scrolltop-sticky": _ref.props.target !== "window" }];
		},
		icon: "p-scrolltop-icon"
	}
});
//#endregion
//#region node_modules/primevue/scrolltop/index.mjs
var scrolltop_exports = /* @__PURE__ */ __exportAll({ default: () => script$7 });
var script$7 = {
	name: "ScrollTop",
	"extends": {
		name: "BaseScrollTop",
		"extends": script$j,
		props: {
			target: {
				type: String,
				"default": "window"
			},
			threshold: {
				type: Number,
				"default": 400
			},
			icon: {
				type: String,
				"default": void 0
			},
			behavior: {
				type: String,
				"default": "smooth"
			},
			buttonProps: {
				type: Object,
				"default": function _default() {
					return { rounded: true };
				}
			}
		},
		style: ScrollTopStyle,
		provide: function provide() {
			return {
				$pcScrollTop: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false,
	scrollListener: null,
	container: null,
	data: function data() {
		return { visible: false };
	},
	mounted: function mounted() {
		if (this.target === "window") this.bindDocumentScrollListener();
		else if (this.target === "parent") this.bindParentScrollListener();
	},
	beforeUnmount: function beforeUnmount() {
		if (this.target === "window") this.unbindDocumentScrollListener();
		else if (this.target === "parent") this.unbindParentScrollListener();
		if (this.container) {
			x.clear(this.container);
			this.overlay = null;
		}
	},
	methods: {
		onClick: function onClick() {
			(this.target === "window" ? void 0 : this.$el.parentElement).scroll({
				top: 0,
				behavior: this.behavior
			});
		},
		checkVisibility: function checkVisibility(scrollY) {
			if (scrollY > this.threshold) this.visible = true;
			else this.visible = false;
		},
		bindParentScrollListener: function bindParentScrollListener() {
			var _this = this;
			this.scrollListener = function() {
				_this.checkVisibility(_this.$el.parentElement.scrollTop);
			};
			this.$el.parentElement.addEventListener("scroll", this.scrollListener);
		},
		bindDocumentScrollListener: function bindDocumentScrollListener() {
			var _this2 = this;
			this.scrollListener = function() {
				_this2.checkVisibility($());
			};
			(void 0).addEventListener("scroll", this.scrollListener);
		},
		unbindParentScrollListener: function unbindParentScrollListener() {
			if (this.scrollListener) {
				this.$el.parentElement.removeEventListener("scroll", this.scrollListener);
				this.scrollListener = null;
			}
		},
		unbindDocumentScrollListener: function unbindDocumentScrollListener() {
			if (this.scrollListener) {
				(void 0).removeEventListener("scroll", this.scrollListener);
				this.scrollListener = null;
			}
		},
		onEnter: function onEnter(el) {
			x.set("overlay", el, this.$primevue.config.zIndex.overlay);
		},
		onAfterLeave: function onAfterLeave(el) {
			x.clear(el);
		},
		containerRef: function containerRef(el) {
			this.container = el ? el.$el : void 0;
		}
	},
	computed: { scrollTopAriaLabel: function scrollTopAriaLabel() {
		return this.$primevue.config.locale.aria ? this.$primevue.config.locale.aria.scrollTop : void 0;
	} },
	components: {
		ChevronUpIcon: script$a,
		Button: script$d
	}
};
function render$6(_ctx, _cache, $props, $setup, $data, $options) {
	var _component_Button = resolveComponent("Button");
	return openBlock(), createBlock(Transition, mergeProps({
		name: "p-scrolltop",
		appear: "",
		onEnter: $options.onEnter,
		onAfterLeave: $options.onAfterLeave
	}, _ctx.ptm("transition")), {
		"default": withCtx(function() {
			return [$data.visible ? (openBlock(), createBlock(_component_Button, mergeProps({
				key: 0,
				ref: $options.containerRef,
				"class": _ctx.cx("root"),
				onClick: $options.onClick,
				"aria-label": $options.scrollTopAriaLabel,
				unstyled: _ctx.unstyled
			}, _ctx.buttonProps, { pt: _ctx.ptm("root") }), {
				icon: withCtx(function(slotProps) {
					return [renderSlot(_ctx.$slots, "icon", { "class": normalizeClass(_ctx.cx("icon")) }, function() {
						return [(openBlock(), createBlock(resolveDynamicComponent(_ctx.icon ? "span" : "ChevronUpIcon"), mergeProps({ "class": [
							_ctx.cx("icon"),
							_ctx.icon,
							slotProps["class"]
						] }, _ctx.ptm("root")["icon"], { "data-pc-section": "icon" }), null, 16, ["class"]))];
					})];
				}),
				_: 3
			}, 16, [
				"class",
				"onClick",
				"aria-label",
				"unstyled",
				"pt"
			])) : createCommentVNode("", true)];
		}),
		_: 3
	}, 16, ["onEnter", "onAfterLeave"]);
}
script$7.render = render$6;
//#endregion
//#region node_modules/primevue/toast/style/index.mjs
function _typeof$4(o) {
	"@babel/helpers - typeof";
	return _typeof$4 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$4(o);
}
function _defineProperty$4(e, r, t) {
	return (r = _toPropertyKey$4(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$4(t) {
	var i = _toPrimitive$4(t, "string");
	return "symbol" == _typeof$4(i) ? i : i + "";
}
function _toPrimitive$4(t, r) {
	if ("object" != _typeof$4(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$4(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ToastStyle = BaseStyle.extend({
	name: "toast",
	style: style,
	classes: {
		root: function root(_ref2) {
			return ["p-toast p-component p-toast-" + _ref2.props.position];
		},
		message: function message(_ref3) {
			var props = _ref3.props;
			return ["p-toast-message", {
				"p-toast-message-info": props.message.severity === "info" || props.message.severity === void 0,
				"p-toast-message-warn": props.message.severity === "warn",
				"p-toast-message-error": props.message.severity === "error",
				"p-toast-message-success": props.message.severity === "success",
				"p-toast-message-secondary": props.message.severity === "secondary",
				"p-toast-message-contrast": props.message.severity === "contrast"
			}];
		},
		messageContent: "p-toast-message-content",
		messageIcon: function messageIcon(_ref4) {
			var props = _ref4.props;
			return ["p-toast-message-icon", _defineProperty$4(_defineProperty$4(_defineProperty$4(_defineProperty$4({}, props.infoIcon, props.message.severity === "info"), props.warnIcon, props.message.severity === "warn"), props.errorIcon, props.message.severity === "error"), props.successIcon, props.message.severity === "success")];
		},
		messageText: "p-toast-message-text",
		summary: "p-toast-summary",
		detail: "p-toast-detail",
		closeButton: "p-toast-close-button",
		closeIcon: "p-toast-close-icon"
	},
	inlineStyles: { root: function root(_ref) {
		var position = _ref.position;
		return {
			position: "fixed",
			top: position === "top-right" || position === "top-left" || position === "top-center" ? "20px" : position === "center" ? "50%" : null,
			right: (position === "top-right" || position === "bottom-right") && "20px",
			bottom: (position === "bottom-left" || position === "bottom-right" || position === "bottom-center") && "20px",
			left: position === "top-left" || position === "bottom-left" ? "20px" : position === "center" || position === "top-center" || position === "bottom-center" ? "50%" : null
		};
	} }
});
//#endregion
//#region node_modules/@primevue/icons/check/index.mjs
var script$6 = {
	name: "CheckIcon",
	"extends": script$g
};
function _toConsumableArray$4(r) {
	return _arrayWithoutHoles$4(r) || _iterableToArray$4(r) || _unsupportedIterableToArray$4(r) || _nonIterableSpread$4();
}
function _nonIterableSpread$4() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$4(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$4(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$4(r, a) : void 0;
	}
}
function _iterableToArray$4(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$4(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$4(r);
}
function _arrayLikeToArray$4(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$5(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$4(_cache[0] || (_cache[0] = [createElementVNode("path", {
		d: "M4.86199 11.5948C4.78717 11.5923 4.71366 11.5745 4.64596 11.5426C4.57826 11.5107 4.51779 11.4652 4.46827 11.4091L0.753985 7.69483C0.683167 7.64891 0.623706 7.58751 0.580092 7.51525C0.536478 7.44299 0.509851 7.36177 0.502221 7.27771C0.49459 7.19366 0.506156 7.10897 0.536046 7.03004C0.565935 6.95111 0.613367 6.88 0.674759 6.82208C0.736151 6.76416 0.8099 6.72095 0.890436 6.69571C0.970973 6.67046 1.05619 6.66385 1.13966 6.67635C1.22313 6.68886 1.30266 6.72017 1.37226 6.76792C1.44186 6.81567 1.4997 6.8786 1.54141 6.95197L4.86199 10.2503L12.6397 2.49483C12.7444 2.42694 12.8689 2.39617 12.9932 2.40745C13.1174 2.41873 13.2343 2.47141 13.3251 2.55705C13.4159 2.64268 13.4753 2.75632 13.4938 2.87973C13.5123 3.00315 13.4888 3.1292 13.4271 3.23768L5.2557 11.4091C5.20618 11.4652 5.14571 11.5107 5.07801 11.5426C5.01031 11.5745 4.9368 11.5923 4.86199 11.5948Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$6.render = render$5;
//#endregion
//#region node_modules/@primevue/icons/exclamationtriangle/index.mjs
var script$5 = {
	name: "ExclamationTriangleIcon",
	"extends": script$g
};
function _toConsumableArray$3(r) {
	return _arrayWithoutHoles$3(r) || _iterableToArray$3(r) || _unsupportedIterableToArray$3(r) || _nonIterableSpread$3();
}
function _nonIterableSpread$3() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$3(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$3(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$3(r, a) : void 0;
	}
}
function _iterableToArray$3(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$3(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$3(r);
}
function _arrayLikeToArray$3(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$4(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$3(_cache[0] || (_cache[0] = [
		createElementVNode("path", {
			d: "M13.4018 13.1893H0.598161C0.49329 13.189 0.390283 13.1615 0.299143 13.1097C0.208003 13.0578 0.131826 12.9832 0.0780112 12.8932C0.0268539 12.8015 0 12.6982 0 12.5931C0 12.4881 0.0268539 12.3848 0.0780112 12.293L6.47985 1.08982C6.53679 1.00399 6.61408 0.933574 6.70484 0.884867C6.7956 0.836159 6.897 0.810669 7 0.810669C7.103 0.810669 7.2044 0.836159 7.29516 0.884867C7.38592 0.933574 7.46321 1.00399 7.52015 1.08982L13.922 12.293C13.9731 12.3848 14 12.4881 14 12.5931C14 12.6982 13.9731 12.8015 13.922 12.8932C13.8682 12.9832 13.792 13.0578 13.7009 13.1097C13.6097 13.1615 13.5067 13.189 13.4018 13.1893ZM1.63046 11.989H12.3695L7 2.59425L1.63046 11.989Z",
			fill: "currentColor"
		}, null, -1),
		createElementVNode("path", {
			d: "M6.99996 8.78801C6.84143 8.78594 6.68997 8.72204 6.57787 8.60993C6.46576 8.49782 6.40186 8.34637 6.39979 8.18784V5.38703C6.39979 5.22786 6.46302 5.0752 6.57557 4.96265C6.68813 4.85009 6.84078 4.78686 6.99996 4.78686C7.15914 4.78686 7.31179 4.85009 7.42435 4.96265C7.5369 5.0752 7.60013 5.22786 7.60013 5.38703V8.18784C7.59806 8.34637 7.53416 8.49782 7.42205 8.60993C7.30995 8.72204 7.15849 8.78594 6.99996 8.78801Z",
			fill: "currentColor"
		}, null, -1),
		createElementVNode("path", {
			d: "M6.99996 11.1887C6.84143 11.1866 6.68997 11.1227 6.57787 11.0106C6.46576 10.8985 6.40186 10.7471 6.39979 10.5885V10.1884C6.39979 10.0292 6.46302 9.87658 6.57557 9.76403C6.68813 9.65147 6.84078 9.58824 6.99996 9.58824C7.15914 9.58824 7.31179 9.65147 7.42435 9.76403C7.5369 9.87658 7.60013 10.0292 7.60013 10.1884V10.5885C7.59806 10.7471 7.53416 10.8985 7.42205 11.0106C7.30995 11.1227 7.15849 11.1866 6.99996 11.1887Z",
			fill: "currentColor"
		}, null, -1)
	])), 16);
}
script$5.render = render$4;
//#endregion
//#region node_modules/@primevue/icons/infocircle/index.mjs
var script$4 = {
	name: "InfoCircleIcon",
	"extends": script$g
};
function _toConsumableArray$2(r) {
	return _arrayWithoutHoles$2(r) || _iterableToArray$2(r) || _unsupportedIterableToArray$2(r) || _nonIterableSpread$2();
}
function _nonIterableSpread$2() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$2(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$2(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$2(r, a) : void 0;
	}
}
function _iterableToArray$2(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$2(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$2(r);
}
function _arrayLikeToArray$2(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$3(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$2(_cache[0] || (_cache[0] = [createElementVNode("path", {
		"fill-rule": "evenodd",
		"clip-rule": "evenodd",
		d: "M3.11101 12.8203C4.26215 13.5895 5.61553 14 7 14C8.85652 14 10.637 13.2625 11.9497 11.9497C13.2625 10.637 14 8.85652 14 7C14 5.61553 13.5895 4.26215 12.8203 3.11101C12.0511 1.95987 10.9579 1.06266 9.67879 0.532846C8.3997 0.00303296 6.99224 -0.13559 5.63437 0.134506C4.2765 0.404603 3.02922 1.07129 2.05026 2.05026C1.07129 3.02922 0.404603 4.2765 0.134506 5.63437C-0.13559 6.99224 0.00303296 8.3997 0.532846 9.67879C1.06266 10.9579 1.95987 12.0511 3.11101 12.8203ZM3.75918 2.14976C4.71846 1.50879 5.84628 1.16667 7 1.16667C8.5471 1.16667 10.0308 1.78125 11.1248 2.87521C12.2188 3.96918 12.8333 5.45291 12.8333 7C12.8333 8.15373 12.4912 9.28154 11.8502 10.2408C11.2093 11.2001 10.2982 11.9478 9.23232 12.3893C8.16642 12.8308 6.99353 12.9463 5.86198 12.7212C4.73042 12.4962 3.69102 11.9406 2.87521 11.1248C2.05941 10.309 1.50384 9.26958 1.27876 8.13803C1.05367 7.00647 1.16919 5.83358 1.61071 4.76768C2.05222 3.70178 2.79989 2.79074 3.75918 2.14976ZM7.00002 4.8611C6.84594 4.85908 6.69873 4.79698 6.58977 4.68801C6.48081 4.57905 6.4187 4.43185 6.41669 4.27776V3.88888C6.41669 3.73417 6.47815 3.58579 6.58754 3.4764C6.69694 3.367 6.84531 3.30554 7.00002 3.30554C7.15473 3.30554 7.3031 3.367 7.4125 3.4764C7.52189 3.58579 7.58335 3.73417 7.58335 3.88888V4.27776C7.58134 4.43185 7.51923 4.57905 7.41027 4.68801C7.30131 4.79698 7.1541 4.85908 7.00002 4.8611ZM7.00002 10.6945C6.84594 10.6925 6.69873 10.6304 6.58977 10.5214C6.48081 10.4124 6.4187 10.2652 6.41669 10.1111V6.22225C6.41669 6.06754 6.47815 5.91917 6.58754 5.80977C6.69694 5.70037 6.84531 5.63892 7.00002 5.63892C7.15473 5.63892 7.3031 5.70037 7.4125 5.80977C7.52189 5.91917 7.58335 6.06754 7.58335 6.22225V10.1111C7.58134 10.2652 7.51923 10.4124 7.41027 10.5214C7.30131 10.6304 7.1541 10.6925 7.00002 10.6945Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$4.render = render$3;
//#endregion
//#region node_modules/@primevue/icons/timescircle/index.mjs
var script$3 = {
	name: "TimesCircleIcon",
	"extends": script$g
};
function _toConsumableArray$1(r) {
	return _arrayWithoutHoles$1(r) || _iterableToArray$1(r) || _unsupportedIterableToArray$1(r) || _nonIterableSpread$1();
}
function _nonIterableSpread$1() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$1(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray$1(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray$1(r, a) : void 0;
	}
}
function _iterableToArray$1(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles$1(r) {
	if (Array.isArray(r)) return _arrayLikeToArray$1(r);
}
function _arrayLikeToArray$1(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function render$2(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("svg", mergeProps({
		width: "14",
		height: "14",
		viewBox: "0 0 14 14",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg"
	}, _ctx.pti()), _toConsumableArray$1(_cache[0] || (_cache[0] = [createElementVNode("path", {
		"fill-rule": "evenodd",
		"clip-rule": "evenodd",
		d: "M7 14C5.61553 14 4.26215 13.5895 3.11101 12.8203C1.95987 12.0511 1.06266 10.9579 0.532846 9.67879C0.00303296 8.3997 -0.13559 6.99224 0.134506 5.63437C0.404603 4.2765 1.07129 3.02922 2.05026 2.05026C3.02922 1.07129 4.2765 0.404603 5.63437 0.134506C6.99224 -0.13559 8.3997 0.00303296 9.67879 0.532846C10.9579 1.06266 12.0511 1.95987 12.8203 3.11101C13.5895 4.26215 14 5.61553 14 7C14 8.85652 13.2625 10.637 11.9497 11.9497C10.637 13.2625 8.85652 14 7 14ZM7 1.16667C5.84628 1.16667 4.71846 1.50879 3.75918 2.14976C2.79989 2.79074 2.05222 3.70178 1.61071 4.76768C1.16919 5.83358 1.05367 7.00647 1.27876 8.13803C1.50384 9.26958 2.05941 10.309 2.87521 11.1248C3.69102 11.9406 4.73042 12.4962 5.86198 12.7212C6.99353 12.9463 8.16642 12.8308 9.23232 12.3893C10.2982 11.9478 11.2093 11.2001 11.8502 10.2408C12.4912 9.28154 12.8333 8.15373 12.8333 7C12.8333 5.45291 12.2188 3.96918 11.1248 2.87521C10.0308 1.78125 8.5471 1.16667 7 1.16667ZM4.66662 9.91668C4.58998 9.91704 4.51404 9.90209 4.44325 9.87271C4.37246 9.84333 4.30826 9.8001 4.2544 9.74557C4.14516 9.6362 4.0838 9.48793 4.0838 9.33335C4.0838 9.17876 4.14516 9.0305 4.2544 8.92113L6.17553 7L4.25443 5.07891C4.15139 4.96832 4.09529 4.82207 4.09796 4.67094C4.10063 4.51982 4.16185 4.37563 4.26872 4.26876C4.3756 4.16188 4.51979 4.10066 4.67091 4.09799C4.82204 4.09532 4.96829 4.15142 5.07887 4.25446L6.99997 6.17556L8.92106 4.25446C9.03164 4.15142 9.1779 4.09532 9.32903 4.09799C9.48015 4.10066 9.62434 4.16188 9.73121 4.26876C9.83809 4.37563 9.89931 4.51982 9.90198 4.67094C9.90464 4.82207 9.84855 4.96832 9.74551 5.07891L7.82441 7L9.74554 8.92113C9.85478 9.0305 9.91614 9.17876 9.91614 9.33335C9.91614 9.48793 9.85478 9.6362 9.74554 9.74557C9.69168 9.8001 9.62748 9.84333 9.55669 9.87271C9.4859 9.90209 9.40996 9.91704 9.33332 9.91668C9.25668 9.91704 9.18073 9.90209 9.10995 9.87271C9.03916 9.84333 8.97495 9.8001 8.9211 9.74557L6.99997 7.82444L5.07884 9.74557C5.02499 9.8001 4.96078 9.84333 4.88999 9.87271C4.81921 9.90209 4.74326 9.91704 4.66662 9.91668Z",
		fill: "currentColor"
	}, null, -1)])), 16);
}
script$3.render = render$2;
//#endregion
//#region node_modules/primevue/toast/index.mjs
var toast_exports = /* @__PURE__ */ __exportAll({ default: () => script });
var script$2 = {
	name: "BaseToast",
	"extends": script$j,
	props: {
		group: {
			type: String,
			"default": null
		},
		position: {
			type: String,
			"default": "top-right"
		},
		autoZIndex: {
			type: Boolean,
			"default": true
		},
		baseZIndex: {
			type: Number,
			"default": 0
		},
		breakpoints: {
			type: Object,
			"default": null
		},
		closeIcon: {
			type: String,
			"default": void 0
		},
		infoIcon: {
			type: String,
			"default": void 0
		},
		warnIcon: {
			type: String,
			"default": void 0
		},
		errorIcon: {
			type: String,
			"default": void 0
		},
		successIcon: {
			type: String,
			"default": void 0
		},
		closeButtonProps: {
			type: null,
			"default": null
		},
		onMouseEnter: {
			type: Function,
			"default": void 0
		},
		onMouseLeave: {
			type: Function,
			"default": void 0
		},
		onClick: {
			type: Function,
			"default": void 0
		}
	},
	style: ToastStyle,
	provide: function provide() {
		return {
			$pcToast: this,
			$parentInstance: this
		};
	}
};
function _typeof$3(o) {
	"@babel/helpers - typeof";
	return _typeof$3 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$3(o);
}
function _defineProperty$3(e, r, t) {
	return (r = _toPropertyKey$3(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$3(t) {
	var i = _toPrimitive$3(t, "string");
	return "symbol" == _typeof$3(i) ? i : i + "";
}
function _toPrimitive$3(t, r) {
	if ("object" != _typeof$3(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$3(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script$1 = {
	name: "ToastMessage",
	hostName: "Toast",
	"extends": script$j,
	emits: ["close"],
	closeTimeout: null,
	createdAt: null,
	lifeRemaining: null,
	props: {
		message: {
			type: null,
			"default": null
		},
		templates: {
			type: Object,
			"default": null
		},
		closeIcon: {
			type: String,
			"default": null
		},
		infoIcon: {
			type: String,
			"default": null
		},
		warnIcon: {
			type: String,
			"default": null
		},
		errorIcon: {
			type: String,
			"default": null
		},
		successIcon: {
			type: String,
			"default": null
		},
		closeButtonProps: {
			type: null,
			"default": null
		},
		onMouseEnter: {
			type: Function,
			"default": void 0
		},
		onMouseLeave: {
			type: Function,
			"default": void 0
		},
		onClick: {
			type: Function,
			"default": void 0
		}
	},
	mounted: function mounted() {
		if (this.message.life) {
			this.lifeRemaining = this.message.life;
			this.startTimeout();
		}
	},
	beforeUnmount: function beforeUnmount() {
		this.clearCloseTimeout();
	},
	methods: {
		startTimeout: function startTimeout() {
			var _this = this;
			this.createdAt = (/* @__PURE__ */ new Date()).valueOf();
			this.closeTimeout = setTimeout(function() {
				_this.close({
					message: _this.message,
					type: "life-end"
				});
			}, this.lifeRemaining);
		},
		close: function close(params) {
			this.$emit("close", params);
		},
		onCloseClick: function onCloseClick() {
			this.clearCloseTimeout();
			this.close({
				message: this.message,
				type: "close"
			});
		},
		clearCloseTimeout: function clearCloseTimeout() {
			if (this.closeTimeout) {
				clearTimeout(this.closeTimeout);
				this.closeTimeout = null;
			}
		},
		onMessageClick: function onMessageClick(event) {
			var _this$onClick;
			(_this$onClick = this.onClick) === null || _this$onClick === void 0 || _this$onClick.call(this, {
				originalEvent: event,
				message: this.message
			});
		},
		handleMouseEnter: function handleMouseEnter(event) {
			if (this.onMouseEnter) {
				this.onMouseEnter({
					originalEvent: event,
					message: this.message
				});
				if (event.defaultPrevented) return;
				if (this.message.life) {
					this.lifeRemaining = this.createdAt + this.lifeRemaining - (/* @__PURE__ */ new Date()).valueOf();
					this.createdAt = null;
					this.clearCloseTimeout();
				}
			}
		},
		handleMouseLeave: function handleMouseLeave(event) {
			if (this.onMouseLeave) {
				this.onMouseLeave({
					originalEvent: event,
					message: this.message
				});
				if (event.defaultPrevented) return;
				if (this.message.life) this.startTimeout();
			}
		}
	},
	computed: {
		iconComponent: function iconComponent() {
			return {
				info: !this.infoIcon && script$4,
				success: !this.successIcon && script$6,
				warn: !this.warnIcon && script$5,
				error: !this.errorIcon && script$3
			}[this.message.severity];
		},
		closeAriaLabel: function closeAriaLabel() {
			return this.$primevue.config.locale.aria ? this.$primevue.config.locale.aria.close : void 0;
		},
		dataP: function dataP() {
			return cn(_defineProperty$3({}, this.message.severity, this.message.severity));
		}
	},
	components: {
		TimesIcon: script$b,
		InfoCircleIcon: script$4,
		CheckIcon: script$6,
		ExclamationTriangleIcon: script$5,
		TimesCircleIcon: script$3
	},
	directives: { ripple: Ripple }
};
function _typeof$2(o) {
	"@babel/helpers - typeof";
	return _typeof$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$2(o);
}
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), true).forEach(function(r) {
			_defineProperty$2(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$2(e, r, t) {
	return (r = _toPropertyKey$2(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$2(t) {
	var i = _toPrimitive$2(t, "string");
	return "symbol" == _typeof$2(i) ? i : i + "";
}
function _toPrimitive$2(t, r) {
	if ("object" != _typeof$2(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$2(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var _hoisted_1$1 = ["data-p"];
var _hoisted_2 = ["data-p"];
var _hoisted_3 = ["data-p"];
var _hoisted_4 = ["data-p"];
var _hoisted_5 = ["aria-label", "data-p"];
function render$1(_ctx, _cache, $props, $setup, $data, $options) {
	var _directive_ripple = resolveDirective("ripple");
	return openBlock(), createElementBlock("div", mergeProps({
		"class": [_ctx.cx("message"), $props.message.styleClass],
		role: "alert",
		"aria-live": "assertive",
		"aria-atomic": "true",
		"data-p": $options.dataP
	}, _ctx.ptm("message"), {
		onClick: _cache[1] || (_cache[1] = function() {
			return $options.onMessageClick && $options.onMessageClick.apply($options, arguments);
		}),
		onMouseenter: _cache[2] || (_cache[2] = function() {
			return $options.handleMouseEnter && $options.handleMouseEnter.apply($options, arguments);
		}),
		onMouseleave: _cache[3] || (_cache[3] = function() {
			return $options.handleMouseLeave && $options.handleMouseLeave.apply($options, arguments);
		})
	}), [$props.templates.container ? (openBlock(), createBlock(resolveDynamicComponent($props.templates.container), {
		key: 0,
		message: $props.message,
		closeCallback: $options.onCloseClick
	}, null, 8, ["message", "closeCallback"])) : (openBlock(), createElementBlock("div", mergeProps({
		key: 1,
		"class": [_ctx.cx("messageContent"), $props.message.contentStyleClass]
	}, _ctx.ptm("messageContent")), [!$props.templates.message ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [(openBlock(), createBlock(resolveDynamicComponent($props.templates.messageicon ? $props.templates.messageicon : $props.templates.icon ? $props.templates.icon : $options.iconComponent && $options.iconComponent.name ? $options.iconComponent : "span"), mergeProps({ "class": _ctx.cx("messageIcon") }, _ctx.ptm("messageIcon")), null, 16, ["class"])), createElementVNode("div", mergeProps({
		"class": _ctx.cx("messageText"),
		"data-p": $options.dataP
	}, _ctx.ptm("messageText")), [createElementVNode("span", mergeProps({
		"class": _ctx.cx("summary"),
		"data-p": $options.dataP
	}, _ctx.ptm("summary")), toDisplayString($props.message.summary), 17, _hoisted_3), $props.message.detail ? (openBlock(), createElementBlock("div", mergeProps({
		key: 0,
		"class": _ctx.cx("detail"),
		"data-p": $options.dataP
	}, _ctx.ptm("detail")), toDisplayString($props.message.detail), 17, _hoisted_4)) : createCommentVNode("", true)], 16, _hoisted_2)], 64)) : (openBlock(), createBlock(resolveDynamicComponent($props.templates.message), {
		key: 1,
		message: $props.message
	}, null, 8, ["message"])), $props.message.closable !== false ? (openBlock(), createElementBlock("div", normalizeProps(mergeProps({ key: 2 }, _ctx.ptm("buttonContainer"))), [withDirectives((openBlock(), createElementBlock("button", mergeProps({
		"class": _ctx.cx("closeButton"),
		type: "button",
		"aria-label": $options.closeAriaLabel,
		onClick: _cache[0] || (_cache[0] = function() {
			return $options.onCloseClick && $options.onCloseClick.apply($options, arguments);
		}),
		autofocus: "",
		"data-p": $options.dataP
	}, _objectSpread$1(_objectSpread$1({}, $props.closeButtonProps), _ctx.ptm("closeButton"))), [(openBlock(), createBlock(resolveDynamicComponent($props.templates.closeicon || "TimesIcon"), mergeProps({ "class": [_ctx.cx("closeIcon"), $props.closeIcon] }, _ctx.ptm("closeIcon")), null, 16, ["class"]))], 16, _hoisted_5)), [[_directive_ripple]])], 16)) : createCommentVNode("", true)], 16))], 16, _hoisted_1$1);
}
script$1.render = render$1;
function _typeof$1(o) {
	"@babel/helpers - typeof";
	return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1(o);
}
function _defineProperty$1(e, r, t) {
	return (r = _toPropertyKey$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == _typeof$1(i) ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != _typeof$1(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$1(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _toConsumableArray(r) {
	return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}
function _nonIterableSpread() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
function _iterableToArray(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles(r) {
	if (Array.isArray(r)) return _arrayLikeToArray(r);
}
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
var messageIdx = 0;
var script = {
	name: "Toast",
	"extends": script$2,
	inheritAttrs: false,
	emits: ["close", "life-end"],
	data: function data() {
		return { messages: [] };
	},
	styleElement: null,
	mounted: function mounted() {
		ToastEventBus.on("add", this.onAdd);
		ToastEventBus.on("remove", this.onRemove);
		ToastEventBus.on("remove-group", this.onRemoveGroup);
		ToastEventBus.on("remove-all-groups", this.onRemoveAllGroups);
		if (this.breakpoints) this.createStyle();
	},
	beforeUnmount: function beforeUnmount() {
		this.destroyStyle();
		if (this.$refs.container && this.autoZIndex) x.clear(this.$refs.container);
		ToastEventBus.off("add", this.onAdd);
		ToastEventBus.off("remove", this.onRemove);
		ToastEventBus.off("remove-group", this.onRemoveGroup);
		ToastEventBus.off("remove-all-groups", this.onRemoveAllGroups);
	},
	methods: {
		add: function add(message) {
			if (message.id == null) message.id = messageIdx++;
			this.messages = [].concat(_toConsumableArray(this.messages), [message]);
		},
		remove: function remove(params) {
			var index = this.messages.findIndex(function(m) {
				return m.id === params.message.id;
			});
			if (index !== -1) {
				this.messages.splice(index, 1);
				this.$emit(params.type, { message: params.message });
			}
		},
		onAdd: function onAdd(message) {
			if (this.group == message.group) this.add(message);
		},
		onRemove: function onRemove(message) {
			this.remove({
				message,
				type: "close"
			});
		},
		onRemoveGroup: function onRemoveGroup(group) {
			if (this.group === group) this.messages = [];
		},
		onRemoveAllGroups: function onRemoveAllGroups() {
			var _this = this;
			this.messages.forEach(function(message) {
				return _this.$emit("close", { message });
			});
			this.messages = [];
		},
		onEnter: function onEnter() {
			if (this.autoZIndex) x.set("modal", this.$refs.container, this.baseZIndex || this.$primevue.config.zIndex.modal);
		},
		onLeave: function onLeave() {
			var _this2 = this;
			if (this.$refs.container && this.autoZIndex && l(this.messages)) setTimeout(function() {
				x.clear(_this2.$refs.container);
			}, 200);
		},
		createStyle: function createStyle() {
			if (!this.styleElement && !this.isUnstyled) {
				var _this$$primevue;
				this.styleElement = (void 0).createElement("style");
				this.styleElement.type = "text/css";
				_t(this.styleElement, "nonce", (_this$$primevue = this.$primevue) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.config) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.csp) === null || _this$$primevue === void 0 ? void 0 : _this$$primevue.nonce);
				(void 0).head.appendChild(this.styleElement);
				var innerHTML = "";
				for (var breakpoint in this.breakpoints) {
					var breakpointStyle = "";
					for (var styleProp in this.breakpoints[breakpoint]) breakpointStyle += styleProp + ":" + this.breakpoints[breakpoint][styleProp] + "!important;";
					innerHTML += "\n                        @media screen and (max-width: ".concat(breakpoint, ") {\n                            .p-toast[").concat(this.$attrSelector, "] {\n                                ").concat(breakpointStyle, "\n                            }\n                        }\n                    ");
				}
				this.styleElement.innerHTML = innerHTML;
			}
		},
		destroyStyle: function destroyStyle() {
			if (this.styleElement) {
				(void 0).head.removeChild(this.styleElement);
				this.styleElement = null;
			}
		}
	},
	computed: { dataP: function dataP() {
		return cn(_defineProperty$1({}, this.position, this.position));
	} },
	components: {
		ToastMessage: script$1,
		Portal: script$c
	}
};
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), true).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var _hoisted_1 = ["data-p"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
	var _component_ToastMessage = resolveComponent("ToastMessage");
	var _component_Portal = resolveComponent("Portal");
	return openBlock(), createBlock(_component_Portal, null, {
		"default": withCtx(function() {
			return [createElementVNode("div", mergeProps({
				ref: "container",
				"class": _ctx.cx("root"),
				style: _ctx.sx("root", true, { position: _ctx.position }),
				"data-p": $options.dataP
			}, _ctx.ptmi("root")), [createVNode(TransitionGroup, mergeProps({
				name: "p-toast-message",
				tag: "div",
				onEnter: $options.onEnter,
				onLeave: $options.onLeave
			}, _objectSpread({}, _ctx.ptm("transition"))), {
				"default": withCtx(function() {
					return [(openBlock(true), createElementBlock(Fragment, null, renderList($data.messages, function(msg) {
						return openBlock(), createBlock(_component_ToastMessage, {
							key: msg.id,
							message: msg,
							templates: _ctx.$slots,
							closeIcon: _ctx.closeIcon,
							infoIcon: _ctx.infoIcon,
							warnIcon: _ctx.warnIcon,
							errorIcon: _ctx.errorIcon,
							successIcon: _ctx.successIcon,
							closeButtonProps: _ctx.closeButtonProps,
							onMouseEnter: _ctx.onMouseEnter,
							onMouseLeave: _ctx.onMouseLeave,
							onClick: _ctx.onClick,
							unstyled: _ctx.unstyled,
							onClose: _cache[0] || (_cache[0] = function($event) {
								return $options.remove($event);
							}),
							pt: _ctx.pt
						}, null, 8, [
							"message",
							"templates",
							"closeIcon",
							"infoIcon",
							"warnIcon",
							"errorIcon",
							"successIcon",
							"closeButtonProps",
							"onMouseEnter",
							"onMouseLeave",
							"onClick",
							"unstyled",
							"pt"
						]);
					}), 128))];
				}),
				_: 1
			}, 16, ["onEnter", "onLeave"])], 16, _hoisted_1)];
		}),
		_: 1
	});
}
script.render = render;
//#endregion
//#region app/app.vue?vue&type=script&setup=true&lang.ts
var app_vue_vue_type_script_setup_true_lang_default = /*@__PURE__*/ defineComponent({
	__name: "app",
	__ssrInlineRender: true,
	setup(__props) {
		useHead$1({ meta: [
			{
				property: "og:title",
				content: "Fast Send"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:image",
				content: "https://fastsend.ing/ogImg.webp"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Fast Send"
			},
			{
				name: "twitter:description",
				content: "Fast peer-to-peer file and directory transfers"
			},
			{
				name: "twitter:image",
				content: "https://fastsend.ing/ogImg.webp"
			},
			{
				name: "twitter:site",
				content: "@ShouChen_"
			},
			{
				name: "twitter:creator",
				content: "@ShouChen_"
			}
		] });
		useAppStore();
		return (_ctx, _push, _parent, _attrs) => {
			const _component_NuxtPwaManifest = VitePwaManifest_default;
			const _component_NuxtRouteAnnouncer = ServerPlaceholder;
			const _component_FullScreenLoader = FullScreenLoader_default;
			const _component_Toast = script;
			const _component_NavBar = NavBar_default;
			const _component_NuxtPage = page_default;
			const _component_AppFooter = AppFooter_default;
			const _component_ScrollTop = script$7;
			const _component_InstallPWA = InstallPWA_default;
			const _component_DocPanel = DocPanel_default;
			_push(`<!--[-->`);
			_push(ssrRenderComponent(_component_NuxtPwaManifest, null, null, _parent));
			_push(ssrRenderComponent(_component_NuxtRouteAnnouncer, null, null, _parent));
			_push(ssrRenderComponent(_component_FullScreenLoader, null, null, _parent));
			_push(ssrRenderComponent(_component_Toast, { position: "top-right" }, null, _parent));
			_push(ssrRenderComponent(_component_NavBar, null, null, _parent));
			_push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
			_push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
			_push(ssrRenderComponent(_component_ScrollTop, null, null, _parent));
			_push(ssrRenderComponent(_component_InstallPWA, null, null, _parent));
			_push(ssrRenderComponent(_component_DocPanel, null, null, _parent));
			_push(`<!--]-->`);
		};
	}
});
//#endregion
//#region app/app.vue
var _sfc_setup$2 = app_vue_vue_type_script_setup_true_lang_default.setup;
app_vue_vue_type_script_setup_true_lang_default.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
	return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
var app_default = app_vue_vue_type_script_setup_true_lang_default;
//#endregion
//#region node_modules/nuxt/dist/app/components/nuxt-error-page.vue
var _sfc_main$1 = {
	__name: "nuxt-error-page",
	__ssrInlineRender: true,
	props: { error: Object },
	setup(__props) {
		const _error = __props.error;
		const status = Number(_error.statusCode || 500);
		const is404 = status === 404;
		const statusText = _error.statusMessage ?? (is404 ? "Page Not Found" : "Internal Server Error");
		const description = _error.message || _error.toString();
		const stack = void 0;
		const _Error404 = defineAsyncComponent(() => import('../build/error-404-5xfVzqfQ.mjs'));
		const _Error = defineAsyncComponent(() => import('../build/error-500-BCf8tQyW.mjs'));
		const ErrorTemplate = is404 ? _Error404 : _Error;
		return (_ctx, _push, _parent, _attrs) => {
			_push(ssrRenderComponent(unref(ErrorTemplate), mergeProps({
				status: unref(status),
				statusText: unref(statusText),
				statusCode: unref(status),
				statusMessage: unref(statusText),
				description: unref(description),
				stack: unref(stack)
			}, _attrs), null, _parent));
		};
	}
};
var _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../node_modules/nuxt/dist/app/components/nuxt-error-page.vue");
	return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
//#endregion
//#region virtual:nuxt:node_modules%2F.cache%2Fnuxt%2F.nuxt%2Fisland-renderer.mjs
var IslandRenderer = () => null;
//#endregion
//#region node_modules/nuxt/dist/app/components/nuxt-root.vue
var _sfc_main = {
	__name: "nuxt-root",
	__ssrInlineRender: true,
	setup(__props) {
		const nuxtApp = useNuxtApp();
		nuxtApp.deferHydration();
		nuxtApp.ssrContext.url;
		const SingleRenderer = false;
		provide(PageRouteSymbol, useRoute$1());
		nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup", []);
		const error = useError();
		const abortRender = error.value && !nuxtApp.ssrContext.error;
		function invokeAppErrorHandler(err, target, info) {
			const errorHandler = nuxtApp.vueApp.config.errorHandler;
			if (errorHandler && !errorHandler.__nuxt_default) try {
				errorHandler(err, target, info);
			} catch (handlerError) {
				console.error("[nuxt] Error in `app.config.errorHandler`", handlerError);
			}
		}
		onErrorCaptured((err, target, info) => {
			nuxtApp.hooks.callHook("vue:error", err, target, info)?.catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
			{
				const p = nuxtApp.runWithContext(() => showError(err));
				onServerPrefetch(() => p);
				invokeAppErrorHandler(err, target, info);
				return false;
			}
		});
		const islandContext = nuxtApp.ssrContext.islandContext;
		return (_ctx, _push, _parent, _attrs) => {
			ssrRenderSuspense(_push, {
				default: () => {
					if (unref(abortRender)) _push(`<div></div>`);
					else if (unref(error)) _push(ssrRenderComponent(unref(_sfc_main$1), { error: unref(error) }, null, _parent));
					else if (unref(islandContext)) _push(ssrRenderComponent(unref(IslandRenderer), { context: unref(islandContext) }, null, _parent));
					else if (unref(SingleRenderer)) ssrRenderVNode(_push, createVNode(resolveDynamicComponent(unref(SingleRenderer)), null, null), _parent);
					else _push(ssrRenderComponent(unref(app_default), null, null, _parent));
				},
				_: 1
			});
		};
	}
};
var _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
	const ssrContext = useSSRContext();
	(ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("../node_modules/nuxt/dist/app/components/nuxt-root.vue");
	return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
//#endregion
//#region node_modules/nuxt/dist/app/entry.js
var entry$1 = async function createNuxtAppServer(ssrContext) {
	const vueApp = createApp(_sfc_main);
	const nuxt = createNuxtApp({
		vueApp,
		ssrContext
	});
	try {
		await applyPlugins(nuxt, virtual_nuxt_node_modules_2F_cache_2Fnuxt_2F_nuxt_2Fplugins_server_default);
		await nuxt.hooks.callHook("app:created", vueApp);
	} catch (error) {
		await nuxt.hooks.callHook("app:error", error);
		nuxt.payload.error ||= createError$1(error);
	}
	if (ssrContext && (ssrContext["~renderResponse"] || ssrContext._renderResponse)) throw new Error("skipping render");
	return vueApp;
};
var entry_default = ((ssrContext) => entry$1(ssrContext));

const entry = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: entry_default
}, Symbol.toStringTag, { value: 'Module' }));

export { DynamicDialogEventBus as $, x as A, BaseStyle as B, ConnectedOverlayScrollHandler as C, script$j as D, script$i as E, script$a as F, script$g as G, script$6 as H, __exportAll as I, script$3 as J, FilterService as K, s as L, BaseDirective as M, NuxtLink as N, OverlayEventBus as O, FocusTrap as P, script$e as Q, Ripple as R, FilterMatchMode as S, FilterOperator as T, getVNodeProp as U, _default as V, script$8 as W, ConfirmationEventBus as X, unblockBodyScroll as Y, blockBodyScroll as Z, _plugin_vue_export_helper_default as _, useLocalePath as a, script$11 as a0, script$5 as a1, script$4 as a2, s$1 as a3, entry as a4, useRouter as b, composables_exports as c, useHead$1 as d, components_default$1 as e, script$12 as f, script$14 as g, humanFileSize as h, useToast as i, useAppStore as j, useUserStore as k, doDownloadFromBlob as l, calcMD5 as m, isModernFileAPIAvailable as n, formatTime as o, copyToClipboard as p, appDiagnostics as q, useFetch as r, script$d as s, supportsDirectorySelection as t, useI18n as u, script$b as v, script$f as w, script$c as x, script$15 as y, script$h as z };
//# sourceMappingURL=entry.mjs.map
