const sources = [
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/recipient",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/recipient"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/recipient"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/recipient"
                    }
                ]
            },
            {
                "loc": "/zh/recipient",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/recipient"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/recipient"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/recipient"
                    }
                ]
            },
            {
                "loc": "/room",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/room"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/room"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/room"
                    }
                ]
            },
            {
                "loc": "/zh/room",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/room"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/room"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/room"
                    }
                ]
            },
            {
                "loc": "/sender",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/sender"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/sender"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/sender"
                    }
                ]
            },
            {
                "loc": "/zh/sender",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/sender"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh/sender"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/sender"
                    }
                ]
            },
            {
                "loc": "/",
                "_sitemap": "en-US",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            },
            {
                "loc": "/zh",
                "_sitemap": "zh-CN",
                "alternatives": [
                    {
                        "hreflang": "en-US",
                        "href": "/"
                    },
                    {
                        "hreflang": "zh-CN",
                        "href": "/zh"
                    },
                    {
                        "hreflang": "x-default",
                        "href": "/"
                    }
                ]
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
